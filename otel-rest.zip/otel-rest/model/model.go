package model

type Users struct {
	Id    string `form:"id" json:"userid"`
	Name  string `form:"firstname" json:"username"`
	Email string `form:"lastname" json:"email"`
}

type Response struct {
	Status  int    `json:"status"`
	Message string `json:"message"`
	Data    []Users
}
