package main

import (
	"fmt"
	"log"
	"net/http"

	config "gojaegerrest/config"

	user "gojaegerrest/user"

	_ "github.com/go-sql-driver/mysql"
	"github.com/gorilla/mux"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

func main() {
	// for init service tracing when running service
	fn := config.InitTraceProvider("gojaegertrace")
	defer fn()

	router := mux.NewRouter()
	router.HandleFunc("/getuser", user.ReturnAllUsers).Methods("GET")
	router.Handle("/metrics", promhttp.Handler())
	// http.HandleFunc("/metrics", exporter.ServeHTTP)

	fmt.Println("Connected to port 2020")

	log.Fatal(http.ListenAndServe(":2020", router))

}
