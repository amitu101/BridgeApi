# Opentelemetry For Rest API

1. Import
"go.opentelemetry.io/otel/api/global"
"go.opentelemetry.io/otel/api/trace"
"go.opentelemetry.io/otel/label"
"go.opentelemetry.io/otel/exporters/trace/jaeger"
sdktrace "go.opentelemetry.io/otel/sdk/trace"

2. Replace gojaegerrest to git.capitalx.id/example/otel-rest

3. Import database jaegergrpc.sql 