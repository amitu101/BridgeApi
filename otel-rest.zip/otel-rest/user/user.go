package user

import (
	"encoding/json"
	config "gojaegerrest/config"
	model "gojaegerrest/model"
	"log"
	"net/http"
)

func ReturnAllUsers(w http.ResponseWriter, r *http.Request) {
	var users model.Users
	var response model.Response
	var arruser []model.Users

	db, err := config.Connect()
	if err != nil {
		log.Println(err.Error())
	}
	defer db.Close()

	rows, err := db.Query("Select user_id,name,email from user")
	if err != nil {
		log.Print(err)
	}

	for rows.Next() {
		if err := rows.Scan(&users.Id, &users.Name, &users.Email); err != nil {
			log.Print(err.Error())

		} else {
			arruser = append(arruser, users)
		}
	}

	response.Status = http.StatusOK
	response.Message = "Success"
	response.Data = arruser
	x := response.Status

	w.Header().Set("Content-Type", "application/json")
	// create span service with label http response code
	config.Conjaeger(w, r, x)
	json.NewEncoder(w).Encode(response)

}
