package config

import (
	"context"
	"database/sql"
	"log"
	"net/http"
	"time"

	"go.opentelemetry.io/otel/api/global"
	"go.opentelemetry.io/otel/api/trace"
	"go.opentelemetry.io/otel/label"

	"go.opentelemetry.io/otel/exporters/trace/jaeger"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
)

func Connect() (*sql.DB, error) {
	// for connection to db
	db, err := sql.Open("mysql", "root:@tcp(localhost:3306)/jaegergrpc")

	if err != nil {
		log.Println(err.Error())
	}

	return db, err
}

// for init service tracing
func InitTraceProvider(service string) func() {
	// create new service tracing
	flush, err := jaeger.InstallNewPipeline(
		// direct telemetry / tracing data to jaeger collector endpoint
		jaeger.WithCollectorEndpoint("http://localhost:14268/api/traces"),
		jaeger.WithProcess(jaeger.Process{
			// add service name
			ServiceName: service,
			// add label attribute for process part, below tags part
			Tags: []label.KeyValue{
				label.String("exporter", "jaeger"),
				label.Float64("float", 312.23),
			},
		}),

		jaeger.WithSDK(&sdktrace.Config{DefaultSampler: sdktrace.AlwaysSample()}),
	)
	if err != nil {
		log.Fatal(err)
	}

	return func() {
		flush()
	}
}
func Conjaeger(w http.ResponseWriter, r *http.Request, x int) {
	// add instrumentation name for span in tags part
	tr := global.Tracer("serviceuser")
	// add label attribute for tags part
	commonLabels := []label.KeyValue{
		label.String("http.method", r.Method),
		label.Int("http.status_code", x),
		label.String("http.url", r.RequestURI),
	}
	// create span parent
	_, span := tr.Start(
		context.Background(),
		r.RequestURI,
		trace.WithAttributes(commonLabels...))
	<-time.After(time.Second)
	// create span child if exist
	// for i := 0; i < 3; i++ {
	// 	_, iSpan := tr.Start(ctx, r.RequestURI)
	// 	log.Printf("Doing really hard work (%d / 10)\n", i+1)

	// 	<-time.After(time.Second)
	// 	iSpan.End()
	// }
	span.End()
}
