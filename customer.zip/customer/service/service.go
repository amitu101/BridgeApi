package service

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"reflect"
	"strconv"
	"time"

	"google.golang.org/grpc/codes"

	"git.capitalx.id/dimii/customer/repository"
	"git.capitalx.id/dimii/customer/utils"

	errHdlr "git.capitalx.id/core/common/error"
	userClient "git.capitalx.id/core/user/client"
	userModels "git.capitalx.id/core/user/model"
	accountClient "git.capitalx.id/dimii/account/client"
	"git.capitalx.id/dimii/customer/common"
	models "git.capitalx.id/dimii/customer/model"
)

// CustomerService represent the customer's services
type CustomerService interface {
	CheckRegistrationPhoneNumberAvailability(ctx context.Context, mobileNumber, username string) (*userModels.OTPResponse, error)
	StoreCustomer(ctx context.Context, userID, createdBy uint64, mobileNumber, name string) (uint64, error)
	RegisterCustomer(ctx context.Context, savingProductID uint32, passCode, mobileNumber, deviceID, username string) (string, error)
	GetCustomerData(ctx context.Context, customerDataReq models.GetCustomerReq) (models.Customer, error)
	DeleteCustomer(ctx context.Context, mobileNumber string) (string, error)
	GetCustomerDataByIdOrMobileNumber(ctx context.Context, request *models.GetCustomerDataRequest) (models.Customer, error)
	DeleteCustomerLinkage(ctx context.Context, mobileNumber string) (string, error)
	GetCustomerAccountLinkageStatus(ctx context.Context, customerID, limitCount uint64) (*[]models.CustomerAccountLinkageStatusResponse, error)
	StoreAccountLinkage(ctx context.Context, request models.CustomerAccountLinkage) (int64, error)
	GetCustomerDetails(ctx context.Context, req models.CustomerDetailRequest) (*common.DataResponse, error)
	ValidatePhoneNumberLinkage(ctx context.Context, deviceId, phoneNumber, clientId string) (*models.OTPResponse, error)
	RemoveLinkage(ctx context.Context, mobileNumber, clientId, partnerAccountId string) (*models.RemoveLinkageResponse, error)
}

// NewCustomerService will create new an customerService object representation of CustomerService interface
func NewCustomerService(c repository.CustomerRepository, u userClient.UserClient, a accountClient.AccountClient) CustomerService {
	return &customerService{c, u, a}
}

type customerService struct {
	customerRepos  repository.CustomerRepository
	userClients    userClient.UserClient
	accountClients accountClient.AccountClient
}


const (
	StatusCustomerActive   = 1
	StatusCustomerInactive = 2
	StatusCustomerBlocked  = 3
	StatusCustomerDeleted  = 4
	TypeEMoneyCustomer     = 1
	TypeMerchantOrPartner  = 2
	KycLevelUnverified     = 1
	KycLevelVerified       = 2
	RegistrationOTPID      = int32(1)
	LoginOTPID             = int32(2)
	AccountLinkageOTPID    = int32(3)
	countdownResendOTP     = 60 // countdown duration per resend otp in second
	StatusLinked           = 1
	StatusUnlinked         = 2
)

func (c *customerService) CheckRegistrationPhoneNumberAvailability(ctx context.Context, mobileNumber, username string) (*userModels.OTPResponse, error) {
	msg, err := c.customerRepos.GetCustomerStatusByMobileNumber(mobileNumber)
	if err != nil {
		return nil, err
	}

	if msg == "This mobile number already blocked" {
		errMsg := "This mobile number already blocked"
		newErrFormat := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Unavailable,
			Message: errMsg,
		}
		log.Println(errMsg)

		return nil, newErrFormat
	}

	if msg == "This mobile number already exist" {
		errMsg := "This mobile number is already exist"
		newErrFormat := errHdlr.ServiceError{
			Code:    "ALREADY_EXISTS",
			Status:  codes.AlreadyExists,
			Message: errMsg,
		}
		log.Println(errMsg)
		return nil, newErrFormat
	}

	remainingBlockedTime, err := c.userClients.GetUserResendOTPBlockedTime(ctx, mobileNumber)
	if err != nil {
		return nil, err
	}
	log.Println("remainingBlockedTime: ", remainingBlockedTime)

	if remainingBlockedTime > 0 {
		errMsg := "This mobile number already temporary blocked"
		newErrFormat := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Unavailable,
			Message: errMsg,
			Attributes: map[string]string{
				"blocked_duration":      strconv.Itoa((int)(remainingBlockedTime / 60)),
				"blocked_duration_unit": "minutes",
			},
		}
		log.Println(errMsg)

		return nil, newErrFormat
	}

	// call generate otp from user service, Here 1 means registration
	otpResp, err := c.userClients.GenerateOTP(ctx, mobileNumber, RegistrationOTPID)
	if err != nil {
		errMsg := "Failed to generate OTP, mobile number : " + mobileNumber
		newErrFormat := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(err)
		return nil, newErrFormat
	}

	otpRespJson, _ := json.Marshal(otpResp)

	log.Println("otpResp: ", string(otpRespJson))
	log.Println("otpResp.OtpDuration type: ", reflect.TypeOf(otpResp.OtpDuration))

	return &userModels.OTPResponse{
		CountdownResendOTP: int32(countdownResendOTP),
		OtpDuration:        otpResp.OtpDuration,
		Message:            "Kami mengirimkan kamu kode verifikasi ke nomor ponsel " + mobileNumber,
	}, nil
}

func (c *customerService) StoreCustomer(_ context.Context, userID, createdBy uint64, mobileNumber, name string) (uint64, error) {
	cif := utils.GenerateDigitRandomUnique()
	createdTime := time.Now()
	cus := &models.Customer{
		CustomerID: userID,
		Mobile:     mobileNumber,
		Cif:        strconv.Itoa(int(cif)),
		Name:       name,
		FullName:   name,
		Status:     StatusCustomerActive,
		Type:       TypeEMoneyCustomer,
		KycLevel:   KycLevelUnverified,
		CreatedBy:  createdBy,
		CreatedAt:  createdTime,
		UpdatedBy:  createdBy,
		UpdatedAt:  createdTime,
	}

	resp, err := c.customerRepos.StoreCustomer(cus)
	if err != nil {
		return 0, err
	}

	return resp, nil
}

func (c *customerService) RegisterCustomer(ctx context.Context, savingProductID uint32, passCode, mobileNumber, deviceID, fullName string) (string, error) {
	var createdBy uint64
	createdBy = 100 // created by system

	user := userClient.User{
		CreatedBy: createdBy,
		Passcode:  passCode,
		Mobile:    mobileNumber,
		DeviceID:  deviceID,
		Name:      fullName,
	}
	// register to user service
	respU, errU := c.userClients.StoreUser(ctx, user)
	if errU != nil {
		errMsg := "There is an error when storing user"
		err := errHdlr.ServiceError{
			Code:    "REGISTRATION_FAILED",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There was an error when storing User")
		log.Println(errU)
		return "failed", err
	}

	log.Println("[Register Customer]-User ID : ",respU)

	// register to customer service
	respC, errC := c.StoreCustomer(ctx, respU, createdBy, mobileNumber, fullName)
	if errC != nil {
		errMsg := "There is an error when storing user"
		err := errHdlr.ServiceError{
			Code:    "REGISTRATION_FAILED",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There is an error when storing Customer, customer name :", mobileNumber)
		log.Println(errC)
		return "failed", err
		//return "failed", err
	}

	// register to account service
	_, errA := c.accountClients.StoreSavingAccount(ctx, respC, createdBy, savingProductID, mobileNumber, fullName)
	if errA != nil {
		_, errDelUser := c.userClients.DeleteUser(ctx, mobileNumber)
		if errDelUser != nil {
			errMsg := "There is an error when deleting user, mobile number :" + mobileNumber
			err := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println("There was an error deleting user, mobile number : ", mobileNumber)
			return "failed", err
		}
		_, errDelCus := c.DeleteCustomer(ctx, mobileNumber)
		if errDelCus != nil {
			log.Println("There was an error deleting customer, mobile number : ", mobileNumber)
			errMsg := "There is an error when deleting customer, mobile number :" + mobileNumber
			err := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			return "failed", err
		}
		errMsg := "There is an error when storing account"
		err := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There was an error storing account, mobile number : ", mobileNumber)
		return "failed", err
	}

	return "Succeeded", nil
}

func (c *customerService) GetCustomerData(_ context.Context, customerDataReq models.GetCustomerReq) (models.Customer, error) {
	cus, err := c.customerRepos.GetCustomerDataByMobileNumber(customerDataReq)
	if err != nil {
		return models.Customer{}, err
	}

	return cus, nil
}

func (c *customerService) DeleteCustomer(_ context.Context, mobileNumber string) (string, error) {
	resp, err := c.customerRepos.DeleteCustomer(mobileNumber)
	if err != nil {
		return "", err
	}

	return resp, nil
}
func (c *customerService) GetCustomerDataByIdOrMobileNumber(_ context.Context, request *models.GetCustomerDataRequest) (models.Customer, error) {
	cus, err := c.customerRepos.GetCustomerDataByIdOrMobileNumber(request)
	if err != nil {
		return models.Customer{}, err
	}

	return cus, nil
}

func (c *customerService) DeleteCustomerLinkage(ctx context.Context, mobileNumber string) (string, error) {
	msg, err := c.customerRepos.DeleteCustomerLinkage(mobileNumber)
	if err != nil {
		return "", err
	}

	return msg, nil
}

func (c *customerService) GetCustomerAccountLinkageStatus(ctx context.Context, customerID, limitCount uint64) (*[]models.CustomerAccountLinkageStatusResponse, error) {
	return c.customerRepos.GetCustomerAccountLinkageStatus(customerID, limitCount)
}

func (c *customerService) StoreAccountLinkage(ctx context.Context, data models.CustomerAccountLinkage) (int64, error) {

	id := utils.GenerateDigitRandomUnique()
	createdTime := time.Now()
	data.ID = id
	data.Status = StatusLinked
	data.LastLinked = createdTime
	data.UpdateBy = data.CreatedBy
	data.UpdatedTime = data.CreatedTime

	ret, err := c.customerRepos.StoreAccountLinkage(data)

	if err != nil {
		log.Println(err)
		errMsg := "There is an error when store resend OTP... "
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errMsg)
		return 0, errHndlr
	}
	return ret, nil
}

func (c *customerService) GetCustomerDetails(_ context.Context, req models.CustomerDetailRequest) (*common.DataResponse, error) {
	var dataResp *common.DataResponse
	var err error

	// Get customerID from account service using saving account id
	if req.SavingAccountID != 0 {
		sv, err := c.accountClients.GetSavingAccount(context.Background(), &accountClient.GetSavingAccountRequest{Id: req.SavingAccountID})
		if err != nil {
			log.Printf("[service] GetCustomerDetails: Exception GetSavingAccount. Error: %s\n", err)
			return nil, common.AppErrorCode(common.CustomerDetailNotFound)
		}
		req.CustomerId = sv.CustomerId
	}

	dataResp, err = c.customerRepos.GetCustomerDetails(req)

	if err != nil {
		log.Printf("[service] GetCustomerDetails: Exception GetCustomerDetails. Error: %s\n", err)
		return nil, err
	}

	//Get saving account id from account service using customerID
	custResp := dataResp.Data.(*models.CustomerDetailResponse)
	custResp.SavingAccountID = []uint64{}
	if req.SavingAccountID == 0 {
		custID, err := strconv.ParseUint(custResp.CustomerID, 0, 64)
		sv, err := c.accountClients.GetCustomerSavingAccount(context.Background(), &accountClient.GetSavingAccountCustomerRequest{CardNo: custResp.MobileNumber, CustomerID: custID})
		if err != nil {
			log.Printf("[service] GetCustomerDetails: Exception GetSavingAccount. Error: %s\n", err)
		} else {
			for _, sAccount := range sv.List {
				custResp.SavingAccountID = append(custResp.SavingAccountID, sAccount.ID)
			}
		}

	} else {
		custResp.SavingAccountID = append(custResp.SavingAccountID, req.SavingAccountID)
	}

	return dataResp, nil
}

type Error struct {
	Errors map[string]interface{} `json:"errors"`
}

func (c *customerService) ValidatePhoneNumberLinkage(ctx context.Context, deviceId, phoneNumber, clientId string) (*models.OTPResponse, error) {
	log.Println(fmt.Sprintf("[service-ValidatePhoneNumberLinkage-] device_id : %v, mobile_number : %v, client_id : %v  ", deviceId, phoneNumber, clientId))
	linked, id, err := c.customerRepos.CheckPhoneNumberLinkage(phoneNumber)
	if err != nil {
		return nil, err
	}
	if linked {
		errMsg := fmt.Sprintf("This Phone Number %v Already Linked with Other Account,Linked ID : %d  ", phoneNumber, id)
		err := errHdlr.ServiceError{
			Code:    "ALREADY_LINKED",
			Status:  codes.AlreadyExists,
			Message: errMsg + phoneNumber,
		}
		log.Println(errMsg)
		return nil, err
	}

	otp, err := c.userClients.CheckMobileNumberLinkage(ctx, deviceId, phoneNumber, clientId)

	e := Error{}
	e.Errors = make(map[string]interface{})

	if err != nil {
		log.Println("error apa :", err)
		switch v := err.(type) {
		case errHdlr.ServiceError:
			errHndlr := errHdlr.ServiceError{
				Code:       v.Code,
				Status:     codes.Aborted,
				Attributes: v.Attributes,
				Message:    v.Message,
			}
			log.Println(v.Message)
			return nil, errHndlr
		default:
			log.Println("other errorrr.....")

		}
		return nil, err
	}

	return &models.OTPResponse{
		OtpDuration:        otp.OtpDuration,
		CountdownResendOTP: otp.CountDownResendOtp,
		Message:            otp.Message,
	}, nil
}
func (c *customerService) RemoveLinkage(ctx context.Context, mobileNumber, clientId, partnerAccountId string) (*models.RemoveLinkageResponse, error) {
	_, err := c.customerRepos.RemoveLinkage(mobileNumber, clientId, partnerAccountId)
	if err != nil{
			return nil,err
	}
	msg := fmt.Sprintf("The linkage for Mobile Number %s, Client Id : %s , Partner Account Id : %s has been unlinked",mobileNumber,clientId,partnerAccountId)
	return &models.RemoveLinkageResponse{
		Message: msg,
	},nil
}
