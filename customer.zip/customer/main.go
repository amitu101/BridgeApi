package main

import (
	"context"
	"encoding/json"
	"git.capitalx.id/dimii/customer/gcs"
	"log"

	"net/http"
	"os"
	"os/signal"
	"syscall"

	"git.capitalx.id/dimii/customer/proto"

	_ "git.capitalx.id/dimii/customer/client"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"google.golang.org/grpc"

	cfg "git.capitalx.id/core/config/vault"
	restHandler "git.capitalx.id/dimii/customer/common"
	deliveryGrpc "git.capitalx.id/dimii/customer/delivery"
	customerRepo "git.capitalx.id/dimii/customer/repository"
	customerSrv "git.capitalx.id/dimii/customer/service"

	userClient "git.capitalx.id/core/user/client"
	accountClient "git.capitalx.id/dimii/account/client"

	commonHttp "git.capitalx.id/core/common/http"
	HandlerHTTP "git.capitalx.id/dimii/customer/delivery/http"

	"git.capitalx.id/core/common/mysql"

	common "git.capitalx.id/core/common/grpc"
)

func serveHTTP(addr string, cu customerSrv.CustomerService) error {
	//mux := http.DefaultServeMux
	HandlerHTTP.NewCustomerHandler(cu)
	log.Println("http server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(http.HandlerFunc(restHandler.Serve))); err != nil {
		return err
	}
	return nil
}

func serveHTTPGRPC(addr, addrGrpc string) error {
	log.Println("ini addrGrpc: ", addrGrpc)
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// Set runtime.GlobalHTTPErrorHandler = CustomHTTPError
	runtime.GlobalHTTPErrorHandler = CustomHTTPError

	mux := runtime.NewServeMux()
	opts := []grpc.DialOption{grpc.WithInsecure()}
	err := proto.RegisterCustomerHandlerHandlerFromEndpoint(ctx, mux, addrGrpc, opts)
	if err != nil {
		log.Println("err in serveHTTPGrpc: ", err)
	}

	log.Println("gw server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(mux)); err != nil {
		return err
	}
	return nil
}

func main() {
	config, err := cfg.GetConfig("customer")
	if err != nil {
		log.Println(err)
		return
	}

	gcsHost := config.GetString(`gcs.host`)
	gcsServiceAcct  := config.GetString(`gcs.service.account`)
	gcsBucket       := config.GetString(`gcs.bucket`)

	gcsConfig := gcs.Config{
		Host: gcsHost,
		ServiceAccount: gcsServiceAcct,
		Bucket: gcsBucket,
	}

	gcsUtil := gcs.NewGCSUtility(gcsConfig)


	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dbConn, err := mysql.DB(dbConfig)
	if err != nil {
		log.Println(err)
		return
	}
	defer func() {
		if err := dbConn.Close(); err != nil {
			log.Print(err)
		}
	}()

	cr := customerRepo.NewMariaCustomerRepository(dbConn)

	// connect to user service
	userClientAddr := config.GetString(`server.user_address`)
	uclient, errU := userClient.NewUserClient(userClientAddr)
	if errU != nil {
		log.Println("err connect to User Service: ", errU)
	}

	// connect to account service
	accountClientAddr := config.GetString(`server.account_address`)
	aclient, errA := accountClient.NewAccountClient(accountClientAddr)
	if errU != nil {
		log.Println("err connect to Account Service: ", errA)
	}

	cu := customerSrv.NewCustomerService(cr, uclient, aclient)

	// get all required addr
	addrGrpc := config.GetString("server.address")
	addrGw := config.GetString("server.address.gw")
	addrHttp := config.GetString("server.address.http")

	// grpc
	errHdlr := common.WithDefault()
	server := grpc.NewServer(errHdlr...)
	deliveryGrpc.NewCustomerServerGrpc(server, cu,gcsUtil)

	go func() {
		common.Serve(addrGrpc, server)
	}()

	go serveHTTP(addrHttp, cu)
	go serveHTTPGRPC(addrGw, addrGrpc)
	log.Println("grpc server started. Listening on port: ", addrGrpc)
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGINT, syscall.SIGTERM)

	<-done
	//l.Close()
	log.Println("All server stopped!")
	//}()
}

type Error struct {
	Errors map[string]interface{} `json:"errors"`
}

func CustomHTTPError(ctx context.Context, _ *runtime.ServeMux, marshaler runtime.Marshaler, w http.ResponseWriter, _ *http.Request, err error) {
	const fallback = `{"error": "failed to marshal error message"}`

	sm, _ := runtime.ServerMetadataFromContext(ctx)
	e := Error{}
	attr := make(map[string]interface{})
	e.Errors = make(map[string]interface{})

	// extract trailer metadata
	for k, vs := range sm.TrailerMD {
		for _, v := range vs {
			switch k {
			case "error_code":
				e.Errors["error_code"] = v
			case "error_message":
				e.Errors["error_message"] = v
			case "content-type":

			default:
				attr[k] = v
			}
		}
	}

	if len(attr) != 0 {
		e.Errors["attributes"] = attr
	}

	w.Header().Set("Content-type", marshaler.ContentType())
	w.WriteHeader(runtime.HTTPStatusFromCode(grpc.Code(err)))

	jErr := json.NewEncoder(w).Encode(e.Errors)

	if jErr != nil {
		w.Write([]byte(fallback))
	}
}
