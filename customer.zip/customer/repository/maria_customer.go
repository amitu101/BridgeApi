package repository

import (
	"database/sql"
	"log"
	"time"

	"git.capitalx.id/dimii/customer/common"
	models "git.capitalx.id/dimii/customer/model"
)

type mariaCustomerRepository struct {
	Conn *sql.DB
}

// NewMariaCustomerRepository will create an object that represent the customer.Repository interface
func NewMariaCustomerRepository(Conn *sql.DB) CustomerRepository {

	return &mariaCustomerRepository{Conn}
}

const (
	dobtimeFormat = "02 January 2006"
	dateFormat    = "2006-01-02T15:04:05-07:00"
)

const (
	insertCustomer = "INSERT INTO customer(id, mobile, cif, name, full_name, status, type, kyc_level, created_by, created_time, " +
		"updated_by, updated_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
	selectStatus             = "SELECT status FROM customer WHERE mobile = ?"
	selectUserByMobileNumber = "SELECT id, full_name, mobile, email, type, kyc_level, status, photo_url,verification_status FROM customer " +
		"WHERE mobile = ?"
	selectUserByCustomerId = "SELECT id, full_name, mobile, email, type, kyc_level, status, photo_url,verification_status FROM customer " +
		"WHERE id = ?"
	deleteCustomer                         = "DELETE FROM customer WHERE mobile = ?"
	updateCustomerMerchantLinkage          = "UPDATE customer_merchant SET status = ? WHERE mobile = ?"
	customerLinkageDisableStatus           = -1
	selectAllCustomerAccountLinkageStatus  = "SELECT merchant_id,merchant_name,merchant_account_id,status,last_linked,last_blocked from customer_merchant where customer_id = ? limit = ?;"
	selectCustomerAccountLinkageStatusByID = "SELECT merchant_id,merchant_name,status,last_linked,last_blocked from customer_merchant where customer_id = ?"
	insertAccountLinkage                   = "INSERT INTO customer_merchant(id, customer_id," +
		"mobile, merchant_id, merchant_name, status, last_linked, last_unlinked, " +
		"created_by,created_time, " +
		"updated_by, updated_time,partner_account_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"
	selectCustomerDetail     = "select id, full_name, mobile, email, type, kyc_level, status, cif, id_no, dob, address from customer "
	customerMobile           = " where mobile = ? "
	customercif              = " where cif = ? "
	customerId               = " where id = ? "
	checkLinkedByPhoneNumber = "SELECT id FROM customer_merchant WHERE mobile = ? AND status = 1"
	removeLinkage = "UPDATE customer_merchant SET status = ? WHERE mobile = ? and merchant_id = ? and partner_account_id = ? "
)

func (m *mariaCustomerRepository) GetCustomerStatusByMobileNumber(mobileNumber string) (string, error) {
	var status int
	err := m.Conn.QueryRow(selectStatus, mobileNumber).Scan(&status)
	if err != nil {
		if err == sql.ErrNoRows {
			// there were no rows, but otherwise no error occurred
		} else {
			return "", err
		}
	}

	if status == 1 {
		return "This mobile number already exist", nil
	}

	if status == 3 {
		return "This mobile number already blocked", nil
	}

	return "This mobile number not already exist", nil
}

func (m *mariaCustomerRepository) StoreCustomer(cus *models.Customer) (uint64, error) {
	_, err := m.Conn.Exec(insertCustomer, cus.CustomerID, cus.Mobile, cus.Cif, cus.Name, cus.FullName,
		cus.Status, cus.Type, cus.KycLevel, cus.CreatedBy, cus.CreatedAt, cus.UpdatedBy, cus.UpdatedAt)
	if err != nil {
		return 0, err
	}

	return cus.CustomerID, nil
}

func (m *mariaCustomerRepository) GetCustomerDataByMobileNumber(req models.GetCustomerReq) (models.Customer, error) {
	cus := models.Customer{}

	var (
		query = selectUserByMobileNumber
		param interface{}
	)

	param = req.MobileNumber
	if req.CustomerID > 0 {
		query = selectUserByCustomerId
		param = req.CustomerID
	}

	err := m.Conn.QueryRow(query, param).Scan(&cus.CustomerID, &cus.FullName, &cus.Mobile,
		&cus.Email, &cus.Type, &cus.KycLevel, &cus.Status, &cus.PhotoURL,&cus.VerificationStatus)
	if err != nil {
		return models.Customer{}, err
	}

	return cus, nil
}

func (m *mariaCustomerRepository) DeleteCustomer(mobileNumber string) (string, error) {
	_, err := m.Conn.Exec(deleteCustomer, mobileNumber)
	if err != nil {
		return "", err
	}

	return "deleted", nil

}

func (m *mariaCustomerRepository) GetCustomerDataByIdOrMobileNumber(request *models.GetCustomerDataRequest) (models.Customer, error) {
	cus := models.Customer{}

	if request.CustomerId != 0 {

		err := m.Conn.QueryRow(selectUserByCustomerId, request.CustomerId).Scan(&cus.CustomerID, &cus.FullName, &cus.Mobile,
			&cus.Email, &cus.Type, &cus.KycLevel, &cus.Status, &cus.PhotoURL,&cus.VerificationStatus)
		if err != nil {
			return models.Customer{}, err
		}

		return cus, nil
	} else {
		err := m.Conn.QueryRow(selectUserByMobileNumber, request.Mobile).Scan(&cus.CustomerID, &cus.FullName, &cus.Mobile,
			&cus.Email, &cus.Type, &cus.KycLevel, &cus.Status, &cus.PhotoURL,&cus.VerificationStatus)
		if err != nil {
			return models.Customer{}, err
		}

		return cus, nil
	}
}

func (m *mariaCustomerRepository) DeleteCustomerLinkage(mobileNumber string) (string, error) {
	_, err := m.Conn.Exec(updateCustomerMerchantLinkage, customerLinkageDisableStatus, mobileNumber)
	if err != nil {
		return "", err
	}

	return "deleted", nil

}

func (m *mariaCustomerRepository) GetCustomerAccountLinkageStatus(customerID, limitCount uint64) (*[]models.CustomerAccountLinkageStatusResponse, error) {
	cuss := []models.CustomerAccountLinkageStatusResponse{}

	if customerID == 0 {
		rows, err := m.Conn.Query(selectAllCustomerAccountLinkageStatus, customerID, limitCount)
		if err != nil {
			return &cuss, err
		}
		for rows.Next() {
			cus := models.CustomerAccountLinkageStatusResponse{}
			err := rows.Scan(&cus.MerchantID, &cus.MerchantName, &cus.MerchantAccountID, &cus.Status, &cus.LastLinked, &cus.LastBlocked)
			if err != nil {
				return &cuss, err
			}
			cuss = append(cuss, cus)
		}
		return &cuss, nil
	}

	rows, err := m.Conn.Query(selectCustomerAccountLinkageStatusByID)
	if err != nil {
		return &cuss, err
	}
	for rows.Next() {
		cus := models.CustomerAccountLinkageStatusResponse{}
		err := rows.Scan(&cus.MerchantID, &cus.MerchantName, &cus.MerchantAccountID, &cus.Status, &cus.LastLinked, &cus.LastBlocked)
		if err != nil {
			return &cuss, err
		}
		cuss = append(cuss, cus)
	}
	return &cuss, nil
}

func (m *mariaCustomerRepository) StoreAccountLinkage(data models.CustomerAccountLinkage) (int64, error) {
	_, err := m.Conn.Exec(insertAccountLinkage, data.ID, data.CustomerId, data.MobileNumber, data.MerchantId,
		data.MerchantName, data.Status, data.LastLinked, data.LastUnlinked, data.CreatedBy, data.CreatedTime,
		data.UpdateBy, data.UpdatedTime, data.PartnerAccountId)
	if err != nil {
		log.Println(err)
		return 0, err
	}

	return data.ID, nil
}

func (m *mariaCustomerRepository) GetCustomerDetails(request models.CustomerDetailRequest) (*common.DataResponse, error) {
	cus := new(models.CustomerDetailResponse)
	var rw *sql.Row

	if request.CustomerId != 0 {
		rw = m.Conn.QueryRow(selectCustomerDetail+customerId, request.CustomerId)
	} else if request.MobileNumber != "" {
		rw = m.Conn.QueryRow(selectCustomerDetail+customerMobile, request.MobileNumber)
	} else if request.Cif != "" {
		rw = m.Conn.QueryRow(selectCustomerDetail+customercif, request.Cif)
	} else {
		log.Printf("[repository:maria_customer] mobile_number or cif or customer_id is required \n")
		return nil, common.AppErrorCode(common.SearchCustomerNoParam)
	}
	err := rw.Scan(&cus.CustomerID, &cus.FullName, &cus.MobileNumber,
		&cus.Email, &cus.Type, &cus.KycLevel, &cus.Status, &cus.Cif, &cus.IDNo, &cus.DOB, &cus.Address)

	if err != nil {
		if err == sql.ErrNoRows {
			log.Printf("[repository:maria_customer] GetCustomerDetails. Customer not available %s \n", err)
			return nil, common.AppErrorCode(common.CustomerDetailNotFound)
		} else {
			log.Printf("[repository:maria_customer] GetCustomerDetails. Error while getting customer details Error: %s \n", err)
			return nil, models.ErrInternalServerError
		}
	}

	t, err := time.Parse(dateFormat, cus.DOB)
	if err != nil {
		log.Printf("[repository:maria_customer] GetCustomerDetails. Error while parsing time. Error: %s \n", err)
	}
	cus.DOB = t.Format(dobtimeFormat)
	return &common.DataResponse{Data: cus, Message: common.GetMessage(common.CustomerDetailSuccess)}, nil
}
func (m *mariaCustomerRepository) CheckPhoneNumberLinkage(mobileNumber string) (bool, uint64, error) {
	var id uint64

	err := m.Conn.QueryRow(checkLinkedByPhoneNumber, mobileNumber).Scan(&id)

	if err != nil {
		log.Println(err)
		return false, 0, nil
	}

	return true, id, nil
}
func (m *mariaCustomerRepository) RemoveLinkage(mobileNumber,clientId,partnerAccountId string)(bool,error){
	_, err := m.Conn.Exec(removeLinkage, mobileNumber,clientId,partnerAccountId)
	if err != nil {
		return false, err
	}

	return true, nil
}
