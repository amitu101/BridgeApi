package repository

import (
	"git.capitalx.id/dimii/customer/common"
	models "git.capitalx.id/dimii/customer/model"
)

// CustomerRepository represent the customer's repository contract
type CustomerRepository interface {
	GetCustomerStatusByMobileNumber(mobileNumber string) (string, error)
	StoreCustomer(cus *models.Customer) (uint64, error)
	GetCustomerDataByMobileNumber(req models.GetCustomerReq) (models.Customer, error)
	DeleteCustomer(mobileNumber string) (string, error)
	GetCustomerDataByIdOrMobileNumber(*models.GetCustomerDataRequest) (models.Customer, error)
	DeleteCustomerLinkage(mobileNumber string) (string, error)
	GetCustomerAccountLinkageStatus(customerID, limitCount uint64) (*[]models.CustomerAccountLinkageStatusResponse, error)
	StoreAccountLinkage(data models.CustomerAccountLinkage) (int64, error)
	GetCustomerDetails(req models.CustomerDetailRequest) (*common.DataResponse, error)
	CheckPhoneNumberLinkage(mobileNumber string) (bool, uint64, error)
	RemoveLinkage(mobileNumber,clientId,partnerAccountId string)(bool,error)
}
