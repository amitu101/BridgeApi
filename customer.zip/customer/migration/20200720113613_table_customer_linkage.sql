-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE IF NOT EXISTS `customer_merchant` (
  `id` BIGINT UNSIGNED NOT NULL,
  `customer_id` BIGINT UNSIGNED NOT NULL,
  `mobile` VARCHAR(15) NOT NULL,
  `merchant_id` BIGINT UNSIGNED NOT NULL,
  `merchant_name` VARCHAR(255) NOT NULL DEFAULT '',
  `partner_account_id` varchar(255),
  `status` INT NOT NULL,
  `last_linked` DATETIME NOT NULL,
  `last_unlinked` DATETIME NULL DEFAULT '0000-00-00',
  `created_by` BIGINT UNSIGNED NOT NULL,
  `created_time` DATETIME NOT NULL,
  `updated_by` BIGINT UNSIGNED NOT NULL,
  `updated_time` TIMESTAMP NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;
-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP TABLE IF EXISTS `customer_merchant`;
