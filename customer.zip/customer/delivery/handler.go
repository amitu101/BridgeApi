package delivery

import (
	"bytes"
	"context"
	"fmt"
	"git.capitalx.id/dimii/customer/gcs"
	"git.capitalx.id/dimii/customer/proto"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"io"
	"log"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	models "git.capitalx.id/dimii/customer/model"
	_srv "git.capitalx.id/dimii/customer/service"
)

func NewCustomerServerGrpc(gserver *grpc.Server, customerSrv _srv.CustomerService,gcsUtil gcs.CloudStorage) {
	customerServer := &server{
		service: customerSrv,
		gcs : gcsUtil,
	}

	proto.RegisterCustomerHandlerServer(gserver, customerServer)
	reflection.Register(gserver)

}

const (
	maxImageSize = 1 << 21
	EKTP_FOLDER   = "e-ktp/"
	SELFIE_FOLDER = "selfie/"
)

type server struct {
	service _srv.CustomerService
	gcs  gcs.CloudStorage
}

func (s *server) CheckRegistrationPhoneNumberAvailability(ctx context.Context, request *proto.CheckRegisPhoneNumberReq) (*proto.CheckMobileNumberAvailabilityResponse, error) {
	otpResp, err := s.service.CheckRegistrationPhoneNumberAvailability(ctx, request.Mobilenumber, request.Username)
	if err != nil {
		return nil, err
	}

	return &proto.CheckMobileNumberAvailabilityResponse{
		Countdownresendotp: otpResp.CountdownResendOTP,
		Otpduration:        otpResp.OtpDuration,
		Message:            otpResp.Message,
	}, nil
}

func (s *server) StoreCustomer(ctx context.Context, request *proto.StoreCustomerData) (*proto.StoreCustomerDataResponse, error) {
	cus := &models.Customer{
		CustomerID: request.Id,
		Mobile:     request.Mobile,
		CreatedBy:  request.Createdby,
	}

	resp, err := s.service.StoreCustomer(ctx, cus.CustomerID, cus.CreatedBy, cus.Mobile, "")
	if err != nil {
		return nil, err
	}

	return &proto.StoreCustomerDataResponse{
		Id: resp,
	}, nil
}

func (s *server) RegisterCustomer(ctx context.Context, request *proto.RegisterCustomerRequest) (*proto.RegisterCustomerResponse, error) {
	_, err := s.service.RegisterCustomer(ctx, request.Savingproductid, request.Passcode, request.Mobilenumber, request.Deviceid, request.Fullname)
	if err != nil {
		return nil, err
	}

	return &proto.RegisterCustomerResponse{
		Message: "Succeeded",
	}, nil
}

func (s *server) GetCustomerData(ctx context.Context, request *proto.CustomerMobileNumberRequest) (*proto.CustomerDataResponse, error) {

	reqIns := models.GetCustomerReq{
		CustomerID:   request.CustomerID,
		MobileNumber: request.Mobilenumber,
	}

	resp, err := s.service.GetCustomerData(ctx, reqIns)
	if err != nil {
		return nil, err
	}
	var status proto.VerificationStatus

	switch resp.VerificationStatus {
	case 0 :
		status = proto.VerificationStatus_UNVERIFIED
	case 1 :
		status = proto.VerificationStatus_IN_PROCESS
	case 2 :
		status = proto.VerificationStatus_VERIFIED
	case 3 :
		status = proto.VerificationStatus_REJECTED
	default:
		status = proto.VerificationStatus_UNVERIFIED
	}

	return &proto.CustomerDataResponse{
		Customerid:   resp.CustomerID,
		Fullname:     resp.FullName,
		Mobilenumber: resp.Mobile,
		Email:        resp.Email,
		Type:         resp.Type,
		Kyclevel:     resp.KycLevel,
		Status:       resp.Status,
		Photourl:     resp.PhotoURL,
		VerificationStatus: status ,
	}, nil
}

func (s *server) GetCustomerDataByIdOrMobileNumber(ctx context.Context, request *proto.GetCustomerRequest) (*proto.CustomerDataResponse, error) {
	resp, err := s.service.GetCustomerDataByIdOrMobileNumber(ctx, &models.GetCustomerDataRequest{
		CustomerId: request.CustomerId,
		Mobile:     request.MobileNumber,
	})

	if err != nil {
		return nil, err
	}

	var status proto.VerificationStatus
	switch resp.VerificationStatus {
	case 0 :
		status = proto.VerificationStatus_UNVERIFIED
	case 1 :
		status = proto.VerificationStatus_IN_PROCESS
	case 2 :
		status = proto.VerificationStatus_VERIFIED
	case 3 :
		status = proto.VerificationStatus_REJECTED
	default:
		status = proto.VerificationStatus_UNVERIFIED
	}
	return &proto.CustomerDataResponse{
		Customerid:   resp.CustomerID,
		Fullname:     resp.FullName,
		Mobilenumber: resp.Mobile,
		Email:        resp.Email,
		Type:         resp.Type,
		Kyclevel:     resp.KycLevel,
		Status:       resp.Status,
		Photourl:     resp.PhotoURL,
		VerificationStatus: status,
	}, nil
}

func (s *server) DeleteCustomer(ctx context.Context, request *proto.MobileNumberRequest) (*proto.DeleteCustomerResponse, error) {
	resp, err := s.service.DeleteCustomer(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &proto.DeleteCustomerResponse{
		Message: resp,
	}, nil
}

func (s *server) DeleteCustomerLinkage(ctx context.Context, request *proto.MobileNumberRequest) (*proto.DeleteCustomerResponse, error) {
	resp, err := s.service.DeleteCustomerLinkage(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &proto.DeleteCustomerResponse{
		Message: resp,
	}, nil
}

func (s *server) StoreAccountLinkage(ctx context.Context, request *proto.AccountLinkageReq) (*proto.AccountLinkageResp, error) {
	log.Println("partner account id : ", request.PartnerAccountId)
	data := models.CustomerAccountLinkage{
		CustomerId:       request.CustomerId,
		MerchantId:       request.MerchantId,
		MerchantName:     request.MerchantName,
		PartnerAccountId: request.PartnerAccountId,
		//MobileNumber: request.MobileNumber,
	}
	//log.Println("[handler-StoreAccountLinkage], mobile number : ",request.MobileNumber)
	log.Println("[handler-StoreAccountLinkage], CustomerId : ",request.CustomerId)
	log.Println("[handler-StoreAccountLinkage], MerchantName : ",request.MerchantName)
	log.Println("[handler-StoreAccountLinkage], MerchantId : ",request.MerchantId)

	id, err := s.service.StoreAccountLinkage(ctx, data)
	if err != nil {
		log.Println(err)
		return nil, err
	}
	log.Println("The linkage successfully stored with linkage id :", id)
	return &proto.AccountLinkageResp{
		LinkageId: id,
	}, nil

}
func (s *server) ValidatePhoneNumberLinkage(ctx context.Context, request *proto.ValidatePhoneNumberReq) (*proto.ValidatePhoneNumberResp, error) {

	log.Println(fmt.Sprintf("[handler-ValidatePhoneNumberLinkage-] device_id : %v, mobile_number : %v, client_id : %v  ",request.DeviceId,request.MobileNumber,request.ClientId))
	otp, err := s.service.ValidatePhoneNumberLinkage(ctx, request.DeviceId, request.MobileNumber,request.ClientId)

	if err != nil {
		log.Println(err)
		return nil, err
	}

	return &proto.ValidatePhoneNumberResp{
		OtpDuration:        otp.OtpDuration,
		CountDownResendOtp: otp.CountdownResendOTP,
		Message:            otp.Message,
	}, nil
}
func(s *server)RemoveLinkage(ctx context.Context,request *proto.RemoveLinkageReq)(*proto.RemoveLinkageResp,error){
	_, _ = s.service.RemoveLinkage(ctx, request.MobileNumber, request.ClientId, request.PartnerAccountId)
	return nil, nil
}

func(s *server)UploadImage(stream proto.CustomerHandler_UploadImageServer) error{
	req, err := stream.Recv()

	if err != nil {
		return logError(status.Errorf(codes.Unknown, "cannot receive image info"))
	}
	fileName := req.GetInfo().GetFileName()
	fileExt  := req.GetInfo().GetFileExtension()
	fileType := req.GetInfo().GetFileType() //e-ktp, selfie

	log.Printf("receive an upload-image request for fileName %s with ext %s and type %s", fileName, fileExt, fileType)

	_, err = fileFilter(fileExt)
	if err != nil{
		return logError(status.Errorf(codes.Unknown, "file format not supported: %v", err))
	}

	imageData := bytes.Buffer{}
	imageSize := 0
	i := 0
	for {
		i++
		req, err := stream.Recv()
		if err == io.EOF {
			log.Print("no more data")
			break
		}
		if err != nil {
			return logError(status.Errorf(codes.Unknown, "cannot receive chunk data: %v", err))
		}

		chunk := req.GetChunkData()
		size := len(chunk)

		//log.Printf("%d - received a chunk with size: %d",i, size)

		imageSize += size
		if imageSize >= maxImageSize {
			return logError(status.Errorf(codes.InvalidArgument, "image is too large: %d > %d", imageSize, maxImageSize))
		}
		_, err = imageData.Write(chunk)
		if err != nil {
			return logError(status.Errorf(codes.Internal, "cannot write chunk data: %v", err))
		}
	}

	var folder string
	switch fileType {
		case proto.FileType_E_KTP:
			folder = EKTP_FOLDER
		case proto.FileType_Selfie:
			folder = SELFIE_FOLDER
		default:
			folder = "temp/"
	}

	context := context.Background()
	err = s.gcs.PutFile(context,folder,fileName,imageData.Bytes())
	if err != nil {
		log.Println(err)
		msg := &proto.UploadImageResponse{
			Message: "Upload Failed",
			Code: proto.UploadStatusCode_Failed,
		}
		stream.SendAndClose(msg)
	}

	msg := &proto.UploadImageResponse{
		Message: "Successfully Uploaded",
		Code: proto.UploadStatusCode_Ok,
	}

	stream.SendAndClose(msg)

	return nil
}

func fileFilter(fileExt string) (string, error) {

	log.Printf("FILE EXTENSION: %s\n", fileExt)

	switch fileExt {
	case "jpg", "jpeg", "png":
		return fileExt, nil
	}
	return fileExt, fmt.Errorf("We do not allow files of type %s. We only allow jpg, jpeg, txt, md extensions.", fileExt)
}
func logError(err error) error {
	if err != nil {
		log.Print(err)
	}
	return err
}
