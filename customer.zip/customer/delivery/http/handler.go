package http

import (
	"encoding/json"
	"sort"
	"strconv"
	"strings"

	"log"
	"net/http"
	nethttp "net/http"

	rh "git.capitalx.id/dimii/customer/common"
	cModel "git.capitalx.id/dimii/customer/model"
	srv "git.capitalx.id/dimii/customer/service"
)

func httpResponseWrite(rw nethttp.ResponseWriter, response interface{}, statusCode int) {
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	json.NewEncoder(rw).Encode(response)
}

// CustomerHandler  represent the http handler for Customer
type CustomerHandler struct {
	CUsecase srv.CustomerService
}

type httpResponse struct {
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

// NewCustomerHandler will initialize the users/ resources endpoint
func NewCustomerHandler(customerSrv srv.CustomerService) {
	handler := &CustomerHandler{
		CUsecase: customerSrv}

	// ENDPOINT | /customer/:customer_id/linkage?count=5  --  handler.GetAccountLinkageStatus
	rh.Route(http.MethodGet, "/r/customer", handler.GetCustomerSearch)
	rh.Route(http.MethodGet, "/r/customer/([0-9]+)", handler.GetCustomerDetails)
	rh.Route(http.MethodGet, "/r/customer/([0-9]+)/linkage", handler.GetAccountLinkageStatus)
	//rh.Route(http.MethodGet, "/account-linkage", handler.StoreAccountLinkage)

}

//GetCustomerSearch search customer details
func (handler *CustomerHandler) GetCustomerSearch(rw nethttp.ResponseWriter, req *nethttp.Request) {

	mobileNumber := strings.TrimSpace(req.URL.Query().Get("mobile_number"))
	cif := strings.TrimSpace(req.URL.Query().Get("cif"))
	var savingAccountID uint64
	var err error

	if savingAccountIDstr := strings.TrimSpace(req.URL.Query().Get("saving_account_id")); savingAccountIDstr != "" {
		savingAccountID, err = strconv.ParseUint(savingAccountIDstr, 0, 64)
		if err != nil {
			log.Printf("[delivery:http:handler] GetCustomerSearch Error in converting savingAccountID string to integer. Error: %s \n", err)
		}
	}

	if mobileNumber == "" && cif == "" && savingAccountID == 0 {
		response := &rh.DataResponse{Message: rh.GetMessage(rh.SearchCustomerNoParam)}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	customerDtlRq := cModel.CustomerDetailRequest{MobileNumber: mobileNumber, Cif: cif, SavingAccountID: savingAccountID}
	result, err := handler.CUsecase.GetCustomerDetails(req.Context(), customerDtlRq)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, result, nethttp.StatusOK)
	case *rh.AppError:
		if e.Code == rh.CustomerDetailNotFound {
			response := &rh.DataResponse{Message: e.Message, Data: []int{}}
			httpResponseWrite(rw, response, nethttp.StatusNotFound)
		} else {
			response := &rh.DataResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &rh.DataResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}

}

//GetCustomerDetails get customer details
func (handler *CustomerHandler) GetCustomerDetails(rw nethttp.ResponseWriter, req *nethttp.Request) {

	customerID, err := strconv.ParseUint(rh.Param(req, 0), 0, 64)

	if err != nil {
		log.Printf("[delivery:http:handler] GetCustomerDetails Error in converting customerID string to integer. Error: %s \n", err)
		response := &rh.DataResponse{Message: "Unable to Parse Customer_ID from URL Param"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	customerDtlRq := cModel.CustomerDetailRequest{CustomerId: customerID}
	result, err := handler.CUsecase.GetCustomerDetails(req.Context(), customerDtlRq)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, result, nethttp.StatusOK)
	case *rh.AppError:
		if e.Code == rh.CustomerDetailNotFound {
			response := &rh.DataResponse{Message: e.Message, Data: []int{}}
			httpResponseWrite(rw, response, nethttp.StatusOK)
		} else {
			response := &rh.DataResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &rh.DataResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}

}

func (handler *CustomerHandler) GetAccountLinkageStatus(rw nethttp.ResponseWriter, req *nethttp.Request) {
	// ENDPOINT : /customer/:customer_id/linkage?count=5

	customerID, _ := strconv.Atoi(rh.Param(req, 0))
	if customerID == 0 {
		response := &rh.DataResponse{Message: "Unable to Parse Customer_ID from URL Param"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	// Parsing URL Query Param
	count := strings.TrimSpace(req.URL.Query().Get("count"))
	if count == "" {
		// Default Count Value
		count = "5"
	}
	limitCount, _ := strconv.Atoi(count)

	outputData, err := handler.CUsecase.GetCustomerAccountLinkageStatus(req.Context(), uint64(customerID), uint64(limitCount))
	if err != nil {
		response := &rh.DataResponse{Data: outputData, Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		return
	}
	// Sorting by MerchantID
	sort.Slice(*outputData, func(i, j int) bool { return (*outputData)[i].MerchantID < (*outputData)[j].MerchantID })
	response := &rh.DataResponse{Data: outputData, Message: "success"}
	httpResponseWrite(rw, response, nethttp.StatusOK)
}
