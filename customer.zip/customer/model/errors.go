package model

import "errors"

var (
	// ErrInternalServerError will throw if any the Internal Server Error happen
	ErrInternalServerError = errors.New("Internal Server Error")
	// ErrNotFound will throw if the requested item is not exists
	ErrNotFound = errors.New("Your requested Item is not found")
	// ErrConflict will throw if the current action already exists
	ErrConflict = errors.New("Your Item already exist")
	// ErrPhoneNumberRegistered will throw if the current action already exists
	ErrPhoneNumberRegistered = errors.New("Your phone number already registered")
	// ErrBadParamInput will throw if the given request-body or params is not valid
	ErrBadParamInput = errors.New("Given Param is not valid")
	// ErrCanNotUpdate will throw if the given request-body or params is can not be updated
	ErrCanNotUpdate = errors.New("Your request can not be updated")
	// ErrNotAuthorized will throw if the user not authorized
	ErrNotAuthorized = errors.New("You are not authorized")
	// ErrMobileNumberBlocked will throw if the user blocked
	ErrMobileNumberBlocked = errors.New("This phone number already blocked")
)
