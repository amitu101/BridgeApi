package model

import "time"

//Customer is customer data type
type Customer struct {
	CustomerID uint64
	Name       string
	Mobile     string
	Email      string
	Cif        string
	IDNo       string
	FullName   string
	DOB        time.Time
	Gender     int32
	Address    string
	PhotoURL   string
	IconURL    string
	Status     int64
	Type       int32
	KycLevel   int32
	VerificationStatus int32
	CreatedBy  uint64
	CreatedAt  time.Time
	UpdatedBy  uint64
	UpdatedAt  time.Time
}

//CheckMobileNumberAvailabilityResponse is check mobile number availability response data type
type CheckMobileNumberAvailabilityResponse struct {
	Message string
}

type GetCustomerReq struct {
	CustomerID   uint64
	MobileNumber string
}
type GetCustomerDataRequest struct {
	CustomerId uint64
	Mobile     string
}

type CustomerAccountLinkageStatusResponse struct {
	MerchantID        uint64    `json:"partner_id"`
	MerchantName      string    `json:"partner_name"`
	MerchantAccountID string    `json:"partner_account_id"`
	Status            int64     `json:"status"`
	LastLinked        time.Time `json:"last_linked"`
	LastBlocked       time.Time `json:"last_blocked"`
}

type CustomerAccountLinkage struct {
	ID               int64
	CustomerId       uint64
	MobileNumber     string
	MerchantId       uint64
	MerchantName     string
	Status           int8
	PartnerAccountId string
	LastLinked       time.Time
	LastUnlinked     time.Time
	CreatedBy        uint64
	CreatedTime      time.Time
	UpdateBy         uint64
	UpdatedTime      time.Time
}
type CustomerAccountLinkageJsonPayload struct {
	CustomerId   uint64 `json:"customer_id" form:"customer_id" query:"customer_id"`
	MobileNumber string `json:"mobile_number" form:"mobile_number" query:"mobile_number"`
	MerchantId   uint64 `json:"merchant_id" form:"merchant_id" query:"merchant_id"`
	MerchantName string `json:"merchant_name" form:"merchant_name" query:"merchant_name"`
}

type CustomerDetailRequest struct {
	MobileNumber    string
	Cif             string
	CustomerId      uint64
	SavingAccountID uint64
}

type CustomerDetailResponse struct {
	CustomerID      string   `json:"customer_id"`
	FullName        string   `json:"full_name"`
	MobileNumber    string   `json:"mobile_number"`
	Email           string   `json:"email"`
	Type            int32    `json:"type"`
	KycLevel        int32    `json:"kyc_level"`
	Status          int32    `json:"status"`
	SavingAccountID []uint64 `json:"saving_account_id"`
	Cif             string   `json:"cif"`
	IDNo            string   `json:"id_no"`
	DOB             string   `json:"dob"`
	BirthPlace      string   `json:"birth_place"`
	Address         string   `json:"address"`
	City            string   `json:"city"`
	Province        string   `json:"province"`
}
type OTPResponse struct {
	CountdownResendOTP int32
	OtpCode            string
	MobileNumber       string
	OtpDuration        int32
	Message            string

}
type RemoveLinkageResponse struct {
	Message            string
}

type VerificationStatusResponse struct{
	Status 				int8
	Message 			string
}
