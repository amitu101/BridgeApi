package common

const (
	//success
	CustomerDetailSuccess = 150

	//Failure
	CustomerDetailNotFound = 250
	SearchCustomerNoParam  = 251
)

func GetMessage(id uint32) string {
	keyValueMap := map[uint32]string{
		CustomerDetailSuccess:  "Successfully got Customer details",
		CustomerDetailNotFound: "Customer Details not found",
		SearchCustomerNoParam:  "mobile_number or cif or saving_account_id is required"}
	value, _ := keyValueMap[id]
	return value
}
