package gcs

import (
	"cloud.google.com/go/storage"
	"context"
	"encoding/json"
	"fmt"
	"google.golang.org/api/option"
	"log"
	"time"
)

type Config struct {
	Host string
	ServiceAccount string
	Bucket string
}

type Util struct {
	config Config
}

type CloudStorage interface {
	//GenerateV4GetObjectSignedURL(fileName string) (string, error)
	//GenerateV4PutObjectSignedURL(fileName string) (string, error)
	PutFile (context context.Context,folder,fileName string,content[] byte) error
	//GetFile (context context.Context,fileName string,content[] byte,getURL string) error
}

func NewGCSUtility(config Config) CloudStorage {
	return &Util{
		config: config,
	}
}

type ServiceAccount struct {
	Type string             `json:"type"`
	ProjectId string        `json:"project_id"`
	PrivateKey string       `json:"private_key"`
	ClientEmail string      `json:"client_email"`
	ClientId string         `json:"client_id"`
	AuthUri string          `json:"auth_uri"`
	TokenUri string         `json:"token_uri""`
	AuthProviderCert string `json:"auth_provider_x509_cert_url""`
}

// generateV4GetObjectSignedURL generates object signed URL with GET method.
//func (gcs *Util) GenerateV4GetObjectSignedURL(fileName string) (string, error) {
//	// bucket := "bucket-name"
//	// object := "object-name"
//	// serviceAccount := "service_account.json"
//	var raw map[string]interface{}
//
//	in := []byte(gcs.config.ServiceAccount)
//
//	err := json.Unmarshal(in,&raw)
//	if err != nil {
//		return "", fmt.Errorf("json.UnMarshal : %v",err)
//	}
//
//	out,err := json.Marshal(raw)
//	if err != nil {
//		return "", fmt.Errorf("json.Marshal : %v",err)
//	}
//
//	conf, err := google.JWTConfigFromJSON(out)
//	if err != nil {
//		return "", fmt.Errorf("google.JWTConfigFromJSON: %v", err)
//	}
//	opts := &storage.SignedURLOptions{
//		Scheme:         storage.SigningSchemeV4,
//		Method:         "PUT",
//		GoogleAccessID: conf.Email,
//		PrivateKey:     conf.PrivateKey,
//		Expires:        time.Now().Add(15 * time.Minute),
//	}
//	u, err := storage.SignedURL(gcs.config.Bucket, gcs.config.Object, opts)
//	if err != nil {
//		return "", fmt.Errorf("storage.SignedURL: %v", err)
//	}
//
//	//fmt.Fprintln(w, "Generated GET signed URL:")
//	//fmt.Fprintf(w, "%q\n", u)
//	//fmt.Fprintln(w, "You can use this URL with any user agent, for example:")
//	//fmt.Fprintf(w, "curl %q\n", u)
//	return u, nil
//}

// generateV4PutObjectSignedURL generates object signed URL with PUT method.
//func (gcs *Util) GenerateV4PutObjectSignedURL(fileName string) (string, error) {
//	// bucket := "bucket-name"
//	// object := "object-name"
//	// serviceAccount := "service_account.json"
//	jsonKey, err := json.Marshal(gcs.config.ServiceAccount)
//	if err != nil {
//		log.Println(err)
//		return "", fmt.Errorf("json.Marshal : %v",err)
//	}
//	conf, err := google.JWTConfigFromJSON(jsonKey)
//	if err != nil {
//		log.Println(err)
//		return "", fmt.Errorf("google.JWTConfigFromJSON: %v", err)
//	}
//	opts := &storage.SignedURLOptions{
//		Scheme: storage.SigningSchemeV4,
//		Method: "PUT",
//		Headers: []string{
//			"Content-Type:application/octet-stream",
//		},
//		GoogleAccessID: conf.Email,
//		PrivateKey:     conf.PrivateKey,
//		Expires:        time.Now().Add(15 * time.Minute),
//	}
//	u, err := storage.SignedURL(gcs.config.Bucket, gcs.config.Object, opts)
//	if err != nil {
//		log.Println(err)
//		return "", fmt.Errorf("storage.SignedURL: %v", err)
//	}
//	log.Printf("PUT URL : %v\n\n", u)
//
//	//fmt.Fprintln(w, "Generated PUT signed URL:")
//	//fmt.Fprintf(w, "%q\n", u)
//	//fmt.Fprintln(w, "You can use this URL with any user agent, for example:")
//	//fmt.Fprintf(w, "curl -X PUT -H 'Content-Type: application/octet-stream' --upload-file my-file %q\n", u)
//	return u, nil
//}

func (gcs *Util)PutFile (ctx context.Context,folder,fileName string,content[] byte) error{
	var raw map[string]interface{}
	if err := json.Unmarshal([]byte(gcs.config.ServiceAccount), &raw); err != nil {
		log.Println(err)
		return fmt.Errorf("json.UnMarshal : %v",err)
	}
	raw["count"] = 1
	out, err := json.Marshal(raw)
	if err != nil {
		log.Println(err)
		return fmt.Errorf("json.Marshal : %v",err)
	}

	client, err := storage.NewClient(ctx,option.WithCredentialsJSON(out))
	if err != nil {
		return fmt.Errorf("storage.NewClient: %v", err)
	}
	defer client.Close()

	ctx, cancel := context.WithTimeout(ctx, time.Second*50)
	defer cancel()

	log.Println(fileName)

	// Upload an object with storage.Writer.
	wc := client.Bucket(gcs.config.Bucket).Object(folder+ fileName).NewWriter(ctx)

	if _, err := wc.Write(content); err != nil {
		return fmt.Errorf("wc.Write: %v", err)
	}

	if err := wc.Close(); err != nil {
		return fmt.Errorf("Writer.Close: %v", err)
	}

	return nil
}

//func (gcs *Util)GetFile (context context.Context,fileName string,content[] byte,getURL string) error{
//	client := urlfetch.Client(context)
//	req, err := http.NewRequest("GET", getURL, bytes.NewBuffer(content))
//	res, err := client.Do(req)
//	if err != nil {
//		log.Printf("%v\n", err)
//		return err
//	}
//	res.Body.Close()
//	log.Printf("Response Code: %s\n\n", res.Status)
//	return nil
//}
