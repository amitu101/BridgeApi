package client

import (
	"bufio"
	"context"
	"git.capitalx.id/dimii/customer/proto"
	"google.golang.org/grpc"
	"io"
	"log"
	"os"
	"path/filepath"
	"time"
)

type customerClient struct {
	conn   *grpc.ClientConn
	client proto.CustomerHandlerClient
}

type CustomerClient interface {
	CheckRegistrationPhoneNumberAvailability(ctx context.Context, in *CheckRegisPhoneNumberReq) (*CheckMobileNumberAvailabilityResponse, error)
	StoreCustomer(ctx context.Context, in *StoreCustomerData) (*StoreCustomerDataResponse, error)
	RegisterCustomer(ctx context.Context, in *RegisterCustomerRequest) (*RegisterCustomerResponse, error)
	GetCustomerData(ctx context.Context, in *CustomerMobileNumberRequest) (*CustomerDataResponse, error)
	DeleteCustomer(ctx context.Context, in *MobileNumberRequest) (*DeleteCustomerResponse, error)
	GetCustomerDataByIdOrMobileNumber(ctx context.Context, in *GetCustomerRequest) (*CustomerDataResponse, error)
	DeleteCustomerLinkage(ctx context.Context, in *MobileNumberRequest) (*DeleteCustomerResponse, error)
	Close() error
	UploadImage(imagePath ,fileType string)
}


func NewCustomerClient(address string) (CustomerClient, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	client := proto.NewCustomerHandlerClient(conn)

	return &customerClient{conn: conn, client: client}, nil
}

func (c customerClient) Close() error {
	return c.conn.Close()
}

func (c customerClient) CheckRegistrationPhoneNumberAvailability(ctx context.Context, in *CheckRegisPhoneNumberReq) (*CheckMobileNumberAvailabilityResponse, error) {
	res, err := c.client.CheckRegistrationPhoneNumberAvailability(ctx, &proto.CheckRegisPhoneNumberReq{
		Mobilenumber: in.Mobilenumber,
		Username:     in.Username,
	})

	if err != nil {
		return nil, err
	}

	return &CheckMobileNumberAvailabilityResponse{
		Countdownresendotp: res.Countdownresendotp,
		Otpduration:        res.Otpduration,
		Message:            res.Message,
	}, nil
}

func (c customerClient) StoreCustomer(ctx context.Context, in *StoreCustomerData) (*StoreCustomerDataResponse, error) {
	res, err := c.client.StoreCustomer(ctx, &proto.StoreCustomerData{
		Id:        in.Id,
		Mobile:    in.Mobile,
		Createdby: in.Createdby,
	})

	if err != nil {
		return nil, err
	}

	return &StoreCustomerDataResponse{
		Id: res.Id,
	}, nil
}

func (c customerClient) RegisterCustomer(ctx context.Context, in *RegisterCustomerRequest) (*RegisterCustomerResponse, error) {
	res, err := c.client.RegisterCustomer(ctx, &proto.RegisterCustomerRequest{
		Savingproductid: in.Savingproductid,
		Passcode:        in.Passcode,
		Mobilenumber:    in.Mobilenumber,
		Deviceid:        in.Deviceid,
		Fullname:        in.Fullname,
	})

	if err != nil {
		return nil, err
	}

	return &RegisterCustomerResponse{
		Message: res.Message,
	}, nil
}

func (c customerClient) GetCustomerData(ctx context.Context, in *CustomerMobileNumberRequest) (*CustomerDataResponse, error) {
	res, err := c.client.GetCustomerData(ctx, &proto.CustomerMobileNumberRequest{
		Mobilenumber: in.Mobilenumber,
		Username:     in.Username,
		CustomerID:   in.CustomerID,
	})

	if err != nil {
		return nil, err
	}

	return &CustomerDataResponse{
		Customerid:   res.Customerid,
		Fullname:     res.Fullname,
		Mobilenumber: res.Mobilenumber,
		Email:        res.Email,
		Type:         res.Type,
		Kyclevel:     res.Kyclevel,
		Status:       res.Status,
		Photourl:     res.Photourl,
	}, nil
}

func (c customerClient) DeleteCustomer(ctx context.Context, in *MobileNumberRequest) (*DeleteCustomerResponse, error) {
	res, err := c.client.DeleteCustomer(ctx, &proto.MobileNumberRequest{Mobilenumber: in.Mobilenumber})

	if err != nil {
		return nil, err
	}

	return &DeleteCustomerResponse{
		Message: res.Message,
	}, nil
}

func (c customerClient) GetCustomerDataByIdOrMobileNumber(ctx context.Context, in *GetCustomerRequest) (*CustomerDataResponse, error) {
	res, err := c.client.GetCustomerDataByIdOrMobileNumber(ctx, &proto.GetCustomerRequest{
		CustomerId:   in.CustomerId,
		MobileNumber: in.MobileNumber,
	})

	if err != nil {
		return nil, err
	}

	return &CustomerDataResponse{
		Customerid:   res.Customerid,
		Fullname:     res.Fullname,
		Mobilenumber: res.Mobilenumber,
		Email:        res.Email,
		Type:         res.Type,
		Kyclevel:     res.Kyclevel,
		Status:       res.Status,
		Photourl:     res.Photourl,
	}, nil
}

func (c customerClient) DeleteCustomerLinkage(ctx context.Context, in *MobileNumberRequest) (*DeleteCustomerResponse, error) {
	res, err := c.client.DeleteCustomerLinkage(ctx, &proto.MobileNumberRequest{Mobilenumber: in.Mobilenumber})

	if err != nil {
		return nil, err
	}

	return &DeleteCustomerResponse{
		Message: res.Message,
	}, nil

}
func (c customerClient) UploadImage(imagePath,fileType string){
	file,err := os.Open(imagePath)
	if err != nil {
		log.Fatal("cannot open image file: ", err)
	}
	defer file.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	stream,err := c.client.UploadImage(ctx)
	if err != nil {
		log.Fatal("cannot upload image: ", err)
	}
	req := &proto.UploadImageRequest{
		Data: &proto.UploadImageRequest_Info{
			Info: &proto.ImageInfo{
				FileName: "test.jpg",
				FileExtension: filepath.Ext(imagePath),
				FileType: proto.FileType_E_KTP,
			},
		},
	}

	err = stream.Send(req)
	if err != nil {
		log.Fatal("cannot send image info to server: ", err, stream.RecvMsg(nil))
	}

	reader := bufio.NewReader(file)
	buffer := make([]byte, 1024)

	for {
		n, err := reader.Read(buffer)
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Fatal("cannot read chunk to buffer: ", err)
		}

		req := &proto.UploadImageRequest{
			Data: &proto.UploadImageRequest_ChunkData{
				ChunkData: buffer[:n],
			},
		}

		err = stream.Send(req)
		if err != nil {
			log.Fatal("cannot send chunk to server: ", err, stream.RecvMsg(nil))
		}

	}
	res, err := stream.CloseAndRecv()
	if err != nil {
		log.Fatal("cannot receive response: ", err)
	}

	log.Printf("image uploaded with code: %s, message: %s", res.GetCode(), res.GetMessage())

}