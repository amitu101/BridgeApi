package client

//this block is for duplicating models in pb.go, so we dont need to import another package
type CheckRegisPhoneNumberReq struct {
	Mobilenumber string
	Username     string
}

type CheckMobileNumberAvailabilityResponse struct {
	Countdownresendotp int32
	Otpduration        int32
	Message            string
}

type StoreCustomerData struct {
	Id        uint64
	Mobile    string
	Createdby uint64
}

type RegisterCustomerRequest struct {
	Savingproductid uint32
	Passcode        string
	Mobilenumber    string
	Deviceid        string
	Fullname        string
}

type CustomerMobileNumberRequest struct {
	Mobilenumber string
	Username     string
	CustomerID   uint64
}

type MobileNumberRequest struct {
	Mobilenumber string
}

type GetCustomerRequest struct {
	CustomerId   uint64
	MobileNumber string
}

type GetCustomerAccountLinkageStatusRequest struct {
	CustomerId uint64
}

type StoreCustomerDataResponse struct {
	Id uint64
}

type RegisterCustomerResponse struct {
	Message string
}

type CustomerDataResponse struct {
	Customerid   uint64
	Fullname     string
	Mobilenumber string
	Email        string
	Type         int32
	Kyclevel     int32
	Status       int64
	Photourl     string
}

type DeleteCustomerResponse struct {
	Message string
}
