package utils

import (
	"encoding/binary"
	"time"

	uuid "github.com/satori/go.uuid"
)

func GenerateUUID() (uint64, uint64) {
	u := uuid.NewV4()
	u1 := binary.BigEndian.Uint64(u[0:16])
	u2 := binary.BigEndian.Uint64(u[8:16])

	return u1, u2
}

func GenerateDigitRandomUnique() int64 {
	uniqueNumber:=time.Now().UnixNano()/(1<<22)
	return uniqueNumber
}