<h1>Customer Service</h1>

Customer service manages:

- Customer registration
- Customer KYC

Project structure

```
git.capitalx.id/dimii/customer
├── config
│   └── env
│       └── config.go
├── delivery
│   ├── customer.pb.go
│   └── handler.go
├── migration
│   └── create_table_customer_12062020161604.sql
├── model
│   ├── customer.go
│   └── errors.go
├── repository
│   ├── maria_customer.go
│   └── repository.go
├── service
│   └── service.go
├── config.json
├── Dockerfile
├── sonar-project.properties
├── go.mod
├── go.sum
├── main.go
├── Makefile
└── README.md
```

To import other services in private repo do the following:

1. In terminal, do this command: export GOPRIVATE="git.capitalx.id"
2. In go.mod delete following lines:
```
replace git.capitalx.id/core/user => /Users/budhi/go/src/git.capitalx.id/core/user

replace git.capitalx.id/core/messaging => /Users/budhi/go/src/git.capitalx.id/core/messaging

replace git.capitalx.id/dimii/account => /Users/budhi/go/src/git.capitalx.id/dimii/account

And

	git.capitalx.id/core/messaging v0.0.0
	git.capitalx.id/core/user v0.0.0
	git.capitalx.id/dimii/account v0.0.0
```

Then run `go run main.go` or `go build` to automatically download service dependencies
