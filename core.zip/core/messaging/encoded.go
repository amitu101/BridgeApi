package messaging

import (
	"errors"
	"reflect"
)

type Encoder interface {
	Encode(in interface{}) ([]byte, error)
	Decode(in []byte, out interface{}) error
}

type EncodedClient struct {
	cli     *Client
	encoder *Encoder
}

type Callback interface{}

func NewEncodedClient(client *Client, encoder *Encoder) (*EncodedClient, error) {
	if client == nil || encoder == nil {
		return nil, errors.New("client & encoder cannot bil nil")
	}

	return &EncodedClient{cli: client, encoder: encoder}, nil
}

func (ec *EncodedClient) Publish(topic string, input interface{}) error {
	msg, err := (*ec.encoder).Encode(input)
	if err != nil {
		return err
	}

	return (*ec.cli).Publish(topic, msg)
}

func (ec *EncodedClient) BulkPublish(topic string, input []interface{}) error {
	messages := make([][]byte, len(input))
	var err error
	for i, v := range input {
		if messages[i], err = (*ec.encoder).Encode(v); err != nil {
			return err
		}
	}

	return (*ec.cli).BulkPublish(topic, messages)
}

func (ec *EncodedClient) Subscribe(topic string, queue string, cb Callback) (*SubscriptionHandler, error) {
	if cb == nil {
		return nil, errors.New("callback cannot be nil")
	}

	cbType := reflect.TypeOf(cb)
	if cbType.Kind() != reflect.Func {
		return nil, errors.New("callback needs to be a func")
	}

	numArgs := cbType.NumIn()
	if numArgs == 0 || numArgs > 4 {
		return nil, errors.New("callback requires at least one argument and max four arguments")
	}

	argType := cbType.In(numArgs - 1)
	cbValue := reflect.ValueOf(cb)

	fn := func(t string, q string, input []byte) error {
		var oPtr reflect.Value

		if argType.Kind() != reflect.Ptr {
			oPtr = reflect.New(argType)
		} else {
			oPtr = reflect.New(argType.Elem())
		}

		if err := (*ec.encoder).Decode(input, oPtr.Interface()); err != nil {
			return err
		}

		if argType.Kind() != reflect.Ptr {
			oPtr = reflect.Indirect(oPtr)
		}

		var oV []reflect.Value

		switch numArgs {
		case 1:
			oV = []reflect.Value{oPtr}
		case 2:
			subV := reflect.ValueOf(t)
			oV = []reflect.Value{subV, oPtr}
		case 3:
			subV := reflect.ValueOf(t)
			replyV := reflect.ValueOf(q)
			oV = []reflect.Value{subV, replyV, oPtr}
		}

		rvs := cbValue.Call(oV)
		if rvs == nil || len(rvs) == 0 {
			return nil
		}

		rv := rvs[0].Interface()
		if rv == nil {
			return nil
		}

		return rv.(error)
	}

	return (*ec.cli).Subscribe(topic, queue, fn)
}

func (ec *EncodedClient) Close() error {
	cli := ec.cli
	if cli != nil {
		ec.cli = nil
		return (*cli).Close()
	}

	return nil
}
