package kafka

import (
	"context"
	"errors"
	"git.capitalx.id/core/messaging"
	"github.com/Shopify/sarama"
	"io"
	"log"
	"sync"
)

type Client struct {
	client        sarama.Client
	config        *sarama.Config
	producer      sarama.SyncProducer
	subscriptions sync.Map
}

func NewClient(address []string, config *sarama.Config) (*Client, error) {
	if config == nil {
		config = sarama.NewConfig()
	}
	config.Version = sarama.V2_5_0_0
	config.Producer.Return.Successes = true
	config.Producer.Return.Errors = true
	config.Consumer.Return.Errors = true

	client, err := sarama.NewClient(address, config)
	if err != nil {
		return nil, err
	}

	return &Client{client: client}, nil
}

func (kc *Client) Close() error {
	if kc.client == nil {
		return nil
	}

	func() {
		kc.subscriptions.Range(func(key, value interface{}) bool {
			subsHandler, ok := value.(*SubscriptionHandler)
			if ok {
				_ = subsHandler.Close()
				return true
			}

			return false
		})
	}()

	if kc.producer != nil {
		if err := kc.producer.Close(); err != nil {
			log.Print(err)
		}
		kc.producer = nil
	}

	if err := kc.client.Close(); err != nil {
		return err
	}

	kc.client = nil
	return nil
}

func (kc *Client) Publish(topic string, message []byte) error {
	if kc.producer == nil {
		producer, err := sarama.NewSyncProducerFromClient(kc.client)
		if err != nil {
			return err
		}

		kc.producer = producer
	}

	msg := sarama.ProducerMessage{Topic: topic, Value: sarama.ByteEncoder(message)}
	if _, _, err := kc.producer.SendMessage(&msg); err != nil {
		log.Print(err)
		return err
	}

	return nil
}

func (kc *Client) BulkPublish(topic string, messages [][]byte) error {
	if kc.producer == nil {
		producer, err := sarama.NewSyncProducerFromClient(kc.client)
		if err != nil {
			return err
		}

		kc.producer = producer
	}

	var producerMessages []*sarama.ProducerMessage
	for _, message := range messages {
		producerMessages = append(producerMessages, &sarama.ProducerMessage{Topic: topic, Value: sarama.ByteEncoder(message)})
	}

	if err := kc.producer.SendMessages(producerMessages); err != nil {
		log.Print(err)
		return err
	}

	return nil
}

func (kc *Client) Subscribe(topic string, subscription string, handler func(string, string, []byte) error) (*messaging.SubscriptionHandler, error) {
	if kc.client == nil {
		return nil, errors.New("inactive connection")
	}

	if len(subscription) == 0 {
		consumer := newSingleConsumer(kc.client)

		go func() {
			if err := consumer.Consume(topic, subscription, handler); err != nil {
				log.Println(err)
			}
		}()

		kch := &SubscriptionHandler{kc: kc, name: topic, consumer: consumer}
		kc.addHandler(topic, kch)
		var sc messaging.SubscriptionHandler = kch
		return &sc, nil
	} else {
		consumer := newGroupConsumer(kc.client)

		go func() {
			if err := consumer.Consume(topic, subscription, handler); err != nil {
				log.Println(err)
			}
		}()

		kch := &SubscriptionHandler{kc: kc, name: topic, consumer: consumer}
		kc.addHandler(topic, kch)
		var sc messaging.SubscriptionHandler = kch
		return &sc, nil
	}
}

type groupConsumer struct {
	client sarama.Client
	signal chan struct{}
}

func newGroupConsumer(client sarama.Client) *groupConsumer {
	return &groupConsumer{client: client, signal: make(chan struct{}, 1)}
}

func (cg *groupConsumer) Consume(topic, group string, handler func(string, string, []byte) error) error {
	consumer, err := sarama.NewConsumerGroupFromClient(group, cg.client)
	if err != nil {
		log.Print(err)
		return err
	}

	//track errors
	go func() {
		for err := range consumer.Errors() {
			log.Print(err)
		}
	}()

	ctx, cancel := context.WithCancel(context.Background())
	topics := []string{topic}
	cgHandler := consumerGroupHandler{group: group, handler: handler}
	go func() {
		for {
			if err := consumer.Consume(ctx, topics, cgHandler); err != nil {
				log.Print(err)
				return
			}
			if ctx.Err() != nil {
				return
			}
		}
	}()

	<-cg.signal
	cancel()
	return consumer.Close()
}

func (cg *groupConsumer) Close() error {
	close(cg.signal)
	return nil
}

type consumerGroupHandler struct {
	group   string
	handler func(string, string, []byte) error
}

func (consumerGroupHandler) Setup(_ sarama.ConsumerGroupSession) error   { return nil }
func (consumerGroupHandler) Cleanup(_ sarama.ConsumerGroupSession) error { return nil }
func (h consumerGroupHandler) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	for msg := range claim.Messages() {
		if err := h.handler(msg.Topic, h.group, msg.Value); err != nil {
			log.Printf("error while running subscription callback method for subject: %v, %v", msg.Topic, err)
		} else {
			session.MarkMessage(msg, "")
		}
	}
	return nil
}

type singleConsumer struct {
	client sarama.Client
	signal chan struct{}
}

func newSingleConsumer(client sarama.Client) *singleConsumer {
	return &singleConsumer{client: client, signal: make(chan struct{}, 1)}
}

func (sc *singleConsumer) Consume(topic, group string, handler func(string, string, []byte) error) error {
	consumer, err := sarama.NewConsumerFromClient(sc.client)
	if err != nil {
		log.Print(err)
		return err
	}

	partitionConsumer, err := consumer.ConsumePartition(topic, 0, sarama.OffsetNewest)
	if err != nil {
		log.Print(err)
		return err
	}

loop:
	for {
		select {
		case msg := <-partitionConsumer.Messages():
			if err := handler(msg.Topic, group, msg.Value); err != nil {
				log.Printf("error while running subscription callback method for subject: %v, %v", topic, err)
			}
		case <-sc.signal:
			break loop
		}
	}

	if err := partitionConsumer.Close(); err != nil {
		log.Print(err)
	}

	if err := consumer.Close(); err != nil {
		log.Print(err)
		return err
	}

	return nil
}

func (sc *singleConsumer) Close() error {
	close(sc.signal)
	return nil
}

type SubscriptionHandler struct {
	kc       *Client
	name     string
	consumer io.Closer
}

func (ksh *SubscriptionHandler) Close() error {
	if ksh.consumer != nil {
		ksh.kc.removeHandler(ksh.name)
		return ksh.consumer.Close()
	}
	return nil
}

func (kc *Client) addHandler(key string, handler *SubscriptionHandler) {
	kc.subscriptions.Store(key, handler)
}

func (kc *Client) removeHandler(key string) {
	kc.subscriptions.Delete(key)
}
