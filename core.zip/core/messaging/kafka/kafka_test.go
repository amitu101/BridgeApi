package kafka

import (
	"sync"
	"testing"
)

func newClient() (pc *Client, err error) {
	return NewClient([]string{"127.0.0.1:9092"}, nil)
}

func TestPublish(t *testing.T) {
	topic := "test"

	pc, err := newClient()
	if err != nil {
		t.Fatal(err)
	}

	defer func() {
		if err := pc.Close(); err != nil {
			t.Error(err)
		}
	}()

	if err := pc.Publish(topic, []byte("kafka")); err != nil {
		t.Error(err)
	}

}

func TestBulkPublish(t *testing.T) {
	topic := "test"

	pc, err := newClient()
	if err != nil {
		t.Fatal(err)
	}

	defer func() {
		if err := pc.Close(); err != nil {
			t.Error(err)
		}
	}()

	if err := pc.BulkPublish(topic, [][]byte{[]byte("kafka"), []byte("messaging")}); err != nil {
		t.Error(err)
	}
}

func TestSubscribe(t *testing.T) {
	topic := "test-kafka"

	sub, serr := newClient()
	if serr != nil {
		t.Fatal(serr)
	}

	var wg = sync.WaitGroup{}
	wg.Add(2)

	_, err := sub.Subscribe(topic, "test", func(s string, q string, bytes []byte) error {
		t.Logf("got message: %v", string(bytes))
		wg.Done()
		return nil
	})

	if err != nil {
		t.Fatal(err)
	}

	pub, perr := newClient()
	if perr != nil {
		t.Fatal(perr)
	}

	if err = pub.BulkPublish(topic, [][]byte{[]byte("kafka"), []byte("messaging")}); err != nil {
		t.Error(err)
	} else {
		wg.Wait()
	}

	if err := sub.Close(); err != nil {
		t.Error(err)
	}
	if err := pub.Close(); err != nil {
		t.Error(err)
	}
}
