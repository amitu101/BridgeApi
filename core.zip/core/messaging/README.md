<h1>Messaging Service</h1>


Messaging service is general interface to publish or subscribe to a messaging system.