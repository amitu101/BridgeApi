package redis

import (
	"errors"
	"log"
	"sync"

	"git.capitalx.id/core/messaging"
	"github.com/go-redis/redis/v7"
)

var (
	errorInactiveClient = errors.New("inactive connection")
)

func NewClient(url string, options *redis.Options) (*Client, error) {
	var cli *redis.Client

	if options == nil {
		cli = redis.NewClient(&redis.Options{Addr: url})
	} else {
		options.Addr = url
		cli = redis.NewClient(options)
	}

	return NewSharedClient(cli, true), nil
}

func NewFailoverClient(master string, sentinels []string, options *redis.FailoverOptions) (*Client, error) {
	var cli *redis.Client

	if options == nil {
		cli = redis.NewFailoverClient(&redis.FailoverOptions{MasterName: master, SentinelAddrs: sentinels})
	} else {
		options.MasterName = master
		options.SentinelAddrs = sentinels
		cli = redis.NewFailoverClient(options)
	}

	return NewSharedClient(cli, true), nil
}

func NewSharedClient(cli *redis.Client, closeClient bool) *Client {
	return &Client{client: cli, subscriptions: make(map[string]*SubscriptionHandler), closeClient: closeClient}
}

type Client struct {
	client        *redis.Client
	closeClient   bool
	lock          sync.Mutex
	subscriptions map[string]*SubscriptionHandler
}

func (rc *Client) addHandler(key string, handler *SubscriptionHandler) {
	rc.lock.Lock()
	defer rc.lock.Unlock()
	rc.subscriptions[key] = handler
}

func (rc *Client) removeHandler(key string) {
	rc.lock.Lock()
	defer rc.lock.Unlock()
	delete(rc.subscriptions, key)
}

func (rc *Client) Close() error {
	client := rc.client
	if client == nil {
		return nil
	}

	rc.client = nil

	for _, v := range rc.subscriptions {
		_ = v.Close()
	}

	if rc.closeClient {
		return client.Close()
	}

	return nil
}

func (rc *Client) Publish(subj string, msg []byte) error {
	if rc.client == nil {
		return errorInactiveClient
	}

	return rc.client.Publish(subj, msg).Err()
}

func (rc *Client) BulkPublish(subj string, msgs [][]byte) error {
	if rc.client == nil {
		return errorInactiveClient
	}

	var err error
	pipeline := rc.client.Pipeline()
	defer func() {
		if err := pipeline.Close(); err != nil {
			log.Printf("error while bulk-publishing to channel '%s': %v", subj, err)
		}
	}()

	for _, msg := range msgs {
		if err = pipeline.Publish(subj, msg).Err(); err != nil {
			return err
		}
	}

	_, err = pipeline.Exec()
	return err
}

func (rc *Client) Subscribe(subj string, queue string, f func(string, string, []byte) error) (*messaging.SubscriptionHandler, error) {
	if rc.client == nil {
		return nil, errorInactiveClient
	}

	cli := rc.client
	pubsub := cli.Subscribe(subj)
	channel := pubsub.Channel()

	go func(topic, subscription string) {
		for msg := range channel {
			if err := f(topic, subscription, []byte(msg.Payload)); err != nil {
				log.Printf("error while running subscription callback method for subject: %v, %v", subj, err)
			}
		}
	}(subj, queue)

	rch := &SubscriptionHandler{rc: rc, name: subj, subs: pubsub}
	rc.addHandler(subj, rch)
	var sc messaging.SubscriptionHandler = rch
	return &sc, nil
}

type SubscriptionHandler struct {
	rc   *Client
	name string
	subs *redis.PubSub
}

func (rch *SubscriptionHandler) Close() error {
	subs := rch.subs
	if subs == nil {
		return nil
	}

	name := rch.name
	rch.rc.removeHandler(name)
	if err := subs.Unsubscribe(name); err != nil {
		log.Printf("error while closing a subscription channel: %v", err)
	}
	return subs.Close()
}
