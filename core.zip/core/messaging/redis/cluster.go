package redis

import (
	"log"
	"sync"

	"git.capitalx.id/core/messaging"
	"github.com/go-redis/redis/v7"
)

func NewClusterClient(nodes []string, options *redis.ClusterOptions) (*ClusterClient, error) {
	var cli *redis.ClusterClient

	if options == nil {
		cli = redis.NewClusterClient(&redis.ClusterOptions{Addrs: nodes})
	} else {
		options.Addrs = nodes
		cli = redis.NewClusterClient(options)
	}

	return NewSharedClusterClient(cli, true), nil
}

func NewSharedClusterClient(cli *redis.ClusterClient, closeClient bool) *ClusterClient {
	return &ClusterClient{client: cli, subscriptions: make(map[string]*ClusterSubscriptionHandler), closeClient: closeClient}
}

type ClusterClient struct {
	client        *redis.ClusterClient
	closeClient   bool
	lock          sync.Mutex
	subscriptions map[string]*ClusterSubscriptionHandler
}

func (rc *ClusterClient) addHandler(key string, handler *ClusterSubscriptionHandler) {
	rc.lock.Lock()
	defer rc.lock.Unlock()
	rc.subscriptions[key] = handler
}

func (rc *ClusterClient) removeHandler(key string) {
	rc.lock.Lock()
	defer rc.lock.Unlock()
	delete(rc.subscriptions, key)
}

func (rc *ClusterClient) Close() error {
	client := rc.client
	if client == nil {
		return nil
	}

	rc.client = nil

	for _, v := range rc.subscriptions {
		_ = v.Close()
	}

	if rc.closeClient {
		return client.Close()
	}

	return nil
}

func (rc *ClusterClient) Publish(subj string, msg []byte) error {
	if rc.client == nil {
		return errorInactiveClient
	}

	return rc.client.Publish(subj, msg).Err()
}

func (rc *ClusterClient) BulkPublish(subj string, msgs [][]byte) error {
	if rc.client == nil {
		return errorInactiveClient
	}

	var err error
	pipeline := rc.client.Pipeline()
	defer func() {
		if err := pipeline.Close(); err != nil {
			log.Printf("error while bulk-publishing to channel '%s': %v", subj, err)
		}
	}()

	for _, msg := range msgs {
		if err = pipeline.Publish(subj, msg).Err(); err != nil {
			return err
		}
	}

	_, err = pipeline.Exec()
	return err
}

func (rc *ClusterClient) Subscribe(subj string, queue string, f func(string, string, []byte) error) (*messaging.SubscriptionHandler, error) {
	if rc.client == nil {
		return nil, errorInactiveClient
	}

	cli := rc.client
	pubsub := cli.Subscribe(subj)
	channel := pubsub.Channel()

	go func(topic, subscription string) {
		for msg := range channel {
			if err := f(topic, subscription, []byte(msg.Payload)); err != nil {
				log.Printf("error while running subscription callback method for subject: %v, %v", subj, err)
			}
		}
	}(subj, queue)

	rch := &ClusterSubscriptionHandler{rc: rc, name: subj, subs: pubsub}
	rc.addHandler(subj, rch)
	var sc messaging.SubscriptionHandler = rch
	return &sc, nil
}

type ClusterSubscriptionHandler struct {
	rc   *ClusterClient
	name string
	subs *redis.PubSub
}

func (rch *ClusterSubscriptionHandler) Close() error {
	subs := rch.subs
	if subs == nil {
		return nil
	}

	name := rch.name
	rch.rc.removeHandler(name)
	if err := subs.Unsubscribe(name); err != nil {
		log.Printf("error while closing a subscription channel: %v", err)
	}
	return subs.Close()
}
