package messaging

import "encoding/json"

type jsonEncoder struct {
}

func (je *jsonEncoder) Encode(in interface{}) ([]byte, error) {
	return json.Marshal(in)
}

func (je *jsonEncoder) Decode(in []byte, out interface{}) error {
	return json.Unmarshal(in, out)
}

var je = &jsonEncoder{}

func JsonEncoder() *Encoder {
	var e Encoder = je
	return &e
}
