package messaging

import (
	"io"
)

type Client interface {
	io.Closer
	Publish(string, []byte) error
	BulkPublish(string, [][]byte) error
	Subscribe(topic string, subscription string, f func(string, string, []byte) error) (*SubscriptionHandler, error)
}

type SubscriptionHandler interface {
	io.Closer
}
