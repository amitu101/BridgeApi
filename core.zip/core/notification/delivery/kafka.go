package delivery

import (
	"crypto/tls"
	"encoding/json"
	"log"
	"os"

	"git.capitalx.id/core/notification/model"
	"git.capitalx.id/core/notification/service"

	"git.capitalx.id/core/messaging/kafka"
	"github.com/Shopify/sarama"
)

//getKafkaConfig config
func getKafkaConfig(tlsConfig *tls.Config) *sarama.Config {
	config := sarama.NewConfig()
	config.Version = sarama.V2_5_0_0
	config.Consumer.Return.Errors = true
	config.Producer.Retry.Max = 5
	config.Producer.RequiredAcks = sarama.RequiredAcks(-1)
	if tlsConfig != nil {
		config.Net.TLS.Enable = true
		config.Net.TLS.Config = tlsConfig
	}
	return config
}

//getKafkaClient......
func getKafkaClient(address []string, tlsConfig *tls.Config) (*kafka.Client, error) {
	config := getKafkaConfig(tlsConfig)
	return kafka.NewClient(address, config)
}

func handler(service service.NotificationService) func(topic, subscription string, data []byte) error {
	return func(topic, subscription string, data []byte) error {
		var message model.NotificationMessage
		err := json.Unmarshal(data, &message)
		if err != nil {
			log.Println("consumerhandler json unmarshal err: ", err)
			return err
		}

		return service.SendNotification(message)
	}
}

func StartKafkaListener(address []string, tlsConfig *tls.Config, service service.NotificationService) {
	client, err := getKafkaClient(address, tlsConfig)
	if err != nil {
		log.Println("StartKafkaListiner unable to Get Kafka Client: ", err)
		os.Exit(-1)
	}

	if _, err := client.Subscribe(model.NOTIFICATION_TOPIC, "notification_groupID", handler(service)); err != nil {
		log.Println("StartKafkaListiner client.Subscribe err: ", err)
	}
}
