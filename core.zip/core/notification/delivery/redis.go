package delivery

import (
	"crypto/tls"
	"git.capitalx.id/core/messaging/redis"
	"git.capitalx.id/core/notification/service"
	redis2 "github.com/go-redis/redis/v7"
	"log"
	"os"
)

func StartRedisListener(address string, service service.NotificationService) {
	client, err := redis.NewClient(address, nil)
	if err != nil {
		log.Println("Unable to Get Redis Client: ", err)
		os.Exit(-1)
	}

	if _, err := client.Subscribe("notification", "notification_groupID", handler(service)); err != nil {
		log.Println("Start redis listener client.Subscribe err: ", err)
	}
}

func StartRedisClusterListener(address []string, tlsconfig *tls.Config, service service.NotificationService) {
	options := redis2.ClusterOptions{TLSConfig: tlsconfig}
	client, err := redis.NewClusterClient(address, &options)
	if err != nil {
		log.Println("Unable to Get Redis Client: ", err)
		os.Exit(-1)
	}

	if _, err := client.Subscribe("notification", "notification_groupID", handler(service)); err != nil {
		log.Println("Start redis listener client.Subscribe err: ", err)
	}
}
