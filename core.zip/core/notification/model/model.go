package model

import (
	"time"
)

const (
	//SMS is notification via text message
	SMS int = 0x1
	//EMAIL is notification via email
	EMAIL int = 0x2
	//PUSH is notification via app push
	PUSH int = 0x4

	NOTIFICATION_TOPIC = "notification"
)

//NotificationMessage ...
type NotificationMessage struct {
	//to identify the template for the notification
	NotificationID string `json:"id"`
	//should support multiple channels
	Channel int `json:"channel"`
	//the language of the notification,the value should use ISO 639-1 codes,
	// e.g. "id" for Indonesia, "en" for English
	Language string `json:"language"`

	Sender    string `json:"sender"`    //sender number/email/name
	Recipient string `json:"recipient"` //recipient number/email/device id
	//Data (map), the data to be inserted into the template
	Data map[string]string `json:"data"` //the data to be inserted into the template
}

//MessageTemplate ...
type MessageTemplate struct {
	TemplateID string `json:"template_id"`
	//'1 = sms\n2 = email\n4 = push',
	ChannelType int       `json:"channel_type"`
	Language    string    `json:"language"`
	Sender      string    `json:"sender"`
	Subject     string    `json:"subject"`
	Message     string    `json:"message"`
	CreatedTime time.Time `json:"created_time"`
	UpdatedTime time.Time `json:"updated_time"`
}

func IsEmail(channel int) bool {
	return channel&EMAIL == EMAIL
}

func IsSMS(channel int) bool {
	return channel&SMS == SMS
}

func IsPush(channel int) bool {
	return channel&PUSH == PUSH
}
