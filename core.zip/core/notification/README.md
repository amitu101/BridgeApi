<h1>Notification Service</h1>


Notification service is service for delivering message notification to user or customer. It support these notification channels:

- SMS/Text
- Email
- Android via Firebase Cloud Messaging (FCM)
- iOS via Apple Push Notification service (APNs)

<h3>Protocol</h3>

Other services that need to notify user or customer will send message to Notification service via messaging system. 
Apache Kafka will be used as a messaging platform.
The message sent to Notification service contains:
- Notifiation ID, to identify the template for the notification
- Channel type, should support multiple channels
- Language, the language of the notification
- Sender, sender number/email/name
- Recipient, recipient number/email/device id
- Data, map structure will be used to store the data

<h3>Template</h3>

The notification supports different template for each channel and language.