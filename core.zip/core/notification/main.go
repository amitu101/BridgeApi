package main

import (
	"context"
	"git.capitalx.id/core/common/tls"
	"log"
	"net/smtp"
	"os"

	"git.capitalx.id/core/common/mysql"
	core_config "git.capitalx.id/core/config"
	vault_cfg "git.capitalx.id/core/config/vault"
	viper_cfg "git.capitalx.id/core/config/viper"

	_inbox_client "git.capitalx.id/core/inbox/client"
	"git.capitalx.id/core/notification/delivery"
	"git.capitalx.id/core/notification/repository"
	"git.capitalx.id/core/notification/service"
)

func getConfig() (core_config.Config, error) {
	address := os.Getenv("VAULT_ADDR")
	token := os.Getenv("VAULT_TOKEN")

	if address != "" && token != "" {
		config, err := vault_cfg.GetConfig("notification")

		if err == nil {
			return config, nil
		} else {
			return nil, err
		}
	}
	return viper_cfg.NewConfig("notification", "config.json")
}

func main() {
	config, err := getConfig()
	if err != nil {
		log.Println(err)
		return
	}
	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dataStore, err := repository.NewDBStore(dbConfig)
	if err != nil {
		log.Fatal("cannot connect to datastore")
	}
	defer func() {
		if err := dataStore.Close(); err != nil {
			log.Print(err)
		}
	}()

	smsUrl := config.GetString("nusasms.url")
	smsUser := config.GetString("nusasms.user")
	smsPassword := config.GetString("nusasms.password")

	smsGateway := repository.NusaSMSGateway(smsUrl, smsUser, smsPassword)

	// Now hard coded. This configuration should came from configuration service
	pushService := repository.NewPushService(config.GetString("firebase.key"))

	// New inbox service
	in, err := _inbox_client.NewInboxClient(config.GetString("inbox.url"))
	if err != nil {
		log.Print(err)
	}

	smtpServer := config.GetString("smtp.server")
	smtpUser := config.GetString("smtp.user")
	smtpPwd := config.GetString("smtp.password")
	smtpHost := config.GetString("smtp.host")

	auth := smtp.PlainAuth("", smtpUser, smtpPwd, smtpHost)
	mailServer := repository.SMTPServer{Address: smtpServer, Auth: auth}
	mailer := repository.NewSMTPService([]repository.SMTPServer{mailServer}, repository.NewRoundRobinSelector())

	svc := service.NewNotificationService(dataStore, smsGateway, mailer, pushService, in)

	kafkaAddr := config.GetArray("messaging.host")
	kafkaCa := config.GetBinary("kafka.ca")
	kafkaCert := config.GetBinary("kafka.cert")
	kafkaKey := config.GetBinary("kafka.key")

	tlsConfig := tls.WithCertificate(kafkaCa, kafkaCert, kafkaKey, false)

	delivery.StartKafkaListener(kafkaAddr, tlsConfig, svc)
	log.Println("subscribed to kafka cluster")

	// Handle signals like ctrl+c etc
	_, cancel := context.WithCancel(context.Background())
	repository.CaptureSignal(cancel)
}
