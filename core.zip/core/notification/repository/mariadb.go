package repository

import (
	"database/sql"
	"git.capitalx.id/core/common/mysql"
	"git.capitalx.id/core/notification/model"
	_ "github.com/go-sql-driver/mysql" //mysql driver
	"log"
)

type mariaDBStore struct {
	db *sql.DB
}

//NewDBStore creates new mariadb storage
func NewDBStore(config mysql.Config) (DataStore, error) {
	db, err := mysql.DB(config)
	if err != nil {
		return nil, err
	}

	return &mariaDBStore{db: db}, nil
}

func (mdb *mariaDBStore) Close() error {
	return mdb.db.Close()
}

func (mdb *mariaDBStore) GetTemplate(channelType int, id string, language string) (model.MessageTemplate, error) {
	template := model.MessageTemplate{
		TemplateID:  id,
		ChannelType: channelType,
		Language:    language,
	}
	err := mdb.db.QueryRow("select sender, subject, message from template where template_id = ? and channel_type = ? and language = ?;", id, channelType, language).Scan(&template.Sender, &template.Subject, &template.Message)
	if err != nil {
		log.Println("GetTemplate QueryRow Scan err: ", err)
	}
	return template, err
}
