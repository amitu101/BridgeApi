package repository

import (
	"io"

	"git.capitalx.id/core/notification/model"
)

//DataStore is interface to database access
type DataStore interface {
	GetTemplate(int, string, string) (model.MessageTemplate, error)
	io.Closer
}

type SMS struct {
	Mobile string
	Text   string
	OTP    bool
}

type SMSGateway interface {
	Send(SMS) error
}

//Email is email notification
type Email struct {
	Sender     string
	Recipients []string
	CC         []string
	BCC        []string
	Subject    string
	Attachment []byte
	Message    string
}

type Mailer interface {
	Send(Email) error
}

//Push notification object
type Push struct {
	Sender            string
	RegistrationToken string
	Subject           string
	Message           string
	Data              map[string]string
}

//PushService interface
type PushService interface {
	Send(Push) error
}
