package repository

import (
	"context"
	firebase "firebase.google.com/go/v4"
	"log"

	"firebase.google.com/go/v4/messaging"
)

type pushservice struct {
	app *firebase.App
}

func (ps *pushservice) Send(p Push) error {

	// Obtain a messaging.Client from the App.
	ctx := context.Background()
	client, err := ps.app.Messaging(ctx)
	if err != nil {
		log.Printf("error getting Messaging client: %v\n", err)
	}

	data := map[string]string{
		"subject":            p.Subject,
		"message":            p.Message,
		"notificationTypeID": p.Data["notificationTypeID"],
		"landingurl":         p.Data["landingurl"],
		"sender":             p.Sender,
		"userID":             p.Data["userID"],
		"createdTime":        p.Data["createdTime"],
		"createdBy":          p.Data["createdBy"],
	}

	message := &messaging.Message{
		Token: p.RegistrationToken,
		Data:  data}

	// Send a message to the device corresponding to the provided registration token.
	response, err := client.Send(ctx, message)
	if err != nil {
		log.Println(err)
	} else {
		log.Print("Successfully sent push message. MessageID: ", response)
	}
	return nil
}

//NewPushService implementation
func NewPushService(path string) PushService {
	//p := filepath.FromSlash(path)
	//opt := option.WithCredentialsFile(p)
	//app, err := firebase.NewApp(context.Background(), nil, opt)
	app, err := firebase.NewApp(context.Background(), nil)
	if err != nil {
		log.Printf("error initializing app: %v\n", err)
	}
	return &pushservice{app: app}
}
