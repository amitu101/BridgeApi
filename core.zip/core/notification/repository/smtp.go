package repository

import (
	"math/rand"
	"net/smtp"
	"sync"
	"time"
)

//SMTPServer is smtp server configuration
type SMTPServer struct {
	Address string
	Sender  string
	Auth    smtp.Auth
}

//Selector select one index between range
type Selector interface {
	Select(int) int
}

type roundRobinSelector struct {
	counter int
	lock    sync.Mutex
}

//NewRoundRobinSelector return selector which chooses a round robin index each time
func NewRoundRobinSelector() Selector {
	return &roundRobinSelector{counter: 0}
}

func (s *roundRobinSelector) Select(size int) int {
	s.lock.Lock()
	defer s.lock.Unlock()
	if s.counter >= size {
		s.counter = 0
	}
	index := s.counter
	s.counter++

	return index
}

type randomSelector struct {
	generator *rand.Rand
}

// NewRandomSelector returns a selector which chooses a random index each time.
func NewRandomSelector() Selector {
	s := new(randomSelector)
	s.generator = rand.New(rand.NewSource(time.Now().UTC().UnixNano()))
	return s
}

func (s *randomSelector) Select(size int) int {
	return s.generator.Intn(size)
}

type smtpService struct {
	servers  []SMTPServer
	selector Selector
}

//NewSMTPService return new SMTP service
func NewSMTPService(servers []SMTPServer, selector Selector) Mailer {
	return &smtpService{servers: servers, selector: selector}
}

func (es *smtpService) Send(email Email) error {
	index := es.selector.Select(len(es.servers))
	return sendEmail(es.servers[index], email)
}

func sendEmail(server SMTPServer, email Email) error {
	mime := "MIME-version: 1.0;\nContent-Type: text/html; charset=\"UTF-8\";\n\n"
	subject := "Subject: " + email.Subject + "\n"
	msg := []byte(subject + mime + "\n" + email.Message)

	return smtp.SendMail(server.Address, server.Auth, server.Sender, email.Recipients, msg)
}
