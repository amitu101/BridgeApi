package repository

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"time"
)

type nusasms struct {
	url      string
	user     string
	password string
}

type Result struct {
	Status      string `json:"status"`
	MessageID   string `json:"messageid"`
	Destination string `json:"destination"`
}

type Response struct {
	results []Result `json:"results"`
}

func (n *nusasms) Send(sms SMS) error {
	// Prepare Query Parameters
	params := url.Values{}
	params.Add("user", n.user)
	params.Add("password", n.password)
	params.Add("SMSText", sms.Text)
	params.Add("GSM", sms.Mobile)
	params.Add("output", "json")
	if sms.OTP {
		params.Add("otp", "Y")
	}

	// Add Query Parameters to the URL
	client := &http.Client{
		Timeout: time.Duration(10) * time.Second,
	}

	req, err := http.NewRequest(http.MethodGet, n.url, nil)
	req.URL.RawQuery = params.Encode()
	if err != nil {
		log.Println("http.NewRequest err: ", err)
		return err
	}

	res, err := client.Do(req)
	if err != nil {
		log.Println("Client Error: ", err)
		return err
	}

	body, errs := ioutil.ReadAll(res.Body)
	if errs != nil {
		log.Println("ioutil.ReadAll Error : ", errs)
		return err
	}

	log.Println("NusaSMS Resp: ", string(body))

	var r Response
	if err := json.Unmarshal(body, &r); err != nil {
		return err
	}
	if len(r.results) > 0 {
		log.Println("Status: ", r.results[0].Status, " MSGID: ", r.results[0].MessageID, " RecptNumber : ", r.results[0].Destination)
	}

	return nil
}

func NusaSMSGateway(url, user, password string) SMSGateway {
	return &nusasms{
		url:      url,
		user:     user,
		password: password,
	}
}
