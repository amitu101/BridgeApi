package repository

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"
)

//CaptureSignal ...
func CaptureSignal(cancel context.CancelFunc) {
	defer cancel()

	signalChan := make(chan os.Signal, 1)
	signal.Notify(signalChan, syscall.SIGINT, syscall.SIGTERM)

	for {
		signalReceived := <-signalChan
		switch signalReceived {
		// kill -SIGINT XXXX or Ctrl+c
		case syscall.SIGINT:
			log.Printf("\ncaught sig: %+v\n", syscall.SIGINT)
			log.Printf("Gracefully shutting down server...\n")
			cancel()
			os.Exit(int(syscall.SIGKILL))
		// kill -SIGTERM XXXX
		case syscall.SIGTERM:
			log.Printf("\ncaught sig: %+v\n", syscall.SIGTERM)
			log.Printf("Gracefully shutting down server...\n")
			cancel()
			os.Exit(int(syscall.SIGTERM))
		default:
			log.Printf("\ncaught sig: %+v\n", signalReceived)
			log.Printf("Gracefully shutting down server...\n")
			cancel()
			os.Exit(1)
		}
	}
}
