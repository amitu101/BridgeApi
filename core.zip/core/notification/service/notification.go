package service

import (
	"bytes"
	"context"
	"errors"
	html "html/template"
	"io"
	"log"
	"strconv"
	text "text/template"

	_inbox_model "git.capitalx.id/core/inbox/model"
	_inbox_service "git.capitalx.id/core/inbox/service"
	"git.capitalx.id/core/notification/model"
	"git.capitalx.id/core/notification/repository"
)

//NotificationService is service to send notification
type NotificationService interface {
	SendNotification(model.NotificationMessage) error
	io.Closer
}

type notificationService struct {
	dataStore    repository.DataStore
	smsGateway   repository.SMSGateway
	mailer       repository.Mailer
	pushNotif    repository.PushService
	inboxService _inbox_service.InboxService
}

//NewNotificationService interface implementation
func NewNotificationService(dataStore repository.DataStore, smsgw repository.SMSGateway, mailer repository.Mailer, pushNotif repository.PushService, inboxService _inbox_service.InboxService) NotificationService {
	return &notificationService{dataStore: dataStore, smsGateway: smsgw, mailer: mailer, pushNotif: pushNotif, inboxService: inboxService}
}

func (ns *notificationService) SendNotification(msg model.NotificationMessage) error {
	if msg.NotificationID == "" {
		log.Print("Template ID  cannot be empty ")
		return errors.New("Invalid template id")
	}

	if msg.Recipient == "" {
		log.Print("Recipient value cannot be empty")
		return errors.New("Invalid recipient")
	}
	language := "id"
	if len(msg.Language) > 0 {
		language = msg.Language
	}

	if model.IsSMS(msg.Channel) {
		template, err := ns.dataStore.GetTemplate(model.SMS, msg.NotificationID, language)
		if err != nil {
			log.Print(err)
		} else {

			tmpl, err := text.New(msg.NotificationID).Parse(template.Message)
			if err != nil {
				log.Print(err)
			} else {
				var tmplbuf bytes.Buffer
				if err := tmpl.Execute(&tmplbuf, msg.Data); err != nil {
					log.Print(err)
				} else {
					message := tmplbuf.String()

					if err := ns.smsGateway.Send(repository.SMS{
						Mobile: msg.Recipient,
						Text:   message,
						OTP:    msg.Data["otp"] == "1",
					}); err != nil {
						log.Print(err)
					}
				}
			}
		}
	}
	if model.IsEmail(msg.Channel) {
		template, err := ns.dataStore.GetTemplate(model.EMAIL, msg.NotificationID, language)
		if err != nil {
			log.Print(err)
		} else {
			tmpl, err := html.New(msg.NotificationID).Parse(template.Message)
			if err != nil {
				log.Print(err)
			} else {
				var tmplbuf bytes.Buffer
				if err := tmpl.Execute(&tmplbuf, msg.Data); err != nil {
					log.Print(err)
				} else {
					message := tmplbuf.String()

					if err := ns.mailer.Send(repository.Email{
						Sender:     template.Sender,
						Recipients: []string{msg.Recipient},
						Subject:    template.Subject,
						Message:    message,
					}); err != nil {
						log.Print(err)
					}
				}
			}
		}
	}

	if model.IsPush(msg.Channel) {

		template, err := ns.dataStore.GetTemplate(model.PUSH, msg.NotificationID, language)
		if err != nil {
			log.Print(err)
		} else {

			tmpl, err := text.New(msg.NotificationID).Parse(template.Message)
			if err != nil {
				log.Print(err)
			} else {
				var tmplbuf bytes.Buffer
				if err := tmpl.Execute(&tmplbuf, msg.Data); err != nil {
					log.Print(err)
				} else {
					message := tmplbuf.String()

					// Send push notification
					deviceRegisterationToken := msg.Recipient
					if err := ns.pushNotif.Send(repository.Push{
						Sender:            msg.Sender,
						RegistrationToken: deviceRegisterationToken,
						Subject:           template.Subject,
						Message:           message,
						Data:              msg.Data}); err != nil {
						log.Print(err)
					}

					// Persist into inbox service
					persistInboxService(ns.inboxService, msg, template, message)
				}
			}
		}
	}

	return nil
}

// Persist into inbox service
func persistInboxService(inboxService _inbox_service.InboxService, msg model.NotificationMessage, template model.MessageTemplate, message string) {

	userID, err := strconv.Atoi(msg.Data["userID"])
	if err != nil {
		log.Print(err)
	}
	notifTypeID, err := strconv.Atoi(msg.Data["notificationTypeID"])
	if err != nil {
		log.Print(err)
	}
	createdBy, err := strconv.Atoi(msg.Data["createdBy"])
	if err != nil {
		log.Print(err)
	}
	if err != nil {
		log.Print(err)
	}

	_, err = inboxService.StoreNotification(context.Background(), &_inbox_model.NotificationInbox{
		Sender:             msg.Sender,
		Subject:            template.Subject,
		Message:            message,
		LandingURL:         msg.Data["landingurl"],
		UserID:             uint64(userID),
		NotificationTypeID: uint32(notifTypeID),
		CreatedBy:          uint64(createdBy),
		CreatedTime:        msg.Data["createdTime"]})

	if err != nil {
		log.Println("[services.notification] Error in persist to Inbox Service: ", err)
	}

}

func (ns *notificationService) Close() error {
	return ns.dataStore.Close()
}
