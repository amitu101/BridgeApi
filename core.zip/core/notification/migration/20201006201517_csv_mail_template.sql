-- +goose Up
-- SQL in this section is executed when the migration is applied.
insert into template(template_id, channel_type, language, sender, subject, message, created_time, created_by, updated_by)
values ('mail.csv.in', 2, 'en', '', 'CSV Upload Status', 'File {{.csvName}} has been processed. Total failed {{.failedCount}} failed amount {{.failedAmount}}, total success {{.successCount}} success amount {{.successAmount}}, total transaction {{.totalCount}} total amount {{.totalAmount}}', now(), 0, 0);

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
