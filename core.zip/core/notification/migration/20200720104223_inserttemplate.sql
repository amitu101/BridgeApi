/*dummy insert for push notification*/
insert into template(template_id, channel_type, language, sender, subject, message, created_time, created_by, updated_by)
values ('trx.topup.in', 4, 'id', '', 'Uang Masuk', 'Top-up saldo Anda senilai {{.topupAmount}} berhasil ditambahkan. Saldo dimii Anda saat ini {{.balance}}', now(), 0, 0);

