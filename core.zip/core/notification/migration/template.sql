insert into template(template_id, channel_type, language, sender, subject, message, created_time, created_by, updated_by)
values ('auth.otp', 1, 'id', '', '', 'Kode OTP: {{.code}}. Hati-hati penipuan! Kode OTP ini hanya untuk kamu, jangan pernah berikan ke siapapun. Pihak Dimii tidak pernah meminta kode ini', now(), 0, 0);
