package http

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func newRequest(method, url string) *http.Request {
	req, err := http.NewRequest(method, url, nil)
	if err != nil {
		panic(err)
	}
	return req
}

func TestCORS(t *testing.T) {
	r := newRequest("GET", "http://www.example.com")
	rr := httptest.NewRecorder()

	testHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {})

	CORS(testHandler).ServeHTTP(rr, r)

	if got, want := rr.Code, http.StatusOK; got != want {
		t.Fatalf("bad status: got %v want %v", got, want)
	}
}

func TestDefaultHandler(t *testing.T) {
	r := newRequest("GET", "http://www.example.com")
	rr := httptest.NewRecorder()

	testHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {})

	DefaultHandler(testHandler).ServeHTTP(rr, r)

	if got, want := rr.Code, http.StatusOK; got != want {
		t.Fatalf("bad status: got %v want %v", got, want)
	}
}
