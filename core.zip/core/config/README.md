<h1>Config Service</h1>

Config service is general interface to get configuration for services. The configuration itself can be stored in any kind of mechanism like environment variable, file, or key value store like etcd or consul.
Some configuration may contain sensitive data like password or cryptographic key. This kind of configuration need special storage that support data encryption. HashiCorp Vault is one that support this.

<h3>Type</h3>

Configuration can be a native type like character, integer, double, string or a common structure like array or map.
List of ip address is an example for an array structure. The database connection is other example that may be stored in map structure since it contains multiple configuration like url, username and password. 

<h3>Dynamic Configuration</h3>

Config service need to support dynamic configuration at runtime, so service doesn't need to be restarted when admin change the configuration.
Config service should have watch mechanism that listen to configuration change and do something to reload the service with new configuration.