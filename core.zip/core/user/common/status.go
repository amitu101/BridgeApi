package common

const (
	//success
	PermissionSuccess    = 100
	CreateRoleSuccess    = 101
	UpdateRoleSuccessful = 102
	GettingOTPSuccess    = 103
	BlockUserSuccess     = 104
	UnBlockUserSuccess   = 105
	TokenVerified        = 106

	//Failure
	RoleNameTaken          = 200
	PermNotAvailable       = 201
	RoleNameNotAvailable   = 202
	UpdateRoleUnsuccessful = 203
	OTPNotFound            = 204
	BlockUserUnSuccess     = 205
	UnBlockUserUnSuccess   = 206
	UserBlockedAlready     = 207
	UserUnblockedAlready   = 208
	InvalidUserStatus      = 209
	UserNotFound           = 210
	TokenInvalid           = 211
	TokenExpired           = 212
	RoleIdNotAvailable     = 213
	UserExistsForRole      = 214

	//User Status Code
	UserActiveStatus           = 1
	UserInActiveStatus         = 2
	UserBlockedStatus          = 3
	UserDeletedStatus          = 4
	UserPermanentBlockedStatus = 5
	UserInvitedStatus          = 6

	//User Role Status Code
	UserRoleActiveStatus   = 1
	UserRoleInactiveStatus = 2
	UserRoleDeletedStatus  = 3

	//Application ID
	DimiiLandApplicationID = 1
)

func GetMessage(id uint32) string {
	keyValueMap := map[uint32]string{
		PermissionSuccess:      "Successfully got permissions",
		CreateRoleSuccess:      "Create New Role Successful",
		RoleNameTaken:          "Role Name already taken",
		PermNotAvailable:       "Permissions not available",
		RoleNameNotAvailable:   "Role Name not available to update",
		UpdateRoleUnsuccessful: "Edit Role unsuccessful",
		UpdateRoleSuccessful:   "Edit Role successful",
		OTPNotFound:            "OTP data not found",
		GettingOTPSuccess:      "Getting OTP Code successful",
		TokenVerified:          "Token Verified",
		RoleIdNotAvailable:    "Role ID not available",
		BlockUserSuccess:     "Block User Successful",
		BlockUserUnSuccess:   "Block User Unsuccessful",
		UserExistsForRole:    "This role is registered with existing user",
		UnBlockUserSuccess:   "Unblock User Successful",
		UnBlockUserUnSuccess: "Unblock User Unsuccessful",
		UserBlockedAlready:   "User already blocked",
		UserUnblockedAlready: "User already unblocked",
		InvalidUserStatus:    "Acceptable User status: 1 - Unblock , 5 - Block",
		UserNotFound:         "User not found",
		TokenInvalid:         "Token Invalid",
		TokenExpired:         "Token Expired"}
	value, _ := keyValueMap[id]
	return value
}
