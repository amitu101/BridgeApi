package authprovider

import (
	"context"
	"database/sql"
	"log"

	errHdlr "git.capitalx.id/core/common/error"
	"git.capitalx.id/core/user/jwt"
	"git.capitalx.id/core/user/repository"
	"git.capitalx.id/core/user/utils"
	"google.golang.org/grpc/codes"
)

const (
	otpNotifID                = "auth.otp"
	otpMessage                = "Kami mengirimkan kamu kode verifikasi ke nomor ponsel "
	incorrectPasscodeMessage  = "The pass code you entered is incorrect. Please try again"
	failedSendMessage         = "Failed to sending message: "
	failedUpdateDeviceMessage = "failed update to user device"
)

var (
	letterRunes             = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	digitLength             = 6          // digit length otp code
	expiredPeriod           = uint(300)  // how long otp can be consumed
	counterLimit            = 5          // how many times user can input failure code
	resendCounterLimit      = 3          // how many times user can request resend otp code
	blockedDuration         = uint(900)  // duration until user permitted to request resend otp in second
	passCodeCounterLimit    = 5          // how many times user can input failure passCode
	passCodeBlockedDuration = int64(900) // duration until user permitted to input passCode again in second
	blockTime               = 60         //Duration in Mins
	countdownResendOTP      = 60         // countdown duration per resend otp in second
)

type dbAuthentication struct {
	//UService service.UserService
	userRepos      repository.CacheUserRepository
	userMariaRepos repository.SqlUserRepository
	signer         jwt.Signer
}

func NewDbAuth(c repository.CacheUserRepository, m repository.SqlUserRepository, s jwt.Signer) AuthProvider {
	return &dbAuthentication{c, m, s}
}

const (
	StatusUserDeviceUnblocked = 1
	StatusUserDeviceBlocked   = 2
)

func (u *dbAuthentication) Login(ctx context.Context, userName, passCode string) (bool, error) {
	passCodeDB, err := u.userMariaRepos.GetPassCodeByUserName(userName)
	if err != nil {
		if err == sql.ErrNoRows {
			errMsg := "There is no record found or Not Registered User:" + userName
			errHndlr := errHdlr.ServiceError{
				Code:    "PASSCODE_NOT_FOUND",
				Status:  codes.NotFound,
				Message: errMsg,
			}
			log.Println("There is no record found :", userName)
			return false, errHndlr
		}
		errMsg := "There is an error when getting Passcode, Username :" + userName
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There is no record found :", userName)
		return false, errHndlr
	}

	_, errVerification := VerifyingPassCode(passCode, passCodeDB)
	if errVerification != nil {
		errMsg := "There is an error when verifying passcode"
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		return false, errHndlr
	}
	return true, nil
}

func VerifyingPassCode(passCodeInput, passCode string) (bool, error) {
	match, err := utils.ComparePasswordAndHash(passCodeInput, passCode)
	if err != nil {
		log.Print(err)
		return false, err
	}
	return match, nil
}
