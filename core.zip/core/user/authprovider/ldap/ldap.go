package ldap

import (
	"crypto/tls"
	"fmt"
	"log"
	"strings"

	"github.com/go-ldap/ldap"
)

type Config struct {
	Host      string
	Port      string
	BindDN    string
	Password  string
	TlSEnable bool
	CA        []byte
	Cert      []byte
	Key       []byte
	SearchDN  string
}
type Ldap struct {
	Conn     *ldap.Conn
	BindDN   string
	BindPass string
	SearchDN string
}

func LDAP(config Config) (*Ldap, error) {
	tlsConfig := WithCertificate(config.Cert, config.Key)

	ldapConn, err := ldap.DialTLS("tcp", fmt.Sprintf("%s:%s", config.Host, config.Port), tlsConfig)
	if err != nil {
		log.Println("ldap connection error", err)
		return nil, err
	}

	//defer ldapConn.Close()

	// bind using basedn
	err = ldapConn.Bind(config.BindDN, config.Password)
	if err != nil {
		log.Println("ldap connection error with supplied credentials", err)
		return nil, err
	}

	return &Ldap{
		Conn:     ldapConn,
		BindDN:   config.BindDN,
		BindPass: config.Password,
		SearchDN: config.SearchDN,
	}, nil
}

func GetDomainFromUserName(userName string) (string, string, error) {
	var domain string
	res := strings.Split(userName, "@")
	uid := res[0]
	domain = res[1]
	return uid, domain, nil
}

func WithCertificate(cert, key []byte) *tls.Config {
	keyPair, err := tls.X509KeyPair(cert, key)
	if err != nil {
		return nil
	}

	tlsCfg := &tls.Config{
		Certificates: []tls.Certificate{keyPair},
	}

	return tlsCfg
}
