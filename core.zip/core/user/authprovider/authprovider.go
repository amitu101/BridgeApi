package authprovider

import (
	"context"
	"fmt"
	"log"
	"runtime/debug"
	"time"

	"git.capitalx.id/core/id/service"
	ldap2 "git.capitalx.id/core/user/authprovider/ldap"
	"git.capitalx.id/core/user/jwt"
	models "git.capitalx.id/core/user/model"
	mariaRepo "git.capitalx.id/core/user/repository"
	"github.com/go-ldap/ldap"
)

type AuthProvider interface {
	Login(ctx context.Context, userName, passWord string) (bool, error)
}

const (
	ldapServer       = "ldap.forumsys.com"
	ldapPort         = 389
	ldapBindDN       = "cn=read-only-admin,dc=example,dc=com"
	ldapPassword     = "password"
	ldapSearchDN     = "dc=example,dc=com"
	StatusUserActive = 1
)

type ldapAuthentication struct {
	Ldap       *ldap2.Ldap
	Signer     jwt.Signer
	seqService service.SequenceService
	mariaRepo  mariaRepo.SqlUserRepository
}

func NewLdapAuth(c *ldap2.Ldap, s jwt.Signer, seq service.SequenceService, repository mariaRepo.SqlUserRepository) AuthProvider {
	return &ldapAuthentication{
		Ldap:       c,
		Signer:     s,
		seqService: seq,
		mariaRepo:  repository,
	}
}

//func (l *ldapAuthentication) Login(ctx context.Context, userName, passWord string) (*models.LoginResponse, error) {
func (l *ldapAuthentication) Login(ctx context.Context, userName, passWord string) (bool, error) {
	defer func() {
		if err := recover(); err != nil {
			fmt.Println(err, " ldapAuthentication Login execption : ", string(debug.Stack()))
		}
	}()
	uid, _, _ := ldap2.GetDomainFromUserName(userName)
	// construct search query based on uid/username
	searchRequest := ldap.NewSearchRequest(l.Ldap.SearchDN, ldap.ScopeWholeSubtree, ldap.NeverDerefAliases,
		0, 0, false,
		fmt.Sprintf("(&(objectClass=organizationalPerson)(uid=%s))", uid),
		//fmt.Sprintf("(uid=%s)", uid),
		[]string{"dn", "cn", "sn", "mail"},
		nil,
	)
	// perform the search, validate it's result
	sr, err := l.Ldap.Conn.Search(searchRequest)
	if err != nil {
		return false, err
	}

	if len(sr.Entries) == 0 {
		return false, fmt.Errorf("user not found")
	}

	fmt.Println("-------------------")
	sr.Entries[0].PrettyPrint(1)
	fmt.Println("-------------------")

	// verify user password by binding to user dn (with user password)
	err = l.Ldap.Conn.Bind(sr.Entries[0].DN, passWord)
	if err != nil {
		log.Println("ldapAuthentication Unable to Verify User and Password with ldap")
		return false, err
	}
	log.Println("Successfully to Verify User and Password with ldap")

	return true, nil
}

func StoreUser(ctx context.Context, user *models.User, sequenceService service.SequenceService, repository mariaRepo.SqlUserRepository) (uint64, error) {

	newId, err := sequenceService.GetIdNextVal(ctx)
	if err != nil {
		log.Println("Unable to get ID from ID Generator Service when storing user, user :" + user.Name)
		return 0, err
	}

	//uniqueRand := utils.GenerateDigitRandomUnique()
	id := newId.Value
	createdBy := id
	createdTime := time.Now()
	user.Mobile = ""
	user.Status = StatusUserActive
	user.CreatedBy = createdBy
	user.CreatedTime = createdTime
	user.UpdatedTime = createdTime
	user.UpdatedBy = createdBy

	resp, err := repository.MariaStoreUser(id, "", user)
	if err != nil {
		return 0, err
	}
	return resp, nil
}
