package repository

import (
	"context"
	"database/sql"
	"log"
	"net/http"

	"git.capitalx.id/core/user/common"
	models "git.capitalx.id/core/user/model"
)

const (
	selectUserDevice = "select mobile, device_id, expired_device_id_blocked, counter, status, device_reg_token from user_device " +
		"where mobile = ? and device_id = ?"
	selectUserDeviceByMobileNumber = `SELECT ud.mobile, ud.device_id, ud.expired_device_id_blocked, ud.counter, 
		ud.status, ud.device_reg_token
		FROM user_device  ud
		JOIN user u ON u.device_id = ud.device_id
			 AND u.mobile = ud.mobile
		WHERE u.mobile = ?`
	insertUserDevice = "insert into user_device(mobile, device_id, expired_device_id_blocked, counter, status, device_reg_token) " +
		"values (?,?,?,?,?,?)"
	updateUserDevice = "update user_device set expired_device_id_blocked = ?, counter = ?, status = ? where " +
		"mobile = ? and device_id = ?"
	updateDeviceToken     = "update user_device set device_reg_token = ? where mobile = ? and device_id = ?"
	selectUserDeviceCount = `SELECT count(device_id) last_blocked
		FROM user_device WHERE mobile IN (SELECT mobile FROM user WHERE id=?)`
	selectUserDeviceByUserID = `SELECT  device_id, counter, status, last_login, last_blocked 
		FROM user_device WHERE mobile IN (SELECT mobile FROM user WHERE id=?) LIMIT ? , ?`
)

func (m *mariaUserRepository) getUserDevice(query string, params ...interface{}) (models.UserDevice, error) {
	ud := models.UserDevice{}

	err := m.Conn.QueryRow(query, params...).Scan(&ud.Mobile, &ud.DeviceID,
		&ud.ExpiredDeviceIDBlocked, &ud.Counter, &ud.Status, &ud.DeviceRegToken)
	if err != nil && err != sql.ErrNoRows {
		return models.UserDevice{}, err
	}
	return ud, nil
}
func (m *mariaUserRepository) CheckStatusByDeviceID(mobileNumber, deviceID string) (models.UserDevice, error) {
	return m.getUserDevice(selectUserDevice, mobileNumber, deviceID)
}

func (m *mariaUserRepository) GetUserDeviceByMobileNumber(mobileNumber string) (models.UserDevice, error) {
	return m.getUserDevice(selectUserDeviceByMobileNumber, mobileNumber)
}

func (m *mariaUserRepository) StoreUserDevice(req *models.UserDevice) (string, error) {
	_, err := m.Conn.Exec(insertUserDevice, req.Mobile, req.DeviceID, req.ExpiredDeviceIDBlocked, req.Counter, req.Status, req.DeviceRegToken)
	if err != nil {
		return "failed", err
	}

	return "Succeeded", nil
}

func (m *mariaUserRepository) UpdateUserDevice(req *models.UserDevice) (string, error) {
	_, err := m.Conn.Exec(updateUserDevice, req.ExpiredDeviceIDBlocked, req.Counter, req.Status, req.Mobile, req.DeviceID)
	if err != nil {
		return "failed", err
	}

	return "Succeeded", nil
}

func (m *mariaUserRepository) UpdateUserDeviceToken(mobileNumber, deviceID, deviceToken string) (int64, error) {

	result, err := m.Conn.Exec(updateDeviceToken, deviceToken, mobileNumber, deviceID)

	if err != nil {
		log.Print(err)
		return 0, err
	}
	r, err := result.RowsAffected()
	if err != nil {
		log.Print(err)
		return 0, err
	}

	return r, nil
}

func (m *mariaUserRepository) GetUserDeviceByUserID(ctx context.Context, p *models.UserDeviceListRequest) (*common.HTTPResponse, error) {
	var rowCount uint64
	e := m.Conn.QueryRow(selectUserDeviceCount, p.ID).Scan(&rowCount)
	if e != nil {
		if e == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", e)
			return &common.HTTPResponse{Data: make([]*models.UserGroupPermissions, 0), Message: "Permissions not available", HTTPstatus: http.StatusNotFound}, nil
		} else {
			log.Printf("[repository:maria_user] ListPermissions count db query err: %s \n", e)
			return nil, models.ErrInternalServerError
		}

	}
	var index, count uint64
	if p.PageNumber != 0 && p.Count != 0 {
		index = (p.PageNumber * p.Count) - p.Count
		count = p.Count
	} else {
		index = 0
		count = rowCount
	}

	data := []models.UserDeviceResponce{}
	ud := models.UserDeviceResponce{}
	qry, err := m.Conn.Query(selectUserDeviceByUserID, p.ID, index, count)

	if err != nil {
		log.Print("[repository:maria_user] selectUserDeviceByUserID row parse err: ", err)
		return nil, models.ErrInternalServerError
	}
	var LastBlocked, LastLogin sql.NullString
	for qry.Next() {
		err = qry.Scan(
			&ud.DeviceID,
			&ud.Counter,
			&ud.Status,
			&LastLogin,
			&LastBlocked,
		)
		ud.LastBlocked = LastBlocked.String
		ud.LastLogin = LastLogin.String
		if err != nil {
			if err == sql.ErrNoRows {
				return &common.HTTPResponse{Message: "No user/device found", Length: 0}, nil
			}
			log.Print("[repository:maria_user] selectUserDeviceByUserID row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		data = append(data, ud)
	}
	// return &data, nil
	return &common.HTTPResponse{Data: data, Length: rowCount}, nil
}
