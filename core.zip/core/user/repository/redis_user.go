package repository

import (
	"context"
	"time"

	"github.com/go-redis/redis/v7"

	models "git.capitalx.id/core/user/model"
)

type redisUserRepository struct {
	Conn *redis.ClusterClient
}

// NewRedisUserRepository will create an object that represent the user.Repository interface
func NewRedisUserRepository(Conn *redis.ClusterClient) CacheUserRepository {

	return &redisUserRepository{Conn}
}

func (r *redisUserRepository) StoreOTP(ctx context.Context, key string, req *models.GenerateOTP, counter int, expiredPeriod int32) error {
	expiredTime := time.Duration(expiredPeriod) * time.Second
	value := map[string]interface{}{
		"otp_code": req.OtpCode,
		"secret":   req.Secret,
		"counter":  counter,
		"status":   req.Status,
	}

	err := r.Conn.HMSet(key, value).Err()
	if err != nil {
		return err
	}

	_ = r.Conn.Expire(key, expiredTime)

	return nil
}

func (r *redisUserRepository) GetValueOTP(ctx context.Context, key string) (map[string]string, error) {
	val, err := r.Conn.HGetAll(key).Result()
	if err != nil {
		return nil, err
	}

	return val, nil
}

func (r *redisUserRepository) DeleteOTP(ctx context.Context, key string) bool {
	err := r.Conn.Del(key).Err()
	if err != nil {
		return false
	}

	return true
}

func (r *redisUserRepository) GetRemainingTimeOTP(ctx context.Context, key string) int32 {
	ttl, _ := r.Conn.TTL(key).Result()

	remaining := int32(ttl / time.Second)

	return remaining
}

func (r *redisUserRepository) StoreResendOTP(ctx context.Context, key, status string, counter int, expiredPeriod int32) error {
	expiredTime := time.Duration(expiredPeriod) * time.Second
	var value map[string]interface{}
	value = map[string]interface{}{
		"counter": counter,
		"status":  status,
	}

	err := r.Conn.HMSet(key, value).Err()
	if err != nil {
		return err
	}

	_ = r.Conn.Expire(key, expiredTime)

	return nil
}

func (r *redisUserRepository) StoreEmailToken(key string, token string, expiredPeriod int32) error {
	expiredTime := time.Duration(expiredPeriod) * time.Second
	value := map[string]interface{}{
		"email_token": token}
	err := r.Conn.HMSet(key, value).Err()
	if err != nil {
		return err
	}
	_ = r.Conn.Expire(key, expiredTime)

	return nil
}

func (r *redisUserRepository) GetEmailToken(ctx context.Context, key string) (string, error) {
	token, err := r.Conn.HGet(key, "email_token").Result()
	if err != nil {
		return "", err
	}
	return token, nil
}

func (r *redisUserRepository) GetAccountLinkageKeyValue(ctx context.Context, key, hashkey string) (string, error) {
	val, err := r.Conn.HGet(key, hashkey).Result()
	if err != nil {
		return val, err
	}
	return val, nil
}

func (r *redisUserRepository) SetAccountLinkageKeyValue(ctx context.Context, key, hashkey string, value bool) error {
	hash := map[string]interface{}{hashkey: value}
	err := r.Conn.HMSet(key, hash).Err()
	if err != nil {
		return err
	}
	return nil
}
