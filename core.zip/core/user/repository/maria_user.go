package repository

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"strconv"
	"strings"
	"time"

	"git.capitalx.id/core/user/common"
	models "git.capitalx.id/core/user/model"
)

type mariaUserRepository struct {
	Conn *sql.DB
}

// NewMariaUserRepository will create an object that represent the user.Repository interface
func NewMariaUserRepository(Conn *sql.DB) SqlUserRepository {
	return &mariaUserRepository{Conn}
}

const (
	dimmiLandAccess = "dimiiland"
	dimmiAppAccess  = "dimiiapp"

	insertUser = "INSERT INTO user(id, name, username, mobile, email, passcode, device_id, status, created_by," +
		"created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
	selectStatus       = "SELECT status FROM user WHERE mobile = ?"
	selectPassCode     = "SELECT passcode FROM user WHERE mobile = ?"
	getPassCodeByUname = "SELECT passcode FROM user WHERE username = ?"
	selectUser         = `SELECT id, COALESCE(username, "") AS username, COALESCE(name, "") AS name, mobile,
					COALESCE(email, "") AS email, COALESCE(device_id, "") AS device_id, status FROM user WHERE mobile = ?`
	selectDimiilandUserByEmail = `SELECT u.id, COALESCE(u.username, "") AS username, COALESCE(u.name, "") AS name, u.mobile, COALESCE(u.email, "") AS email, COALESCE(u.device_id, "") AS device_id, u.status  from user u
	inner join user_application ua on ua.user_id = u.id
	inner join application a on a.id = ua.application_id
	where u.email = ? and a.id=? and u.status = ? `
	blockUser           = `UPDATE user SET status = ? WHERE mobile = ?`
	deleteUser          = `DELETE FROM user WHERE mobile = ?`
	resetPasscode       = `UPDATE user SET passcode = ? WHERE mobile = ?`
	getDimilandUserList = "select u.id, u.email, u.status, u.last_login, r.name from user u " +
		"inner join user_role ur on ur.user_id = u.id " +
		"inner join role r on r.id = ur.role_id " +
		"inner join user_application ua on ua.user_id = u.id " +
		"inner join application a on a.id = ua.application_id " +
		"where "
	queryByRole                   = `select role.name as role_name,role.description as role_description, permission.name as permission_name,permission.description as permission_description,permission.id,role.id from role,role_permission,permission where role_permission.role_id=role.id and permission.id=role_permission.permission_id and role.name LIKE ? and role_permission.status = 1 and role.status=1 order by role.created_time Desc;`
	getRole                   = `select role.name as role_name,role.description as role_description, permission.name as permission_name,permission.description as permission_description,permission.id,role.id from role,role_permission,permission where role_permission.role_id=role.id and permission.id=role_permission.permission_id and role.name = ? and role_permission.status = 1 and role.status = 1 ;`
	selectRoleByID             = `select name from role where id = ? and status = 1 `
	queryByPermission             = `select role.name as role_name,role.description as role_description, permission.name as permission_name,permission.description as permission_description,permission.id,role.id from role,role_permission,permission where role_permission.role_id=role.id and permission.id=role_permission.permission_id and permission.name LIKE ? and role_permission.status = 1 and role.status =1 order by role.created_time Desc;`
	getPermissions                = `select id, name, description, status, group_id, group_name from permission LIMIT ? , ?` //ORDER BY created_time  ASC
	getPermissionsCount           = `select COUNT(*) from permission `
	insertRole                    = `insert into role(name, description, status, created_by, created_time, updated_by, updated_time) value (?,?,?,?,?,?,?) `
	updateRole                    = `update role set description= ?, status= ?, updated_by= ?, updated_time = ? where name= ?`
	selectRolesCount              = `SELECT COUNT(role_id) FROM user_role WHERE role_id = ?`
	selectRolesCountBasedOnRoleID = "SELECT COUNT(*) FROM role WHERE id in "
	updateeRoleStatus             = `update role set status= ? where id = ? `
	insertRolePermisssions        = `insert into role_permission(role_id, permission_id, status, created_by, created_time, updated_by, updated_time) value (?,?,?,?,?,?,?) `
	deleteRolePermisssions       = `update role_permission set status = 0 where role_id = ? `
	updateRolePermisssions       = `update role_permission set status = 1 where role_id = ? and permission_id = ? `
	selectRoleByName              = `select id, name from role where name = ?`
	selectStatusByMail            = "SELECT id, status  FROM user WHERE email = ?"
	insertNewUser                 = "INSERT INTO user (id, username, email, status, created_by, created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?,?)"
	updateDeviceID                = "UPDATE user SET device_id = ? WHERE mobile = ?"
	selectUserPermissionList      = "SELECT id,name,description FROM permission WHERE status = ?"
	selectUserRolePermissionList  = "SELECT role_id,permission_id FROM role_permission WHERE status = ?"
	selectUserRolesList           = "SELECT role.id, role.name,role.description FROM role WHERE status = ? ORDER BY created_time Desc LIMIT ? , ?"
	selectUserRolesCount          = "SELECT COUNT(id) FROM role WHERE status = ?"
	selectUserByUserName          = `select application.name from user,user_application,application where user.id = user_application.user_id and user_application.application_id = application.id and user.username = '%s' ;`
	queryUserRoleByUserName       = `select role.name as role_name,permission.id as permission_id,permission.name as permission_name from user,user_role,role,role_permission,permission where user.id=user_role.user_id and user_role.role_id=role.id and role.id=role_permission.role_id and role_permission.permission_id=permission.id and user.username = '%s' ;`
	selectRolesByUserID           = "SELECT role_id FROM user_role WHERE user_id = ?;"
	deleteUserRole                = "UPDATE user_role SET status = ? WHERE role_id = ? AND user_id=?;"
	addUserRole                   = "INSERT INTO user_role (role_id, user_id, status, created_by, created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?);"
	selectPermissionByUserID      = "SELECT DISTINCT " +
		"u.id as user_id,u.username as user_name " +
		",p.id as permission_id,p.name as permission_name " +
		",p.status as permission_status,p.description as permission_desc " +
		"FROM user u " +
		"left join user_role ur on ur.user_id = u.id and ur.status = 1 " +
		"left join role_permission rp on rp.role_id = ur.role_id and rp.status = 1 " +
		"left join role r on r.id = rp.role_id and r.status = ? " +
		"left join permission p on p.id = rp.permission_id and p.status = ? " +
		"where u.id = ? and u.status = 1"
	blockUserByUserID   = `UPDATE user SET status = ?, block_reason = ? WHERE id = ?;`
	unblockUserByUserID = `UPDATE user SET status = ? WHERE  id = ?;`
	selectUserbyUserID  = `SELECT id, COALESCE(username, "") AS username, COALESCE(name, "") AS name, mobile,
					COALESCE(email, "") AS email, COALESCE(device_id, "") AS device_id, status FROM user WHERE id = ?`
	UpdateUserStatusByUserName = "UPDATE user SET status=%v where username='%v' ;"
	inserUserApplicationType   = "INSERT INTO user_application (user_id, application_id, status, created_by, created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?);"
	GetCount                   = `select count(*) from permission p where id in `
	storeDimiilandUserPassword = "UPDATE user SET passcode = ?,status = ? WHERE id = ?;"
)

func (m *mariaUserRepository) MariaStoreUser(ID uint64, passCode string, u *models.User) (uint64, error) {
	_, err := m.Conn.Exec(insertUser, ID, u.Name, u.Username, u.Mobile, u.Email, passCode, u.DeviceID, u.Status,
		u.CreatedBy, u.CreatedTime, u.UpdatedBy, u.UpdatedTime)
	if err != nil {
		return 0, err
	}

	return ID, nil
}

func (m *mariaUserRepository) CheckStatusByPhoneNumber(mobileNumber string) (int, error) {
	var status int

	log.Println("Mobile Number :", mobileNumber)
	err := m.Conn.QueryRow(selectStatus, mobileNumber).Scan(&status)
	if err != nil {
		if err == sql.ErrNoRows {
			// there were no rows, but otherwise no error occurred
			return -1, nil
		} else {
			return 0, err
		}
	}

	log.Println("status berapa : ", status)

	return status, nil
}

func (m *mariaUserRepository) GetPassCodeByPhoneNumber(mobileNumber string) (string, error) {
	var passCode string

	err := m.Conn.QueryRow(selectPassCode, mobileNumber).Scan(&passCode)
	if err != nil {
		return "", err
	}

	return passCode, nil
}

func (m *mariaUserRepository) GetPassCodeByUserName(username string) (string, error) {
	var passCode string

	err := m.Conn.QueryRow(getPassCodeByUname, username).Scan(&passCode)
	if err != nil {
		return "", err
	}

	return passCode, nil
}

func (m *mariaUserRepository) fetch(query string, args ...interface{}) ([]*models.User, error) {
	rows, err := m.Conn.Query(query, args...)
	if err != nil {
		log.Print(err)
		return nil, models.ErrInternalServerError
	}

	defer closeRows(rows)

	result := make([]*models.User, 0)
	for rows.Next() {
		u := new(models.User)
		err = rows.Scan(
			&u.ID,
			&u.Username,
			&u.Name,
			&u.Mobile,
			&u.Email,
			&u.DeviceID,
			&u.Status,
		)

		result = append(result, u)
	}

	return result, nil
}

func (m *mariaUserRepository) GetUserByPhoneNumber(_ context.Context, mobileNumber string) (*models.User, error) {
	list, err := m.fetch(selectUser, mobileNumber)
	if err != nil {
		return nil, err
	}

	if len(list) <= 0 {
		return nil, models.ErrNotFound
	}

	return list[0], nil
}

func (m *mariaUserRepository) GetDimiilandUserByEmail(_ context.Context, email string, userStatus uint64) (*models.User, error) {
	list, err := m.fetch(selectDimiilandUserByEmail, email, common.DimiiLandApplicationID, userStatus)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, common.AppErrorCode(common.UserNotFound)
		}
		return nil, err
	}

	if len(list) <= 0 {
		return nil, common.AppErrorCode(common.UserNotFound)
	}

	return list[0], nil
}

func (m *mariaUserRepository) BlockUser(_ context.Context, mobileNumber string, status int) (string, error) {
	_, err := m.Conn.Exec(blockUser, status, mobileNumber)
	if err != nil {
		return "", err
	}

	return "Successfully blocked", nil
}

func (m *mariaUserRepository) DeleteUser(_ context.Context, mobileNumber string) (string, error) {
	_, err := m.Conn.Exec(deleteUser, mobileNumber)
	if err != nil {
		return "", err
	}

	return "Deleted", nil
}

func (m *mariaUserRepository) UpdatePasscode(ctx context.Context, mobileNumber, passcode string) (int64, error) {
	result, err := m.Conn.Exec(resetPasscode, passcode, mobileNumber)

	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}
	r, err := result.RowsAffected()
	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}

	return r, nil
}

func closeRows(rows *sql.Rows) {
	if err := rows.Close(); err != nil {
		log.Print(err)
	}
}

func (m *mariaUserRepository) GetDimiilandUsersList(ctx context.Context, params map[string]string) (*[]models.DimilandUsers, uint64, error) {
	data := []models.DimilandUsers{}
	ud := models.DimilandUsers{}
	var sqlStatement string = getDimilandUserList
	var count uint64 = 0
	//where conditions
	sqlStatement += "a.name = '" + params["userType"] + "'"
	if len(params["email"]) > 0 {
		sqlStatement += " and u.email like '%" + params["email"] + "%'"
	}
	if params["status"] == "" {
		sqlStatement += " and u.status != 4"
	} else {
		splitStatus := strings.Split(params["status"], ",")
		i := 0
		inStringStatus := "("
		for _, val := range splitStatus {
			inStringStatus += val
			if i != len(splitStatus)-1 {
				inStringStatus += ","
			}
			i++
		}
		inStringStatus += ")"
		sqlStatement += " and u.status in " + inStringStatus
	}
	if len(params["role"]) > 0 {
		splitRole := strings.Split(params["role"], ",")
		i := 0
		inStringRole := "("
		for _, val := range splitRole {
			inStringRole += "'" + val + "'"
			if i != len(splitRole)-1 {
				inStringRole += ","
			}
			i++
		}
		inStringRole += ")"
		sqlStatement += " and r.name in " + inStringRole
	}
	sqlStatement += " and ur.status != 3 "
	countQuery := sqlStatement
	if len(params["order_by_column"]) > 0 {
		sqlStatement += " order by " + params["order_by_column"]
	}
	if params["ascending"] == "true" {
		sqlStatement += " desc "
	}
	sqlStatement += " group by u.id, r.name "
	sqlStatement += " limit " + params["limit"]

	limit, _ := strconv.Atoi(params["limit"])
	pageNumber, _ := strconv.Atoi(params["page_number"])
	pageNumber = pageNumber - 1
	if pageNumber <= 0 {
		pageNumber = 0
	}
	offset := strconv.Itoa(limit * pageNumber)
	sqlStatement += " offset " + offset
	sqlStatement += `;`

	qry, err := m.Conn.Query(sqlStatement)
	if err != nil {
		return &data, count, err
	}
	for qry.Next() {
		err = qry.Scan(
			&ud.ID,
			&ud.Email,
			&ud.Status,
			&ud.LastLogin,
			&ud.Role,
		)
		if err != nil {
			return &data, count, err
		}
		data = append(data, ud)
	}
	//count
	splitForCountQuery := strings.Split(countQuery, "from")
	finalCountQuery := "select count(u.id) from " + splitForCountQuery[1]
	cQry, err := m.Conn.Query(finalCountQuery)
	if err != nil {
		return &data, count, err
	}
	for cQry.Next() {
		err := cQry.Scan(&count)
		if err != nil {
			return &data, count, err
		}
	}

	return &data, count, nil
}

func (m *mariaUserRepository) UserRoleByRoles(ctx context.Context, role string) ([]models.RolePermissions, error) {
	result := make([]models.RolePermissions, 0)
	roleMap, err := m.GetRoles(queryByRole,"%"+role+"%")
	if err != nil {
		log.Print("UserRoleByRoles db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	// Inline REST API RESP
	for i, _ := range roleMap {
		result = append(result, roleMap[i])
	}
	return result, nil

}

func (m *mariaUserRepository) GetRole(ctx context.Context, roleId uint64) (models.RolePermissions, error) {
    var roles models.RolePermissions
	var roleName string
	err := m.Conn.QueryRow(selectRoleByID, roleId).Scan(&roleName)
	if err != nil || roleName == "" {
		log.Print("Id not found ")
		return roles , common.AppErrorCode(common.RoleIdNotAvailable)
	}
	roleMap, err := m.GetRoles(getRole,roleName)
	if err != nil {
		log.Print("UserRoleByRoles db query err: ", err)
		return roles, models.ErrInternalServerError
	}
	// Inline REST API RESP
	return models.RolePermissions{
		Name:        roleMap[roleName].Name,
		Description: roleMap[roleName].Description,
		Status:      roleMap[roleName].Status,
		Permissions: roleMap[roleName].Permissions,
	},nil

}

func (m *mariaUserRepository) GetRoles(query string,params ...interface{}) (map[string]models.RolePermissions, error) {
	rows, err := m.Conn.Query(query, params...)
	if err != nil {
		log.Print("UserRoleByRoles db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(rows)
	temp := map[string]models.RolePermissions{}
	for rows.Next() {
		var roleName, roleDescription string
		var roleID uint64
		perm := new(models.Permission)
		//role_name  | role_description | permission_name | permission_description
		err = rows.Scan(&roleName, &roleDescription, &perm.Name, &perm.Description,&perm.ID,&roleID)

		per := models.Permission{
			ID:          perm.ID,
			Name:        perm.Name,
			Description: perm.Description,
		}
		ura := models.RolePermissions{
			ID:          roleID,
			Name:        roleName,
			Description: roleDescription,
			Permissions: []models.Permission{per},
		}
		urpData, ok := temp[roleName]
		if !ok {
			temp[roleName] = ura
		} else {
			urpData.Permissions = append(urpData.Permissions, per)
			temp[roleName] = urpData
		}
	}
	return temp, nil
}

func (m *mariaUserRepository) UserRoleByPermissions(ctx context.Context, permission string) ([]models.RolePermissions, error) {
	rows, err := m.Conn.Query(queryByPermission, "%"+permission+"%")
	if err != nil {
		log.Print("UserRoleByPermissions db query err: ", err)
		return nil, models.ErrInternalServerError
	}

	defer closeRows(rows)

	result := make([]models.RolePermissions, 0)
	temp := map[string]models.RolePermissions{}
	for rows.Next() {
		var roleName, roleDescription string
		var roleID uint64
		perm := new(models.Permission)
		//role_name  | role_description | permission_name | permission_description
		err = rows.Scan(&roleName, &roleDescription, &perm.Name, &perm.Description,&perm.ID,&roleID)

		per := models.Permission{
			ID:          perm.ID,
			Name:        perm.Name,
			Description: perm.Description,
		}
		ura := models.RolePermissions{
			ID:          roleID,
			Name:        roleName,
			Description: roleDescription,
			Permissions: []models.Permission{per},
		}
		urpData, ok := temp[roleName]
		if !ok {
			temp[roleName] = ura
		} else {
			urpData.Permissions = append(urpData.Permissions, per)
			temp[roleName] = urpData
		}
	}

	// Inline REST API RESP
	for i, _ := range temp {
		result = append(result,temp[i])
	}
	return result, nil
}

func (m mariaUserRepository) ListPermissions(_ context.Context, p *models.PageRequest) (*common.HTTPResponse, error) {
	var rowCount uint64
	e := m.Conn.QueryRow(getPermissionsCount).Scan(&rowCount)
	if e != nil {
		if e == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", e)
			return nil, common.AppErrorCode(common.PermNotAvailable)
		} else {
			log.Printf("[repository:maria_user] ListPermissions count db query err: %s \n", e)
			return nil, models.ErrInternalServerError
		}

	}
	var index, count uint64
	if p.PageNumber != 0 && p.Count != 0 {
		index = (p.PageNumber * p.Count) - p.Count
		count = p.Count
	} else {
		index = 0
		count = rowCount
	}
	rows, err := m.Conn.Query(getPermissions, index, count)
	result := make([]*models.UserGroupPermissions, 0)

	if err != nil {
		if err == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", err)
			return nil, common.AppErrorCode(common.PermNotAvailable)
		} else {
			log.Print("[repository:maria_use r] ListPermissions db query err: ", err)
			return nil, models.ErrInternalServerError
		}

	}
	defer closeRows(rows)

	groupList := map[string]*models.UserGroupPermissions{}
	for rows.Next() {
		var groupID, groupName, permName, permDescription string
		var permID uint64
		var perStatus int64
		err = rows.Scan(&permID, &permName, &permDescription, &perStatus, &groupID, &groupName)

		if err != nil {
			log.Print("[repository:maria_user] ListPermissions row parse err: ", err)
			return nil, models.ErrInternalServerError
		}

		perm := new(models.Permission)
		perm.ID = permID
		perm.Name = permName
		perm.Description = permDescription
		perm.Status = perStatus

		permResult, ok := groupList[groupID]
		if !ok {
			permRs := make([]*models.Permission, 0)
			permRs = append(permRs, perm)
			grpList := &models.UserGroupPermissions{GroupID: groupID, GroupName: groupName, Permissions: permRs}
			groupList[groupID] = grpList
		} else {
			permResult.Permissions = append(permResult.Permissions, perm)
			groupList[groupID] = permResult
		}
	}

	if len(groupList) == 0 {
		log.Print("[repository:maria_user] ListPermissions : No row found ")
		return nil, common.AppErrorCode(common.PermNotAvailable)
	}

	for _, val := range groupList {
		result = append(result, val)
	}
	return &common.HTTPResponse{Data: result, Message: common.GetMessage(common.PermissionSuccess), Length: rowCount}, nil

}

func (m mariaUserRepository) AddUserRole(_ context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error) {
	var roleName string
	var _roleID int64
	e := m.Conn.QueryRow(selectRoleByName, rp.Name).Scan(&_roleID, &roleName)

	if e != nil && e != sql.ErrNoRows {
		log.Printf("[maria_notification.repository] Exception in AdduserRole: get role by name %s \n", e)
		return nil, models.ErrInternalServerError
	}
	//Checking role name already used
	if roleName != "" {
		return nil, common.AppErrorCode(common.RoleNameTaken)
	}

	isValid, err := m.checkPermissions(rp.Permissions)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AdduserRole: check permissions %s \n", err)
		return nil, models.ErrInternalServerError
	}
	if isValid == false {
		return nil, common.AppErrorCode(common.PermNotAvailable)
	}
	// save role
	tx, err := m.Conn.Begin()
	result, err := m.Conn.Exec(insertRole, rp.Name, rp.Description, rp.Status, rp.CreatedBy, rp.CreatedTime, rp.UpdatedBy, rp.UpdatedTime)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AdduserRole: insert into role table %s \n", err)
		tx.Rollback()
		return nil, models.ErrInternalServerError
	}

	roleID, _ := result.LastInsertId()
	// save role permission mapping
	for _, permID := range rp.Permissions {
		_, err := m.Conn.Exec(insertRolePermisssions, roleID, permID, rp.Status, rp.CreatedBy, rp.CreatedTime, rp.UpdatedBy, rp.UpdatedTime)
		if err != nil {
			log.Printf("[maria_notification.repository] Exception in AdduserRole: insert into role_permission table %s \n", err)
			tx.Rollback()
			return nil, models.ErrInternalServerError
		}
	}
	tx.Commit()
	return &common.HTTPResponse{Message: common.GetMessage(common.CreateRoleSuccess)}, nil
}

func (m mariaUserRepository) UpdateUserRole(_ context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error) {
	var roleName string
	var roleID int64
	// check role name availabe to update
	err := m.Conn.QueryRow(selectRoleByName, rp.Name).Scan(&roleID, &roleName)
	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria_user.repository] Exception in UpdateUserRole: get role by name %s \n", err)
		return nil, models.ErrInternalServerError
	}
	// transaction begin here
	isValid, err := m.checkPermissions(rp.Permissions)
	if !isValid {
		log.Printf("[maria_user.repository] invalid permissions ")
		return nil, common.AppErrorCode(common.PermNotAvailable)
	}
	tx, err := m.Conn.Begin()
	if err != nil {
		log.Printf("[maria_user.repository] Error in connection: %s \n", err)
		return nil, models.ErrInternalServerError
	}
	//Update role
	result, err := m.Conn.Exec(updateRole,rp.Description, rp.Status,rp.UpdatedBy, rp.UpdatedTime, rp.Name)
	if err != nil {
		log.Printf("[maria_user.repository] Exception in UpdateUserRole: update into role table %s \n", err)
		tx.Rollback()
		return nil, models.ErrInternalServerError
	}

	row, err := result.RowsAffected()
	if err != nil {
		log.Printf("[maria_user.repository] Exception in UpdateUserRole: RowsAffected: update into role table %s \n", err)
		return nil, models.ErrInternalServerError
	}

	if row == 0 {
		return nil, common.AppErrorCode(common.UpdateRoleUnsuccessful)
	}
	// delete role permissions mapping
	result, err = m.Conn.Exec(deleteRolePermisssions, roleID)
	if err != nil {
		log.Printf("[maria_user.repository] Exception in UpdateUserRole: delete from role_permission %s \n", err)
		tx.Rollback()
		return nil, models.ErrInternalServerError
	}

	// save new role permissions mapping
	for _, permID := range rp.Permissions {
		result, err := m.Conn.Exec(updateRolePermisssions, roleID, permID)
		if err != nil {
			log.Printf("[maria_user.repository] Exception in UpdateUserPermission: update into role-permission table %s \n", err)
			tx.Rollback()
			return nil, models.ErrInternalServerError
		}
		updatedRows, err := result.RowsAffected()
		if err != nil {
			log.Printf("[maria_user.repository] Exception in UpdateUserPermission: update into role-permission table %s \n", err)
			return nil, models.ErrInternalServerError
		}
		if updatedRows == 0 {
			_, err := m.Conn.Exec(insertRolePermisssions, roleID, permID, rp.Status, rp.CreatedBy, rp.CreatedTime, rp.UpdatedBy, rp.UpdatedTime)
			if err != nil {
				log.Printf("[maria_user.repository] Exception in UpdateUserRole: update into role_permission table %s \n", err)
				tx.Rollback()
				return nil, models.ErrInternalServerError
			}
		}
	}
	err = tx.Commit()
	if err != nil {
		log.Printf("[maria_user.repository] Exception in UpdateUserRole: transaction commit %s \n", err)
		return nil, models.ErrInternalServerError
	}
	return &common.HTTPResponse{Message: common.GetMessage(common.UpdateRoleSuccessful)}, nil
}

func (m mariaUserRepository) DeleteUserRole(_ context.Context, roleID uint64) (string, error) {
	var rowCount uint64
	var deletedRoleStatus uint8 = 4
	e := m.Conn.QueryRow(selectRolesCount, roleID).Scan(&rowCount)
	if e != nil {
		log.Printf("[repository:maria_user] roles count db query err: %s \n", e)
		return "", models.ErrInternalServerError
	}

	if rowCount > 0 {
		return "", common.AppErrorCode(common.UserExistsForRole)
	}

	// delete role
	_, err := m.Conn.Exec(updateeRoleStatus, deletedRoleStatus, roleID)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in DeleteUserRole: delete from role %s \n", err)
		return "", models.ErrInternalServerError
	}
	return "success", nil
}

func (m mariaUserRepository) GetUserRolesList(ctx context.Context, p *models.RolesRequest) (*common.HTTPResponse, error) {
	var rowCount uint64
	e := m.Conn.QueryRow(selectUserRolesCount, p.StatusRole).Scan(&rowCount)
	if e != nil {
		if e == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", e)
			return &common.HTTPResponse{Data: make([]*models.UserGroupPermissions, 0), Message: "Permissions not available", HTTPstatus: http.StatusNotFound}, nil
		} else {
			log.Printf("[repository:maria_user] ListPermissions count db query err: %s \n", e)
			return nil, models.ErrInternalServerError
		}

	}
	var index, count uint64
	if p.PageNumber != 0 && p.Count != 0 {
		index = (p.PageNumber * p.Count) - p.Count
		count = p.Count
	} else {
		index = 0
		count = rowCount
	}
	//Get Permissions
	qry, err := m.Conn.Query(selectUserPermissionList, p.StatusPermisson)
	if err != nil {
		log.Print("UserRoleByPermissions db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	permissions := make(map[int]interface{})
	rl := models.RolesPermission{}
	var pid int
	for qry.Next() {
		err = qry.Scan(
			&pid,
			&rl.Name,
			&rl.Description,
		)
		if err != nil {
			log.Print("[repository:maria_user] UserRoleByPermissions row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		permissions[pid] = rl
	}

	//Get RolePermissions IDs
	qry, err = m.Conn.Query(selectUserRolePermissionList, p.StatusRolePermisson)
	if err != nil {
		log.Print("[repository:maria_user] UserRoleByPermissionList db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	RolePermissions := make(map[int][]interface{})
	var RoleID, PerID int
	for qry.Next() {
		err = qry.Scan(&RoleID, &PerID)
		if err != nil {
			log.Print("[repository:maria_user] selectUserRolesList row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		RolePermissions[RoleID] = append(RolePermissions[RoleID], permissions[PerID])
	}

	//Get RolesList
	qry, err = m.Conn.Query(selectUserRolesList, p.StatusRolePermisson, index, count)
	if err != nil {
		log.Print("[repository:maria_user] selectUserRolesList db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(qry)
	roles := []models.RolesListResponce{}
	rud := models.RolesListResponce{}
	for qry.Next() {
		err = qry.Scan(
			&rud.ID,
			&rud.Name,
			&rud.Description,
		)
		if err != nil {
			log.Print("[repository:maria_user] selectUserRolesList row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		rud.Permission = RolePermissions[rud.ID]
		roles = append(roles, rud)
	}
	return &common.HTTPResponse{Data: roles, Length: rowCount, HTTPstatus: http.StatusOK}, nil
}

func (m mariaUserRepository) UpdateDeviceID(_ context.Context, deviceID, mobileNumber string) (int64, error) {
	result, err := m.Conn.Exec(updateDeviceID, deviceID, mobileNumber)

	if err != nil && err != sql.ErrNoRows {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}
	r, err := result.RowsAffected()
	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}

	return r, nil
}

func (m mariaUserRepository) AddNewDimilandUser(ctx context.Context, r *models.AddNewUserRequest) (*common.HTTPResponse, error) {
	if r.Email == "" || len(r.RoleID) == 0 {
		return &common.HTTPResponse{Message: "Email & Roles are required", HTTPstatus: http.StatusPreconditionFailed}, nil
	}
	var (
		userID            uint64
		status, roleCount int
		err               error
		sqlStatement      string = selectRolesCountBasedOnRoleID
	)
	inStringStatus := "("
	for i, val := range r.RoleID {
		inStringStatus += strconv.Itoa(val)
		if i != len(r.RoleID)-1 {
			inStringStatus += ","
		}
	}
	inStringStatus = inStringStatus + ")"
	sqlStatement = sqlStatement + inStringStatus

	err = m.Conn.QueryRow(sqlStatement).Scan(&roleCount)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AddNewDimilandUser: check roles %s \n", err)
		return nil, models.ErrInternalServerError
	}

	if roleCount != len(r.RoleID) {
		return nil, models.ErrInvalidRole
	}

	err = m.Conn.QueryRow(selectStatusByMail, r.Email).Scan(&userID, &status)
	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria_notification.repository] Exception in AddNewDimilandUser: check user mail %s \n", err)
		return nil, models.ErrInternalServerError
	}

	if status == common.UserInActiveStatus {
		_, err = m.UnblockUserByID(ctx, &models.UserBlockStatus{
			UserID: userID,
			Status: common.UserInvitedStatus,
		})
		if err != nil {
			return nil, err
		}

		return m.EditDimiilandUser(ctx, &models.UserEditRequest{
			UserID:               userID,
			RolesID:              r.RoleID,
			StatusUserRoleActive: common.UserRoleActiveStatus,
			StatusUserRoleDelete: common.UserRoleDeletedStatus,
		})
	}
	if status != 0 {
		return nil, models.ErrMailAlreadyRegistred
	}
	//default status for user role & user type application
	defaultStatus := 1
	//Insert new user type application
	_, err = m.Conn.Exec(inserUserApplicationType, r.UserID, r.ApplicationID, defaultStatus, r.RequestorID, r.CreatedTime, r.RequestorID, r.UpdatedTime)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AddNewDimiilandUser: add user application type %s \n", err)
		return nil, models.ErrInternalServerError
	}

	//Insert new user with email
	_, err = m.Conn.Exec(insertNewUser, r.UserID, r.Email, r.Email, r.Status, r.RequestorID, r.CreatedTime, r.RequestorID, r.UpdatedTime)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AddNewDimiilandUser: add user %s \n", err)
		return nil, models.ErrInternalServerError
	}

	//Insert new user roles
	for _, roleid := range r.RoleID {
		timestamp := time.Now()
		time.Sleep(1000 * time.Millisecond) // get unique time in loop
		_, err := m.Conn.Exec(addUserRole, roleid, r.UserID, defaultStatus, r.RequestorID, timestamp, r.RequestorID, timestamp)
		if err != nil {
			log.Printf("[maria_notification.repository] Exception in AddNewDimiilandUser: add user role %s \n", err)
			return nil, models.ErrInternalServerError
		}
	}
	return &common.HTTPResponse{Message: "Registration successful & Invite mail sent", HTTPstatus: http.StatusOK}, nil
}

func (m *mariaUserRepository) CheckUserHasAccess(ctx context.Context, username string) (bool, error) {
	log.Println("In CheckUserHasAccess : ", username, fmt.Sprintf(selectUserByUserName, username))
	var roleName string

	err := m.Conn.QueryRow(fmt.Sprintf(selectUserByUserName, username)).Scan(&roleName)
	if err != nil {
		return false, err
	}

	return strings.EqualFold(strings.ToLower(roleName), dimmiLandAccess), nil
}

func (m mariaUserRepository) GetUserRolePermissionByUserName(ctx context.Context, userName string) ([]*models.RolePermissions, error) {
	query := fmt.Sprintf(queryUserRoleByUserName, userName)
	log.Println("Inside GetUserRolePermissionByUserName query :\n", query)
	rows, err := m.Conn.Query(query)
	if err != nil {
		log.Print("GetUserRolePermissionByUserName db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(rows)

	result := make([]*models.RolePermissions, 0)
	temp := map[string]models.RolePermissions{}
	for rows.Next() {
		var roleName string
		perm := new(models.Permission)
		//role_name | permission_name
		err = rows.Scan(&roleName, &perm.ID, &perm.Name)
		per := models.Permission{
			ID:   perm.ID,
			Name: perm.Name,
		}
		ura := models.RolePermissions{
			Name:        roleName,
			Permissions: []models.Permission{per},
		}
		data, ok := temp[roleName]
		if !ok {
			temp[roleName] = ura
		} else {
			data.Permissions = append(data.Permissions, per)
			temp[roleName] = data
		}
	}

	// Inline REST API RESP
	for _, val := range temp {
		result = append(result, &val)
	}
	return result, nil

}

func (m mariaUserRepository) EditDimiilandUser(ctx context.Context, rq *models.UserEditRequest) (*common.HTTPResponse, error) {
	var (
		roleCount    int
		err          error
		sqlStatement string = selectRolesCountBasedOnRoleID
	)
	inStringStatus := "("
	for i, val := range rq.RolesID {
		inStringStatus += strconv.Itoa(val)
		if i != len(rq.RolesID)-1 {
			inStringStatus += ","
		}
	}
	inStringStatus = inStringStatus + ")"
	sqlStatement = sqlStatement + inStringStatus

	err = m.Conn.QueryRow(sqlStatement).Scan(&roleCount)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AddNewDimilandUser: check roles %s \n", err)
		return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusInternalServerError}, models.ErrInternalServerError
	}

	if roleCount != len(rq.RolesID) {
		return &common.HTTPResponse{Message: "role_id is invalid", HTTPstatus: http.StatusBadRequest}, nil
	}

	//Get RolesByUserID
	qry, err := m.Conn.Query(selectRolesByUserID, rq.UserID)
	if err != nil {
		log.Print("[repository:maria_user] RolesByUserID db query err: ", err)
		return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusInternalServerError}, models.ErrInternalServerError
	}
	defer closeRows(qry)
	var Existing []int
	var id int
	for qry.Next() {
		err = qry.Scan(&id)
		if err != nil {
			log.Print("[repository:maria_user] RolesByUserID row parse err: ", err)
			return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusInternalServerError}, models.ErrInternalServerError
		}
		Existing = append(Existing, id)
	}

	// transaction begin here
	tx, err := m.Conn.Begin()
	if err != nil {
		return nil, models.ErrInternalServerError
	}
	New := rq.RolesID
	var Add []int
	var Remove []int
	if len(Existing) > 0 {
		//find roles for delete
		for _, s1 := range Existing {
			found := false
			for _, s2 := range New {
				if s1 == s2 {
					found = true
					break
				}
			}
			if !found {
				Remove = append(Remove, s1)
			}
		}
		//find new roles
		for _, n1 := range New {
			found := false
			for _, n2 := range Existing {
				if n1 == n2 {
					found = true
					break
				}
			}
			// if not found. We add it to return slice
			if !found {
				Add = append(Add, n1)
			}
		}
		//Remove roles
		for _, roleID := range Remove {
			_, err := m.Conn.Exec(deleteUserRole, rq.StatusUserRoleDelete, roleID, rq.UserID)
			if err != nil {
				log.Printf("[maria_notification.repository] Exception in EditDimiilandUser: delete user role %s \n", err)
				tx.Rollback()
				return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusInternalServerError}, models.ErrInternalServerError
			}
		}
	} else {
		Add = rq.RolesID
	}

	//Add new roles
	for _, roleID := range Add {
		timestamp := time.Now()
		time.Sleep(1000 * time.Millisecond) // get unique time in loop
		_, err := m.Conn.Exec(addUserRole, roleID, rq.UserID, rq.StatusUserRoleActive, rq.RequestorID, timestamp, rq.RequestorID, timestamp)
		if err != nil {
			log.Printf("[maria_notification.repository] Exception in EditDimiilandUser: add user role %s \n", err)
			tx.Rollback()
			return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusInternalServerError}, models.ErrInternalServerError
		}
	}
	return &common.HTTPResponse{Message: "Edit User Successful", HTTPstatus: http.StatusOK}, nil
}

func (m mariaUserRepository) GetPermissionByUserId(ctx context.Context, param map[string]interface{}) (*models.PermissionsUser, error) {
	userId := param["user_id"]
	activePermission := param["permission_active"]
	activeRole := param["role_active"]
	query := fmt.Sprintf(selectPermissionByUserID)
	log.Println(" TEST GetPermissionByUserId query :\n", query)
	stmt, err := m.Conn.Prepare(query)
	if err != nil {
		fmt.Println(err.Error())
		return nil, models.ErrInternalServerError
	}

	rows, err := stmt.Query(activeRole, activePermission, userId)
	if err != nil {
		log.Print("GetPermissionByUserId db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(rows)

	permissions := make([]string, 0)
	var uid uint64
	var uname string

	for rows.Next() {
		perm := new(models.Permission)
		err = rows.Scan(&uid, &uname, &perm.ID, &perm.Name, &perm.Status, &perm.Description)

		if perm.ID != 0 {
			permissions = append(permissions, perm.Name)
		}
	}
	result := &models.PermissionsUser{
		UserId:      uid,
		UserName:    uname,
		Permissions: permissions,
	}
	return result, nil
}

func (m *mariaUserRepository) BlockUserByID(ctx context.Context, userReq *models.UserBlockStatus) (string, error) {

	result, err := m.Conn.Exec(blockUserByUserID, userReq.Status, userReq.Reason, userReq.UserID)

	if err != nil {
		log.Printf("[maria_notification.repository] BlockUserByID. Exception in updating user status. %s \n", err)
		return "", err
	}
	row, err := result.RowsAffected()

	if err != nil {
		log.Printf("[maria_notification.repository] BlockUserByID. RowsAffected. %s \n", err)
		return "", err
	}

	if row == 0 {
		return common.GetMessage(common.BlockUserUnSuccess), nil
	}
	return common.GetMessage(common.BlockUserSuccess), nil
}

func (m *mariaUserRepository) UnblockUserByID(ctx context.Context, userReq *models.UserBlockStatus) (string, error) {

	// unblock
	result, err := m.Conn.Exec(unblockUserByUserID, userReq.Status, userReq.UserID)

	if err != nil {
		log.Printf("[maria_notification.repository] UnblockUserByID. Exception in updating user status. %s \n", err)
		return "", err
	}
	row, err := result.RowsAffected()

	if err != nil {
		log.Printf("[maria_notification.repository] UnblockUserByID. RowsAffected. %s \n", err)
		return "", err
	}

	if row == 0 {
		return common.GetMessage(common.UnBlockUserUnSuccess), nil
	}
	return common.GetMessage(common.UnBlockUserSuccess), nil
}

func (m *mariaUserRepository) GetUserByUserID(_ context.Context, userID uint64) (*models.User, error) {
	list, err := m.fetch(selectUserbyUserID, userID)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, common.AppErrorCode(common.UserNotFound)
		}
		return nil, err
	}

	if len(list) <= 0 {
		return nil, common.AppErrorCode(common.UserNotFound)
	}

	return list[0], nil
}

func (m *mariaUserRepository) UpdateUserStatus(ctx context.Context, userName string, status int) (bool, error) {
	//`status` INT NOT NULL COMMENT '1 active\n2  inactive\n3  blocked\n4  deleted',
	if status < 1 && status > 4 {
		return false, fmt.Errorf("%v-%v", "Invalid User Status Code", status)
	}

	query := fmt.Sprintf(UpdateUserStatusByUserName, status, userName)
	log.Println("UpdateUserStatus query : ", query)
	_, err := m.Conn.Exec(query)
	if err != nil {
		return false, err
	}

	return true, nil
}

func (m *mariaUserRepository) checkPermissions(permissions []uint64) (bool, error) {

	permParams := make([]interface{}, len(permissions))
	query := `(?` + strings.Repeat(",?", len(permissions)-1) + `)`
	for i, s := range permissions {
		permParams[i] = s
	}
	var count int
	var isValid bool
	rows, err := m.Conn.Query(GetCount+query, permParams...)
	if err != nil {
		return false, err
	}
	if rows.Err() != nil {
		return false, rows.Err()
	}
	for rows.Next() {
		err := rows.Scan(&count)
		if err != nil {
			return false, err
		}
	}
	if count == len(permissions) {
		isValid = true
	}
	defer rows.Close()
	return isValid, nil

}
func (m *mariaUserRepository) StoreDimiilandUserPassword(ctx context.Context, ID uint64, hash string) (*common.HTTPResponse, error) {
	userStatusActive := 1
	_, err := m.Conn.Exec(storeDimiilandUserPassword, hash, userStatusActive, ID)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in storeDimiilandUserPassword: add user password %s \n", err)
		return &common.HTTPResponse{HTTPstatus: http.StatusInternalServerError}, models.ErrInternalServerError
	}
	return &common.HTTPResponse{Message: "Password saved successfully"}, nil
}
