CREATE TABLE `permission` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `group_id` varchar(100) DEFAULT NULL,
  `group_name` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_time` datetime NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `updated_time` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
);