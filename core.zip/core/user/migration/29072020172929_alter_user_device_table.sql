ALTER TABLE user_device ALTER device_reg_token SET DEFAULT '';
UPDATE user_device SET device_reg_token = '' WHERE device_reg_token IS NULL;
ALTER TABLE user_device ADD PRIMARY KEY(mobile, device_id);
ALTER TABLE user_device ADD last_blocked TIMESTAMP NULL AFTER last_login;