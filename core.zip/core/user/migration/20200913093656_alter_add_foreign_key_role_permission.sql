
ALTER TABLE `role` MODIFY `id` bigint(20) unsigned AUTO_INCREMENT;
ALTER TABLE `permission` MODIFY `id` bigint(20) unsigned AUTO_INCREMENT;
ALTER TABLE `permission` MODIFY `id` bigint(20) unsigned AUTO_INCREMENT;
ALTER TABLE `permission` ADD `group_id` VARCHAR(100) DEFAULT NULL;
ALTER TABLE `permission` ADD `group_name` VARCHAR(255) DEFAULT NULL;
