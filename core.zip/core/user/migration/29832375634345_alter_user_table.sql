ALTER TABLE user MODIFY mobile VARCHAR(255);
ALTER TABLE user DROP index mobile_unique;
ALTER TABLE user ADD domain VARCHAR(30) NOT NULL AFTER status;
ALTER TABLE user ADD `last_login` DATETIME;
ALTER TABLE user MODIFY `passcode` VARCHAR(255)
ALTER TABLE user DROP `domain`;