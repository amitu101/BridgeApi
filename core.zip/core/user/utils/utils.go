package utils

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"errors"
	"fmt"
	"log"
	"regexp"
	"strings"
	"time"

	"golang.org/x/crypto/argon2"

	core_config "git.capitalx.id/core/config"
	cfg "git.capitalx.id/core/config/vault"
	models "git.capitalx.id/core/user/model"
)

var config core_config.Config

func init() {
	_config, err := cfg.GetConfig("user")

	if err != nil {
		log.Println(err)
		return
	}
	config = _config
}

func GenerateFromPassword(password string, p *models.GeneratePwdParams) (encodedHash string, err error) {
	// Generate a cryptographically secure random salt.
	salt, err := generateRandomBytes(p.SaltLength)
	if err != nil {
		return "", err
	}

	hash := argon2.IDKey([]byte(password), salt, p.Iterations, p.Memory, p.Parallelism, p.KeyLength)

	// Base64 encode the salt and hashed password.
	b64Salt := base64.RawStdEncoding.EncodeToString(salt)
	b64Hash := base64.RawStdEncoding.EncodeToString(hash)

	// Return a string using the standard encoded hash representation.
	encodedHash = fmt.Sprintf("$argon2id$v=%d$m=%d,t=%d,p=%d$%s$%s", argon2.Version, p.Memory, p.Iterations, p.Parallelism, b64Salt, b64Hash)

	return encodedHash, nil
}

func generateRandomBytes(n uint32) ([]byte, error) {
	b := make([]byte, n)
	_, err := rand.Read(b)
	if err != nil {
		return nil, err
	}

	return b, nil
}

func GenerateDigitRandomUnique() int64 {
	uniqueNumber := time.Now().UnixNano() / (1 << 22)
	return uniqueNumber
}

func ComparePasswordAndHash(password, encodedHash string) (match bool, err error) {
	// Extract the parameters, salt and derived key from the encoded password
	// hash.
	p, salt, hash, err := decodeHash(encodedHash)
	if err != nil {
		return false, err
	}

	// Derive the key from the other password using the same parameters.
	otherHash := argon2.IDKey([]byte(password), salt, p.Iterations, p.Memory, p.Parallelism, p.KeyLength)

	// Check that the contents of the hashed passwords are identical. Note
	// that we are using the subtle.ConstantTimeCompare() function for this
	// to help prevent timing attacks.
	if subtle.ConstantTimeCompare(hash, otherHash) == 1 {
		return true, nil
	}
	return false, nil
}

func decodeHash(encodedHash string) (p *models.GeneratePwdParams, salt, hash []byte, err error) {
	vals := strings.Split(encodedHash, "$")
	if len(vals) != 6 {
		return nil, nil, nil, models.ErrInvalidHash
	}

	var version int
	_, err = fmt.Sscanf(vals[2], "v=%d", &version)
	if err != nil {
		return nil, nil, nil, err
	}
	if version != argon2.Version {
		return nil, nil, nil, models.ErrIncompatibleVersion
	}

	p = &models.GeneratePwdParams{}
	_, err = fmt.Sscanf(vals[3], "m=%d,t=%d,p=%d", &p.Memory, &p.Iterations, &p.Parallelism)
	if err != nil {
		return nil, nil, nil, err
	}

	salt, err = base64.RawStdEncoding.DecodeString(vals[4])
	if err != nil {
		return nil, nil, nil, err
	}
	p.SaltLength = uint32(len(salt))

	hash, err = base64.RawStdEncoding.DecodeString(vals[5])
	if err != nil {
		return nil, nil, nil, err
	}
	p.KeyLength = uint32(len(hash))

	return p, salt, hash, nil
}

func ByPassOTPTesting(phoneNumber, otp string) bool {
	otpPhoneNumbers := []models.OtpPhoneNumberTesting{
		{
			PhoneNumber: "088866668888",
			Otp:         "868686",
		},
		{
			PhoneNumber: "088888882222",
			Otp:         "020202",
		},
		{
			PhoneNumber: "087654321111",
			Otp:         "111111",
		},
		{
			PhoneNumber: "088888883333",
			Otp:         "030303",
		},
	}

	newReq := models.OtpPhoneNumberTesting{
		PhoneNumber: phoneNumber,
		Otp:         otp,
	}

	a := 0
	for i := 0; i < len(otpPhoneNumbers); i++ {
		if otpPhoneNumbers[i] == newReq {
			a += 1
			break
		}
	}

	if a == 0 {
		return false
	}

	return true
}

func GenerateRandomToken() string {
	random, _ := generateRandomBytes(64)
	sha := sha256.New()
	sha.Write([]byte(random))
	hash := sha.Sum(nil)
	return fmt.Sprintf("%x", hash)
}

//ValidateEmail will validate email address
func ValidateEmail(email string) (string, error) {
	email = strings.ToLower(strings.TrimSpace(email))
	var emailRegex = regexp.MustCompile("^[a-zA-Z0-9.!#$%&'*+\\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")
	if !emailRegex.MatchString(email) {
		return "", errors.New("Invalid Email Addresss")
	}
	return email, nil
}
