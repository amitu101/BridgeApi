package service

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"database/sql"
	"encoding/base32"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"strconv"
	"strings"
	"time"

	"git.capitalx.id/core/config"
	"git.capitalx.id/core/user/authprovider"
	ldap2 "git.capitalx.id/core/user/authprovider/ldap"
	"git.capitalx.id/core/user/jwt"
	"google.golang.org/grpc/codes"

	"git.capitalx.id/core/id/service"
	"git.capitalx.id/core/user/repository"
	"git.capitalx.id/core/user/utils"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"

	errHdlr "git.capitalx.id/core/common/error"
	msgKfk "git.capitalx.id/core/messaging"
	notif "git.capitalx.id/core/notification/model"
	"git.capitalx.id/core/user/common"
	models "git.capitalx.id/core/user/model"
)

const (
	OTPNotifID                = "auth.otp"
	PasswordMail              = "auth.mail"
	PasswordResetMail         = "auth.mail.pass.rest"
	UserInviteMail            = "auth.mail.invite.user"
	GsuiteUserInviteMail      = "auth.gsuite.invite.user"
	OTPResetNotifID           = "auth.reset.otp"
	PasscodeResetNotifID      = "auth.reset.success"
	otpMessage                = "Kami mengirimkan kamu kode verifikasi ke nomor ponsel "
	incorrectPasscodeMessage  = "The pass code you entered is incorrect. Please try again"
	failedSendMessage         = "Failed to sending message: "
	failedUpdateDeviceMessage = "failed update to user device"
	otpVerifiedHashKey        = "IS_OTP_VERIFIED"
	accountLinkageKeyPrefix   = "account_linkage_otp_"
)

const (
	otpIDRegister       = 1
	otpIDLogin          = 2
	otpIDAccountLinkage = 3
	otpIDResend         = 4
	otpIDForgetPasscode = 5
	otpIDResendLinkage  = 6
)

var (
	letterRunes             = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	digitLength             = 6          // digit length otp code
	expiredPeriod           = uint(300)  // how long otp can be consumed
	counterLimit            = 5          // how many times user can input failure code
	resendCounterLimit      = 3          // how many times user can request resend otp code
	blockedDuration         = uint(900)  // duration until user permitted to request resend otp in second
	passCodeCounterLimit    = 5          // how many times user can input failure passCode
	passCodeBlockedDuration = int64(900) // duration until user permitted to input passCode again in second
	blockTime               = 60         //Duration in Mins
	countdownResendOTP      = 60         // countdown duration per resend otp in second
)

const (
	HTTPSProtocol = "https://"
)

const (
	KeyPassResetEmailToken  = "pass-reset-email-"
	KeyPassInviteEmailToken = "user-invite-email-"
)

// UserService represent the user's services
type UserService interface {
	GenerateOTP(ctx context.Context, mobileNumber string, id int32) (*models.OTPResponse, error)
	ValidateInputOTP(ctx context.Context, mobileNumber string, otpCode string, id int32) (*models.OTPValidateResponse, error)
	ResendOTP(ctx context.Context, mobileNumber string, classificationID int32) (*models.ResendOTPResponse, error)
	StoreUser(ctx context.Context, user *models.User) (uint64, error)
	CheckLoginPhoneNumberStatus(ctx context.Context, deviceID, mobileNumber string) (*models.OTPResponse, error)
	Login(ctx context.Context, passCode, deviceID, mobileNumber string) (*models.LoginResponse, error)
	GetUserByMobileNumber(ctx context.Context, mobileNumber string) (*models.User, error)
	BlockUser(ctx context.Context, mobileNumber string) (string, error)
	DeleteUser(ctx context.Context, mobileNumber string) (string, error)
	UpdateDeviceToken(ctx context.Context, mobileNumber, deviceID, deviceToken string) (int64, error)
	GetUserDeviceByMobileNumber(ctx context.Context, mobileNumber string) (*models.UserDevice, error)
	GetUserResendOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error)
	GetUserInputOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error)
	ResetPasscodeOTP(ctx context.Context, deviceID, mobileNumber string) (*models.OTPResponse, error)
	UpdatePasscode(ctx context.Context, mobileNumber, passcode string) (int64, error)
	GetDimiilandUsersList(ctx context.Context, params map[string]string) (*[]models.DimilandUsers, uint64, error)
	GetUserRolesByRole(ctx context.Context, roleName string) ([]models.RolePermissions, error)
	GetUserRolesByPermissionName(ctx context.Context, permissionName string) ([]models.RolePermissions, error)
	GetUserDeviceByUserID(ctx context.Context, p *models.UserDeviceListRequest) (*common.HTTPResponse, error)
	ListPermissions(ctx context.Context, p *models.PageRequest) (*common.HTTPResponse, error)
	AddUserRole(ctx context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error)
	UpdateUserRole(ctx context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error)
	DeleteUserRole(ctx context.Context, roleID uint64) (string, error)
	CheckMobileNumberLinkage(ctx context.Context, deviceID, mobileNumber string, clientId string) (*models.OTPResponse, error)
	ValidateInputOTPLinkage(ctx context.Context, mobileNumber, otpCode string, id int32, clientId string) (*models.OTPValidateResponse, error)
	LoginLinkage(ctx context.Context, passCode, deviceID, mobileNumber string) (*models.LoginLinkageResponse, error)
	ResendOTPLinkage(ctx context.Context, mobileNumber string, classificationID int32) (*models.ResendOTPResponse, error)
	AddNewUser(ctx context.Context, rp *models.AddNewUserRequest) (*common.HTTPResponse, error)
	DimiiLandDummyLogin(ctx context.Context, params *models.DummyLoginRequest) (*models.DummyLoginResponse, error)
	GetUserRolesList(ctx context.Context, r *models.RolesRequest) (*common.HTTPResponse, error)
	DimmiLandLogin(ctx context.Context, userName, password string) (*models.LoginResponse, error)
	ValidatePhoneAndPasscode(code string) (bool, error)
	GetOTP(ctx context.Context, mobileNumber string, otpType int32) (*common.HTTPResponse, error)
	EditDimiilandUser(ctx context.Context, rp *models.UserEditRequest) (*common.HTTPResponse, error)
	DimiilandUserReinvite(ctx context.Context, rp *models.DimiilandUserReinviteRequest) (*common.HTTPResponse, error)
	SendDimiilandUserPasswordResetLink(ctx context.Context, rp *models.UserPassResetLinkRequest) (*common.HTTPResponse, error)
	VerifyDimiilandUserPasswordResetLink(ctx context.Context, token string) (*common.HTTPResponse, error)
	GetPermissionByUserId(ctx context.Context, userId uint64) (*models.PermissionsUser, error)
	UpdateUserBlockedStatus(ctx context.Context, userReq *models.UserBlockStatus) (*common.HTTPResponse, error)
	UpdateUserStatus(ctx context.Context, username string, status int) (bool, error)
	VerifyDimiilandUserInviteLink(ctx context.Context, emailToken string) (*common.HTTPResponse, error)
	DimiilandUserNewPassword(ctx context.Context, rp *models.DimiilandUserNewPasswordRequest) (*common.HTTPResponse, error)
	GetRole(ctx context.Context, roleId uint64) (models.RolePermissions, error)
}

// NewUserService will create new an userService object representation of UserService interface
func NewUserService(r repository.CacheUserRepository, m repository.SqlUserRepository, mk msgKfk.Client, s service.SequenceService, signer jwt.Signer, jwtSigner jwt.JWTSigner, ldap *ldap2.Ldap, config config.Config) UserService {
	return &userService{r, m, mk, s, signer, jwtSigner, ldap, config}
}

type userService struct {
	userRepos      repository.CacheUserRepository
	userMariaRepos repository.SqlUserRepository
	kfkClients     msgKfk.Client
	seqService     service.SequenceService
	signer         jwt.Signer
	jwtSigner      jwt.JWTSigner
	ldap           *ldap2.Ldap
	config         config.Config
}

func (u *userService) GetUserDeviceByMobileNumber(ctx context.Context, mobileNumber string) (*models.UserDevice, error) {
	userDevice, err := u.userMariaRepos.GetUserDeviceByMobileNumber(mobileNumber)
	return &userDevice, err
}

type ValidateRequest struct {
	MobileNumber string `json:"mobileNumber"`
	Passcode     string `json:"passcode"`
}

const (
	StatusUserDeviceUnblocked = 1
	StatusUserDeviceBlocked   = 2
)
const (
	UserDimiilandID = 1
	UserDimiiappID  = 2
)
const (
	StatusInActive = 0
	StatusActive   = 1
)
const (
	statusRoleActive          = 1
	statusPermissonActive     = 1
	statusRolePermissonActive = 1
)

// RandStringRunes to generate random string
func RandStringRunes(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

// GenerateCustomOTP to generate OTP code
func GenerateCustomOTP(digitLength int, expiredPeriod uint) (*models.GenerateOTP, error) {
	utf8string := RandStringRunes(16)
	secret := base32.StdEncoding.EncodeToString([]byte(utf8string))
	passCode, err := totp.GenerateCodeCustom(secret, time.Now(), totp.ValidateOpts{
		Period:    expiredPeriod,
		Skew:      1,
		Digits:    otp.Digits(digitLength),
		Algorithm: otp.AlgorithmSHA512,
	})
	if err != nil {
		return nil, err
	}

	return &models.GenerateOTP{
		OtpCode: passCode,
		Secret:  secret,
		Status:  "",
	}, nil
}

// ValidateOTPCustomerRegistration to validate otp from user input
func ValidateOTPCustomerRegistration(otpInput string, secret string) bool {
	valid, _ := totp.ValidateCustom(otpInput, secret, time.Now(), totp.ValidateOpts{
		Period:    expiredPeriod,
		Skew:      1,
		Digits:    otp.Digits(digitLength),
		Algorithm: otp.AlgorithmSHA512,
	})

	if !valid {
		return false
	}

	return true
}

func getKeyName(id int32) (string, bool) {
	keyValueMap := map[int32]string{otpIDRegister: "register-", otpIDLogin: "login-", otpIDAccountLinkage: "account_linkage-", otpIDResend: "resend-", otpIDForgetPasscode: "forget_passcode-", otpIDResendLinkage: "resend_linkage-"}
	value, ok := keyValueMap[id]
	return value, ok
}

func (u *userService) GenerateOTP(ctx context.Context, mobileNumber string, id int32) (*models.OTPResponse, error) {

	key, ok := getKeyName(id)
	if ok {
		key = key + mobileNumber
	} else {
		key = mobileNumber
	}

	counter := 0
	OTPData, err := GenerateCustomOTP(digitLength, expiredPeriod)
	if err != nil {
		return nil, err
	}

	errStore := u.userRepos.StoreOTP(ctx, key, OTPData, counter, int32(expiredPeriod))
	if errStore != nil {
		return nil, errStore
	}

	var notifiID string
	switch id {
	case otpIDLogin:
		notifiID = OTPNotifID
	case otpIDForgetPasscode:
		notifiID = OTPResetNotifID
	default:
		notifiID = OTPNotifID
	}

	// sending OTP to messaging
	data := make(map[string]string)
	data["code"] = OTPData.OtpCode
	data["otp"] = "1"
	topic := notif.NOTIFICATION_TOPIC
	msg := notif.NotificationMessage{
		Recipient:      mobileNumber,
		NotificationID: notifiID,
		Data:           data,
		Language:       "id",
		Channel:        notif.SMS,
	}

	msgByte, _ := json.Marshal(msg)

	errSending := u.kfkClients.Publish(topic, msgByte)
	if errSending != nil {
		log.Println(failedSendMessage, errSending)
		log.Println("Failed to sending message: ", errSending)
	}

	return &models.OTPResponse{
		OtpCode:      OTPData.OtpCode,
		MobileNumber: mobileNumber,
		OtpDuration:  int32(expiredPeriod),
		Message:      otpMessage + mobileNumber,
	}, nil
}
func (u *userService) ValidateInputOTP(ctx context.Context, mobileNumber, otpCode string, id int32) (*models.OTPValidateResponse, error) {
	// for testing purpose
	resByPass := utils.ByPassOTPTesting(mobileNumber, otpCode)
	if resByPass {
		return &models.OTPValidateResponse{
			Message: "Kode verifikasi valid",
		}, nil
	}

	key, ok := getKeyName(id)
	if ok {
		key = key + mobileNumber
	} else {
		key = mobileNumber
	}
	strOtpInput := fmt.Sprintf("%v", otpCode)

	value, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return nil, err
	}
	log.Println("value: ", len(value))

	var message string

	if len(value) == 0 {
		message = "Kode verifikasi kamu yang kamu masukkan sudah tidak berlaku. Silahkan minta kirim ulang kode verifikasi baru!"

		err := errHdlr.ServiceError{
			Code:    "OTP_EXPIRED",
			Status:  codes.OutOfRange,
			Message: message,
		}
		return nil, err

	}

	strEmptyValue := value["message"]
	if strEmptyValue == "key doesnt exists" {
		return &models.OTPValidateResponse{
			Message: "Kode verifikasi kamu yang kamu masukkan sudah tidak berlaku. Silahkan minta kirim ulang kode verifikasi baru!",
		}, nil
	}

	redisCurrentCounter := value["counter"]
	strRedisOtpCode := value["otp_code"]
	redisSecret := value["secret"]
	currentCounter, _ := strconv.Atoi(redisCurrentCounter)
	remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
	numberOfCounter := currentCounter + 1

	var attributes = map[string]string{
		"count": strconv.Itoa(numberOfCounter),
		"max":   strconv.Itoa(counterLimit),
	}
	if numberOfCounter > counterLimit { // if user try to input OTP > x times
		if id == otpIDLogin || id == otpIDForgetPasscode {
			req := &models.GenerateOTP{
				OtpCode: strRedisOtpCode,
				Secret:  redisSecret,
				Status:  "blocked",
			}
			errStore := u.userRepos.StoreOTP(ctx, key, req, numberOfCounter, int32(blockedDuration))
			if errStore != nil {
				return nil, errStore
			}

			message = fmt.Sprintf("Kode verifikasi yang kamu masukkan salah %d kali. Tunggu selama %v detik untuk mencoba kembali atau hubungi call center 1500912", counterLimit, blockedDuration)

		} else {
			message = fmt.Sprintf("Kode verifikasi yang kamu masukkan sudah salah %d x! Silahkan minta kirim ulang kode verifikasi baru", counterLimit)
		}

		attributes["blocked_duration"] = strconv.Itoa(int(blockedDuration))
		attributes["blocked_duration_unit"] = "seconds"
		err := errHdlr.ServiceError{
			Code:       "OTP_BLOCKED",
			Status:     codes.OutOfRange,
			Message:    message,
			Attributes: attributes,
		}
		log.Printf("numberOfCounter : %d , counterLimit :%d, blockedDuration :%d, blocked_duration_unit:%s \n", numberOfCounter, counterLimit, blockedDuration, "seconds")
		return nil, err
	} else {
		strOtpInput := fmt.Sprintf("%v", otpCode)
		valid := ValidateOTPCustomerRegistration(strOtpInput, redisSecret)
		if !valid {
			remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
			req := &models.GenerateOTP{
				OtpCode: strRedisOtpCode,
				Secret:  redisSecret,
				Status:  "",
			}

			errStore := u.userRepos.StoreOTP(ctx, key, req, numberOfCounter, remainingTime)
			if errStore != nil {
				return nil, errStore
			}
			message = fmt.Sprintf("Your OTP code is invalid. Number of failed: %d", numberOfCounter)
			log.Println("numberofcounter: ", numberOfCounter)
			err := errHdlr.ServiceError{
				Code:       "OTP_INVALID",
				Status:     codes.InvalidArgument,
				Message:    message,
				Attributes: attributes,
			}
			return nil, err

		}
	}
	// if user try to input more than x times and OTP time not Expired
	if numberOfCounter > counterLimit && remainingTime > 0 {
		var msg string
		if id == otpIDRegister {
			msg = fmt.Sprintf("Kode verifikasi yang kamu masukkan sudah salah %d x! Silahkan minta kirim ulang kode verifikasi baru", counterLimit)
		} else if id == otpIDLogin {
			if _, err := u.userMariaRepos.BlockUser(ctx, mobileNumber, common.UserBlockedStatus); err != nil {
				log.Println("Error BlockUser : ", mobileNumber, " BlockUser err: ", err)
			}
			msg = fmt.Sprintf("Kode verifikasi yang kamu masukkan salah %d kali. Tunggu selama %v menit untuk linkage kembali atau hubungi call center 1500912", counterLimit, blockTime)
		}
		return &models.OTPValidateResponse{
			Message: msg,
		}, nil
	}

	//ID == 2  Means Account Linkage OTP Validation
	//remainingTime == 0 Means OTP is Expired
	if id == otpIDLogin && remainingTime == 0 {
		//statusHash := map[int32]string{1: "active",2: "inactive",3: "blocked",4: "deleted",}
		statusKey, _ := u.userMariaRepos.CheckStatusByPhoneNumber(key)
		// Checking IF Mobile Number is Blocked
		if statusKey == common.UserBlockedStatus {
			return &models.OTPValidateResponse{
				Message: fmt.Sprintf("Silahkan tunggu selama %v menit untuk menghubungkan akun atau hubungi call center", blockTime),
			}, nil
		}
	}

	//strOtpInput := fmt.Sprintf("%v", otpCode)
	valid := ValidateOTPCustomerRegistration(strOtpInput, redisSecret)
	if !valid {
		//Added on the Top, below line
		//remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
		req := &models.GenerateOTP{
			OtpCode: strRedisOtpCode,
			Secret:  redisSecret,
			Status:  "",
		}
		errStore := u.userRepos.StoreOTP(ctx, key, req, numberOfCounter, remainingTime)
		if errStore != nil {
			return nil, errStore
		}
		return &models.OTPValidateResponse{
			Message: "Kode verifikasi yang kamu masukkan salah! Silahkan coba lagi atau kirim ulang",
		}, nil
	}

	keyPrefix, _ := getKeyName(otpIDResend)
	//resendKey := "resend-" + mobileNumber
	resendKey := keyPrefix + mobileNumber
	isDeleted := u.userRepos.DeleteOTP(ctx, resendKey)
	if !isDeleted {
		return nil, models.ErrDeleteFailed
	}

	return &models.OTPValidateResponse{
		Message: "Kode verifikasi valid",
	}, nil
}

func (u *userService) ResendOTP(ctx context.Context, mobileNumber string, classificationID int32) (*models.ResendOTPResponse, error) {
	//key := "resend-" + mobileNumber
	keyPrefix, _ := getKeyName(otpIDResend)
	key := keyPrefix + mobileNumber
	value, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return nil, err
	}
	log.Println("value dari ResendOTP: ", value)
	log.Println("len(value) ResendOTP: ", len(value))

	keyGenOTP, ok := getKeyName(classificationID)
	if ok {
		keyGenOTP = keyGenOTP + mobileNumber
	} else {
		keyGenOTP = mobileNumber
	}

	if len(value) != 0 {
		strRedisCurrentCounter := value["counter"]
		currentCounter, _ := strconv.Atoi(strRedisCurrentCounter)
		remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
		strRedisStatus := value["status"]
		numberOfCounter := currentCounter + 1

		if strRedisStatus == "blocked" && numberOfCounter > resendCounterLimit {
			message := fmt.Sprintf("Nomor ponsel %v sedang dibekukan sementara. Silahkan coba daftar lagi dalam %d detik", mobileNumber, remainingTime)

			err := errHdlr.ServiceError{
				Code:    "PHONE_NUMBER_BLOCKED",
				Status:  codes.Aborted,
				Message: message,
				Attributes: map[string]string{
					"count":                 strconv.Itoa(numberOfCounter),
					"max":                   strconv.Itoa(resendCounterLimit),
					"blocked_duration":      strconv.Itoa((int)(remainingTime)),
					"blocked_duration_unit": "seconds",
				},
			}

			return nil, err
		} else {
			var otpstatus string

			// Generate new OTP code
			OTPData, err := GenerateCustomOTP(digitLength, expiredPeriod)
			if err != nil {
				errMsg := "There is an error when generating OTP..."
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				return nil, errHndlr
			}

			errStore := u.userRepos.StoreOTP(ctx, keyGenOTP, OTPData, 0, int32(expiredPeriod))
			if errStore != nil {
				errMsg := "There is an error when storing OTP..."
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				return nil, errHndlr
			}

			// if user request for resend otp more then resendCounterLimit
			if numberOfCounter > resendCounterLimit {
				otpstatus = "blocked"
				newNumberOfCounter := numberOfCounter + 1
				errStoreResend := u.userRepos.StoreResendOTP(ctx, key, otpstatus, newNumberOfCounter, int32(blockedDuration))
				if errStoreResend != nil {
					errMsg := "There is an error when storing resend OTP..."
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					log.Println(errStoreResend)
					return nil, errHndlr
				}

				isDeleted := u.userRepos.DeleteOTP(ctx, keyGenOTP)
				if !isDeleted {
					errMsg := "There is an error when deleting OTP, mobile number : " + mobileNumber
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					return nil, errHndlr
				}

				message := fmt.Sprintf("Nomor ponsel %v sedang dibekukan sementara. Silahkan coba lagi dalam %d detik", mobileNumber, blockedDuration)

				err := errHdlr.ServiceError{
					Code:    "PHONE_NUMBER_BLOCKED",
					Status:  codes.Aborted,
					Message: message,
					Attributes: map[string]string{
						"count":                 strconv.Itoa(numberOfCounter),
						"max":                   strconv.Itoa(resendCounterLimit),
						"blocked_duration":      strconv.Itoa((int)(blockedDuration)),
						"blocked_duration_unit": "seconds",
					},
				}

				return nil, err
			} else { // if user request for resend otp code less than resendCounterLimit
				errStoreResend := u.userRepos.StoreResendOTP(ctx, key, otpstatus, numberOfCounter, int32(expiredPeriod))
				if errStoreResend != nil {
					errMsg := "There is an error when storing resend OTP..."
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					log.Println(errStoreResend)
					return nil, errHndlr
				}
			}

			var notifiID string
			switch classificationID {
			case otpIDLogin:
				notifiID = OTPNotifID
			case otpIDForgetPasscode:
				notifiID = OTPResetNotifID
			default:
				notifiID = OTPNotifID
			}

			// sending OTP to messaging
			data := make(map[string]string)
			data["code"] = OTPData.OtpCode
			data["otp"] = "1"
			topic := notif.NOTIFICATION_TOPIC
			msg := notif.NotificationMessage{
				Recipient:      mobileNumber,
				NotificationID: notifiID,
				Data:           data,
				Language:       "id",
				Channel:        notif.SMS,
			}

			msgByte, _ := json.Marshal(msg)

			errSending := u.kfkClients.Publish(topic, msgByte)
			if errSending != nil {
				log.Println(failedSendMessage, errSending)
			}

			return &models.ResendOTPResponse{
				CountdownResendOTP: int32(countdownResendOTP),
				OtpDuration:        int32(expiredPeriod),
				NumberOfResend:     int32(numberOfCounter),
				Message:            otpMessage + mobileNumber,
			}, nil
		}
	}

	log.Println(" kosong")

	// if user resend otp code for the first time
	counter := 1
	OTPData, err := GenerateCustomOTP(digitLength, expiredPeriod)
	if err != nil {
		errMsg := "There is an error when generate custom OTP..."
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(err)
		return nil, errHndlr
	}

	log.Println("samoe disini: ")
	log.Println("OTPData: ", OTPData)

	errStore := u.userRepos.StoreOTP(ctx, keyGenOTP, OTPData, 0, int32(expiredPeriod))
	if errStore != nil {
		errMsg := "There is an error when store OTP..., mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errStore)
		return nil, errHndlr
	}

	errStoreResend := u.userRepos.StoreResendOTP(ctx, key, "", counter, int32(expiredPeriod))
	if errStoreResend != nil {
		errMsg := "There is an error when store resend OTP... "
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errStoreResend)
		return nil, errHndlr
	}

	log.Println("sampai sebelum send sms")

	var notifiID string
	switch classificationID {
	case otpIDLogin:
		notifiID = OTPNotifID
	case otpIDForgetPasscode:
		notifiID = OTPResetNotifID
	default:
		notifiID = OTPNotifID
	}
	// sending OTP to messaging
	data := make(map[string]string)
	data["code"] = OTPData.OtpCode
	data["otp"] = "1"
	topic := notif.NOTIFICATION_TOPIC
	msg := notif.NotificationMessage{
		Recipient:      mobileNumber,
		NotificationID: notifiID,
		Data:           data,
		Language:       "id",
		Channel:        notif.SMS,
	}

	msgByte, _ := json.Marshal(msg)

	errSending := u.kfkClients.Publish(topic, msgByte)
	if errSending != nil {
		log.Println(failedSendMessage, errSending)
	}

	log.Println("sampai gak ya")

	return &models.ResendOTPResponse{
		CountdownResendOTP: int32(countdownResendOTP),
		OtpDuration:        int32(expiredPeriod),
		NumberOfResend:     int32(counter),
		Message:            otpMessage + mobileNumber,
	}, nil
}

func (u *userService) StoreUser(ctx context.Context, user *models.User) (uint64, error) {
	passCodeHash, errGen := GeneratedPassCode(user.Passcode, user.Mobile)
	if errGen != nil {
		return 0, errGen
	}

	newId, err := u.seqService.GetIdNextVal(ctx)
	if err != nil {
		log.Println("Unable to get ID from ID Generator Service when storing user, user :" + user.Name)
		return 0, err
	}

	//uniqueRand := utils.GenerateDigitRandomUnique()
	id := newId.Value
	createdTime := time.Now()

	if user.Username == "" {
		user.Username = user.Mobile
	}

	user.Status = common.UserActiveStatus
	user.CreatedTime = createdTime
	user.UpdatedTime = createdTime
	user.UpdatedBy = user.CreatedBy

	resp, err := u.userMariaRepos.MariaStoreUser(id, passCodeHash, user)
	if err != nil {
		return 0, err
	}
	return resp, nil
}

// GeneratedPassCode to hash the passCode
func GeneratedPassCode(passCode, mobileNumber string) (string, error) {
	p := &models.GeneratePwdParams{
		Memory:      64 * 1024,
		Iterations:  3,
		Parallelism: 2,
		SaltLength:  16,
		KeyLength:   32,
	}

	// Pass the plaintext password and parameters to our generateFromPassword
	// helper function.
	combined := passCode + mobileNumber
	hash, err := utils.GenerateFromPassword(combined, p)
	if err != nil {
		return "", nil
	}

	return hash, nil
}

// Validate input OTP count
func validateUserInputOTPBlockedTime(ctx context.Context, mobileNumber string, u *userService) error {
	remainingInputBlockedTime, errRemaining := u.GetUserInputOTPBlockedTime(ctx, mobileNumber)
	if errRemaining != nil {
		return errRemaining
	}

	if remainingInputBlockedTime > 0 {
		log.Println("masuk remainingInputBlockedTime > 0")
		errMsg := "This mobile number already temporary blocked"
		newErrFormat := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Unavailable,
			Message: errMsg,
			Attributes: map[string]string{
				"blocked_duration":      strconv.Itoa(int(remainingInputBlockedTime)),
				"blocked_duration_unit": "seconds",
			},
		}
		log.Println(errMsg)

		return newErrFormat
	}
	return nil
}

// Validate phone number status
func validateStatusByPhoneNumber(ctx context.Context, mobileNumber string, u *userService) error {
	checkByMobileNumber, errCheck := u.userMariaRepos.CheckStatusByPhoneNumber(mobileNumber)
	if errCheck != nil {
		errMsg := "Fail to check phone number status : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errCheck)
		return errHndlr
	}

	if checkByMobileNumber == -1 {
		errMsg := "This mobile number has not been registered, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "NOT_REGISTERED",
			Status:  codes.NotFound,
			Message: errMsg,
		}
		log.Println(errMsg)
		return errHndlr
	}

	if checkByMobileNumber == common.UserBlockedStatus {

		errMsg := "This mobile number is currently blocked, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Aborted,
			Message: errMsg,
		}
		log.Println(errMsg)
		return errHndlr
	}

	if checkByMobileNumber == common.UserInActiveStatus {
		// code :"NOT_REGISTERED"
		errMsg := "This mobile number is inactive, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "NOT_REGISTERED",
			Status:  codes.Aborted,
			Message: errMsg,
		}
		log.Println(errMsg)
		return errHndlr
	}

	return nil
}

// validate phone number status at device level
func validateStatusByDeviceID(ctx context.Context, deviceID, mobileNumber string, u *userService) error {

	checkDeviceID, errCheckDevice := u.userMariaRepos.CheckStatusByDeviceID(mobileNumber, deviceID)

	log.Println("checkDeviceID: ", checkDeviceID)
	if errCheckDevice != nil {
		errMsg := "Failed on check device id status, device id : " + deviceID
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errCheckDevice)
		return errHndlr
	}

	now := time.Now()
	nowEpoch := now.Unix()
	if checkDeviceID.ExpiredDeviceIDBlocked > nowEpoch {
		// code : BLOCKED
		log.Println("masuk checkDeviceID.ExpiredDeviceIDBlocked > nowEpoc")
		remainingTime := checkDeviceID.ExpiredDeviceIDBlocked - nowEpoch
		errMsg := "This mobile number is currently blocked, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Aborted,
			Message: errMsg,
			Attributes: map[string]string{
				"blocked_duration":      strconv.Itoa(int(remainingTime)),
				"blocked_duration_unit": "seconds",
			},
		}
		log.Println("remainingTime: ", remainingTime)
		log.Println(errMsg)
		return errHndlr
	}

	log.Println("checkDeviceID.ExpiredDeviceIDBlocked: ", checkDeviceID.ExpiredDeviceIDBlocked)
	log.Println("nowEpoch: ", nowEpoch)
	log.Println("checkDeviceID.Counter: ", checkDeviceID.Counter)

	if (checkDeviceID.ExpiredDeviceIDBlocked < nowEpoch) && (checkDeviceID.Counter >= 5) {
		log.Println("masuk checkDeviceID.ExpiredDeviceIDBlocked < nowEpoch && checkDeviceID.Counter > 5")

		req := &models.UserDevice{
			Mobile:                 mobileNumber,
			DeviceID:               deviceID,
			ExpiredDeviceIDBlocked: int64(0),
			Counter:                int32(0),
			Status:                 StatusUserDeviceUnblocked,
		}

		log.Println("req: ", req)

		_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
		if errUpdate != nil {
			errMsg := "failed update to user device, device id :" + deviceID
			errHndlr := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println(errMsg)
			return errHndlr
		}
	}

	return nil
}

// Validate resend OTP input count
func validateResendOTPBlockedTime(ctx context.Context, mobileNumber string, u *userService) error {
	remainingBlockedTime, errRemaining := u.GetUserResendOTPBlockedTime(ctx, mobileNumber)
	if errRemaining != nil {
		return errRemaining
	}

	if remainingBlockedTime > 0 {
		errMsg := "This mobile number already temporary blocked"
		newErrFormat := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Unavailable,
			Message: errMsg,
			Attributes: map[string]string{
				"blocked_duration":      strconv.Itoa(int(remainingBlockedTime)),
				"blocked_duration_unit": "seconds",
			},
		}
		log.Println(errMsg)

		return newErrFormat
	}
	return nil
}

// CheckLoginPhoneNumberStatus is for check status on device level whether blocked or not in login case
func (u *userService) CheckLoginPhoneNumberStatus(ctx context.Context, deviceID, mobileNumber string) (*models.OTPResponse, error) {

	if err := validateUserInputOTPBlockedTime(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	if err := validateStatusByPhoneNumber(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	if err := validateStatusByDeviceID(ctx, mobileNumber, deviceID, u); err != nil {
		return nil, err
	}

	if err := validateResendOTPBlockedTime(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	OTPData, errOTP := u.GenerateOTP(ctx, mobileNumber, otpIDLogin)
	if errOTP != nil {
		errMsg := "Error generating OTP, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errOTP)
		return nil, errHndlr
	}

	log.Println("OTPData: ", OTPData)

	return &models.OTPResponse{
		CountdownResendOTP: int32(countdownResendOTP),
		OtpDuration:        int32(expiredPeriod),
		Message:            otpMessage + mobileNumber,
	}, nil
}

func VerifyingPassCode(passCodeInput, passCode, mobileNumber string) (bool, error) {
	combinedInput := passCodeInput + mobileNumber
	match, err := utils.ComparePasswordAndHash(combinedInput, passCode)
	if err != nil {
		log.Print(err)
		return false, err
	}

	return match, nil
}

func (u *userService) Login(ctx context.Context, passCode, deviceID, mobileNumber string) (*models.LoginResponse, error) {
	passCodeDB, err := u.userMariaRepos.GetPassCodeByPhoneNumber(mobileNumber)
	if err != nil {
		if err == sql.ErrNoRows {
			errMsg := "There is no record found or Not Registered, phone number:" + mobileNumber
			errHndlr := errHdlr.ServiceError{
				Code:    "PASSCODE_NOT_FOUND",
				Status:  codes.NotFound,
				Message: errMsg,
			}
			log.Println("There is no record found :", mobileNumber)
			return nil, errHndlr
		}
		errMsg := "There is an error when getting Passcode, phone number :" + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There is no record found :", mobileNumber)
		return nil, errHndlr
	}

	verifyingPassCode, errVerification := VerifyingPassCode(passCode, passCodeDB, mobileNumber)
	if errVerification != nil {
		errMsg := "There is an error when verifying passcode"
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There is no record found :", mobileNumber)
		return nil, errHndlr
	}

	if !verifyingPassCode {
		counter := 1
		expiredDeviceIDBlocked := 0
		req := &models.UserDevice{
			Mobile:                 mobileNumber,
			DeviceID:               deviceID,
			ExpiredDeviceIDBlocked: int64(expiredDeviceIDBlocked),
			Counter:                int32(counter),
			Status:                 StatusUserDeviceUnblocked,
		}
		// checking on device level
		checkDeviceID, errCheckDevice := u.userMariaRepos.CheckStatusByDeviceID(mobileNumber, deviceID)
		if errCheckDevice != nil {
			errMsg := "There is an error when check by device id, device id :" + deviceID
			errHndlr := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println("There is an error when check by device id, device id :", deviceID)
			return nil, errHndlr
		}

		now := time.Now()
		nowEpoch := now.Unix()

		if checkDeviceID.ExpiredDeviceIDBlocked != 0 {
			log.Println("masuk checkDeviceID.ExpiredDeviceIDBlocked != 0")
			var remainingTime int64
			remainingTime = checkDeviceID.ExpiredDeviceIDBlocked - nowEpoch
			if remainingTime < 0 && checkDeviceID.Counter >= 5 {
				log.Println("kurang dari 0 dan counter >= 5")

				req.ExpiredDeviceIDBlocked = 0
				req.Status = StatusUserDeviceUnblocked
				req.Counter = 1
				req.DeviceRegToken = checkDeviceID.DeviceRegToken

				log.Println("req: ", req)

				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					errMsg := "failed update to user device, device id :" + deviceID
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					return nil, errHndlr
				}

				err := errHdlr.ServiceError{
					Code:    "PASSCODE_INVALID",
					Status:  codes.Unauthenticated,
					Message: incorrectPasscodeMessage,
				}
				return nil, err
			}
			message := fmt.Sprintf("Nomor ponsel %v sedang diblokir sementara. Silahkan coba lagi dalam %d detik", mobileNumber, remainingTime)

			err := errHdlr.ServiceError{
				Code:    "PASSCODE_BLOCKED",
				Status:  codes.Aborted,
				Message: message,
				Attributes: map[string]string{
					"count":                 strconv.Itoa(5),
					"max":                   strconv.Itoa(passCodeCounterLimit),
					"blocked_duration":      strconv.Itoa((int)(remainingTime)),
					"blocked_duration_unit": "seconds",
				},
			}

			return nil, err
		}
		if checkDeviceID.DeviceID == "" {
			log.Println("checkDeviceID.DeviceID == ''")
			_, errStore := u.userMariaRepos.StoreUserDevice(req)
			if errStore != nil {
				errMsg := "failed store to user device, device id: " + deviceID
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				log.Println(errMsg)
				return nil, errHndlr
			}
		} else if checkDeviceID.ExpiredDeviceIDBlocked != 0 && checkDeviceID.ExpiredDeviceIDBlocked < nowEpoch {
			log.Println("masuk else if checkDeviceID.ExpiredDeviceIDBlocked != 0 && checkDeviceID.ExpiredDeviceIDBlocked < nowEpoch")
			_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
			if errUpdate != nil {
				errMsg := "failed update to user device, device id :" + deviceID
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				log.Println(errMsg)
				return nil, errHndlr
			}

			errMsg := incorrectPasscodeMessage + ", Device ID : " + deviceID
			errHndlr := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println(errMsg)
			return nil, errHndlr

		} else {
			log.Println("masuk aaa")
			req.Counter = checkDeviceID.Counter + 1

			var attributes = map[string]string{
				"count": strconv.Itoa(int(req.Counter)),
				"max":   strconv.Itoa(passCodeCounterLimit),
			}

			if req.Counter == int32(passCodeCounterLimit-1) {

				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					errMsg := failedUpdateDeviceMessage + ",Device ID : " + deviceID
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					return nil, errHndlr
				}
				message := "The account will be blocked if you enter the wrong Pass code one more time"
				newErrFormat := errHdlr.ServiceError{
					Code:       "PASS_INVALID_LAST_ATTEMPT",
					Status:     codes.Unknown,
					Message:    message,
					Attributes: attributes,
				}

				return nil, newErrFormat

			} else if checkDeviceID.Counter >= int32(passCodeCounterLimit-1) {
				log.Println("masuk sini")
				req.Status = StatusUserDeviceBlocked
				req.ExpiredDeviceIDBlocked = nowEpoch + passCodeBlockedDuration
				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					newErrFormat := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: failedUpdateDeviceMessage,
					}
					return nil, newErrFormat
				}

				message := `The pass code you entered has been incorrect ` + strconv.Itoa(passCodeCounterLimit) + `x times. Your account is blocked`
				attributes["blocked_duration"] = strconv.Itoa(int(passCodeBlockedDuration))
				attributes["blocked_duration_unit"] = "seconds"
				newErrFormat := errHdlr.ServiceError{
					Code:       "PASSCODE_BLOCKED",
					Status:     codes.Unknown,
					Message:    message,
					Attributes: attributes,
				}

				return nil, newErrFormat

			} else {
				log.Println("sini")
				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					newErrFormat := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: failedUpdateDeviceMessage,
					}
					return nil, newErrFormat
				}

				err := errHdlr.ServiceError{
					Code:    "PASSCODE_INVALID",
					Status:  codes.Unauthenticated,
					Message: incorrectPasscodeMessage,
				}
				return nil, err

			}
		}

		err := errHdlr.ServiceError{
			Code:    "PASSCODE_INVALID",
			Status:  codes.Unauthenticated,
			Message: incorrectPasscodeMessage,
		}
		return nil, err
	}

	// checking on device level
	checkDeviceID, errCheckDevice := u.userMariaRepos.CheckStatusByDeviceID(mobileNumber, deviceID)
	if errCheckDevice != nil {
		return nil, errCheckDevice
	}
	now := time.Now()
	nowEpoch := now.Unix()
	if checkDeviceID.ExpiredDeviceIDBlocked > nowEpoch {
		remainingTime := checkDeviceID.ExpiredDeviceIDBlocked - nowEpoch
		message := fmt.Sprintf("Nomor ponsel %v sedang diblokir sementara. Silahkan coba lagi dalam %d detik", mobileNumber, remainingTime)
		log.Println("remainingTime: ", remainingTime)
		err := errHdlr.ServiceError{
			Code:    "PASSCODE_BLOCKED",
			Status:  codes.Aborted,
			Message: message,
			Attributes: map[string]string{
				"count":                 strconv.Itoa(5),
				"max":                   strconv.Itoa(passCodeCounterLimit),
				"blocked_duration":      strconv.Itoa((int)(remainingTime)),
				"blocked_duration_unit": "seconds",
			},
		}

		return nil, err
	}

	counter := 0
	expiredDeviceIDBlocked := 0
	req := &models.UserDevice{
		Mobile:                 mobileNumber,
		DeviceID:               deviceID,
		ExpiredDeviceIDBlocked: int64(expiredDeviceIDBlocked),
		Counter:                int32(counter),
		Status:                 StatusUserDeviceUnblocked,
	}

	_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
	if errUpdate != nil {
		errMsg := failedUpdateDeviceMessage + ",Device ID : " + deviceID
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		return nil, errHndlr
	}
	// Add new device_id
	if checkDeviceID.DeviceID == "" {
		_, errStore := u.userMariaRepos.StoreUserDevice(req)
		if errStore != nil {
			errMsg := "failed store to user device, device id: " + deviceID
			errHndlr := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println(errMsg)
			return nil, errHndlr
		}
	}

	userData, errUserData := u.userMariaRepos.GetUserByPhoneNumber(ctx, mobileNumber)
	if errUserData != nil {
		errMsg := "failed to get user data, mobile number :" + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errUserData)
		return nil, errHndlr
	}

	// Login success then update new device_id based on mobile_number
	_, err = u.userMariaRepos.UpdateDeviceID(ctx, deviceID, mobileNumber)
	if err != nil {
		errMsg := fmt.Sprintf("Failed to update deviceID. mobile_number : %s, device_id: %s", mobileNumber, deviceID)
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errUserData)
		return nil, errHndlr
	}

	token, err := u.signer.Sign(*userData)
	if err != nil {
		return nil, err
	}

	return &models.LoginResponse{
		Username:     userData.Username,
		MobileNumber: userData.Mobile,
		IDToken:      token,
	}, nil
}

func (u *userService) GetUserByMobileNumber(ctx context.Context, mobileNumber string) (*models.User, error) {
	userData, err := u.userMariaRepos.GetUserByPhoneNumber(ctx, mobileNumber)
	if err != nil {
		return nil, err
	}

	return userData, nil
}

func (u *userService) BlockUser(ctx context.Context, mobileNumber string) (string, error) {
	userstatus := common.UserBlockedStatus
	resp, err := u.userMariaRepos.BlockUser(ctx, mobileNumber, userstatus)
	if err != nil {
		return "", nil
	}

	return resp, nil
}

func (u *userService) DeleteUser(ctx context.Context, mobileNumber string) (string, error) {
	resp, err := u.userMariaRepos.DeleteUser(ctx, mobileNumber)
	if err != nil {
		return "", err
	}

	return resp, nil
}

func (u *userService) UpdateDeviceToken(_ context.Context, mobileNumber, deviceID, deviceToken string) (int64, error) {
	resp, err := u.userMariaRepos.UpdateUserDeviceToken(mobileNumber, deviceID, deviceToken)
	if err != nil {
		return 0, err
	}
	return resp, nil
}

func (u *userService) GetUserResendOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error) {
	key := "resend-" + mobileNumber

	otpData, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return 0, err
	}
	log.Println("otpData: ", otpData)

	status := otpData["status"]
	log.Println("status: ", status)

	if status == "blocked" {
		remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
		if remainingTime > 0 {
			return remainingTime, nil
		}
	}

	return 0, nil
}

func getUserInputOTPBlockedTime(ctx context.Context, mobileNumber string, u *userService, id int32) (int32, error) {
	key, ok := getKeyName(id)
	if ok {
		key = key + mobileNumber
	} else {
		key = mobileNumber
	}

	otpData, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return 0, err
	}
	log.Println("otpData: ", otpData)

	status := otpData["status"]
	log.Println("status: ", status)

	var remainingTime int32 = 0

	if status == "blocked" {
		remainingTime = u.userRepos.GetRemainingTimeOTP(ctx, key)
	}
	return remainingTime, nil
}

func (u *userService) GetUserInputOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error) {

	// Getting Login OTP blocked time
	remainingTime, err := getUserInputOTPBlockedTime(ctx, mobileNumber, u, otpIDLogin)
	if err != nil {
		return 0, err
	}
	if remainingTime > 0 {
		return remainingTime, nil
	}

	// Getting Forget OTP blocked time
	remainingTime, err = getUserInputOTPBlockedTime(ctx, mobileNumber, u, otpIDForgetPasscode)
	if err != nil {
		return 0, err
	}
	if remainingTime > 0 {
		return remainingTime, nil
	}

	return 0, nil
}

func maskPhoneNumber(phoneNumber string) string {

	first3 := phoneNumber[:3]
	last3 := phoneNumber[len(phoneNumber)-3:]
	var mid string

	switch len(phoneNumber) {

	case 10:
		mid = "****"

	case 11:
		mid = "*****"

	case 12:
		mid = "******"

	case 13:
		mid = "*******"
	}

	return first3 + mid + last3
}

func (u *userService) ResetPasscodeOTP(ctx context.Context, deviceID, mobileNumber string) (*models.OTPResponse, error) {

	if err := validateUserInputOTPBlockedTime(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	if err := validateStatusByPhoneNumber(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	if err := validateStatusByDeviceID(ctx, mobileNumber, deviceID, u); err != nil {
		return nil, err
	}

	if err := validateResendOTPBlockedTime(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	OTPData, errOTP := u.GenerateOTP(ctx, mobileNumber, otpIDForgetPasscode)
	if errOTP != nil {
		errMsg := "Error generating OTP, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errOTP)
		return nil, errHndlr
	}

	log.Println("OTPData: ", OTPData)

	return &models.OTPResponse{
		CountdownResendOTP: int32(countdownResendOTP),
		OtpDuration:        int32(expiredPeriod),
		Message:            otpMessage + mobileNumber,
		MobileNumber:       maskPhoneNumber(mobileNumber)}, nil
}

func (u *userService) UpdatePasscode(ctx context.Context, mobileNumber, passcode string) (int64, error) {
	var resp int64
	passCodeHash, errGen := GeneratedPassCode(passcode, mobileNumber)
	if errGen != nil {
		log.Print(errGen)
		return 0, models.ErrInternalServerError
	}

	resp, err := u.userMariaRepos.UpdatePasscode(ctx, mobileNumber, passCodeHash)

	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}

	// send success notification sms to user
	data := make(map[string]string)
	if resp == 1 {
		topic := notif.NOTIFICATION_TOPIC
		msg := notif.NotificationMessage{
			Recipient:      mobileNumber,
			NotificationID: PasscodeResetNotifID,
			Data:           data,
			Language:       "id",
			Channel:        notif.SMS,
		}
		msgByte, _ := json.Marshal(msg)

		errSending := u.kfkClients.Publish(topic, msgByte)
		if errSending != nil {
			log.Println(failedSendMessage, errSending)
		}
	}

	return resp, nil
}

func (u *userService) GetDimiilandUsersList(ctx context.Context, params map[string]string) (*[]models.DimilandUsers, uint64, error) {
	userDevice, count, err := u.userMariaRepos.GetDimiilandUsersList(ctx, params)
	return userDevice, count, err
}

func (u *userService) GetUserRolesByRole(ctx context.Context, roleName string) ([]models.RolePermissions, error) {
	return u.userMariaRepos.UserRoleByRoles(ctx, roleName)
}

func (u *userService) GetRole(ctx context.Context, roleID uint64) (models.RolePermissions, error) {
	return u.userMariaRepos.GetRole(ctx, roleID)
}

func (u *userService) GetUserRolesByPermissionName(ctx context.Context, permissionName string) ([]models.RolePermissions, error) {
	return u.userMariaRepos.UserRoleByPermissions(ctx, permissionName)
}

func (u *userService) GetUserDeviceByUserID(ctx context.Context, p *models.UserDeviceListRequest) (*common.HTTPResponse, error) {
	return u.userMariaRepos.GetUserDeviceByUserID(ctx, p)
}

func (u *userService) ListPermissions(ctx context.Context, p *models.PageRequest) (*common.HTTPResponse, error) {
	return u.userMariaRepos.ListPermissions(ctx, p)
}

// CheckLoginPhoneNumberStatus is for check status on device level whether blocked or not in login case
func (u *userService) CheckMobileNumberLinkage(ctx context.Context, deviceID, mobileNumber string, clientId string) (*models.OTPResponse, error) {

	log.Println(fmt.Sprintf("[CheckMobileNumberLinkage-] device_id : %v, mobile_number : %v, client_id : %v  ", deviceID, mobileNumber, clientId))
	key := mobileNumber + clientId
	if err := validateUserInputOTPBlockedTime(ctx, key, u); err != nil {
		return nil, err
	}

	if err := validateStatusByPhoneNumber(ctx, mobileNumber, u); err != nil {
		return nil, err
	}

	if err := validateStatusByDeviceID(ctx, mobileNumber, deviceID, u); err != nil {
		return nil, err
	}

	if err := validateResendOTPBlockedTime(ctx, key, u); err != nil {
		return nil, err
	}

	OTPData, errOTP := u.GenerateOTP(ctx, key, otpIDAccountLinkage)
	if errOTP != nil {
		errMsg := "Error generating OTP, mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errOTP)
		return nil, errHndlr
	}

	log.Println("OTPData: ", OTPData)

	return &models.OTPResponse{
		CountdownResendOTP: int32(countdownResendOTP),
		OtpDuration:        int32(expiredPeriod),
		Message:            otpMessage + mobileNumber,
	}, nil
}
func (u *userService) ValidateInputOTPLinkage(ctx context.Context, mobileNumber, otpCode string, id int32, clientId string) (*models.OTPValidateResponse, error) {
	log.Println(fmt.Sprintf("[ValidateInputOTPLinkage-] mobile_number : %v, client_id : %v  ", mobileNumber, clientId))
	// for testing purpose
	resByPass := utils.ByPassOTPTesting(mobileNumber, otpCode)
	if resByPass {
		return &models.OTPValidateResponse{
			Message: "Kode verifikasi valid",
		}, nil
	}

	key, ok := getKeyName(id)
	if ok {
		key = key + mobileNumber + clientId
	} else {
		key = mobileNumber
	}
	strOtpInput := fmt.Sprintf("%v", otpCode)

	value, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return nil, err
	}
	log.Println("value: ", len(value))

	var message string

	if len(value) == 0 {
		message = "Kode verifikasi kamu yang kamu masukkan sudah tidak berlaku. Silahkan minta kirim ulang kode verifikasi baru!"

		err := errHdlr.ServiceError{
			Code:    "OTP_EXPIRED",
			Status:  codes.OutOfRange,
			Message: message,
		}
		return nil, err

	}

	strEmptyValue := value["message"]
	if strEmptyValue == "key doesnt exists" {
		return &models.OTPValidateResponse{
			Message: "Kode verifikasi kamu yang kamu masukkan sudah tidak berlaku. Silahkan minta kirim ulang kode verifikasi baru!",
		}, nil
	}

	redisCurrentCounter := value["counter"]
	strRedisOtpCode := value["otp_code"]
	redisSecret := value["secret"]
	currentCounter, _ := strconv.Atoi(redisCurrentCounter)
	remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
	numberOfCounter := currentCounter + 1

	var attributes = map[string]string{
		"count": strconv.Itoa(numberOfCounter),
		"max":   strconv.Itoa(counterLimit),
	}
	if numberOfCounter > counterLimit { // if user try to input OTP > x times
		if id == otpIDAccountLinkage {
			req := &models.GenerateOTP{
				OtpCode: strRedisOtpCode,
				Secret:  redisSecret,
				Status:  "blocked",
			}
			errStore := u.userRepos.StoreOTP(ctx, key, req, numberOfCounter, int32(blockedDuration))
			if errStore != nil {
				return nil, errStore
			}

			message = fmt.Sprintf("Kode verifikasi yang kamu masukkan salah %d kali. Tunggu selama %v detik untuk mencoba kembali atau hubungi call center 1500912", counterLimit, blockedDuration)

		} else {
			message = fmt.Sprintf("Kode verifikasi yang kamu masukkan sudah salah %d x! Silahkan minta kirim ulang kode verifikasi baru", counterLimit)
		}

		attributes["blocked_duration"] = strconv.Itoa(int(blockedDuration))
		attributes["blocked_duration_unit"] = "seconds"
		err := errHdlr.ServiceError{
			Code:       "OTP_BLOCKED",
			Status:     codes.OutOfRange,
			Message:    message,
			Attributes: attributes,
		}
		log.Printf("numberOfCounter : %d , counterLimit :%d, blockedDuration :%d, blocked_duration_unit:%s \n", numberOfCounter, counterLimit, blockedDuration, "seconds")
		return nil, err
	} else {
		strOtpInput := fmt.Sprintf("%v", otpCode)
		valid := ValidateOTPCustomerRegistration(strOtpInput, redisSecret)
		if !valid {
			remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
			req := &models.GenerateOTP{
				OtpCode: strRedisOtpCode,
				Secret:  redisSecret,
				Status:  "",
			}

			errStore := u.userRepos.StoreOTP(ctx, key, req, numberOfCounter, remainingTime)
			if errStore != nil {
				return nil, errStore
			}
			message = fmt.Sprintf("Your OTP code is invalid. Number of failed: %d", numberOfCounter)
			log.Println("numberofcounter: ", numberOfCounter)
			err := errHdlr.ServiceError{
				Code:       "OTP_INVALID",
				Status:     codes.InvalidArgument,
				Message:    message,
				Attributes: attributes,
			}
			return nil, err

		}
	}
	// if user try to input more than x times and OTP time not Expired
	if numberOfCounter > counterLimit && remainingTime > 0 {
		var msg string
		if id == otpIDAccountLinkage {
			if _, err := u.userMariaRepos.BlockUser(ctx, mobileNumber, common.UserBlockedStatus); err != nil {
				log.Println("Error BlockUser : ", mobileNumber, " BlockUser err: ", err)
			}
			msg = fmt.Sprintf("Kode verifikasi yang kamu masukkan salah %d kali. Tunggu selama %v menit untuk linkage kembali atau hubungi call center 1500912", counterLimit, blockTime)
		}
		return &models.OTPValidateResponse{
			Message: msg,
		}, nil
	}

	//ID == 2  Means Account Linkage OTP Validation
	//remainingTime == 0 Means OTP is Expired
	if id == otpIDAccountLinkage && remainingTime == 0 {
		//statusHash := map[int32]string{1: "active",2: "inactive",3: "blocked",4: "deleted",}
		statusKey, _ := u.userMariaRepos.CheckStatusByPhoneNumber(mobileNumber)
		// Checking IF Mobile Number is Blocked
		if statusKey == common.UserBlockedStatus {
			return &models.OTPValidateResponse{
				Message: fmt.Sprintf("Silahkan tunggu selama %v menit untuk menghubungkan akun atau hubungi call center", blockTime),
			}, nil
		}
	}

	//strOtpInput := fmt.Sprintf("%v", otpCode)
	valid := ValidateOTPCustomerRegistration(strOtpInput, redisSecret)
	if !valid {
		//Added on the Top, below line
		//remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
		req := &models.GenerateOTP{
			OtpCode: strRedisOtpCode,
			Secret:  redisSecret,
			Status:  "",
		}
		errStore := u.userRepos.StoreOTP(ctx, key, req, numberOfCounter, remainingTime)
		if errStore != nil {
			return nil, errStore
		}
		return &models.OTPValidateResponse{
			Message: "Kode verifikasi yang kamu masukkan salah! Silahkan coba lagi atau kirim ulang",
		}, nil
	}

	keyPrefix, _ := getKeyName(otpIDResendLinkage)
	//resendKey := "resend-" + mobileNumber
	resendKey := keyPrefix + mobileNumber
	isDeleted := u.userRepos.DeleteOTP(ctx, resendKey)
	if !isDeleted {
		return nil, models.ErrDeleteFailed
	}
	//REST API : Setting  Account Linkage OTP VERIFIED Status in RedisDB
	u.userRepos.SetAccountLinkageKeyValue(ctx, accountLinkageKeyPrefix+mobileNumber, otpVerifiedHashKey, true)

	return &models.OTPValidateResponse{
		Message: "Kode verifikasi valid",
	}, nil
}

func (u *userService) LoginLinkage(ctx context.Context, passCode, deviceID, mobileNumber string) (*models.LoginLinkageResponse, error) {
	log.Println(fmt.Sprintf("[LoginLinkage-] mobile_number : %v, device_id : %v  ", mobileNumber, deviceID))
	//FOR REST API : Checking  Account Linkage OTP is VERIFIED or not
	status, err := u.userRepos.GetAccountLinkageKeyValue(ctx, accountLinkageKeyPrefix+mobileNumber, otpVerifiedHashKey)
	if err != nil || status != "1" {
		log.Println(fmt.Sprintf("[LoginLinkage-GetAccountLinkageKeyValue] mobile_number : %v, Account Linkage OTP Status : %v ,device_id : %v  ", mobileNumber, status, deviceID))
		return nil, fmt.Errorf("%v", "Account Linkage OTP is not Verified")
	}

	passCodeDB, err := u.userMariaRepos.GetPassCodeByPhoneNumber(mobileNumber)
	if err != nil {
		if err == sql.ErrNoRows {
			errMsg := "There is no record found or Not Registered, mobile number:" + mobileNumber
			errHndlr := errHdlr.ServiceError{
				Code:    "MOBILE_NUMBER_NOT_FOUND",
				Status:  codes.NotFound,
				Message: errMsg,
			}
			log.Println("There is no record found :", mobileNumber)
			return nil, errHndlr
		}
		errMsg := "There is an error when getting Passcode, phone number :" + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There is no record found :", mobileNumber)
		return nil, errHndlr
	}

	verifyingPassCode, errVerification := VerifyingPassCode(passCode, passCodeDB, mobileNumber)
	if errVerification != nil {
		errMsg := "There is an error when verifying passcode"
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println("There is no record found :", mobileNumber)
		return nil, errHndlr
	}

	if !verifyingPassCode {
		counter := 1
		expiredDeviceIDBlocked := 0
		req := &models.UserDevice{
			Mobile:                 mobileNumber,
			DeviceID:               deviceID,
			ExpiredDeviceIDBlocked: int64(expiredDeviceIDBlocked),
			Counter:                int32(counter),
			Status:                 StatusUserDeviceUnblocked,
		}
		// checking on device level
		checkDeviceID, errCheckDevice := u.userMariaRepos.CheckStatusByDeviceID(mobileNumber, deviceID)
		if errCheckDevice != nil {
			errMsg := "There is an error when check by device id, device id :" + deviceID
			errHndlr := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println("There is an error when check by device id, device id :", deviceID)
			return nil, errHndlr
		}

		now := time.Now()
		nowEpoch := now.Unix()

		if checkDeviceID.ExpiredDeviceIDBlocked != 0 {
			log.Println("masuk checkDeviceID.ExpiredDeviceIDBlocked != 0")
			var remainingTime int64
			remainingTime = checkDeviceID.ExpiredDeviceIDBlocked - nowEpoch
			if remainingTime < 0 && checkDeviceID.Counter >= 5 {
				log.Println("kurang dari 0 dan counter >= 5")

				req.ExpiredDeviceIDBlocked = 0
				req.Status = StatusUserDeviceUnblocked
				req.Counter = 1
				req.DeviceRegToken = checkDeviceID.DeviceRegToken

				log.Println("req: ", req)

				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					errMsg := "failed update to user device, device id :" + deviceID
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					return nil, errHndlr
				}

				err := errHdlr.ServiceError{
					Code:    "PASSCODE_INVALID",
					Status:  codes.Unauthenticated,
					Message: incorrectPasscodeMessage,
				}
				return nil, err
			}
			message := fmt.Sprintf("Nomor ponsel %v sedang diblokir sementara. Silahkan coba lagi dalam %d detik", mobileNumber, remainingTime)

			err := errHdlr.ServiceError{
				Code:    "MOBILE_NUMBER_BLOCKED",
				Status:  codes.PermissionDenied,
				Message: message,
				Attributes: map[string]string{
					"count":                 strconv.Itoa(5),
					"max":                   strconv.Itoa(passCodeCounterLimit),
					"blocked_duration":      strconv.Itoa((int)(remainingTime)),
					"blocked_duration_unit": "seconds",
				},
			}

			return nil, err
		}
		if checkDeviceID.DeviceID == "" {
			log.Println("checkDeviceID.DeviceID == ''")
			_, errStore := u.userMariaRepos.StoreUserDevice(req)
			if errStore != nil {
				errMsg := "failed store to user device, device id: " + deviceID
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				log.Println(errMsg)
				return nil, errHndlr
			}
		} else if checkDeviceID.ExpiredDeviceIDBlocked != 0 && checkDeviceID.ExpiredDeviceIDBlocked < nowEpoch {
			log.Println("masuk else if checkDeviceID.ExpiredDeviceIDBlocked != 0 && checkDeviceID.ExpiredDeviceIDBlocked < nowEpoch")
			_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
			if errUpdate != nil {
				errMsg := "failed update to user device, device id :" + deviceID
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				log.Println(errMsg)
				return nil, errHndlr
			}

			errMsg := incorrectPasscodeMessage + ", Device ID : " + deviceID
			errHndlr := errHdlr.ServiceError{
				Code:    "INTERNAL_SERVER_ERROR",
				Status:  codes.Internal,
				Message: errMsg,
			}
			log.Println(errMsg)
			return nil, errHndlr

		} else {
			log.Println("masuk aaa")
			req.Counter = checkDeviceID.Counter + 1

			var attributes = map[string]string{
				"count": strconv.Itoa(int(req.Counter)),
				"max":   strconv.Itoa(passCodeCounterLimit),
			}

			if req.Counter == int32(passCodeCounterLimit-1) {

				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					errMsg := failedUpdateDeviceMessage + ",Device ID : " + deviceID
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					return nil, errHndlr
				}
				message := "The account will be blocked if you enter the wrong Pass code one more time"
				newErrFormat := errHdlr.ServiceError{
					Code:       "PASS_INVALID_LAST_ATTEMPT",
					Status:     codes.Unauthenticated,
					Message:    message,
					Attributes: attributes,
				}

				return nil, newErrFormat

			} else if checkDeviceID.Counter >= int32(passCodeCounterLimit-1) {
				log.Println("masuk sini")
				req.Status = StatusUserDeviceBlocked
				req.ExpiredDeviceIDBlocked = nowEpoch + passCodeBlockedDuration
				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					newErrFormat := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: failedUpdateDeviceMessage,
					}
					return nil, newErrFormat
				}

				message := `The pass code you entered has been incorrect ` + strconv.Itoa(passCodeCounterLimit) + `x times. Your account is blocked`
				attributes["blocked_duration"] = strconv.Itoa(int(passCodeBlockedDuration))
				attributes["blocked_duration_unit"] = "seconds"
				newErrFormat := errHdlr.ServiceError{
					Code:       "MOBILE_NUMBER_BLOCKED",
					Status:     codes.PermissionDenied,
					Message:    message,
					Attributes: attributes,
				}

				return nil, newErrFormat

			} else {
				log.Println("sini")
				_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
				if errUpdate != nil {
					newErrFormat := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: failedUpdateDeviceMessage,
					}
					return nil, newErrFormat
				}

				err := errHdlr.ServiceError{
					Code:    "PASSCODE_INVALID",
					Status:  codes.Unauthenticated,
					Message: incorrectPasscodeMessage,
				}
				return nil, err
			}
		}

		err := errHdlr.ServiceError{
			Code:    "PASSCODE_INVALID",
			Status:  codes.Unauthenticated,
			Message: incorrectPasscodeMessage,
		}
		return nil, err
	}

	// checking on device level
	checkDeviceID, errCheckDevice := u.userMariaRepos.CheckStatusByDeviceID(mobileNumber, deviceID)
	if errCheckDevice != nil {
		return nil, errCheckDevice
	}
	now := time.Now()
	nowEpoch := now.Unix()
	if checkDeviceID.ExpiredDeviceIDBlocked > nowEpoch {
		remainingTime := checkDeviceID.ExpiredDeviceIDBlocked - nowEpoch
		message := fmt.Sprintf("Nomor ponsel %v sedang diblokir sementara. Silahkan coba lagi dalam %d detik", mobileNumber, remainingTime)
		log.Println("remainingTime: ", remainingTime)
		err := errHdlr.ServiceError{
			Code:    "MOBILE_NUMBER_BLOCKED",
			Status:  codes.PermissionDenied,
			Message: message,
			Attributes: map[string]string{
				"count":                 strconv.Itoa(5),
				"max":                   strconv.Itoa(passCodeCounterLimit),
				"blocked_duration":      strconv.Itoa((int)(remainingTime)),
				"blocked_duration_unit": "seconds",
			},
		}

		return nil, err
	}

	counter := 0
	expiredDeviceIDBlocked := 0
	req := &models.UserDevice{
		Mobile:                 mobileNumber,
		DeviceID:               deviceID,
		ExpiredDeviceIDBlocked: int64(expiredDeviceIDBlocked),
		Counter:                int32(counter),
		Status:                 StatusUserDeviceUnblocked,
	}

	_, errUpdate := u.userMariaRepos.UpdateUserDevice(req)
	if errUpdate != nil {
		errMsg := failedUpdateDeviceMessage + ",Device ID : " + deviceID
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		return nil, errHndlr
	}

	userData, errUserData := u.userMariaRepos.GetUserByPhoneNumber(ctx, mobileNumber)
	if errUserData != nil {
		errMsg := "failed to get user data, mobile number :" + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errUserData)
		return nil, errHndlr
	}

	// No need to return token for Linkage
	//token, err := u.signer.Sign(*userData)
	//if err != nil {
	//	return nil, err
	//}

	return &models.LoginLinkageResponse{
		UserName:     userData.Username,
		MobileNumber: userData.Mobile,
		//IdToken:      token,
	}, nil
}
func (u *userService) ResendOTPLinkage(ctx context.Context, mobileNumber string, classificationID int32) (*models.ResendOTPResponse, error) {
	log.Println(fmt.Sprintf("[ResendOTPLinkage-] mobile_number : %v, id : %d ", mobileNumber, classificationID))
	//key := "resend-" + mobileNumber
	keyPrefix, _ := getKeyName(otpIDResendLinkage)
	key := keyPrefix + mobileNumber
	value, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return nil, err
	}
	log.Println("value dari ResendOTPLinkage: ", value)
	log.Println("len(value) ResendOTPLinkage: ", len(value))

	keyGenOTP, ok := getKeyName(classificationID)
	if ok {
		keyGenOTP = keyGenOTP + mobileNumber
	} else {
		keyGenOTP = mobileNumber
	}

	if len(value) != 0 {
		strRedisCurrentCounter := value["counter"]
		currentCounter, _ := strconv.Atoi(strRedisCurrentCounter)
		remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)
		strRedisStatus := value["status"]
		numberOfCounter := currentCounter + 1

		if strRedisStatus == "blocked" && numberOfCounter > resendCounterLimit {
			message := fmt.Sprintf("Nomor ponsel %v sedang dibekukan sementara. Silahkan coba daftar lagi dalam %d detik", mobileNumber, remainingTime)

			err := errHdlr.ServiceError{
				Code:    "PHONE_NUMBER_BLOCKED",
				Status:  codes.Aborted,
				Message: message,
				Attributes: map[string]string{
					"count":                 strconv.Itoa(numberOfCounter),
					"max":                   strconv.Itoa(resendCounterLimit),
					"blocked_duration":      strconv.Itoa((int)(remainingTime)),
					"blocked_duration_unit": "seconds",
				},
			}

			return nil, err
		} else {
			var otpstatus string

			// Generate new OTP code
			OTPData, err := GenerateCustomOTP(digitLength, expiredPeriod)
			if err != nil {
				errMsg := "There is an error when generating OTP..."
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				return nil, errHndlr
			}

			errStore := u.userRepos.StoreOTP(ctx, keyGenOTP, OTPData, 0, int32(expiredPeriod))
			if errStore != nil {
				errMsg := "There is an error when storing OTP..."
				errHndlr := errHdlr.ServiceError{
					Code:    "INTERNAL_SERVER_ERROR",
					Status:  codes.Internal,
					Message: errMsg,
				}
				return nil, errHndlr
			}

			// if user request for resend otp more then resendCounterLimit
			if numberOfCounter > resendCounterLimit {
				otpstatus = "blocked"
				newNumberOfCounter := numberOfCounter + 1
				errStoreResend := u.userRepos.StoreResendOTP(ctx, key, otpstatus, newNumberOfCounter, int32(blockedDuration))
				if errStoreResend != nil {
					errMsg := "There is an error when storing resend OTP..."
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					log.Println(errStoreResend)
					return nil, errHndlr
				}

				isDeleted := u.userRepos.DeleteOTP(ctx, keyGenOTP)
				if !isDeleted {
					errMsg := "There is an error when deleting OTP, mobile number : " + mobileNumber
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					return nil, errHndlr
				}

				message := fmt.Sprintf("Nomor ponsel %v sedang dibekukan sementara. Silahkan coba lagi dalam %d detik", mobileNumber, blockedDuration)

				err := errHdlr.ServiceError{
					Code:    "PHONE_NUMBER_BLOCKED",
					Status:  codes.Aborted,
					Message: message,
					Attributes: map[string]string{
						"count":                 strconv.Itoa(numberOfCounter),
						"max":                   strconv.Itoa(resendCounterLimit),
						"blocked_duration":      strconv.Itoa((int)(blockedDuration)),
						"blocked_duration_unit": "seconds",
					},
				}

				return nil, err
			} else { // if user request for resend otp code less than resendCounterLimit
				errStoreResend := u.userRepos.StoreResendOTP(ctx, key, otpstatus, numberOfCounter, int32(expiredPeriod))
				if errStoreResend != nil {
					errMsg := "There is an error when storing resend OTP..."
					errHndlr := errHdlr.ServiceError{
						Code:    "INTERNAL_SERVER_ERROR",
						Status:  codes.Internal,
						Message: errMsg,
					}
					log.Println(errMsg)
					log.Println(errStoreResend)
					return nil, errHndlr
				}
			}

			var notifiID string
			switch classificationID {
			case otpIDLogin:
				notifiID = OTPNotifID
			case otpIDForgetPasscode:
				notifiID = OTPResetNotifID
			default:
				notifiID = OTPNotifID
			}

			// sending OTP to messaging
			data := make(map[string]string)
			data["code"] = OTPData.OtpCode
			data["otp"] = "1"
			topic := notif.NOTIFICATION_TOPIC
			msg := notif.NotificationMessage{
				Recipient:      mobileNumber,
				NotificationID: notifiID,
				Data:           data,
				Language:       "id",
				Channel:        notif.SMS,
			}

			msgByte, _ := json.Marshal(msg)

			errSending := u.kfkClients.Publish(topic, msgByte)
			if errSending != nil {
				log.Println(failedSendMessage, errSending)
			}

			return &models.ResendOTPResponse{
				CountdownResendOTP: int32(countdownResendOTP),
				OtpDuration:        int32(expiredPeriod),
				NumberOfResend:     int32(numberOfCounter),
				Message:            otpMessage + mobileNumber,
			}, nil
		}
	}

	log.Println(" kosong")

	// if user resend otp code for the first time
	counter := 1
	OTPData, err := GenerateCustomOTP(digitLength, expiredPeriod)
	if err != nil {
		errMsg := "There is an error when generate custom OTP..."
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(err)
		return nil, errHndlr
	}

	log.Println("samoe disini: ")
	log.Println("OTPData: ", OTPData)

	errStore := u.userRepos.StoreOTP(ctx, keyGenOTP, OTPData, 0, int32(expiredPeriod))
	if errStore != nil {
		errMsg := "There is an error when store OTP..., mobile number : " + mobileNumber
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errStore)
		return nil, errHndlr
	}

	errStoreResend := u.userRepos.StoreResendOTP(ctx, key, "", counter, int32(expiredPeriod))
	if errStoreResend != nil {
		errMsg := "There is an error when store resend OTP... "
		errHndlr := errHdlr.ServiceError{
			Code:    "INTERNAL_SERVER_ERROR",
			Status:  codes.Internal,
			Message: errMsg,
		}
		log.Println(errMsg)
		log.Println(errStoreResend)
		return nil, errHndlr
	}

	log.Println("sampai sebelum send sms")

	var notifiID string
	switch classificationID {
	case otpIDLogin:
		notifiID = OTPNotifID
	case otpIDForgetPasscode:
		notifiID = OTPResetNotifID
	default:
		notifiID = OTPNotifID
	}
	// sending OTP to messaging
	data := make(map[string]string)
	data["code"] = OTPData.OtpCode
	data["otp"] = "1"
	topic := notif.NOTIFICATION_TOPIC
	msg := notif.NotificationMessage{
		Recipient:      mobileNumber,
		NotificationID: notifiID,
		Data:           data,
		Language:       "id",
		Channel:        notif.SMS,
	}

	msgByte, _ := json.Marshal(msg)

	errSending := u.kfkClients.Publish(topic, msgByte)
	if errSending != nil {
		log.Println(failedSendMessage, errSending)
	}

	log.Println("sampai gak ya")

	return &models.ResendOTPResponse{
		CountdownResendOTP: int32(countdownResendOTP),
		OtpDuration:        int32(expiredPeriod),
		NumberOfResend:     int32(counter),
		Message:            otpMessage + mobileNumber,
	}, nil
}

func (u *userService) AddUserRole(ctx context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error) {
	createdTime := time.Now()
	rp.Status = StatusActive
	rp.CreatedTime = createdTime
	rp.UpdatedTime = createdTime
	rp.UpdatedBy = rp.CreatedBy
	return u.userMariaRepos.AddUserRole(ctx, rp)
}

func (u *userService) UpdateUserRole(ctx context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error) {
	rp.Status = StatusActive
	rp.UpdatedTime = time.Now()
	rp.UpdatedBy = rp.CreatedBy
	return u.userMariaRepos.UpdateUserRole(ctx, rp)
}

func (u *userService) DeleteUserRole(ctx context.Context, roleID uint64) (string, error) {
	return u.userMariaRepos.DeleteUserRole(ctx, roleID)
}

func (u *userService) AddNewUser(ctx context.Context, rp *models.AddNewUserRequest) (*common.HTTPResponse, error) {
	createdTime := time.Now()
	rp.Status = common.UserInvitedStatus
	rp.CreatedTime = createdTime
	rp.ApplicationID = UserDimiilandID
	rp.Email = strings.ToLower(rp.Email)
	email, err := utils.ValidateEmail(rp.Email)
	rp.Email = email
	if err != nil {
		return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusPreconditionFailed}, nil
	}
	//user id generation
	id, err := u.seqService.GetIdNextVal(ctx)
	rp.UserID = id.Value

	if err != nil {
		log.Println("Unable to get ID from ID Generator Service when add dimiiland user")
		return &common.HTTPResponse{Message: "Unable to Generator User ID", HTTPstatus: http.StatusPreconditionFailed}, nil
	}
	//Storing user in DB
	response, err := u.userMariaRepos.AddNewDimilandUser(ctx, rp)
	if err != nil {
		return &common.HTTPResponse{Message: err.Error(), HTTPstatus: http.StatusBadRequest}, nil
	}
	user, err := u.userMariaRepos.GetDimiilandUserByEmail(ctx, rp.Email, common.UserInvitedStatus)
	if err != nil {
		return nil, err
	}
	Expired := u.config.GetInt("jwt.user.invite.expired")
	jwtToken, err := u.jwtSigner.SignJwt(user)
	if err != nil {
		return nil, err
	}
	// Storing Email Token in redis
	err = u.userRepos.StoreEmailToken(KeyPassInviteEmailToken+rp.Email, jwtToken, int32(Expired))
	if err != nil {
		log.Println("Unable to Store Email Token in redis for invite dimiiland user")
		return nil, models.ErrInternalServerError
	}
	//Sending password creation link
	BaseURL := u.config.GetString("web.base.url")
	link := BaseURL + "/user/invite?token=" + jwtToken
	data := make(map[string]string)
	data["inviteURL"] = HTTPSProtocol + link

	SendUserInviteMail := notif.NotificationMessage{
		Recipient:      rp.Email,
		NotificationID: UserInviteMail,
		Data:           data,
		Language:       "en",
		Channel:        notif.EMAIL,
	}
	msgByte, _ := json.Marshal(SendUserInviteMail)
	err = u.kfkClients.Publish(notif.NOTIFICATION_TOPIC, msgByte)
	if err != nil {
		return nil, errors.New("Unable to send user invite link mail")
	}
	response = &common.HTTPResponse{Message: "Add New User Successful", HTTPstatus: http.StatusOK}
	return response, nil
}

func (u *userService) DimiiLandDummyLogin(ctx context.Context, params *models.DummyLoginRequest) (*models.DummyLoginResponse, error) {
	ret := "eyJhbGciOiJSUzI1NiIsImtpZCI6InB1YmxpYzpmMzQxNDIzMi1hMDYwLTRiY2UtYjc4Ni1lYjU4MWVjOGViMWIiLCJ0eXAiOiJKV1QifQ.eyJleHAiOjE2MzE2Mjk3MzUsImlhdCI6MTYwMDA5MzczNSwiaXNzIjoiYXBpLmRpbWlpLmRldiIsIm1vYmlsZSI6IjA4MTM3Njc2Mzc4NCIsIm5hbWUiOiJUZXN0Iiwic3ViIjoidGVzdCIsInVzZXJfaWQiOiJ0ZXN0In0.XWMQJnphZ1GtztpvEuNjPnb0V5xXJCybKvKQpuzWCZXEJKvlhqhmGgnPo4RXhweqD43HKj73HIEDxwv7-xX00ovKoVtvTPU-Lw23LzkBXVqYoPDauuiNLanbdWacOtTTIIYebEp5UnhwpvHYUAydC-HFoqP1VwCFm_doN4hmM-vYSsMuWSx1-5I7JQ0ZsvnAu4mU0WM0J-Ns6l0k8Ln-sk35DOsZZyKzMzEdvkZAjfDofhsb2nYuUifXsHbqOIezkWCGoBT1ba78iIpip3_oamoYr_kZ80CcWjdNPgWP90deUB3lYvo5MAhwXfoFuroB6Mf2Hv3Fh6-981iC8Db8Ix03hqU6P6LQKHErHGqHMv5ybizU6qLT3bgtjIeqKqsG-1fZfExYCi2pPOKQXkh10Pk_fuixpFURUSG1UQEuuKTByoX_fPVYODxcuUdZJimKAMtBbimtgJ9IC2TOOPMAcc-ZzjXZYskMSAIGsFmY4kwOKhec-l3Ups5i9OLR0tuxQMbzGr0krWtlJ65jq4anEBdK_tXGIl29J_q6r_mbv6SPWrQKDl5kyrE2BlTnZihVHDqLgOl0y5WIdnYEm2XfQnCn78p_QsiHCSs9jBDiaLS4DdJk5_bxgao3yGp8LtvL87awI5wDMxMW-K6TbLsN9q4p9cJvFtrstX1N9KyAsEI"

	return &models.DummyLoginResponse{
		IdToken: ret,
	}, nil
}

func (u *userService) GetUserRolesList(ctx context.Context, r *models.RolesRequest) (*common.HTTPResponse, error) {
	r.StatusRole = statusRoleActive
	r.StatusPermisson = statusPermissonActive
	r.StatusRolePermisson = statusRolePermissonActive
	return u.userMariaRepos.GetUserRolesList(ctx, r)
}

func (u *userService) DimmiLandLogin(ctx context.Context, userName, password string) (*models.LoginResponse, error) {
	// Check User Has Access or Not
	if status, err := u.userMariaRepos.CheckUserHasAccess(ctx, userName); !status {
		log.Println(userName, " don't Have Access to DimmiLand  err: ", err)
		return nil, errors.New(userName + " don't Have Access to DimmiLand")
	}

	auth := authprovider.NewLdapAuth(u.ldap, u.signer, u.seqService, u.userMariaRepos)
	_, err := auth.Login(ctx, userName, password)
	if err != nil {
		log.Println("Unable to Verify User Cred from LDAP err: ", err)
		//Please Add DB AUTH LOGIN Code Here
		auth = authprovider.NewDbAuth(u.userRepos, u.userMariaRepos, u.signer)
		if _, err = auth.Login(ctx, userName, password); err != nil {
			log.Println("Unable to Verify User Cred from DB err: ", err)
			return nil, err
		}
	}
	// Fetching User Role and Permission By UserName
	result, err := u.userMariaRepos.GetUserRolePermissionByUserName(ctx, userName)
	if err != nil {
		log.Println("DimmiLandLogin Unable to get Users Role Permission By UserName : ", err)
	}
	// Signing User JWT
	token, err := u.signer.Sign(models.User{Username: userName})
	if err != nil {
		log.Println("DimmiLandLogin JWT Token Sign err : ", err)
		return nil, err
	}

	return &models.LoginResponse{Username: userName, IDToken: token, UserRole: result}, nil
}

func (u *userService) GetOTP(ctx context.Context, mobileNumber string, otpType int32) (*common.HTTPResponse, error) {

	key, ok := getKeyName(otpType)
	if ok {
		key = key + mobileNumber
	} else {
		key = mobileNumber
	}

	value, err := u.userRepos.GetValueOTP(ctx, key)
	if err != nil {
		return nil, err
	}

	otpCode, ok := value["otp_code"]
	remainingTime := u.userRepos.GetRemainingTimeOTP(ctx, key)

	if !ok {
		return nil, common.AppErrorCode(common.OTPNotFound)
	}

	data := &models.OTPData{
		OtpCode:      otpCode,
		OtpDuration:  remainingTime,
		MobileNumber: mobileNumber}
	return &common.HTTPResponse{Data: data, Message: common.GetMessage(common.GettingOTPSuccess)}, nil
}

func (u *userService) ValidatePhoneAndPasscode(code string) (bool, error) {
	data, err := u.DecryptCode(code)
	if err != nil {
		log.Println("Error in Decrypting code", err.Error())
		return false, err
	}
	passCodeDB, err := u.userMariaRepos.GetPassCodeByPhoneNumber(data.MobileNumber)
	if err != nil {
		log.Println("Error in Fetching passcode from DB", err.Error())
		return false, err
	}
	isVerified, err := VerifyingPassCode(data.Passcode, passCodeDB, data.MobileNumber)
	if err != nil {
		log.Printf("[Handler] Passcode verification failed %s\n", err.Error())
		return false, err
	}
	return isVerified, nil

}

func (u *userService) DecryptCode(code string) (ValidateRequest, error) {
	var value ValidateRequest
	key := u.config.GetString("payment.key")
	text, _ := base64.StdEncoding.DecodeString(code)
	block, err := aes.NewCipher([]byte(key))
	if err != nil {
		return value, err
	}
	if len(text) < aes.BlockSize {
		return value, errors.New("ciphertext too short")
	}
	iv := text[:aes.BlockSize]
	text = text[aes.BlockSize:]
	cfb := cipher.NewCFBDecrypter(block, iv)
	cfb.XORKeyStream(text, text)
	data, err := base64.StdEncoding.DecodeString(string(text))
	if err != nil {
		return value, err
	}
	if err := json.Unmarshal(data, &value); err != nil {
		panic(err)
	}
	return value, nil

}

func (u *userService) EditDimiilandUser(ctx context.Context, rp *models.UserEditRequest) (*common.HTTPResponse, error) {
	rp.StatusUserRoleActive = common.UserRoleActiveStatus
	rp.StatusUserRoleDelete = common.UserRoleInactiveStatus
	return u.userMariaRepos.EditDimiilandUser(ctx, rp)
}

func (u *userService) GetPermissionByUserId(ctx context.Context, userId uint64) (*models.PermissionsUser, error) {
	param := make(map[string]interface{})
	param["user_id"] = userId
	param["role_active"] = statusRoleActive
	param["permission_active"] = statusPermissonActive
	return u.userMariaRepos.GetPermissionByUserId(ctx, param)
}

func (u *userService) DimiilandUserReinvite(ctx context.Context, rp *models.DimiilandUserReinviteRequest) (*common.HTTPResponse, error) {
	rp.Email = strings.ToLower(rp.Email)
	user, err := u.userMariaRepos.GetDimiilandUserByEmail(ctx, rp.Email, common.UserInvitedStatus)
	if err != nil {
		return nil, err
	}
	Expired := u.config.GetInt("jwt.user.invite.expired")
	jwtToken, err := u.jwtSigner.SignJwt(user)
	if err != nil {
		return nil, err
	}
	// Storing Email Token in redis
	err = u.userRepos.StoreEmailToken(KeyPassInviteEmailToken+rp.Email, jwtToken, int32(Expired))
	if err != nil {
		log.Println("Unable to Store Email Token in redis for invite dimiiland user")
		return nil, models.ErrInternalServerError
	}
	//Sending password creation link
	BaseURL := u.config.GetString("web.base.url")
	link := BaseURL + "/user/invite?token=" + jwtToken
	data := make(map[string]string)
	data["inviteURL"] = HTTPSProtocol + link

	notificationID := UserInviteMail
	if isEmailBelongsToGsuiteAccount(rp.Email) {
		notificationID = GsuiteUserInviteMail
	}

	SendUserInviteMail := notif.NotificationMessage{
		Recipient:      rp.Email,
		NotificationID: notificationID,
		Data:           data,
		Language:       "en",
		Channel:        notif.EMAIL,
	}
	msgByte, _ := json.Marshal(SendUserInviteMail)
	err = u.kfkClients.Publish(notif.NOTIFICATION_TOPIC, msgByte)
	if err != nil {
		return nil, errors.New("Unable to send user invite link mail")
	}

	responce := &common.HTTPResponse{Message: "Reivite User Successful", HTTPstatus: http.StatusOK}
	return responce, nil
}

func isEmailBelongsToGsuiteAccount(email string) bool {
	gsuiteAccount := map[string]bool{
		"capitalx.id": true,
	}
	domain := strings.Split(strings.ToLower(email), "@")[1]
	_, ok := gsuiteAccount[domain]
	return ok
}

func (u *userService) UpdateUserBlockedStatus(ctx context.Context, userReq *models.UserBlockStatus) (*common.HTTPResponse, error) {

	user, err := u.userMariaRepos.GetUserByUserID(ctx, userReq.UserID)
	if err != nil {
		log.Printf("[service] UpdateUserBlockedStatus : Error in Fetching user by id , %s \n", err)
		return nil, err
	}
	// want to unblock
	if userReq.Status == common.UserActiveStatus {
		if userReq.Status == user.Status {
			// already unblocked
			return nil, common.AppErrorCode(common.UserUnblockedAlready)
		}
		resp, err := u.userMariaRepos.UnblockUserByID(ctx, userReq)
		if err != nil {
			return nil, err
		}
		return &common.HTTPResponse{Message: resp}, nil
	} else if userReq.Status == common.UserPermanentBlockedStatus {
		if userReq.Status == user.Status {
			// already blocked
			return nil, common.AppErrorCode(common.UserBlockedAlready)
		}
		resp, err := u.userMariaRepos.BlockUserByID(ctx, userReq)
		if err != nil {
			return nil, err
		}
		return &common.HTTPResponse{Message: resp}, nil
	} else {
		return nil, common.AppErrorCode(common.InvalidUserStatus)
	}
}

func (u *userService) SendDimiilandUserPasswordResetLink(ctx context.Context, rp *models.UserPassResetLinkRequest) (*common.HTTPResponse, error) {
	// need to validate dimiiland user exists
	user, err := u.userMariaRepos.GetDimiilandUserByEmail(ctx, rp.Email, common.UserActiveStatus)
	if err != nil {
		return nil, err
	}
	resetExpired := u.config.GetInt("jwt.rest.password.expired")
	jwtToken, err := u.jwtSigner.SignJwt(user)

	if err != nil {
		return nil, err
	}
	u.userRepos.StoreEmailToken(KeyPassResetEmailToken+rp.Email, jwtToken, int32(resetExpired))

	//Send reset password link
	BaseURL := u.config.GetString("web.base.url")
	link := BaseURL + "/user/password-reset?token=" + jwtToken
	data := make(map[string]string)
	data["email"] = rp.Email
	data["resetURL"] = HTTPSProtocol + link

	resetPasswordLinkMail := notif.NotificationMessage{
		Recipient:      rp.Email,
		NotificationID: PasswordResetMail,
		Data:           data,
		Language:       "en",
		Channel:        notif.EMAIL,
	}
	msgByte, _ := json.Marshal(resetPasswordLinkMail)
	err = u.kfkClients.Publish(notif.NOTIFICATION_TOPIC, msgByte)
	if err != nil {
		return nil, errors.New("Unable to send reset password link mail")
	}
	response := &common.HTTPResponse{Message: "Send reset password link Successful", HTTPstatus: http.StatusOK}
	return response, nil

}

func (u *userService) VerifyDimiilandUserPasswordResetLink(ctx context.Context, emailToken string) (*common.HTTPResponse, error) {

	userClaims, err := u.jwtSigner.VerifyJwt(emailToken)
	if err != nil {
		log.Println("Error in verification failed:", err)
		return nil, common.AppErrorCode(common.TokenInvalid)
	}
	token, err := u.userRepos.GetEmailToken(ctx, KeyPassResetEmailToken+userClaims.Email)
	if err != nil {
		log.Println("Error in VerifyDimiilandUserPasswordResetLink : error", err)

	}

	if token == "" || (token != emailToken) {
		return nil, common.AppErrorCode(common.TokenExpired)
	}

	response := &common.HTTPResponse{Message: common.GetMessage(common.TokenVerified), HTTPstatus: http.StatusOK}
	return response, nil

}

func (u *userService) UpdateUserStatus(ctx context.Context, username string, status int) (bool, error) {
	return u.userMariaRepos.UpdateUserStatus(ctx, username, status)
}

func (u *userService) VerifyDimiilandUserInviteLink(ctx context.Context, emailToken string) (*common.HTTPResponse, error) {
	userClaims, err := u.jwtSigner.VerifyJwt(emailToken)
	if err != nil {
		log.Println("Error: Unable to verify JWT token.", err)
		return nil, common.AppErrorCode(common.TokenInvalid)
	}
	token, err := u.userRepos.GetEmailToken(ctx, KeyPassInviteEmailToken+userClaims.Email)
	if err != nil {
		log.Println("Error: Unable to get JWT token from redis cache.", err)
	}
	if token == "" || (token != emailToken) {
		return nil, common.AppErrorCode(common.TokenExpired)
	}
	response := &common.HTTPResponse{Message: common.GetMessage(common.TokenVerified), HTTPstatus: http.StatusOK}
	return response, nil
}

func (u *userService) DimiilandUserNewPassword(ctx context.Context, rp *models.DimiilandUserNewPasswordRequest) (*common.HTTPResponse, error) {

	jwt, err := u.jwtSigner.VerifyJwt(rp.EmailToken)
	if err != nil {
		log.Println("Error: Unable to verify JWT token.", err)
		return nil, common.AppErrorCode(common.TokenInvalid)
	}

	user, err := u.userMariaRepos.GetDimiilandUserByEmail(ctx, jwt.Email, common.UserInvitedStatus)
	if err != nil {
		return nil, err
	}

	token, err := u.userRepos.GetEmailToken(ctx, KeyPassInviteEmailToken+jwt.Email)
	if err != nil {
		log.Println("Error: Unable to get JWT token from redis cache.", err)
	}
	if token == "" || (token != rp.EmailToken) {
		return nil, common.AppErrorCode(common.TokenExpired)
	}

	hash, _ := GeneratedPassCode(rp.Password, jwt.Email)
	response, err := u.userMariaRepos.StoreDimiilandUserPassword(ctx, user.ID, hash)

	if err != nil {
		return nil, err
	}
	return response, nil
}
