package client

import (
	"context"
	error2 "git.capitalx.id/core/common/error"
	"google.golang.org/grpc/metadata"
	"log"

	"google.golang.org/grpc"

	"git.capitalx.id/core/user/delivery"
)

type userClient struct {
	conn   *grpc.ClientConn
	client delivery.UserHandlerClient
}

//UserClient to access user service
type UserClient interface {
	GenerateOTP(ctx context.Context, mobileNumber string, id int32) (*OTPResponse, error)
	ValidateInputOTP(ctx context.Context, mobileNumber string, otpCode string, id int32) (*OTPValidateResponse, error)
	ResendOTP(ctx context.Context, mobileNumber string, classificationID int32) (*ResendOTPResponse, error)
	StoreUser(ctx context.Context, user User) (uint64, error)
	CheckLoginPhoneNumberStatus(ctx context.Context, deviceID, mobileNumber string) (*OTPResponse, error)
	Login(ctx context.Context, passCode, deviceID, mobileNumber string) (*LoginResponse, error)
	GetUserByMobileNumber(ctx context.Context, mobileNumber string) (*User, error)
	BlockUser(ctx context.Context, mobileNumber string) (string, error)
	DeleteUser(ctx context.Context, mobileNumber string) (string, error)
	UpdateDeviceToken(ctx context.Context, mobileNumber, deviceID, deviceToken string) (int64, error)
	GetUserDeviceByMobileNumber(ctx context.Context, mobileNumber string) (*UserDevice, error)
	GetUserResendOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error)
	GetUserInputOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error)
	Close() error
	CheckMobileNumberLinkage(ctx context.Context, deviceID, mobileNumber string,clientId string) (*CheckMobileNumberLinkageResponse, error)
	ValidateInputOTPLinkage(ctx context.Context, mobileNumber, otpCode string, id int32,clientId string) (*OTPValidationLinkageResponse, error)
	LoginLinkage(ctx context.Context, passCode, deviceID, mobileNumber string) (*LoginLinkageResponse, error)
	ResendOTPLinkage(ctx context.Context, mobileNumber string, classificationID int32) (*ResendOTPLinkageResponse, error)
	ValidatePasscode(ctx context.Context, in *ValidatePasscodeRequest) (*ValidatePasscodeResponse, error)

}

func (u userClient) Close() error {
	return u.conn.Close()
}

//NewUserClient :
func NewUserClient(address string) (UserClient, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	client := delivery.NewUserHandlerClient(conn)

	return &userClient{conn: conn, client: client}, nil
}

func (u userClient) CheckMobileNumberLinkage(ctx context.Context, deviceID, mobileNumber string, clientId string) (*CheckMobileNumberLinkageResponse, error) {
	var md metadata.MD

	resp, err := u.client.CheckMobileNumberLinkage(ctx, &delivery.CheckMobileNumberLinkageRequest{
		MobileNumber: mobileNumber,
		DeviceId:     deviceID,
	},grpc.Trailer(&md))

	e := Error{}
	attr := make(map[string]string)
	e.Errors = make(map[string]interface{})

	var serviceErr error2.ServiceError

	if err != nil{
		// extract trailer metadata
		for k, vs := range md {
			for _, v := range vs {
				switch k {
				case "error_code":
					log.Println(v)
					serviceErr.Code = v
				case "error_message":
					log.Println(v)
					serviceErr.Message = v
				case "content-type":

				default :
					attr[k] = v
				}
			}
		}
		serviceErr.Attributes = attr

		return nil,serviceErr
	}

	return &CheckMobileNumberLinkageResponse{
		CountDownResendOtp: resp.CountDownResendOtp,
		OtpDuration:        resp.OtpDuration,
		Message:            resp.Message,
	}, nil
}

func (u userClient) ValidateInputOTPLinkage(ctx context.Context, mobileNumber, otpCode string, id int32, clientId string) (*OTPValidationLinkageResponse, error) {
	resp, err := u.client.ValidateInputOTPLinkage(ctx, &delivery.OTPValidationLinkageRequest{
		MobileNumber: mobileNumber,
		OtpCode:      otpCode,
		//Id:           id,
	})

	if err != nil {
		return nil, err
	}

	return &OTPValidationLinkageResponse{
		//NumberOfFailed: resp.Numberoffaileds
		Message: resp.Message,
	}, nil
}

func (u userClient) LoginLinkage(ctx context.Context, passCode, deviceID, mobileNumber string) (*LoginLinkageResponse, error) {
	resp, err := u.client.LoginLinkage(ctx, &delivery.LoginLinkageRequest{
		Passcode:     passCode,
		MobileNumber: mobileNumber,
		DeviceId:     deviceID,
	})

	if err != nil {
		return nil, err
	}

	return &LoginLinkageResponse{
		IdToken:      resp.IdToken,
		UserName:     resp.UserName,
		MobileNumber: resp.MobileNumber,
	}, nil
}

func (u userClient) ResendOTPLinkage(ctx context.Context, mobileNumber string, classificationID int32) (*ResendOTPLinkageResponse, error) {
	resp, err := u.client.ResendOTPLinkage(ctx, &delivery.ResendOTPLinkageRequest{
		MobileNumber: mobileNumber,
		Id:           classificationID,
	})

	if err != nil {
		return nil, err
	}

	return &ResendOTPLinkageResponse{
		CountdownResendOTP: resp.CountDownResendOtp,
		OtpDuration:        resp.OtpDuration,
		NumberOfResend:     resp.NumberOfResend,
		Message:            resp.Message,
	}, nil
}


func (u userClient) GenerateOTP(ctx context.Context, mobileNumber string, id int32) (*OTPResponse, error) {
	resp, err := u.client.GenerateOTP(ctx, &delivery.GenerateOTPRequest{
		Mobilenumber: mobileNumber,
		Id:           id,
	})

	if err != nil {
		return nil, err
	}

	return &OTPResponse{
		OtpCode:      resp.Otpcode,
		MobileNumber: resp.Mobilenumber,
		OtpDuration:  resp.Otpduration,
		Message:      resp.Message,
	}, nil
}

func (u userClient) ResendOTP(ctx context.Context, mobileNumber string, classificationID int32) (*ResendOTPResponse, error) {
	resp, err := u.client.ResendOTP(ctx, &delivery.ResendOTPRequest{
		MobileNumber: mobileNumber,
		Id:           classificationID,
	})

	if err != nil {
		return nil, err
	}

	return &ResendOTPResponse{
		CountdownResendOTP: resp.CountDownResendOtp,
		OtpDuration:        resp.OtpDuration,
		NumberOfResend:     resp.NumberOfResend,
		Message:            resp.Message,
	}, nil
}

func (u userClient) ValidateInputOTP(ctx context.Context, mobileNumber, otpCode string, id int32) (*OTPValidateResponse, error) {
	resp, err := u.client.ValidateInputOTP(ctx, &delivery.GetOTPValidateRequest{
		MobileNumber: mobileNumber,
		OtpCode:      otpCode,
		//Id:           id,
	})

	if err != nil {
		return nil, err
	}

	return &OTPValidateResponse{
		//NumberOfFailed: resp.Numberoffaileds
		Message: resp.Message,
	}, nil
}

func (u userClient) StoreUser(ctx context.Context, user User) (uint64, error) {
	resp, err := u.client.StoreUser(ctx, &delivery.StoreUserData{
		Createdby:    user.CreatedBy,
		Passcode:     user.Passcode,
		Mobilenumber: user.Mobile,
		Deviceid:     user.DeviceID,
		Username:     user.Username,
		Email:        user.Email,
		Name:         user.Name,
	})

	if err != nil {
		return 0, err
	}

	return resp.Id, nil
}
type Error struct {
	Errors map[string]interface{} `json:"errors"`
}
func (u userClient) CheckLoginPhoneNumberStatus(ctx context.Context, deviceID, mobileNumber string) (*OTPResponse, error) {
	var md metadata.MD

	resp, err := u.client.CheckLoginPhoneNumberStatus(ctx, &delivery.CheckStatusRequest{
		MobileNumber: mobileNumber,
		DeviceId:     deviceID,
	},grpc.Trailer(&md))

	e := Error{}
	attr := make(map[string]string)
	e.Errors = make(map[string]interface{})

	var serviceErr error2.ServiceError

	if err != nil{
		// extract trailer metadata
		for k, vs := range md {
			for _, v := range vs {
				switch k {
				case "error_code":
					log.Println(v)
					serviceErr.Code = v
				case "error_message":
					log.Println(v)
					serviceErr.Message = v
				case "content-type":

				default :
					attr[k] = v
				}
			}
		}
		serviceErr.Attributes = attr

		return nil,serviceErr
	}

	return &OTPResponse{
		CountdownResendOTP: resp.CountDownResendOtp,
		OtpDuration:        resp.OtpDuration,
		Message:            resp.Message,
	}, nil
}

func (u userClient) Login(ctx context.Context, passCode, deviceID, mobileNumber string) (*LoginResponse, error) {
	resp, err := u.client.Login(ctx, &delivery.LoginRequest{
		Passcode:     passCode,
		MobileNumber: mobileNumber,
		DeviceId:     deviceID,
	})

	if err != nil {
		return nil, err
	}

	return &LoginResponse{
		IDToken:      resp.IdToken,
		Username:     resp.UserName,
		MobileNumber: resp.MobileNumber,
	}, nil
}

func (u userClient) GetUserByMobileNumber(ctx context.Context, mobileNumber string) (*User, error) {
	resp, err := u.client.GetUserByPhoneNumber(ctx, &delivery.GetUserByPhoneNumberRequest{
		Mobilenumber: mobileNumber,
	})

	if err != nil {
		return nil, err
	}

	return &User{
		ID:       resp.Id,
		Username: resp.Username,
		Name:     resp.Name,
		Mobile:   resp.Mobile,
		Email:    resp.Email,
		Status:   resp.Status,
		DeviceID: resp.Deviceid,
	}, nil
}

func (u userClient) GetUserDeviceByMobileNumber(ctx context.Context, mobileNumber string) (*UserDevice, error) {
	userDevice, err := u.client.GetUserDevice(ctx, &delivery.GetMobileNumberRequest{
		Mobilenumber: mobileNumber,
	})

	if err != nil {
		return nil, err
	}
	return &UserDevice{
		Mobile:         userDevice.Mobile,
		DeviceID:       userDevice.DeviceId,
		Status:         userDevice.Status,
		DeviceRegToken: userDevice.DeviceRegToken,
	}, nil
}

func (u userClient) BlockUser(ctx context.Context, mobileNumber string) (string, error) {
	resp, err := u.client.BlockUser(ctx, &delivery.GetMobileNumberRequest{
		Mobilenumber: mobileNumber,
	})

	if err != nil {
		return "", err
	}

	return resp.Message, nil
}

func (u userClient) DeleteUser(ctx context.Context, mobileNumber string) (string, error) {
	resp, err := u.client.DeleteUser(ctx, &delivery.GetMobileNumberRequest{
		Mobilenumber: mobileNumber,
	})

	if err != nil {
		return "", err
	}

	return resp.Message, nil
}

func (u userClient) UpdateDeviceToken(ctx context.Context, mobileNumber, deviceID, deviceToken string) (int64, error) {
	resp, err := u.client.UpdateDeviceRegisterToken(ctx, &delivery.UpdateDeviceTokenRequest{Mobilenumber: mobileNumber,
		Deviceid: deviceID, Token: deviceToken})

	if err != nil {
		return 0, err
	}
	return resp.Status, nil
}

func (u userClient) GetUserResendOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error) {
	resp, err := u.client.GetUserResendOTPBlockedTime(ctx, &delivery.GetMobileNumberRequest{
		Mobilenumber: mobileNumber,
	})
	if err != nil {
		return 0, err
	}
	return resp.Remainingtime, nil
}

func (u userClient) GetUserInputOTPBlockedTime(ctx context.Context, mobileNumber string) (int32, error) {
	resp, err := u.client.GetUserInputOTPBlockedTime(ctx, &delivery.GetMobileNumberRequest{
		Mobilenumber: mobileNumber,
	})
	if err != nil {
		return 0, err
	}
	return resp.Remainingtime, nil
}


func (u userClient) ValidatePasscode(ctx context.Context, in *ValidatePasscodeRequest) (*ValidatePasscodeResponse, error) {
	resp, err := u.client.ValidatePasscode(ctx, &delivery.ValidatePasscodeRequest{
		PaymentCode: in.PaymentCode,
	})
	if err != nil {
		log.Printf("[client] Error validating passcode %s\n", err.Error())
		return nil, err
	}
	return &ValidatePasscodeResponse{
		Valid: resp.Valid,
	},nil
}

