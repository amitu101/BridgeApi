package client

import (
	"time"
)

//User is user data type
type User struct {
	ID          uint64
	Username    string
	Name        string
	Mobile      string
	Email       string
	Passcode    string
	Status      int32
	DeviceID    string
	LastBlocked time.Time
	CreatedBy   uint64
	CreatedTime time.Time
	UpdatedBy   uint64
	UpdatedTime time.Time
}

//LoginData is login data type
type LoginData struct {
	Mobile               string
	Passcode             string
	Status               int32
	DeviceID             string
	ExpiredDeviceBlocked int64
}

//OTPResponse is otp response data type
type OTPResponse struct {
	CountdownResendOTP int32
	OtpCode            string
	MobileNumber       string
	OtpDuration        int32
	Message            string
}

//GenerateOTP is generate otp data type
type GenerateOTP struct {
	OtpCode string
	Secret  string
	Status  string
}

//OTPValidateResponse is otp validate response data type
type OTPValidateResponse struct {
	//NumberOfFailed int32
	Message string
}

//ResendOTPResponse is resend otp response data type
type ResendOTPResponse struct {
	CountdownResendOTP int32
	OtpDuration        int32
	NumberOfResend     int32
	Message            string
}

//GeneratePwdParams is generate password params data type
type GeneratePwdParams struct {
	Memory      uint32
	Iterations  uint32
	Parallelism uint8
	SaltLength  uint32
	KeyLength   uint32
}

//SendMessage is send message data type
type SendMessage struct {
	MobileNumber string
	OtpCode      string
}

// PassCodeSecret is passcode and secret data type
type PasscodeSecret struct {
	PassCode string
}

type LoginResponse struct {
	IDToken      string
	Username     string
	MobileNumber string
}

type OtpPhoneNumberTesting struct {
	PhoneNumber string
	Otp         string
}

// UserDevice is user device data type
type UserDevice struct {
	Mobile                 string
	DeviceID               string
	ExpiredDeviceIDBlocked int64
	Counter                int32
	Status                 int32
	LastLogin              time.Time
	DeviceRegToken         string
}

//ResendOTPLinkageResponse is resend otp response data type
type ResendOTPLinkageResponse struct {
	CountdownResendOTP int32
	OtpDuration        int32
	NumberOfResend     int32
	Message            string
}
type LoginLinkageResponse struct {
	IdToken      string
	UserName     string
	MobileNumber string
}
type OTPValidationLinkageRequest struct {
	MobileNumber string
	OtpCode      string
	Id           int32
	ClientId     string
}
type OTPValidationLinkageResponse struct {
	Message string
}
type CheckMobileNumberLinkageResponse struct {
	CountDownResendOtp int32
	OtpDuration        int32
	Message            string
}
type CheckMobileNumberLinkageRequest struct {
	MobileNumber string
	DeviceId     string
	ClientId     string
}
type ValidatePasscodeRequest struct {
	PaymentCode string
}
type ValidatePasscodeResponse struct {
	Valid bool
}


