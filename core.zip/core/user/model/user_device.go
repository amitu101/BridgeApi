package model

import "time"

// UserDevice is user device data type
type UserDevice struct {
	Mobile                 string
	DeviceID               string
	ExpiredDeviceIDBlocked int64
	Counter                int32
	Status                 int32
	LastLogin              time.Time
	DeviceRegToken         string
}

type UserDeviceResponce struct {
	DeviceID    string `json:"device_id,omitempty"`
	Counter     int32  `json:"counter,omitempty"`
	Status      int32  `json:"status"`
	LastLogin   string `json:"last_login"`
	LastBlocked string `json:"last_blocked"`
}

type UserDeviceListRequest struct {
	ID         uint64
	PageNumber uint64
	Count      uint64
}
