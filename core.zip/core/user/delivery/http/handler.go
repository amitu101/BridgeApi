package http

import (
	"encoding/json"
	"log"
	"net/http"
	nethttp "net/http"
	"strconv"
	"strings"

	"git.capitalx.id/core/user/common"
	"git.capitalx.id/core/user/model"

	models "git.capitalx.id/core/user/model"
	userSrv "git.capitalx.id/core/user/service"
)

//UserHandler represent the http handler for Customer
type UserHandler struct {
	UUsecase userSrv.UserService
}

// NewUserHandler will initialize the users/ resources endpoint
func NewUserHandler(m *nethttp.ServeMux, userSrv userSrv.UserService) {
	handler := &UserHandler{
		UUsecase: userSrv,
	}
	common.Route(http.MethodGet, "/r/user", handler.GetDimiilandUsersList)
	common.Route(nethttp.MethodGet, "/r/user/roles", handler.UserRoles)
	common.Route(nethttp.MethodGet, "/r/user/role/([0-9]+)", handler.GetRole)
	common.Route(http.MethodGet, "/r/role/permissions", handler.ListPermission)
	common.Route(http.MethodGet, "/r/user/([0-9]+)/devices", handler.GetUserDeviceList)
	common.Route(http.MethodPost, "/r/role", handler.AddUserRole)
	common.Route(http.MethodPut, "/r/role", handler.UpdateUserRole)
	common.Route(http.MethodDelete, "/r/role/([0-9]+)", handler.DeleteUserRole)
	common.Route(http.MethodPost, "/r/user/add", handler.AddNewUser)
	common.Route(http.MethodPost, "/r/user/login", handler.DimmiLandlogin)
	common.Route(http.MethodPost, "/r/user/retrieve-otp", handler.RetrieveOTP)
	common.Route(http.MethodPut, "/r/user/edit", handler.EditDimiilandUser)
	common.Route(http.MethodGet, "/r/user/([0-9]+)/permissions", handler.GetPermissionByUserId)
	common.Route(http.MethodPost, "/r/user/reinvite", handler.DimiilandUserReinvite)
	common.Route(http.MethodPut, "/r/user/status", handler.UpdateUserBlockedStatus)
	common.Route(http.MethodPost, "/r/user/password-reset", handler.SendUserPasswordResetLink)
	common.Route(http.MethodGet, "/r/user/password-reset", handler.VerifyPasswordResetLink)
	common.Route(http.MethodPut, "/r/user/deactivate", handler.Deactivate)
	common.Route(http.MethodGet, "/r/user/invite", handler.VerifyDimiilandUserInviteLink)
	common.Route(http.MethodPut, "/r/user/new-password", handler.DimiilandUserNewPassword)
}

func httpResponseWrite(rw nethttp.ResponseWriter, response interface{}, statusCode int) {
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	json.NewEncoder(rw).Encode(response)
}

func (handler *UserHandler) Login(rw nethttp.ResponseWriter, req *nethttp.Request) {
	payload := &models.DummyLoginRequest{}

	err := json.NewDecoder(req.Body).Decode(payload)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	result, err := handler.UUsecase.DimmiLandLogin(req.Context(), payload.UserName, payload.Password)
	if err != nil {
		log.Printf("[delivery:http:handler] : Exception AddUserRole. Error: %s\n", err)
		reponse := &common.HTTPResponse{Message: "internal server error", Data: []int{}}
		httpResponseWrite(rw, reponse, http.StatusInternalServerError)
		return
	}

	response := &common.HTTPResponse{Message: "Login Successfull", Data: result}
	httpResponseWrite(rw, response, nethttp.StatusOK)
}

// ListPermission list of permissions
func (handler *UserHandler) ListPermission(rw nethttp.ResponseWriter, req *nethttp.Request) {

	var pageNumber, count uint64
	var err error

	if strPageNumber := req.URL.Query().Get("page_number"); strPageNumber != "" {
		pageNumber, err = strconv.ParseUint(strPageNumber, 0, 64)
		if err != nil {
			log.Printf("[delivery:http:handler] ListPermission Error in converting pageNumber string to integer. Error: %s \n", err)
		}
	}
	if strCount := req.URL.Query().Get("count"); strCount != "" {
		count, err = strconv.ParseUint(strCount, 0, 64)
		if err != nil {
			log.Printf("[delivery:http:handler] ListPermission Error in converting count string to integer. Error: %s \n", err)
		}
	}

	result, err := handler.UUsecase.ListPermissions(req.Context(), &models.PageRequest{PageNumber: pageNumber, Count: count})

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, result, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.PermNotAvailable {
			response := &common.HTTPResponse{Message: e.Message, Data: []int{}}
			httpResponseWrite(rw, response, nethttp.StatusOK)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}

func (h *UserHandler) UserRoles(rw nethttp.ResponseWriter, req *nethttp.Request) {
	// log.Println("you hit UserRoles")
	// ENDPOINT : /users/roles?permission_name?{permission_name}
	// ENDPOINT : /users/roles?role_name?{role_name}
	// ENDPOINT : /users/roles?page_number=1&count=2 -> will get all roles

	// Parsing URL Query Param
	roleName := strings.TrimSpace(req.URL.Query().Get("role_name"))
	permissionName := strings.TrimSpace(req.URL.Query().Get("permission"))

	if permissionName == "" && roleName == "" {
		var pageNumber, count uint64
		var err error
		if strPageNumber := req.URL.Query().Get("page_number"); strPageNumber != "" {
			pageNumber, err = strconv.ParseUint(strPageNumber, 0, 64)
			if err != nil {
				log.Printf("[delivery:http:handler] ListPermission Error in converting pageNumber string to integer. Error: %s \n", err)
			}
		}
		if strCount := req.URL.Query().Get("count"); strCount != "" {
			count, err = strconv.ParseUint(strCount, 0, 64)
			if err != nil {
				log.Printf("[delivery:http:handler] ListPermission Error in converting count string to integer. Error: %s \n", err)
			}
		}
		result, err := h.UUsecase.GetUserRolesList(req.Context(), &models.RolesRequest{PageNumber: pageNumber, Count: count})
		if err != nil {
			reponse := &common.HTTPResponse{Message: "internal server error", Data: []int{}}
			httpResponseWrite(rw, reponse, http.StatusInternalServerError)
			return
		}
		response := &common.HTTPResponse{Data: result.Data, Length: result.Length}
		httpResponseWrite(rw, response, result.HTTPstatus)
		return
	}

	if roleName != "" {
		outputData, err := h.UUsecase.GetUserRolesByRole(req.Context(), roleName)
		if err != nil {
			log.Println("[delivery:http:handler] UserRoles: Error GetUserRolesByRole. Error: ", err)
			response := &common.HTTPResponse{Message: err.Error(), Data: outputData}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
			return
		}
		response := &common.HTTPResponse{Message: "success", Data: outputData}
		httpResponseWrite(rw, response, nethttp.StatusOK)
		return

	}

	if permissionName != "" {
		outputData, err := h.UUsecase.GetUserRolesByPermissionName(req.Context(), permissionName)
		if err != nil {
			log.Println("[delivery:http:handler] UserRoles: Error GetUserRolesByPermissionName. Error: ", err)
			response := &common.HTTPResponse{Message: err.Error(), Data: outputData}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
			return
		}
		response := &common.HTTPResponse{Message: "success", Data: outputData}
		httpResponseWrite(rw, response, nethttp.StatusOK)
	}

}

//GetDimiilandUsersList will get dimiland user list
func (handler *UserHandler) GetDimiilandUsersList(rw nethttp.ResponseWriter, req *nethttp.Request) {
	// ENDPOINT : /users?limit=5&offset=1
	qParams := make(map[string]string)
	qParams["email"] = ""
	if len(req.URL.Query().Get("email")) > 0 {
		qParams["email"] = strings.TrimSpace(req.URL.Query().Get("email"))
	}
	qParams["role"] = ""
	if len(req.URL.Query().Get("role")) > 0 {
		qParams["role"] = strings.TrimSpace(req.URL.Query().Get("role"))
	}
	qParams["status"] = ""
	if len(req.URL.Query().Get("status")) > 0 {
		qParams["status"] = strings.TrimSpace(req.URL.Query().Get("status"))
	}
	qParams["order_by_column"] = ""
	if len(req.URL.Query().Get("order_by_column")) > 0 {
		qParams["order_by_column"] = strings.TrimSpace(req.URL.Query().Get("order_by_column"))
	}

	count := strings.TrimSpace(req.URL.Query().Get("count"))
	if count == "" {
		count = "5"
	}
	qParams["limit"] = count

	page_number := strings.TrimSpace(req.URL.Query().Get("page_number"))
	if page_number == "" {
		page_number = "1"
	}
	qParams["page_number"] = page_number

	ascending := strings.TrimSpace(req.URL.Query().Get("ascending"))
	if ascending == "" {
		ascending = "false"
	}
	qParams["ascending"] = ascending

	userType := strings.TrimSpace(req.URL.Query().Get("user_type"))
	if userType == "" {
		userType = "dimiiland"
	}
	qParams["userType"] = userType

	Data, length, err := handler.UUsecase.GetDimiilandUsersList(req.Context(), qParams)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error(), Data: Data}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		return
	}
	response := &common.HTTPResponse{Message: "success", Data: Data, Length: length}
	httpResponseWrite(rw, response, nethttp.StatusOK)
}

//GetUserDeviceList will get user device list by user id
func (handler *UserHandler) GetUserDeviceList(rw nethttp.ResponseWriter, req *nethttp.Request) {
	// ENDPOINT : /users/:UserID/devices?limit=5&offset=1
	pr := &model.UserDeviceListRequest{}
	pr.ID, _ = strconv.ParseUint(common.Param(req, 0), 0, 64)

	if strPageNumber := req.URL.Query().Get("page_number"); strPageNumber != "" {
		pr.PageNumber, _ = strconv.ParseUint(strPageNumber, 0, 64)
	}

	if strCount := req.URL.Query().Get("count"); strCount != "" {
		pr.Count, _ = strconv.ParseUint(strCount, 0, 64)
	}

	if pr.ID == 0 {
		response := &common.HTTPResponse{Message: "Users ID is required", Data: []int{}}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	limit, _ := strconv.Atoi(req.URL.Query().Get("count"))
	if limit == 0 {
		limit = 5 //default value
	}
	// offset, _ := strconv.Atoi(req.URL.Query().Get("offset"))
	data, err := handler.UUsecase.GetUserDeviceByUserID(req.Context(), pr)

	if err != nil {
		response := &common.HTTPResponse{Message: err.Error(), Data: data}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	// response := &common.HTTPResponse{Data: data}
	httpResponseWrite(rw, data, nethttp.StatusOK)
}

//AddUserRole add user role
func (handler *UserHandler) AddUserRole(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rpReq := &models.RolePermissionsRequest{}

	err := json.NewDecoder(req.Body).Decode(rpReq)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	if rpReq.Name == "" {
		response := &common.HTTPResponse{Message: "name should not be empty"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	result, err := handler.UUsecase.AddUserRole(req.Context(), rpReq)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, result, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.RoleNameTaken {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusPreconditionFailed)
		} else if e.Code == common.PermNotAvailable {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusPreconditionFailed)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}

//UpdateUserRole update user role
func (handler *UserHandler) UpdateUserRole(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rpReq := &models.RolePermissionsRequest{}

	err := json.NewDecoder(req.Body).Decode(rpReq)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	if rpReq.Name == "" {
		response := &common.HTTPResponse{Message: "name should not be empty"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	result, err := handler.UUsecase.UpdateUserRole(req.Context(), rpReq)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, result, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.RoleNameTaken {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusPreconditionFailed)
		} else if e.Code == common.RoleNameNotAvailable || e.Code == common.UpdateRoleUnsuccessful {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		} else if e.Code == common.PermNotAvailable  {
		    response := &common.HTTPResponse{Message: e.Message}
		    httpResponseWrite(rw, response, nethttp.StatusPreconditionFailed)
	   } else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}

//DeleteUserRole update user role
func (handler *UserHandler) DeleteUserRole(rw nethttp.ResponseWriter, req *nethttp.Request) {
	roleID, err := strconv.ParseUint(common.Param(req, 0), 0, 64)
	if err != nil ||  roleID == 0 {
		response := &common.HTTPResponse{Message: "role ID is invalid" }
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	_, err = handler.UUsecase.DeleteUserRole(req.Context(), roleID)
	switch e := err.(type) {
	case nil:
		response := &common.HTTPResponse{Message: "Success"}
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.UserExistsForRole {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusPreconditionFailed)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}

}

func (handler *UserHandler) AddNewUser(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rpReq := &models.AddNewUserRequest{}

	err := json.NewDecoder(req.Body).Decode(rpReq)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	result, err := handler.UUsecase.AddNewUser(req.Context(), rpReq)

	if err != nil {
		log.Printf("[delivery:http:handler] : Exception AddUserRole. Error: %s\n", err)
		reponse := &common.HTTPResponse{Message: "internal server error", Data: []int{}}
		httpResponseWrite(rw, reponse, http.StatusInternalServerError)
		return
	}
	response := &common.HTTPResponse{Message: result.Message}
	httpResponseWrite(rw, response, result.HTTPstatus)
}

func (handler *UserHandler) DimmiLandlogin(rw nethttp.ResponseWriter, req *nethttp.Request) {
	payload := &models.DummyLoginRequest{}

	err := json.NewDecoder(req.Body).Decode(payload)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	result, err := handler.UUsecase.DimmiLandLogin(req.Context(), payload.UserName, payload.Password)

	if err != nil {
		log.Printf("[delivery:http:handler] : Exception DimmiLandlogin. Error: %s\n", err)
		reponse := &common.HTTPResponse{Message: err.Error(), Data: result}
		httpResponseWrite(rw, reponse, http.StatusInternalServerError)
		return
	}

	response := &common.HTTPResponse{Message: "success", Data: result}
	httpResponseWrite(rw, response, nethttp.StatusOK)
}

// RetrieveOTP get otp for testers for their automation
func (handler *UserHandler) RetrieveOTP(rw nethttp.ResponseWriter, req *nethttp.Request) {
	optRequest := &models.OTPDataRequest{}

	err := json.NewDecoder(req.Body).Decode(optRequest)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	response, err := handler.UUsecase.GetOTP(req.Context(), optRequest.MobileNumber, optRequest.OtpType)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.OTPNotFound {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusOK)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}

func (handler *UserHandler) EditDimiilandUser(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rq := &models.UserEditRequest{}

	err := json.NewDecoder(req.Body).Decode(rq)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	if rq.UserID == 0 || len(rq.RolesID) == 0 || rq.RequestorID == 0 {
		response := &common.HTTPResponse{Message: "user_id,roles_id and requestor_id is required"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	result, err := handler.UUsecase.EditDimiilandUser(req.Context(), rq)

	if err != nil {
		log.Printf("[delivery:http:handler] : Exception AddUserRole. Error: %s\n", err)
		reponse := &common.HTTPResponse{Message: "internal server error", Data: []int{}}
		httpResponseWrite(rw, reponse, http.StatusInternalServerError)
		return
	}
	response := &common.HTTPResponse{Message: result.Message}
	httpResponseWrite(rw, response, result.HTTPstatus)
}
func (handler *UserHandler) GetPermissionByUserId(rw nethttp.ResponseWriter, req *nethttp.Request) {
	//var userId uint64

	log.Println("userid : ", common.Param(req, 0))
	userId, _ := strconv.ParseUint(common.Param(req, 0), 0, 64)

	if userId == 0 {
		response := &common.HTTPResponse{Message: "Users ID is required", Data: []int{}}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	data, err := handler.UUsecase.GetPermissionByUserId(req.Context(), userId)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error(), Data: data}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	if data.UserId == 0 {
		response := &common.HTTPResponse{Message: "User Not Found", Data: nil}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
	if len(data.Permissions) == 0 {
		response := &common.HTTPResponse{Message: "User Has No Available Permissions", Data: nil}
		httpResponseWrite(rw, response, nethttp.StatusUnauthorized)
		return
	}
	//response := &common.HTTPResponse{Data: data}
	httpResponseWrite(rw, data, nethttp.StatusOK)
}

func (handler *UserHandler) DimiilandUserReinvite(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rp := &models.DimiilandUserReinviteRequest{}

	err := json.NewDecoder(req.Body).Decode(rp)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	result, err := handler.UUsecase.DimiilandUserReinvite(req.Context(), rp)

	if err != nil {
		log.Printf("[delivery:http:handler] : Exception Dimiiland User Reinvite. Error: %s\n", err)
		reponse := &common.HTTPResponse{Message: "internal server error", Data: []int{}}
		httpResponseWrite(rw, reponse, http.StatusInternalServerError)
		return
	}
	response := &common.HTTPResponse{Message: result.Message}
	httpResponseWrite(rw, response, result.HTTPstatus)
}

//UpdateUserBlockedStatus Block | Unblock user
func (handler *UserHandler) UpdateUserBlockedStatus(rw nethttp.ResponseWriter, req *nethttp.Request) {
	userReq := &models.UserBlockStatus{}

	err := json.NewDecoder(req.Body).Decode(userReq)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	if userReq.UserID == 0 {
		response := &common.HTTPResponse{Message: "UserID is required"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	if userReq.Status == common.UserPermanentBlockedStatus && userReq.Reason == "" {
		response := &common.HTTPResponse{Message: "Reason should not be empty"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	response, err := handler.UUsecase.UpdateUserBlockedStatus(req.Context(), userReq)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.UserBlockedAlready || e.Code == common.UserUnblockedAlready || e.Code == common.UserNotFound {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusOK)
		} else if e.Code == common.InvalidUserStatus {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}

func (handler *UserHandler) SendUserPasswordResetLink(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rp := &models.UserPassResetLinkRequest{}

	err := json.NewDecoder(req.Body).Decode(rp)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	response, err := handler.UUsecase.SendDimiilandUserPasswordResetLink(req.Context(), rp)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.UserNotFound {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusOK)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}

//VerifyPasswordResetLink VerifyPasswordResetLink
func (handler *UserHandler) VerifyPasswordResetLink(rw nethttp.ResponseWriter, req *nethttp.Request) {
	token := req.URL.Query().Get("token")
	if len(token) <= 0 {
		response := &common.HTTPResponse{Message: common.GetMessage(common.TokenInvalid)}
		httpResponseWrite(rw, response, nethttp.StatusUnauthorized)
		return
	}

	response, err := handler.UUsecase.VerifyDimiilandUserPasswordResetLink(req.Context(), token)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.TokenInvalid {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusUnauthorized)
		} else if e.Code == common.TokenExpired {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusGone)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}

}

func (handler *UserHandler) Deactivate(rw nethttp.ResponseWriter, req *nethttp.Request) {
	// ENDPOINT : /r/user/deactivate
	// Body: {"user_name":"emailaddress@doamin.com" }
	payload := &models.DummyLoginRequest{}

	err := json.NewDecoder(req.Body).Decode(payload)

	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	} else if payload.UserName == "" {
		response := &common.HTTPResponse{Message: "Unable to Parse Request Body UserName is empty"}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	if _, err := handler.UUsecase.UpdateUserStatus(req.Context(), payload.UserName, common.UserInActiveStatus); err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		return
	}

	response := &common.HTTPResponse{Message: "Deactivated User Successfully"}
	httpResponseWrite(rw, response, nethttp.StatusOK)

}

//VerifyDimiilandUserInviteLink  will Verify Dimiiland New User Inviteed Link
func (handler *UserHandler) VerifyDimiilandUserInviteLink(rw nethttp.ResponseWriter, req *nethttp.Request) {
	token := req.URL.Query().Get("token")
	if len(token) <= 0 {
		response := &common.HTTPResponse{Message: common.GetMessage(common.TokenInvalid)}
		httpResponseWrite(rw, response, nethttp.StatusUnauthorized)
		return
	}
	response, err := handler.UUsecase.VerifyDimiilandUserInviteLink(req.Context(), token)
	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.TokenInvalid {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusUnauthorized)
		} else if e.Code == common.TokenExpired {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusGone)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}

}

func (handler *UserHandler) DimiilandUserNewPassword(rw nethttp.ResponseWriter, req *nethttp.Request) {
	rp := &models.DimiilandUserNewPasswordRequest{}
	rp.EmailToken = req.URL.Query().Get("token")
	err := json.NewDecoder(req.Body).Decode(rp)
	if err != nil {
		response := &common.HTTPResponse{Message: err.Error()}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}

	response, err := handler.UUsecase.DimiilandUserNewPassword(req.Context(), rp)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
	case *common.AppError:
		if e.Code == common.UserNotFound {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusOK)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}
}


func (handler *UserHandler) GetRole(rw nethttp.ResponseWriter, req *nethttp.Request) {
	roleID, err := strconv.ParseUint(common.Param(req, 0), 0, 64)
	if err != nil ||  roleID == 0 {
		response := &common.HTTPResponse{Message: "role ID is invalid", Data: []int{}}
		httpResponseWrite(rw, response, nethttp.StatusBadRequest)
		return
	}
    response,err :=handler.UUsecase.GetRole(req.Context(),roleID)
	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, response, nethttp.StatusOK)
		case *common.AppError:
		if e.Code == common.RoleIdNotAvailable {
			response := &common.HTTPResponse{Message: e.Message}
			httpResponseWrite(rw, response, nethttp.StatusPreconditionFailed)
		} else {
			response := &common.HTTPResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
		}
	default:
		response := &common.HTTPResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, nethttp.StatusInternalServerError)
	}



}

