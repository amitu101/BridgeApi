package jwt

import (
	"crypto/x509"
	"encoding/json"
	"encoding/pem"
	"fmt"
	"log"
	"time"

	"gopkg.in/square/go-jose.v2"
	"gopkg.in/square/go-jose.v2/jwt"

	"git.capitalx.id/core/user/model"
)

type JWTSigner interface {
	SignJwt(user *model.User) (string, error)
	VerifyJwt(token string) (*UserClaims, error)
}

type jwtSigner struct {
	issuer     string
	privateKey string
	publicKey  string
	expired    time.Duration
}

func NewJWTSigner(issuer, privateKey, publicKey string, expired time.Duration) JWTSigner {
	return &jwtSigner{
		issuer:     issuer,
		privateKey: privateKey,
		publicKey:  publicKey,
		expired:    expired}
}

func (s *jwtSigner) VerifyJwt(token string) (*UserClaims, error) {
	keyBytes := []byte(s.publicKey)

	verificationKey, err := LoadPublicKey(keyBytes)
	if err != nil {
		log.Println("unable to read public key", err)
		return nil, err
	}

	obj, err := jose.ParseSigned(token)
	if err != nil {
		log.Println("unable to parse message", err)
		return nil, err
	}
	plaintext, err := obj.Verify(verificationKey)
	if err != nil {
		log.Println("invalid signature", err)
		return nil, err
	}

	userClaims := new(UserClaims)
	if err := json.Unmarshal(plaintext, userClaims); err != nil {
		log.Println("UserClaims Unmarshal failed", err)
		return nil, err
	}

	// if userClaims.Expiry.Time().Before(time.Now()) {
	// 	log.Println("Token expired")
	// 	return false, err
	// }
	return userClaims, nil
}

func (s *jwtSigner) SignJwt(user *model.User) (string, error) {

	keyBytes := []byte(s.privateKey)

	signingKey, err := LoadPrivateKey(keyBytes)
	if err != nil {
		log.Println("unable to read private key", err)
		return "", err
	}

	alg := jose.SignatureAlgorithm(jose.ES256)
	sig, err := jose.NewSigner(jose.SigningKey{Algorithm: alg, Key: signingKey}, nil)
	if err != nil {
		log.Println("unable to make signer", err)
		return "", err
	}

	now := time.Now()
	expired := now.Add(s.expired)

	claims := UserClaims{
		Claims: jwt.Claims{
			Subject:  user.Email,
			Issuer:   s.issuer,
			IssuedAt: jwt.NewNumericDate(now),
			Expiry:   jwt.NewNumericDate(expired),
		},
		Username: user.Username,
		Name:     user.Name,
		Mobile:   user.Mobile,
		Email:    user.Email}

	msg, err := jwt.Signed(sig).Claims(claims).CompactSerialize()
	if err != nil {
		log.Println(err)
		return "", err
	}

	return msg, nil
}

// LoadPublicKey loads a public key from PEM/DER/JWK-encoded data.
func LoadPublicKey(data []byte) (interface{}, error) {
	input := data

	block, _ := pem.Decode(data)
	if block != nil {
		input = block.Bytes
	}

	// Try to load SubjectPublicKeyInfo
	pub, err0 := x509.ParsePKIXPublicKey(input)
	if err0 == nil {
		return pub, nil
	}

	cert, err1 := x509.ParseCertificate(input)
	if err1 == nil {
		return cert.PublicKey, nil
	}

	return nil, fmt.Errorf("square/go-jose: parse error, got '%s', '%s'", err0, err1)
}

func LoadPrivateKey(data []byte) (interface{}, error) {
	input := data

	block, _ := pem.Decode(data)
	if block != nil {
		input = block.Bytes
	}

	var priv interface{}
	priv, err0 := x509.ParsePKCS1PrivateKey(input)
	if err0 == nil {
		return priv, nil
	}

	priv, err1 := x509.ParsePKCS8PrivateKey(input)
	if err1 == nil {
		return priv, nil
	}

	priv, err2 := x509.ParseECPrivateKey(input)
	if err2 == nil {
		return priv, nil
	}

	return nil, fmt.Errorf("square/go-jose: parse error, got '%s', '%s', '%s'", err0, err1, err2)
}
