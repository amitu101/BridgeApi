package env

import (
	"encoding/base64"
	"fmt"
	"os"
	"strings"

	"github.com/spf13/viper"

	core_config "git.capitalx.id/core/config"
)

type viperConfig struct {
}

func (v *viperConfig) GetFloat(key string) float64 {
	return viper.GetFloat64(key)
}

func (v *viperConfig) GetBinary(key string) []byte {
	value := viper.GetString(key)
	bytes, err := base64.StdEncoding.DecodeString(value)
	if err == nil {
		return bytes
	}
	return nil
}

func (v *viperConfig) GetArray(key string) []string {
	return viper.GetStringSlice(key)
}

func (v *viperConfig) GetMap(key string) map[string]string {
	return viper.GetStringMapString(key)
}

func (v *viperConfig) Init() {
	viper.SetEnvPrefix(`user`)
	viper.AutomaticEnv()

	env := os.Getenv("ENV")

	replacer := strings.NewReplacer(`.`, `_`)
	viper.SetEnvKeyReplacer(replacer)
	viper.SetConfigType(`json`)
	if env != "" {
		viper.SetConfigFile(fmt.Sprintf(`config.%s.json`, env))
	} else {
		viper.SetConfigFile(`config.json`)
	}

	err := viper.ReadInConfig()

	if err != nil {
		panic(err)
	}

}

func (v *viperConfig) GetString(key string) string {
	return viper.GetString(key)
}

func (v *viperConfig) GetInt(key string) int64 {
	return viper.GetInt64(key)
}

func (v *viperConfig) GetBool(key string) bool {
	return viper.GetBool(key)
}

func NewViperConfig() core_config.Config {
	v := &viperConfig{}
	v.Init()
	return v
}
