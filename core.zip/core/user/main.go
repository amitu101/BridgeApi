package main

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	_ "github.com/lib/pq"

	"google.golang.org/grpc"

	common "git.capitalx.id/core/common/grpc"
	commonHttp "git.capitalx.id/core/common/http"
	"git.capitalx.id/core/common/mysql"
	tls2 "git.capitalx.id/core/common/tls"
	cfg "git.capitalx.id/core/config/vault"
	"git.capitalx.id/core/id/client"
	"git.capitalx.id/core/messaging"
	"git.capitalx.id/core/messaging/kafka"
	rds "git.capitalx.id/core/messaging/redis"
	"git.capitalx.id/core/user/authprovider/ldap"
	restHandler "git.capitalx.id/core/user/common"
	deliveryGrpc "git.capitalx.id/core/user/delivery"
	HandlerHTTP "git.capitalx.id/core/user/delivery/http"
	"git.capitalx.id/core/user/jwt"
	mariaRepo "git.capitalx.id/core/user/repository"
	redisRepo "git.capitalx.id/core/user/repository"
	userSrv "git.capitalx.id/core/user/service"
	"github.com/Shopify/sarama"
	"github.com/go-redis/redis/v7"
)

func getKafkaConfig(username, password string, tlsConfig *tls.Config) *sarama.Config {
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Producer.Return.Successes = true
	kafkaConfig.Net.DialTimeout = 5 * time.Second
	kafkaConfig.Net.WriteTimeout = 5 * time.Second
	if tlsConfig != nil {
		kafkaConfig.Net.TLS.Enable = true
		kafkaConfig.Net.TLS.Config = tlsConfig
	}

	if username != "" {
		kafkaConfig.Net.SASL.Enable = true
		kafkaConfig.Net.SASL.User = username
		kafkaConfig.Net.SASL.Password = password
	}
	return kafkaConfig
}

func getKafkaClient(kafkaAddresses []string, tlsConfig *tls.Config) (messaging.Client, error) {
	config := getKafkaConfig("", "", tlsConfig)
	return kafka.NewClient(kafkaAddresses, config)
}

func getRedisClient(address []string, tlsconfig *tls.Config) (messaging.Client, error) {
	options := redis.ClusterOptions{TLSConfig: tlsconfig}
	return rds.NewClusterClient(address, &options)
}

func serveHTTP(addr string, uu userSrv.UserService) error {
	mux := http.DefaultServeMux
	HandlerHTTP.NewUserHandler(mux, uu)
	log.Println("http server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(http.HandlerFunc(restHandler.Serve))); err != nil {
		return err
	}
	return nil
}

func serveHTTPGRPC(addr, addrGrpc string) error {
	log.Println("ini addrGrpc: ", addrGrpc)
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// Set runtime.GlobalHTTPErrorHandler = CustomHTTPError
	runtime.GlobalHTTPErrorHandler = CustomHTTPError

	mux := runtime.NewServeMux()
	opts := []grpc.DialOption{grpc.WithInsecure()}
	err := deliveryGrpc.RegisterUserHandlerHandlerFromEndpoint(ctx, mux, addrGrpc, opts)
	if err != nil {
		log.Println("err in serveHTTPGrpc: ", err)
	}

	log.Println("gw server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(mux)); err != nil {
		return err
	}
	return nil
}

func main() {
	config, err := cfg.GetConfig("user")
	if err != nil {
		log.Println(err)
		return
	}

	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dbConn, err := mysql.DB(dbConfig)
	defer func() {
		if err := dbConn.Close(); err != nil {
			log.Print(err)
		}
	}()

	kafkaAddr := config.GetArray("messaging.host")
	kafkaCa := config.GetBinary("kafka.ca")
	kafkaCert := config.GetBinary("kafka.cert")
	kafkaKey := config.GetBinary("kafka.key")

	tlsConfig := tls2.WithCertificate(kafkaCa, kafkaCert, kafkaKey, false)
	msgClient, msgErr := getKafkaClient(kafkaAddr, tlsConfig)
	if msgErr != nil {
		log.Println(msgErr)
	}
	log.Println("publisher set to kafka cluster", kafkaAddr)

	var urr redisRepo.CacheUserRepository

	redisCluster := config.GetArray("redis.cluster")
	if len(redisCluster) > 0 {
		redisCa := config.GetBinary("redis.ca")
		//redisCert := config.GetBinary("redis.cert")
		//redisKey := config.GetBinary("redis.key")
		//tlsConfig := tls2.WithCertificate(redisCa, redisCert, redisKey, false)
		tlsConfig := tls2.WithCA(redisCa)
		tlsConfig.InsecureSkipVerify = true

		rdb := redis.NewClusterClient(&redis.ClusterOptions{
			Addrs:     redisCluster,
			TLSConfig: tlsConfig,
		})

		if err := rdb.Ping().Err(); err != nil {
			log.Println("redis connection error", err)
		}

		urr = redisRepo.NewRedisUserRepository(rdb)
	} else {
		addr := config.GetString("redis.addr")
		rdb := redis.NewClient(&redis.Options{
			Addr: addr,
		})

		urr = redisRepo.NewRedisSingleRepository(rdb)
	}

	umr := mariaRepo.NewMariaUserRepository(dbConn)

	idGenerartorAddr := config.GetString(`server.id_generator`)
	idClient, err := client.NewSequenceClient(idGenerartorAddr)

	jwksUrl := config.GetString("jwt.url")
	issuer := config.GetString("jwt.issuer")
	expired := config.GetInt("jwt.expired")

	publicKey := config.GetString("jwt.public.key")
	privateKey := config.GetString("jwt.private.key")
	resetExpired := config.GetInt("jwt.reset.password.expired")

	signer := jwt.NewSigner(jwksUrl, issuer, time.Duration(expired)*time.Second)
	jwtSigner := jwt.NewJWTSigner(issuer, privateKey, publicKey, time.Duration(resetExpired)*time.Second)

	// contact ldap
	ldapServer := config.GetString("ldap.server")
	ldapPort := config.GetString("ldap.port")
	ldapBindDN := config.GetString("ldap.binddn")
	ldapPassword := config.GetString("ldap.password")
	ldapkey := config.GetBinary("ldap.key")
	ldapcert := config.GetBinary("ldap.cert")
	ldapSearchDN := config.GetString("ldap.searchdn")

	ldapConfig := ldap.Config{
		Host:     ldapServer,
		Port:     ldapPort,
		BindDN:   ldapBindDN,
		Password: ldapPassword,
		Key:      ldapkey,
		Cert:     ldapcert,
		SearchDN: ldapSearchDN,
	}

	ldap, err := ldap.LDAP(ldapConfig)
	if err != nil {
		log.Println(err)
	}
	defer func() {
		ldap.Conn.Close()
	}()

	// service
	uu := userSrv.NewUserService(urr, umr, msgClient, idClient, signer, jwtSigner, ldap, config)

	// start grpc
	pbServer := grpc.NewServer(common.WithDefault()...)
	deliveryGrpc.NewUserServerGrpc(pbServer, uu)

	// Create the main listener for http
	// get all required addr
	addrGrpc := config.GetString("server.address")
	addrGw := config.GetString("server.address.gw")
	addrHttp := config.GetString("server.address.http")

	// grpc
	errHdlr := common.WithDefault()
	server := grpc.NewServer(errHdlr...)
	deliveryGrpc.NewUserServerGrpc(server, uu)

	go func() {
		common.Serve(addrGrpc, server)
	}()

	go serveHTTP(addrHttp, uu)
	go serveHTTPGRPC(addrGw, addrGrpc)
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGINT, syscall.SIGTERM)

	<-done
	//l.Close()
	log.Println("All server stopped!")
	//}()

}

type Error struct {
	Errors map[string]interface{} `json:"errors"`
}

func CustomHTTPError(ctx context.Context, _ *runtime.ServeMux, marshaler runtime.Marshaler, w http.ResponseWriter, _ *http.Request, err error) {
	const fallback = `{"error": "failed to marshal error message"}`

	sm, _ := runtime.ServerMetadataFromContext(ctx)
	e := Error{}
	attr := make(map[string]interface{})
	e.Errors = make(map[string]interface{})

	// extract trailer metadata
	for k, vs := range sm.TrailerMD {
		for _, v := range vs {
			switch k {
			case "error_code":
				e.Errors["error_code"] = v
			case "error_message":
				e.Errors["error_message"] = v
			case "content-type":

			default:
				attr[k] = v
			}
		}
	}

	e.Errors["attributes"] = attr

	w.Header().Set("Content-type", marshaler.ContentType())
	w.WriteHeader(runtime.HTTPStatusFromCode(grpc.Code(err)))

	jErr := json.NewEncoder(w).Encode(e.Errors)

	if jErr != nil {
		w.Write([]byte(fallback))
	}
}
