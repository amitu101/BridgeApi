package main

import (
	srv "git.capitalx.id/core/common/grpc"
	"git.capitalx.id/core/common/mysql"
	cfg "git.capitalx.id/core/config/vault"
	deliveryGrpc "git.capitalx.id/core/id/delivery"
	mariaRepo "git.capitalx.id/core/id/repository"
	seqSrv "git.capitalx.id/core/id/service"
	"google.golang.org/grpc"
	"log"
)

func main() {
	config, err := cfg.GetConfig("id")
	if err != nil {
		log.Println(err)
		return
	}

	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dbConn, err := mysql.DB(dbConfig)
	if err != nil {
		log.Println(err)
		return
	}
	defer func() {
		if err := dbConn.Close(); err != nil {
			log.Print(err)
		}
	}()

	smr := mariaRepo.NewSequenceRepository(dbConn)

	//service
	ss := seqSrv.NewSequenceService(smr)

	// start grpc
	server := grpc.NewServer(srv.WithDefault()...)
	deliveryGrpc.NewSequenceServerGrpc(server, ss)
	address := ":" + config.GetString("server.port")
	log.Println("Server Run at ", address)

	srv.Serve(address, server)
}
