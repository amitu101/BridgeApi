package delivery

import (
	context "context"

	"google.golang.org/grpc/reflection"

	"google.golang.org/grpc"

	_srv "git.capitalx.id/core/id/service"
)

func NewSequenceServerGrpc(gserver *grpc.Server, sequenceServer _srv.SequenceService) {
	seqServer := &server{
		service: sequenceServer,
	}
	RegisterSequenceHandlerServer(gserver, seqServer)
	reflection.Register(gserver)
}

type server struct {
	service _srv.SequenceService
}

func (s *server) GetIdNextVal(ctx context.Context, void *GetSequenceRequest) (*GetSequenceResponse, error) {
	SequenceData, err := s.service.GetIdNextVal(ctx)
	if err != nil {
		return nil, err
	}

	return &GetSequenceResponse{
		Val: SequenceData.Value,
	}, nil
}

func (s *server) GetIdDummy(ctx context.Context, void *GetSequenceRequest) (*GetSequenceResponse, error) {
	SequenceData, err := s.service.GetIdDummy(ctx)
	if err != nil {
		return nil, err
	}

	return &GetSequenceResponse{
		Val: SequenceData.Value,
	}, nil
}
