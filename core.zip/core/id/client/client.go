package client

import (
	"context"
	"log"

	models "git.capitalx.id/core/id/model"

	"git.capitalx.id/core/id/delivery"
	"git.capitalx.id/core/id/service"
	"google.golang.org/grpc"
)

type sequenceClient struct {
	conn   *grpc.ClientConn
	client delivery.SequenceHandlerClient
}

func (seq sequenceClient) Close() error {
	return seq.conn.Close()
}

func NewSequenceClient(address string) (service.SequenceService, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())

	if err != nil {
		return nil, err
	}
	client := delivery.NewSequenceHandlerClient(conn)

	return &sequenceClient{
		conn:   conn,
		client: client,
	}, nil
}

func (s sequenceClient) GetIdNextVal(ctx context.Context) (*models.GetSequenceResponse, error) {
	resp, err := s.client.GetIdNextVal(ctx, &delivery.GetSequenceRequest{})
	if err != nil {
		log.Println(err)
		return nil, err
	}

	log.Println("[client]-]ID value : ",resp)

	return &models.GetSequenceResponse{
		Value: resp.Val,
	}, nil

}

func (s sequenceClient) GetIdDummy(ctx context.Context) (*models.GetSequenceResponse, error) {
	resp, err := s.client.GetIdDummy(ctx, &delivery.GetSequenceRequest{})
	if err != nil {
		log.Println(err)
		return nil, err
	}

	log.Println("[client]-]ID value : ",resp)

	return &models.GetSequenceResponse{
		Value: resp.Val,
	}, nil

}
