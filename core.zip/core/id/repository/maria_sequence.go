package repository

import (
	"database/sql"
	"log"
)

type sequenceRepository struct {
	Conn *sql.DB
}

func NewSequenceRepository(Conn *sql.DB) SequenceRepository {
	return &sequenceRepository{Conn}
}

const (
	selectsequence = "select NEXTVAL(seq_id_generator)"
	selectnewseq   = "select NEXTVAL(seq_id_dummy)"
)

func (s *sequenceRepository) GetIdNextVal() (uint64, error) {
	var nextValue uint64

	err := s.Conn.QueryRow(selectsequence).Scan(&nextValue)

	if err != nil {
		return 0, err
	}
	return nextValue, nil
}
func(s *sequenceRepository) GetIdDummy()(uint64,error){
	var nextValue uint64

	err := s.Conn.QueryRow(selectnewseq).Scan(&nextValue)

	if err != nil {
		log.Println(err)
		return 0, err
	}
	return nextValue, nil
}
