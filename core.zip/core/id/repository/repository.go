package repository

type SequenceRepository interface {
	GetIdNextVal() (uint64, error)
	GetIdDummy()(uint64,error)
}
