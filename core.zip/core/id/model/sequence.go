package model

type GetSequenceResponse struct {
	Value uint64
}
type GetSequenceRequest struct{}
