package service

import (
	"context"
	models "git.capitalx.id/core/id/model"
	"git.capitalx.id/core/id/repository"
	"log"
)

type sequenceService struct {
	seqRepos repository.SequenceRepository
}

type SequenceService interface {
	GetIdNextVal(ctx context.Context) (*models.GetSequenceResponse, error)
	GetIdDummy(ctx context.Context)(*models.GetSequenceResponse,error)
}

// NewSequenceService will create new an sequenceService object representation of SequenceService interface
func NewSequenceService(s repository.SequenceRepository) SequenceService {
	return &sequenceService{s}
}

func (s *sequenceService) GetIdNextVal(ctx context.Context) (*models.GetSequenceResponse, error) {
	val, err := s.seqRepos.GetIdNextVal()
		if err != nil {
		log.Println(err)
		return nil, err

	}
	log.Println("[service]-ID Value :",val)
	return &models.GetSequenceResponse{
		Value: val,
	}, nil

}
func (s *sequenceService) GetIdDummy(ctx context.Context) (*models.GetSequenceResponse, error) {
	val, err := s.seqRepos.GetIdDummy()
	if err != nil {
		log.Println(err)
		return nil, err

	}
	log.Println("[service]-ID Value :",val)
	return &models.GetSequenceResponse{
		Value: val,
	}, nil

}
