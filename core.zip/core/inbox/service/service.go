package service

import (
	"context"

	models "git.capitalx.id/core/inbox/model"
	"git.capitalx.id/core/inbox/repository"
)

//InboxService represents inbox service
type InboxService interface {
	StoreNotification(ctx context.Context, u *models.NotificationInbox) (*models.NotificationInbox, error)
	GetUserNotifications(ctx context.Context, userID, count uint64, lastCreatedTimeStamp string) (*models.ListNotification, error)
}

//NewInboxService will create a new inboxService object representation of InboxService interface
func NewInboxService(r repository.NotificationRepository) InboxService {
	return &inboxService{r}
}

type inboxService struct {
	inboxMariaRepo repository.NotificationRepository
}

func (s *inboxService) StoreNotification(_ context.Context, ni *models.NotificationInbox) (*models.NotificationInbox, error) {
	return s.inboxMariaRepo.StoreNotification(ni)
}

func (s *inboxService) GetUserNotifications(ctx context.Context, userID, count uint64, lastCreatedTimeStamp string) (*models.ListNotification, error) {
	return s.inboxMariaRepo.GetUserNotifications(userID, count, lastCreatedTimeStamp)
}
