package model

import "errors"

var (
	// ErrInternalServerError will throw if any the Internal Server Error happen
	ErrInternalServerError = errors.New("internal Server Error")
	// ErrNotFound will throw if the requested item is not exists
	ErrNotFound = errors.New("your requested Item is not found")
	// ErrConflict will throw if the current action already exists
	ErrConflict = errors.New("your Item already exist")
	// ErrBadParamInput will throw if the given request-body or params is not valid
	ErrBadParamInput = errors.New("given Param is not valid")
	// ErrCanNotUpdate will throw if the given request-body or params is can not be updated
	ErrCanNotUpdate = errors.New("your request can not be updated")
	// ErrNotAuthorized will throw if the user not authorized
	ErrNotAuthorized = errors.New("you are not authorized")
	// ErrDeleteFailed will throw if any the delete failed happen
	ErrDeleteFailed = errors.New("delete failed")
	// ErrNotEmpty will throw if object has empty value
	ErrNotEmpty = errors.New("request should not be empty")
)
