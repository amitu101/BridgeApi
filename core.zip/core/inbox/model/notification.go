package model

import "time"

//NotificationInbox is Notification Inbox data type
type NotificationInbox struct {
	NotificationID     uint64
	Sender             string
	Subject            string
	Message            string
	LandingURL         string
	UserID             uint64
	NotificationTypeID uint32
	CreatedBy          uint64
	CreatedTime        string
}

//ListNotification list of NotificationInbox type
type ListNotification struct {
	List []*NotificationInbox
}

//NotificationInboxDB data map
type NotificationInboxDB struct {
	NotificationID     uint64
	Sender             string
	Subject            string
	Message            string
	LandingURL         string
	UserID             uint64
	NotificationTypeID uint32
	CreatedBy          uint64
	CreatedTime        *time.Time
}
