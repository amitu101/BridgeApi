package main

import (
	"fmt"

	"git.capitalx.id/core/common/mysql"

	vault_cfg "git.capitalx.id/core/config/vault"

	"log"
	"sync"

	common "git.capitalx.id/core/common/grpc"
	mariaRepo "git.capitalx.id/core/inbox/repository"
	inboxSrv "git.capitalx.id/core/inbox/service"
	"google.golang.org/grpc"

	deliveryGrpc "git.capitalx.id/core/inbox/delivery"

	_ "github.com/go-sql-driver/mysql"
)

func main() {

	config, err := vault_cfg.GetConfig("inbox")
	if err != nil {
		log.Println(err)
		return
	}

	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dbConn, err := mysql.DB(dbConfig)
	if err != nil {
		log.Println(err)
		return
	}
	defer func() {
		if err := dbConn.Close(); err != nil {
			log.Print(err)
		}
	}()

	inr := mariaRepo.NewMariaNotificationRepository(dbConn)
	// service
	ins := inboxSrv.NewInboxService(inr)
	if err != nil {
		fmt.Println("SOMETHING HAPPEN")
	}
	// create wait group
	wg := new(sync.WaitGroup)

	// add two goroutines to `wg` WaitGroup
	wg.Add(1)

	go func() {
		// start grpc
		pbServer := grpc.NewServer(common.WithDefault()...)
		deliveryGrpc.NewInboxServerGrpc(pbServer, ins)
		common.Serve(config.GetString("server.address"), pbServer)
		wg.Done()
	}()

	fmt.Println("Server Run at ", config.GetString("server.address"))
	wg.Wait()

}
