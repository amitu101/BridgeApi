package repository

import (
	"database/sql"
	"log"
	"strings"
	"time"

	models "git.capitalx.id/core/inbox/model"
)

const (
	timeFormat = "2006-01-02T15:04:05Z0700"
)

const (
	insertNotification = "INSERT INTO notification_inbox" +
		"(sender, subject, message, landing_url, user_id, notification_type_id, created_by, created_time) VALUES (?,?,?,?,?,?,?,?);"

	selectNotification = "SELECT notification_id, sender, subject, message, landing_url, user_id, notification_type_id, created_by, created_time" +
		" FROM notification_inbox where user_id = ? AND created_time < ? " +
		" ORDER BY created_time DESC	LIMIT ?;"
)

// NewMariaNotificationRepository will create an object that represent the inbox.Repository interface
func NewMariaNotificationRepository(Conn *sql.DB) NotificationRepository {
	return &mariaInboxRepository{Conn}
}

type mariaInboxRepository struct {
	Conn *sql.DB
}

func (m *mariaInboxRepository) fetch(query string, args ...interface{}) ([]*models.NotificationInbox, error) {
	rows, err := m.Conn.Query(query, args...)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in fetch notifications %s \n", err)
		return nil, models.ErrInternalServerError
	}

	defer func() {
		if err := rows.Close(); err != nil {
			log.Printf("[maria_notification.repository] Exception when closing in the db connection %s \n", err)
		}
	}()

	result := make([]*models.NotificationInbox, 0)
	for rows.Next() {
		ni := new(models.NotificationInboxDB)
		err = rows.Scan(
			&ni.NotificationID,
			&ni.Sender,
			&ni.Subject,
			&ni.Message,
			&ni.LandingURL,
			&ni.UserID,
			&ni.NotificationTypeID,
			&ni.CreatedBy,
			&ni.CreatedTime)

		attConv := &models.NotificationInbox{
			NotificationID:     ni.NotificationID,
			Sender:             ni.Sender,
			Subject:            ni.Subject,
			Message:            ni.Message,
			LandingURL:         ni.LandingURL,
			UserID:             ni.UserID,
			NotificationTypeID: ni.NotificationTypeID,
			CreatedBy:          ni.CreatedBy,
			CreatedTime:        timeToString(ni.CreatedTime)}
		result = append(result, attConv)

	}

	return result, nil
}

func timeToString(time *time.Time) string {
	return strings.Replace(time.Format(timeFormat), "Z", "+0000", 1)
}

func stringToTime(timestamp string) time.Time {
	var t time.Time
	var err error
	if timestamp == "" {
		t = time.Now()
	} else {
		t, err = time.Parse(timeFormat, timestamp)
		if err != nil {
			log.Printf("[maria_notification.repository] Error when parse time format %s\n", err)
		}
	}
	return t
}

func (m *mariaInboxRepository) StoreNotification(n *models.NotificationInbox) (*models.NotificationInbox, error) {

	result, err := m.Conn.Exec(insertNotification, n.Sender, n.Subject, n.Message, n.LandingURL, n.UserID, n.NotificationTypeID, n.CreatedBy, stringToTime(n.CreatedTime))
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in StoreNotification %s \n", err)
		return nil, models.ErrInternalServerError
	}
	id, _ := result.LastInsertId()
	n.NotificationID = uint64(id)

	return n, nil
}

func (m *mariaInboxRepository) GetUserNotifications(userID, count uint64, lastCreatedTimeStamp string) (*models.ListNotification, error) {

	list, err := m.fetch(selectNotification, userID, stringToTime(lastCreatedTimeStamp), count)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in GetUserNotifications %s \n", err)
		return nil, models.ErrInternalServerError
	}

	return &models.ListNotification{List: list}, nil
}
