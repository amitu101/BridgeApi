package repository

import (
	models "git.capitalx.id/core/inbox/model"
)

//NotificationRepository represent the notification repository's repository contract
type NotificationRepository interface {
	StoreNotification(u *models.NotificationInbox) (*models.NotificationInbox, error)
	GetUserNotifications(userID, count uint64, lastCreatedTimeStamp string) (*models.ListNotification, error)
}
