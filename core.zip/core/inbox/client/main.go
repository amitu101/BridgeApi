package client

import (
	"context"

	"git.capitalx.id/core/inbox/delivery"
	"google.golang.org/grpc"

	models "git.capitalx.id/core/inbox/model"
	"git.capitalx.id/core/inbox/service"
)

type inboxClient struct {
	conn   *grpc.ClientConn
	client delivery.InboxHandlerClient
}

func (u inboxClient) Close() error {
	return u.conn.Close()
}

//NewInboxClient client connect
func NewInboxClient(address string) (service.InboxService, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	client := delivery.NewInboxHandlerClient(conn)

	return &inboxClient{conn: conn, client: client}, nil
}

func (u inboxClient) StoreNotification(ctx context.Context, in *models.NotificationInbox) (*models.NotificationInbox, error) {
	resp, err := u.client.Store(ctx, &delivery.InboxNotification{
		Sender:             in.Sender,
		Subject:            in.Subject,
		Message:            in.Message,
		LandingURL:         in.LandingURL,
		UserID:             in.UserID,
		NotificationTypeID: in.NotificationTypeID,
		CreatedBy:          in.CreatedBy,
		CreatedTime:        in.CreatedTime})

	if err != nil {
		return nil, err
	}

	return &models.NotificationInbox{
		NotificationID:     resp.NotificationID,
		Sender:             resp.Sender,
		Subject:            resp.Subject,
		Message:            resp.Message,
		LandingURL:         resp.LandingURL,
		UserID:             resp.UserID,
		NotificationTypeID: resp.NotificationTypeID,
		CreatedBy:          resp.CreatedBy,
		CreatedTime:        resp.CreatedTime}, nil
}

func (u inboxClient) GetUserNotifications(ctx context.Context, userID, count uint64, lastCreatedTimeStamp string) (*models.ListNotification, error) {
	resp, err := u.client.GetUserNotifications(ctx, &delivery.GetNotificationListRequest{UserID: userID})

	if err != nil {
		return nil, err
	}

	list := make([]*models.NotificationInbox, 0)
	for _, notif := range resp.List {
		ni := new(models.NotificationInbox)
		ni.NotificationID = notif.NotificationID
		ni.Sender = notif.Sender
		ni.Subject = notif.Subject
		ni.Message = notif.Message
		ni.LandingURL = notif.LandingURL
		ni.UserID = notif.UserID
		ni.NotificationTypeID = notif.NotificationTypeID
		ni.CreatedBy = notif.CreatedBy
		ni.CreatedTime = notif.CreatedTime
		list = append(list, ni)
	}
	return &models.ListNotification{List: list}, err

}
