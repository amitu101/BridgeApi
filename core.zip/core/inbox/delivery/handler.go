package delivery

import (
	"context"
	"log"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	models "git.capitalx.id/core/inbox/model"
	_srv "git.capitalx.id/core/inbox/service"
)

//NewInboxServerGrpc will create server
func NewInboxServerGrpc(gserver *grpc.Server, inboxSrv _srv.InboxService) {
	inboxServer := &server{
		service: inboxSrv,
	}
	RegisterInboxHandlerServer(gserver, inboxServer)
	reflection.Register(gserver)
}

type server struct {
	service _srv.InboxService
}

func (s *server) Store(ctx context.Context, request *InboxNotification) (*InboxNotification, error) {

	log.Printf("[handler.delivery] Invoked Store notification handler. userID: %d, notificationTypeId: %d", request.UserID, request.NotificationTypeID)

	ni := &models.NotificationInbox{
		Sender:             request.Sender,
		Subject:            request.Subject,
		Message:            request.Message,
		LandingURL:         request.LandingURL,
		UserID:             request.UserID,
		NotificationTypeID: request.NotificationTypeID,
		CreatedBy:          request.CreatedBy,
		CreatedTime:        request.CreatedTime}

	resp, err := s.service.StoreNotification(ctx, ni)

	if err != nil {
		log.Printf("[handler.delivery] Exception in Store notification %s \n", err)
		return nil, err
	}

	return &InboxNotification{
		NotificationID:     resp.NotificationID,
		Sender:             resp.Sender,
		Subject:            resp.Subject,
		Message:            resp.Message,
		LandingURL:         resp.LandingURL,
		UserID:             resp.UserID,
		NotificationTypeID: resp.NotificationTypeID,
		CreatedBy:          resp.CreatedBy,
		CreatedTime:        resp.CreatedTime}, nil
}

func (s *server) GetUserNotifications(ctx context.Context, request *GetNotificationListRequest) (*NotificationList, error) {

	resp, err := s.service.GetUserNotifications(ctx, request.UserID, request.Count, request.LastCreatedTimestamp)

	if err != nil {
		log.Printf("[handler.delivery] Exception in GetUserNotifications %s \n", err)
		return nil, err
	}
	list := make([]*InboxNotification, 0)
	for _, notif := range resp.List {
		ni := new(InboxNotification)
		ni.NotificationID = notif.NotificationID
		ni.Sender = notif.Sender
		ni.Subject = notif.Subject
		ni.Message = notif.Message
		ni.LandingURL = notif.LandingURL
		ni.UserID = notif.UserID
		ni.NotificationTypeID = notif.NotificationTypeID
		ni.CreatedBy = notif.CreatedBy
		ni.CreatedTime = notif.CreatedTime
		list = append(list, ni)
	}
	return &NotificationList{List: list}, nil
}
