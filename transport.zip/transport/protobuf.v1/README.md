<h1>Protocol Buffers</h1>

gRPC use protocol buffers as both its Interface Definition Language (IDL) and as its underlying message interchange format.
All the proto files for the APIs will be stored in here.