# grpcserviceuser

Repository Service User OpenTelemetry With GRPC