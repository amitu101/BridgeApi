package main

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"time"

	"tesprotogrpcoprekmultisrv/common/config"
	"tesprotogrpcoprekmultisrv/common/model"

	"github.com/golang/protobuf/ptypes/empty"
	"go.opentelemetry.io/otel/api/global"
	"google.golang.org/grpc"
)

func serviceUser() model.UsersClient {
	time.Sleep(time.Second)
	tracer := global.Tracer("clientuser")
	port := config.SERVICE_USER_PORT
	conn, err := grpc.Dial(port, grpc.WithInsecure(),
		config.DialOption(tracer))
	if err != nil {
		log.Fatal("could not connect to", port, err)
	}

	return model.NewUsersClient(conn)
}
func main() {
	fn := config.InitTraceProvider("clientuser")
	defer fn()
	user1 := model.User{
		Id:       "n001",
		Name:     "Asdam",
		Password: "k3r3n@ja",
		Gender:   model.UserGender(model.UserGender_value["80"]),
	}

	user := serviceUser()
	fmt.Println("\n", "===========> user test")
	user.Register(context.Background(), &user1)
	// show all registered users
	res1, err := user.List(context.Background(), new(empty.Empty))
	if err != nil {
		log.Fatal(err.Error())
	}
	res1String, _ := json.Marshal(res1.List)
	log.Println(string(res1String))
}
