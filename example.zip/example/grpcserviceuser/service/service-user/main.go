package main

import (
	"context"
	"log"
	"net"
	"time"

	"tesprotogrpcoprekmultisrv/common/config"
	"tesprotogrpcoprekmultisrv/common/model"
	grgClient "tesprotogrpcoprekmultisrvgrg/client"
	grgModel "tesprotogrpcoprekmultisrvgrg/common/model"

	"github.com/golang/protobuf/ptypes/empty"
	"go.opentelemetry.io/otel/api/global"
	"go.opentelemetry.io/otel/instrumentation/grpctrace"

	// "go.opentelemetry.io/otel/label"

	"google.golang.org/grpc"
)

var localStorage *model.UserList

func init() {
	localStorage = new(model.UserList)
	localStorage.List = make([]*model.User, 0)
}

type UsersServer struct {
}

func (UsersServer) Register(ctx context.Context, param *model.User) (*empty.Empty, error) {
	localStorage.List = append(localStorage.List, param)

	log.Println("Registering other user", param.String())
	// //garage
	garage := grgClient.ServiceGarage()
	garage1 := grgModel.Garage{
		Id:   "q002",
		Name: "Quel'thalasas",
		Coordinate: &grgModel.GarageCoordinate{
			Latitude:  45.123123123,
			Longitude: 54.1231313123,
		},
	}
	// // add garage1 to user1
	garage.Add(ctx, &grgModel.GarageAndUserId{
		UserId: param.Id,
		Garage: &garage1,
	})

	return new(empty.Empty), nil
}

func (UsersServer) List(ctx context.Context, void *empty.Empty) (*model.UserList, error) {
	return localStorage, nil
}
func main() {

	fn := config.InitTraceProvider("srvuserother")
	defer fn()

	// srv := grpc.NewServer(servOpts...)
	uclient, errU := grgClient.NewGarageClient(":7010")
	if errU != nil {
		log.Println("err connect to User Service: ", errU)
	}
	// var cu UsersServer
	var userSrv UsersServer
	// cu := NewCustomerService(&uclient)

	time.Sleep(time.Second)

	srv := grpc.NewServer(
		grpc.UnaryInterceptor(config.ServerInterceptor(global.Tracer(""))),
		grpc.StreamInterceptor(grpctrace.StreamServerInterceptor(global.Tracer(""))))

	model.RegisterUsersServer(srv, userSrv)
	grgModel.RegisterGaragesServer(srv, uclient)

	log.Println("Starting RPC server at", config.SERVICE_USER_PORT)

	l, err := net.Listen("tcp", config.SERVICE_USER_PORT)
	if err != nil {
		log.Fatalf("could not listen to %s: %v", config.SERVICE_USER_PORT, err)
	}

	log.Fatal(srv.Serve(l))
	// time.Sleep(time.Second * 3)
}
