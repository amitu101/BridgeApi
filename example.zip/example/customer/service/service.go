package service

import (
	"context"
	"log"

	"google.golang.org/grpc/codes"

	"git.capitalx.id/example/customer/repository"

	errHdlr "git.capitalx.id/example/common/error"
)

// CustomerService represent the customer's services
type CustomerService interface {
	CheckRegistrationPhoneNumberAvailability(ctx context.Context, mobileNumber string) (string, error)
}

// NewCustomerService will create new an customerService object representation of CustomerService interface
func NewCustomerService(c repository.CustomerRepository) CustomerService {
	return &customerService{c}
}

type customerService struct {
	customerRepos  repository.CustomerRepository
}

func (c *customerService) CheckRegistrationPhoneNumberAvailability(ctx context.Context, mobileNumber string) (string, error) {
	msg, err := c.customerRepos.GetCustomerStatusByMobileNumber(mobileNumber)
	if err != nil {
		return "", err
	}

	if msg == "This mobile number already blocked" {
		errMsg := "This mobile number already blocked"
		newErrFormat := errHdlr.ServiceError{
			Code:    "BLOCKED",
			Status:  codes.Unavailable,
			Message: errMsg,
		}
		log.Println(errMsg)

		return "", newErrFormat
	}

	if msg == "This mobile number already exist" {
		errMsg := "This mobile number is already exist"
		newErrFormat := errHdlr.ServiceError{
			Code:    "ALREADY_EXISTS",
			Status:  codes.AlreadyExists,
			Message: errMsg,
		}
		log.Println(errMsg)
		return "", newErrFormat
	}



	return "You can use this mobile number", nil
}