package model

import "time"

//Customer is customer data type
type Customer struct {
	CustomerID uint64
	Name       string
	Mobile     string
	Email      string
	Cif        string
	IDNo       string
	FullName   string
	DOB        time.Time
	Gender     int32
	Address    string
	PhotoURL   string
	IconURL    string
	Status     int64
	Type       int32
	KycLevel   int32
	CreatedBy  uint64
	CreatedAt  time.Time
	UpdatedBy  uint64
	UpdatedAt  time.Time
}