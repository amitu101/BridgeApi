package repository

import (
	"database/sql"
)

type mariaCustomerRepository struct {
	Conn *sql.DB
}

// NewMariaCustomerRepository will create an object that represent the customer.Repository interface
func NewMariaCustomerRepository(Conn *sql.DB) CustomerRepository {

	return &mariaCustomerRepository{Conn}
}

const (
	selectStatus             = "SELECT status FROM customer WHERE mobile = ?"
)

func (m *mariaCustomerRepository) GetCustomerStatusByMobileNumber(mobileNumber string) (string, error) {
	var status int
	err := m.Conn.QueryRow(selectStatus, mobileNumber).Scan(&status)
	if err != nil {
		if err == sql.ErrNoRows {
			// there were no rows, but otherwise no error occurred
		} else {
			return "", err
		}
	}

	if status == 1 {
		return "This mobile number already exist", nil
	}

	if status == 3 {
		return "This mobile number already blocked", nil
	}

	return "This mobile number not already exist", nil
}