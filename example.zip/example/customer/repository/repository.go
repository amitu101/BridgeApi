package repository

// CustomerRepository represent the customer's repository contract
type CustomerRepository interface {
	GetCustomerStatusByMobileNumber(mobileNumber string) (string, error)
}