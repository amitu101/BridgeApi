package delivery

import (
	"context"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	_srv "git.capitalx.id/example/customer/service"
)

//NewCustomerServerGrpc ...
func NewCustomerServerGrpc(gserver *grpc.Server, customerSrv _srv.CustomerService) {
	// RegisterCustomerHandlerServer using Server struct
	customerServer := &server{
		service: customerSrv,
	}
	RegisterCustomerHandlerServer(gserver, customerServer)

	reflection.Register(gserver)
}

type server struct {
	service _srv.CustomerService
}

func (s *server) CheckRegistrationPhoneNumberAvailability(ctx context.Context, request *CheckRegisPhoneNumberReq) (*CheckMobileNumberAvailabilityResponse, error) {
	resp, err := s.service.CheckRegistrationPhoneNumberAvailability(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &CheckMobileNumberAvailabilityResponse{
		Message:            resp,
	}, nil
}