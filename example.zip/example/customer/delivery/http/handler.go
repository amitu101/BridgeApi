package http

import (
	"fmt"
	"log"
	"net/http"
	"strings"

	srv "git.capitalx.id/example/customer/service"
)

// CustomerHandler  represent the http handler for Customer
type CustomerHandler struct {
	CusSrv srv.CustomerService
}

// NewCustomerHandler will initialize the users/ resources endpoint
func NewCustomerHandler(m *http.ServeMux, customerSrv srv.CustomerService) {
	handler := &CustomerHandler{
		CusSrv: customerSrv,
	}

	m.HandleFunc("/welcome", handler.Welcome)
	m.HandleFunc("/welcome/", handler.WelcomeUser)
}

func parsePathParams(req *http.Request, prefix string) []string {
	var empty []string
	url := strings.TrimPrefix(req.URL.Path, prefix)
	params := strings.Split(url, "/")
	if params[0] == "" {
		return empty
	}
	return params
}

func errorHandler(res http.ResponseWriter, req *http.Request, status int) {
	res.WriteHeader(status)
	if status == http.StatusNotFound {
		fmt.Fprint(res, "404 page not found")
	}
}

func (h *CustomerHandler) Welcome(res http.ResponseWriter, req *http.Request)  {
	if req.Method == "GET"{
		fmt.Fprintf(res, "Hello from customer rest")
		log.Println("Endpoint Hit: Welcome")
	}
}

func welcomeUserOne(res http.ResponseWriter, req *http.Request, pathParams []string) {
	word := fmt.Sprintf("Hello this is from path /welcome/%s", pathParams[0])
	fmt.Fprintf(res, word)
}

func welcomeUserTwo(res http.ResponseWriter, req *http.Request, pathParams []string) {
	word := fmt.Sprintf("Hello this is from path /welcome/%s/%s", pathParams[0], pathParams[1])
	fmt.Fprintf(res, word)
}

func welcomeUserThree(res http.ResponseWriter, req *http.Request, pathParams []string) {
	word := fmt.Sprintf("Hello this is from path /welcome/%s/%s/%s", pathParams[0], pathParams[1], pathParams[2])
	fmt.Fprintf(res, word)
}

func (h *CustomerHandler) WelcomeUser(res http.ResponseWriter, req *http.Request){
	log.Println("you hit WelcomeUser")
	if req.Method == "GET" {
		pathParams := parsePathParams(req, "/welcome/")
		if len(pathParams) == 0 {
			errorHandler(res, req, http.StatusNotFound)
			return
		}

		// this is example for /welcome/:userID
		if len(pathParams) == 1 {
			welcomeUserOne(res, req, pathParams)
		}

		// this is example for /welcome/:userID/customer
		if len(pathParams) == 2 {
			welcomeUserTwo(res, req, pathParams)
		}

		// this is example for /welcome/:userID/customer/:customerID
		if len(pathParams) == 3 {
			welcomeUserThree(res, req, pathParams)
		}
		// and many more
	}
}