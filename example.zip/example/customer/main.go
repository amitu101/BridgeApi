package main

import (
	"context"
	"flag"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"

	//"os"
	//"os/signal"
	//"syscall"

	"google.golang.org/grpc"

	"git.capitalx.id/core/common/mysql"
	"github.com/golang/glog"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"


	common "git.capitalx.id/example/common/grpc"
	cfg "git.capitalx.id/example/config/vault"
	deliveryGrpc "git.capitalx.id/example/customer/delivery"
	HandlerHTTP "git.capitalx.id/example/customer/delivery/http"
	customerRepo "git.capitalx.id/example/customer/repository"
	customerSrv "git.capitalx.id/example/customer/service"
)

var (
	grpcServerEndpoint = flag.String("grpc-server-endpoint", "localhost:9089", "gRPC server endpoint")
)

func run() error {
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// Register gRPC server endpoint
	// Note: Make sure the gRPC server is running properly and accessible
	mux := runtime.NewServeMux()
	opts := []grpc.DialOption{grpc.WithInsecure()}
	err := deliveryGrpc.RegisterCustomerHandlerHandlerFromEndpoint(ctx, mux, *grpcServerEndpoint, opts)
	if err != nil {
		return err
	}
	log.Println("abcd")

	// Start HTTP server (and proxy calls to gRPC server endpoint)
	return http.ListenAndServe(":8081", mux)
}

func main() {
	config, err := cfg.GetConfig("customer")
	if err != nil {
		log.Println(err)
		return
	}

	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dbConn, err := mysql.DB(dbConfig)
	if err != nil {
		log.Println(err)
		return
	}
	defer func() {
		if err := dbConn.Close(); err != nil {
			log.Print(err)
		}
	}()

	cr := customerRepo.NewMariaCustomerRepository(dbConn)

	cu := customerSrv.NewCustomerService(cr)

	// start grpc
	errHdlr := common.WithDefault()
	server := grpc.NewServer(errHdlr...)
	deliveryGrpc.NewCustomerServerGrpc(server, cu)


	go func() {
		common.Serve(config.GetString("server.address"), server)
	}()

	log.Println("grpc Server Run at ", config.GetString("server.address"))

	go func() {
		flag.Parse()
		defer glog.Flush()

		if err := run(); err != nil {
			glog.Fatal(err)
		}
	}()

	//http rest
	mux := http.NewServeMux()
	//
	//http deliver layer
	HandlerHTTP.NewCustomerHandler(mux, cu)

	//// launch a grpc server
	//go func() {
	//	common.Serve(config.GetString("server.address"), server)
	//}()
	//log.Println("grpc Server Run at ", config.GetString("server.address"))
	////
	//// launch a http rest server
	go func() {
		http.ListenAndServe(config.GetString("server.address.http"), mux)
	}()
	log.Println("REST API Server Run at ", config.GetString("server.address.http"))
	//
	// shutting down server gracefully
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGINT, syscall.SIGTERM)

	<- done
	log.Println("All server stopped!")
}