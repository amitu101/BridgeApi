package main

import (
	"encoding/json"
	"errors"
	"gopkg.in/square/go-jose.v2"
	"gopkg.in/square/go-jose.v2/jwt"
	"io/ioutil"
	"log"
	"net/http"
	"strings"
	"time"
)

func main() {
	key, _ := getKey("https://api.dimii.dev/openid/admin/keys/hydra.openid.id-token")
	user := User{Username: "test",
		Name:   "Test",
		Mobile: "081376763784"}
	token, _ := sign(user, key, "api.dimii.dev", 24*365*time.Hour)
	log.Println(token)
}

type User struct {
	ID       uint64
	Username string
	Name     string
	Mobile   string
	Email    string
}

type UserClaims struct {
	jwt.Claims
	Username string `json:"user_id,omitempty"`
	Name     string `json:"name,omitempty"`
	Mobile   string `json:"mobile,omitempty"`
	Email    string `json:"email,omitempty"`
}

func getKey(url string) (*jose.JSONWebKey, error) {
	resp, err := http.Get(url)
	if err != nil {
		log.Println(err)
		return nil, err
	}
	defer func() {
		if err := resp.Body.Close(); err != nil {
			log.Println(err)
		}
	}()

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println(err)
		return nil, err
	}

	jwks := jose.JSONWebKeySet{}
	if err := json.Unmarshal(body, &jwks); err != nil {
		log.Println(err)
		return nil, err
	}

	log.Printf("%v", jwks.Keys[0].Valid())

	if len(jwks.Keys) == 0 {
		return nil, errors.New("cannot find jwks")
	}

	for _, jwk := range jwks.Keys {
		if strings.HasPrefix(jwk.KeyID, "private") {
			return &jwk, nil
		}
	}

	return nil, errors.New("cannot find private key")
}

func sign(user User, key *jose.JSONWebKey, issuer string, ttl time.Duration) (string, error) {
	options := &jose.SignerOptions{}
	options.WithType("JWT")
	options.WithHeader("kid", strings.Replace(key.KeyID, "private", "public", 1))
	sig, err := jose.NewSigner(jose.SigningKey{Algorithm: jose.SignatureAlgorithm(key.Algorithm), Key: key.Key}, options)
	if err != nil {
		return "", err
	}

	now := time.Now()
	expired := now.Add(ttl)

	claims := UserClaims{
		Claims: jwt.Claims{
			Subject:  user.Username,
			Issuer:   issuer,
			IssuedAt: jwt.NewNumericDate(now),
			Expiry:   jwt.NewNumericDate(expired),
		},
		Username: user.Username,
		Name:     user.Name,
		Mobile:   user.Mobile,
		Email:    user.Email,
	}

	raw, err := jwt.Signed(sig).Claims(claims).CompactSerialize()
	if err != nil {
		log.Println(err)
		return "", err
	}

	return raw, nil
}
