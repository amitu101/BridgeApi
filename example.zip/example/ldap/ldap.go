package main

import (
	"crypto/tls"
	"fmt"
	"github.com/go-ldap/ldap/v3"
	"io/ioutil"
	"log"
)

var (
	user = "dev-admin"
	password = "please supply your password"
)

func main() {
	cert, _ := ioutil.ReadFile("gldap.crt")
	key, _ := ioutil.ReadFile("gldap.key")
	tlsConfig := WithCertificate(cert,key)

	ldapConn, err := ldap.DialTLS("tcp", "ldap.google.com:636", tlsConfig)
	if err != nil {
		log.Println("ldap connection error", err)
		return
	}
	defer ldapConn.Close()

	// bind using basedn
	err = ldapConn.Bind("bind user", "bind password")
	if err != nil {
		log.Println("ldap connection error with supplied credentials", err)
		return
	}
	filter := fmt.Sprintf("(uid=%s)", user)
	searchReq := ldap.NewSearchRequest("ou=Users,dc=capitalx,dc=id",
		ldap.ScopeWholeSubtree, ldap.NeverDerefAliases, 0, 0, false,
		filter, nil, nil)

	sr, err := ldapConn.Search(searchReq)
	if err != nil {
		log.Println("ldap search error", err)
		return
	}
	if len(sr.Entries) == 0 {
		log.Println("ldap search no entry")
		return
	}
	userDN := sr.Entries[0].DN
	sr.Entries[0].Print()

	//validate user and password
	err = ldapConn.Bind(userDN, password)

	if err != nil {
		log.Print(err)
	}
}

func WithCertificate(cert, key []byte) *tls.Config {
	keyPair, err := tls.X509KeyPair(cert, key)
	if err != nil {
		return nil
	}

	tlsCfg := &tls.Config{
		Certificates: []tls.Certificate{keyPair},
	}

	return tlsCfg
}
