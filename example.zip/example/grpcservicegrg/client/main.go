package client

import (
	"context"
	"log"
	"tesprotogrpcoprekmultisrvgrg/common/config"
	"time"

	"tesprotogrpcoprekmultisrvgrg/common/model"

	"github.com/golang/protobuf/ptypes/empty"
	"go.opentelemetry.io/otel/api/global"
	"google.golang.org/grpc"
)

var localStorage *model.GarageListByUser

func init() {
	localStorage = new(model.GarageListByUser)
	localStorage.List = make(map[string]*model.GarageList)
}

type GaragesServer struct {
	// // List(ctx context.Context, param *model.GarageUserId) (*model.GarageList, error)
	// // Add(ctx context.Context, param *model.GarageAndUserId) (*empty.Empty, error)
	conn   *grpc.ClientConn
	client model.GaragesClient
}

func (GaragesServer) Add(ctx context.Context, param *model.GarageAndUserId) (*empty.Empty, error) {
	userId := param.UserId
	garage := param.Garage

	if _, ok := localStorage.List[userId]; !ok {
		localStorage.List[userId] = new(model.GarageList)
		localStorage.List[userId].List = make([]*model.Garage, 0)
	}
	localStorage.List[userId].List = append(localStorage.List[userId].List, garage)

	log.Println("Adding garage", garage.String(), "for user", userId)

	return new(empty.Empty), nil
}
func (GaragesServer) List(ctx context.Context, param *model.GarageUserId) (*model.GarageList, error) {
	userId := param.UserId

	return localStorage.List[userId], nil
}
func ServiceGarage() model.GaragesClient {
	fn := config.InitTraceProvider("clientgarage")
	defer fn()
	time.Sleep(time.Second)

	tracer := global.Tracer("clientgarage")
	port := config.SERVICE_GARAGE_PORT
	conn, err := grpc.Dial(port, grpc.WithInsecure(),
		config.DialOption(tracer))
	if err != nil {
		log.Fatal("could not connect to", port, err)
	}

	return model.NewGaragesClient(conn)
}

//NewGarageClient :
func NewGarageClient(address string) (model.GaragesServer, error) {
	time.Sleep(time.Second)

	tracer := global.Tracer("clientgarage")
	port := config.SERVICE_GARAGE_PORT
	conn, err := grpc.Dial(port, grpc.WithInsecure(),
		config.DialOption(tracer))
	if err != nil {
		return nil, err
	}
	client := model.NewGaragesClient(conn)

	return &GaragesServer{conn: conn, client: client}, nil
}
