package main

import (
	common "git.capitalx.id/core/common/grpc"
	"git.capitalx.id/example/user/delivery"
	"git.capitalx.id/example/user/repository"
	"git.capitalx.id/example/user/service"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
	"log"
)

func main() {
	//data store
	dbstore, err := repository.NewDBStore("127.0.0.1:3306", "example", "example", "example")
	if err != nil {
		log.Fatal("cannot connect to data store")
	}

	//service
	svc := service.NewUserService(dbstore)
	defer func() {
		if err := svc.Close(); err != nil {
			log.Print(err)
		}
	}()

	//delivery
	grpcServer := delivery.NewGRPCServer(svc)

	//start grpc
	pbServer := grpc.NewServer(common.WithDefault()...)
	delivery.RegisterUserServer(pbServer, grpcServer)
	reflection.Register(pbServer)

	common.Serve(":8080", pbServer)
}
