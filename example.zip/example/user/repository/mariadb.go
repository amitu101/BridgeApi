package repository

import (
	"database/sql"
	"fmt"
	"git.capitalx.id/example/user/model"

	_ "github.com/go-sql-driver/mysql" //mysql driver
)

type mariaDBStore struct {
	db *sql.DB
}

func dataSourceName(url string, schema string, user string, password string) string {
	return fmt.Sprintf("%s:%s@tcp(%s)/%s?parseTime=true", user, password, url, schema)
}

//NewDBStore creates new mariadb storage
func NewDBStore(url string, schema string, user string, password string) (DataStore, error) {
	db, err := sql.Open("mysql", dataSourceName(url, schema, user, password))
	if err != nil {
		return nil, err
	}
	return &mariaDBStore{db: db}, nil
}

const (
	insertUser = "insert into user(user_id, name, email) values (?,?,?)"
	countUser  = "select count(1) from user where user_id = ?"
	selectUser = "select name, email from user where user_id = ?"
)

func (mdb *mariaDBStore) InsertUser(user model.User) error {
	_, err := mdb.db.Exec(insertUser, user.UserID, user.Name, user.Email)
	return err
}

func (mdb *mariaDBStore) CountUser(userID string) (int, error) {
	var count int
	err := mdb.db.QueryRow(countUser, userID).Scan(&count)
	if err != nil {
		return 0, err
	}

	return count, nil
}

func (mdb *mariaDBStore) SelectUser(userID string) (model.User, error) {
	user := model.User{}
	err := mdb.db.QueryRow(selectUser, userID).Scan(&user.Name, &user.Email)
	if err != nil {
		return model.User{}, err
	}

	return user, nil
}

func (mdb *mariaDBStore) Close() error {
	if mdb.db != nil {
		return mdb.db.Close()
	}

	return nil
}
