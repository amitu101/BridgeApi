package repository

import (
	"git.capitalx.id/example/user/model"
	"io"
)

//DBAccess is interfacae to database access
type DataStore interface {
	InsertUser(model.User) error
	CountUser(string) (int, error)
	SelectUser(string) (model.User, error)
	io.Closer
}
