package model

//User is user data type
type User struct {
	UserID string
	Name   string
	Email  string
}
