create table user(
  user_id varchar(32) not null,
  name varchar(128) not null,
  email varchar(128),
  primary key(user_id));
