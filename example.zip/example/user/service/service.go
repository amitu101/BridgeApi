package service

import (
	"context"
	"git.capitalx.id/example/user/model"
	"git.capitalx.id/example/user/repository"
	"io"
	"strings"
)

//UserService is service to manage user
type UserService interface {
	AddUser(context.Context, model.User) (bool, error)
	GetUser(context.Context, string) (model.User, error)
	io.Closer
}

type simpleUserService struct {
	dataStore repository.DataStore
}

func NewUserService(dataStore repository.DataStore) UserService {
	return &simpleUserService{dataStore: dataStore}
}

func (us *simpleUserService) AddUser(_ context.Context, user model.User) (bool, error) {
	userID := strings.ToLower(user.UserID)
	count, err := us.dataStore.CountUser(userID)
	if err != nil {
		return false, err
	}
	if count > 0 {
		return false, nil
	}
	user.UserID = userID
	err = us.dataStore.InsertUser(user)
	if err != nil {
		return false, err
	}
	return true, nil
}

func (us *simpleUserService) GetUser(_ context.Context, userID string) (model.User, error) {
	user, err := us.dataStore.SelectUser(userID)
	if err != nil {
		return model.User{}, err
	}

	return user, nil
}

func (us *simpleUserService) Close() error {
	return us.dataStore.Close()
}
