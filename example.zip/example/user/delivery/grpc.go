package delivery

import (
	"context"
	"git.capitalx.id/example/user/model"
	"git.capitalx.id/example/user/service"
)

type grpcUserService struct {
	userSvc service.UserService
}

func (s *grpcUserService) AddUser(ctx context.Context, req *AddUserRequest) (*AddUserResponse, error) {
	user := model.User{UserID: req.GetUserId(), Name: req.GetName(), Email: req.GetEmail()}
	result, err := s.userSvc.AddUser(ctx, user)

	if err != nil {
		return nil, err
	}

	return &AddUserResponse{Success: result}, nil
}

func (s *grpcUserService) GetUser(ctx context.Context, request *GetUserRequest) (*GetUserResponse, error) {
	user, err := s.userSvc.GetUser(ctx, request.UserId)
	if err != nil {
		return nil, err
	}
	return &GetUserResponse{
		UserId: user.UserID,
		Name:   user.Name,
		Email:  user.Email,
	}, nil
}

func NewGRPCServer(svc service.UserService) UserServer {
	return &grpcUserService{userSvc: svc}
}
