package client

import (
	"context"
	"git.capitalx.id/example/user/delivery"
	"git.capitalx.id/example/user/model"
	"git.capitalx.id/example/user/service"
	"google.golang.org/grpc"
)

type userClient struct {
	conn   *grpc.ClientConn
	client delivery.UserClient
}

func (u userClient) AddUser(ctx context.Context, user model.User) (bool, error) {
	resp, err := u.client.AddUser(ctx, &delivery.AddUserRequest{
		UserId: user.UserID,
		Name:   user.Name,
		Email:  user.Email,
	})

	if err != nil {
		return false, err
	}

	return resp.Success, nil
}

func (u userClient) GetUser(ctx context.Context, userID string) (model.User, error) {
	resp, err := u.client.GetUser(ctx, &delivery.GetUserRequest{UserId: userID})

	if err != nil {
		return model.User{}, err
	}

	return model.User{
		Name:  resp.Name,
		Email: resp.Email,
	}, nil
}

func (u userClient) Close() error {
	return u.conn.Close()
}

func NewUserClient(address string) (service.UserService, error) {
	conn, err := grpc.Dial(address)
	if err != nil {
		return nil, err
	}

	client := delivery.NewUserClient(conn)

	return &userClient{conn: conn, client: client}, nil
}
