<h1>User Service</h1>

User service manages all related things about user. That's include:

- Organization hierarchy
- Group and access role matrix
- User

<h3>OpenID Connect</h3>

User authentication will follow OpenID standard and use Ory/Hydra implementation that already OpenID certified.
User service need to implement identity provider and integrate with Ory/Hydra.

<h3>Importing private repository</h3>

To import other services in private repo do the following:

1. In terminal, do this command: export GOPRIVATE="git.capitalx.id"
2. In go.mod delete following lines:
```
replace git.capitalx.id/core/user => /Users/budhi/go/src/git.capitalx.id/core/user

replace git.capitalx.id/core/messaging => /Users/budhi/go/src/git.capitalx.id/core/messaging

replace git.capitalx.id/dimii/account => /Users/budhi/go/src/git.capitalx.id/dimii/account

And

	git.capitalx.id/core/messaging v0.0.0
	git.capitalx.id/core/user v0.0.0
	git.capitalx.id/dimii/account v0.0.0
```

Then run `go run main.go` or `go build` to automatically download service dependencies