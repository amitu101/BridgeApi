CREATE TABLE `user_role` (
  `role_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(40) unsigned NOT NULL,
  `status` int(11) NOT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_time` datetime NOT NULL,
  `updated_by` bigint(20) unsigned NOT NULL,
  `updated_time` timestamp NOT NULL DEFAULT current_timestamp()
);