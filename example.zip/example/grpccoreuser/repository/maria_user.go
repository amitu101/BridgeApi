package repository

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"time"

	"git.capitalx.id/core/user/common"
	models "git.capitalx.id/core/user/model"
)

type mariaUserRepository struct {
	Conn *sql.DB
}

// NewMariaUserRepository will create an object that represent the user.Repository interface
func NewMariaUserRepository(Conn *sql.DB) SqlUserRepository {
	return &mariaUserRepository{Conn}
}

const (
	dimmiLandAccess = "dimiiland"
	dimmiAppAccess  = "dimiiapp"

	insertUser = "INSERT INTO user(id, name, username, mobile, email, passcode, device_id, status, created_by," +
		"created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
	selectStatus       = "SELECT status FROM user WHERE mobile = ?"
	selectPassCode     = "SELECT passcode FROM user WHERE mobile = ?"
	getPassCodeByUname = "SELECT passcode FROM user WHERE username = ?"
	selectUser         = `SELECT id, COALESCE(username, "") AS username, COALESCE(name, "") AS name, mobile,
					COALESCE(email, "") AS email, COALESCE(device_id, "") AS device_id, status FROM user WHERE mobile = ?`
	blockUser           = `UPDATE user SET status = ? WHERE mobile = ?`
	deleteUser          = `DELETE FROM user WHERE mobile = ?`
	resetPasscode       = `UPDATE user SET passcode = ? WHERE mobile = ?`
	getDimilandUserList = "select u.id, u.email, u.status, ud.last_login, r.name from user u " +
		"inner join user_device ud on ud.mobile = u.mobile " +
		"inner join user_role ur on ur.user_id = u.id " +
		"inner join role r on r.id = ur.role_id " +
		"inner join user_application ua on ua.user_id = u.id " +
		"inner join application a on a.id = ua.application_id " +
		"where "

	queryByRole                  = `select role.name as role_name,role.description as role_description, permission.name as permission_name,permission.description as permission_description from role,role_permission,permission where role_permission.role_id=role.id and permission.id=role_permission.permission_id and role.name = '%s' ;`
	queryByPermission            = `select role.name as role_name,role.description as role_description, permission.name as permission_name,permission.description as permission_description from role,role_permission,permission where role_permission.role_id=role.id and permission.id=role_permission.permission_id and permission.name = '%s' ;`
	getPermissions               = `select id, name, description, status, group_id, group_name from permission LIMIT ? , ?` //ORDER BY created_time  ASC
	getPermissionsCount          = `select COUNT(*) from permission `
	insertRole                   = `insert into role(name, description, status, created_by, created_time, updated_by, updated_time) value (?,?,?,?,?,?,?) `
	updateRole                   = `update role set name = ?, description= ?, status= ?, updated_by= ?, updated_time = ? where name= ?`
	selectRolesCount             = `SELECT COUNT(role_id) FROM user_role WHERE role_id = ?`
	updateeRoleStatus            = `update role set status= ? where id = ? `
	insertRolePermisssions       = `insert into role_permission(role_id, permission_id, status, created_by, created_time, updated_by, updated_time) value (?,?,?,?,?,?,?) `
	deleteRolePermisssions       = `delete from role_permission where role_id = ? `
	selectRoleByName             = `select id, name from role where name = ?`
	selectStatusByMail           = "SELECT status  FROM user WHERE email = ?"
	insertNewUser                = "INSERT INTO user (id, email, status,domain, created_by, created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?,?)"
	insertNewUserRole            = "INSERT INTO user_role(role_id, user_id, status, created_by, created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?)"
	updateDeviceID               = "UPDATE user SET device_id = ? WHERE mobile = ?"
	selectUserPermissionList     = "SELECT id,name,description FROM permission WHERE status = ?"
	selectUserRolePermissionList = "SELECT role_id,permission_id FROM role_permission WHERE status = ?"
	selectUserRolesList          = "SELECT role.id, role.name,role.description FROM role WHERE status = ? LIMIT ? , ?"
	selectUserRolesCount         = "SELECT COUNT(id) FROM role WHERE status = ?"
	selectUserByUserName         = `select application.name from user,user_application,application where user.id = user_application.user_id and user_application.application_id = application.id and user.username = '%s' ;`
	queryUserRoleByUserName      = `select role.name as role_name,permission.id as permission_id,permission.name as permission_name from user,user_role,role,role_permission,permission where user.id=user_role.user_id and user_role.role_id=role.id and role.id=role_permission.role_id and role_permission.permission_id=permission.id and user.username = '%s' ;`
	selectRolesByUserID          = "SELECT role_id FROM user_role WHERE user_id = ?;"
	deleteUserRole               = "UPDATE user_role SET status = ? WHERE role_id = ? AND user_id=?;"
	addUserRole                  = "INSERT INTO user_role (role_id, user_id, status, created_by, created_time, updated_by, updated_time) VALUES (?,?,?,?,?,?,?);"
	selectPermissionByUserID     = `select user.id as user_id,user.username as user_name,permission.id,permission.name,permission.status,permission.description from user,user_role,role,role_permission,permission where user.id=user_role.user_id and user_role.role_id=role.id and role.id=role_permission.role_id and role_permission.permission_id=permission.id and user.id = '%d' and permission.status = "%d"  and role.status = "%d";`
	blockUserByUserID            = `UPDATE user SET status = ?, block_reason = ? WHERE id = ?;`
	unblockUserByUserID          = `UPDATE user SET status = ? WHERE  id = ?;`
	selectUserbyUserID           = `SELECT id, COALESCE(username, "") AS username, COALESCE(name, "") AS name, mobile,
					COALESCE(email, "") AS email, COALESCE(device_id, "") AS device_id, status FROM user WHERE id = ?`
)

func (m *mariaUserRepository) MariaStoreUser(ID uint64, passCode string, u *models.User) (uint64, error) {
	_, err := m.Conn.Exec(insertUser, ID, u.Name, u.Username, u.Mobile, u.Email, passCode, u.DeviceID, u.Status,
		u.CreatedBy, u.CreatedTime, u.UpdatedBy, u.UpdatedTime)
	if err != nil {
		return 0, err
	}

	return ID, nil
}

func (m *mariaUserRepository) CheckStatusByPhoneNumber(mobileNumber string) (int, error) {
	var status int

	log.Println("Mobile Number :", mobileNumber)
	err := m.Conn.QueryRow(selectStatus, mobileNumber).Scan(&status)
	if err != nil {
		if err == sql.ErrNoRows {
			// there were no rows, but otherwise no error occurred
			return -1, nil
		} else {
			return 0, err
		}
	}

	log.Println("status berapa : ", status)

	return status, nil
}

func (m *mariaUserRepository) GetPassCodeByPhoneNumber(mobileNumber string) (string, error) {
	var passCode string

	err := m.Conn.QueryRow(selectPassCode, mobileNumber).Scan(&passCode)
	if err != nil {
		return "", err
	}

	return passCode, nil
}

func (m *mariaUserRepository) GetPassCodeByUserName(username string) (string, error) {
	var passCode string

	err := m.Conn.QueryRow(getPassCodeByUname, username).Scan(&passCode)
	if err != nil {
		return "", err
	}

	return passCode, nil
}

func (m *mariaUserRepository) fetch(query string, args ...interface{}) ([]*models.User, error) {
	rows, err := m.Conn.Query(query, args...)
	if err != nil {
		log.Print(err)
		return nil, models.ErrInternalServerError
	}

	defer closeRows(rows)

	result := make([]*models.User, 0)
	for rows.Next() {
		u := new(models.User)
		err = rows.Scan(
			&u.ID,
			&u.Username,
			&u.Name,
			&u.Mobile,
			&u.Email,
			&u.DeviceID,
			&u.Status,
		)

		result = append(result, u)
	}

	return result, nil
}

func (m *mariaUserRepository) GetUserByPhoneNumber(_ context.Context, mobileNumber string) (*models.User, error) {
	list, err := m.fetch(selectUser, mobileNumber)
	if err != nil {
		return nil, err
	}

	if len(list) <= 0 {
		return nil, models.ErrNotFound
	}

	return list[0], nil
}

func (m *mariaUserRepository) BlockUser(_ context.Context, mobileNumber string, status int) (string, error) {
	_, err := m.Conn.Exec(blockUser, status, mobileNumber)
	if err != nil {
		return "", err
	}

	return "Successfully blocked", nil
}

func (m *mariaUserRepository) DeleteUser(_ context.Context, mobileNumber string) (string, error) {
	_, err := m.Conn.Exec(deleteUser, mobileNumber)
	if err != nil {
		return "", err
	}

	return "Deleted", nil
}

func (m *mariaUserRepository) UpdatePasscode(ctx context.Context, mobileNumber, passcode string) (int64, error) {
	result, err := m.Conn.Exec(resetPasscode, passcode, mobileNumber)

	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}
	r, err := result.RowsAffected()
	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}

	return r, nil
}

func closeRows(rows *sql.Rows) {
	if err := rows.Close(); err != nil {
		log.Print(err)
	}
}

func (m *mariaUserRepository) GetDimiilandUsersList(ctx context.Context, params map[string]string) (*[]models.DimilandUsers, uint64, error) {
	data := []models.DimilandUsers{}
	ud := models.DimilandUsers{}
	var sqlStatement string = getDimilandUserList
	var count uint64 = 0
	//where conditions
	sqlStatement += "a.name = '" + params["userType"] + "'"
	if len(params["email"]) > 0 {
		sqlStatement += " and u.email like '%" + params["email"] + "%'"
	}
	if params["status"] == "" {
		sqlStatement += " and u.status != 4"
	} else {
		splitStatus := strings.Split(params["status"], ",")
		i := 0
		inStringStatus := "["
		for _, val := range splitStatus {
			inStringStatus += val
			if i != len(splitStatus)-1 {
				inStringStatus += ","
			}
			i++
		}
		inStringStatus += "]"
		sqlStatement += " and u.status in " + inStringStatus
	}
	if len(params["role"]) > 0 {
		splitRole := strings.Split(params["role"], ",")
		i := 0
		inStringRole := "["
		for _, val := range splitRole {
			inStringRole += "'" + val + "'"
			if i != len(splitRole)-1 {
				inStringRole += ","
			}
			i++
		}
		inStringRole += "]"
		sqlStatement += " and r.name in " + inStringRole
	}
	countQuery := sqlStatement
	if len(params["order_by_column"]) > 0 {
		sqlStatement += " order by " + params["order_by_column"]
	}
	if params["ascending"] == "true" {
		sqlStatement += " desc "
	}

	sqlStatement += " limit " + params["limit"]

	limit, _ := strconv.Atoi(params["limit"])
	pageNumber, _ := strconv.Atoi(params["page_number"])
	pageNumber = pageNumber - 1
	if pageNumber <= 0 {
		pageNumber = 0
	}
	offset := strconv.Itoa(limit * pageNumber)
	sqlStatement += " offset " + offset
	sqlStatement += `;`

	qry, err := m.Conn.Query(sqlStatement)
	if err != nil {
		return &data, count, err
	}
	for qry.Next() {
		err = qry.Scan(
			&ud.ID,
			&ud.Email,
			&ud.Role,
			&ud.LastLogin,
			&ud.Status,
		)
		if err != nil {
			return &data, count, err
		}
		data = append(data, ud)
	}
	//count
	splitForCountQuery := strings.Split(countQuery, "from")
	finalCountQuery := "select count(u.id) from " + splitForCountQuery[1]
	cQry, err := m.Conn.Query(finalCountQuery)
	if err != nil {
		return &data, count, err
	}
	for cQry.Next() {
		err := cQry.Scan(&count)
		if err != nil {
			return &data, count, err
		}
	}

	return &data, count, nil
}

func (m *mariaUserRepository) UserRoleByRoles(ctx context.Context, role string) ([]*models.RolePermissions, error) {
	rows, err := m.Conn.Query(fmt.Sprintf(queryByRole, role))
	if err != nil {
		log.Print("UserRoleByRoles db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(rows)

	result := make([]*models.RolePermissions, 0)
	temp := map[string]models.RolePermissions{}
	for rows.Next() {
		var roleName, roleDescription string
		perm := new(models.Permission)
		//role_name  | role_description | permission_name | permission_description
		err = rows.Scan(&roleName, &roleDescription, &perm.Name, &perm.Description)

		per := models.Permission{
			Name:        perm.Name,
			Description: perm.Description,
		}
		ura := models.RolePermissions{
			Name:        roleName,
			Description: roleDescription,
			Permissions: []models.Permission{per},
		}
		urpData, ok := temp[roleName]
		if !ok {
			temp[roleName] = ura
		} else {
			urpData.Permissions = append(urpData.Permissions, per)
			temp[roleName] = urpData
		}
	}

	// Inline REST API RESP
	for _, val := range temp {
		result = append(result, &val)
	}
	return result, nil

}

func (m *mariaUserRepository) UserRoleByPermissions(ctx context.Context, permission string) ([]*models.RolePermissions, error) {
	rows, err := m.Conn.Query(fmt.Sprintf(queryByPermission, permission))
	if err != nil {
		log.Print("UserRoleByPermissions db query err: ", err)
		return nil, models.ErrInternalServerError
	}

	defer closeRows(rows)

	result := make([]*models.RolePermissions, 0)
	temp := map[string]models.RolePermissions{}
	for rows.Next() {
		var roleName, roleDescription string
		perm := new(models.Permission)
		//role_name  | role_description | permission_name | permission_description
		err = rows.Scan(&roleName, &roleDescription, &perm.Name, &perm.Description)

		per := models.Permission{
			Name:        perm.Name,
			Description: perm.Description,
		}
		ura := models.RolePermissions{
			Name:        roleName,
			Description: roleDescription,
			Permissions: []models.Permission{per},
		}
		urpData, ok := temp[roleName]
		if !ok {
			temp[roleName] = ura
		} else {
			urpData.Permissions = append(urpData.Permissions, per)
			temp[roleName] = urpData
		}
	}

	// Inline REST API RESP
	for _, val := range temp {
		result = append(result, &val)
	}
	return result, nil
}

func (m mariaUserRepository) ListPermissions(_ context.Context, p *models.PageRequest) (*common.HTTPResponse, error) {
	var rowCount uint64
	e := m.Conn.QueryRow(getPermissionsCount).Scan(&rowCount)
	if e != nil {
		if e == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", e)
			return nil, common.AppErrorCode(common.PermNotAvailable)
		} else {
			log.Printf("[repository:maria_user] ListPermissions count db query err: %s \n", e)
			return nil, models.ErrInternalServerError
		}

	}
	var index, count uint64
	if p.PageNumber != 0 && p.Count != 0 {
		index = (p.PageNumber * p.Count) - p.Count
		count = p.Count
	} else {
		index = 0
		count = rowCount
	}
	rows, err := m.Conn.Query(getPermissions, index, count)
	result := make([]*models.UserGroupPermissions, 0)

	if err != nil {
		if err == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", err)
			return nil, common.AppErrorCode(common.PermNotAvailable)
		} else {
			log.Print("[repository:maria_use r] ListPermissions db query err: ", err)
			return nil, models.ErrInternalServerError
		}

	}
	defer closeRows(rows)

	groupList := map[string]*models.UserGroupPermissions{}
	for rows.Next() {
		var groupID, groupName, permName, permDescription string
		var permID uint64
		var perStatus int64
		err = rows.Scan(&permID, &permName, &permDescription, &perStatus, &groupID, &groupName)

		if err != nil {
			log.Print("[repository:maria_user] ListPermissions row parse err: ", err)
			return nil, models.ErrInternalServerError
		}

		perm := new(models.Permission)
		perm.ID = permID
		perm.Name = permName
		perm.Description = permDescription
		perm.Status = perStatus

		permResult, ok := groupList[groupID]
		if !ok {
			permRs := make([]*models.Permission, 0)
			permRs = append(permRs, perm)
			grpList := &models.UserGroupPermissions{GroupID: groupID, GroupName: groupName, Permissions: permRs}
			groupList[groupID] = grpList
		} else {
			permResult.Permissions = append(permResult.Permissions, perm)
			groupList[groupID] = permResult
		}
	}

	if len(groupList) == 0 {
		log.Print("[repository:maria_user] ListPermissions : No row found ")
		return nil, common.AppErrorCode(common.PermNotAvailable)
	}

	for _, val := range groupList {
		result = append(result, val)
	}
	return &common.HTTPResponse{Data: result, Message: common.GetMessage(common.PermissionSuccess), Length: rowCount}, nil

}

func (m mariaUserRepository) AddUserRole(_ context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error) {
	var roleName string
	var _roleID int64
	e := m.Conn.QueryRow(selectRoleByName, rp.Name).Scan(&_roleID, &roleName)

	if e != nil && e != sql.ErrNoRows {
		log.Printf("[maria_notification.repository] Exception in AdduserRole: get role by name %s \n", e)
		return nil, models.ErrInternalServerError
	}
	//Checking role name already used
	if roleName != "" {
		return nil, common.AppErrorCode(common.RoleNameTaken)
	}

	// save role
	result, err := m.Conn.Exec(insertRole, rp.Name, rp.Description, rp.Status, rp.CreatedBy, rp.CreatedTime, rp.UpdatedBy, rp.UpdatedTime)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in AdduserRole: insert into role table %s \n", err)
		return nil, models.ErrInternalServerError
	}

	roleID, _ := result.LastInsertId()
	// save role permission mapping
	for _, permID := range rp.Permissions {
		_, err := m.Conn.Exec(insertRolePermisssions, roleID, permID, rp.Status, rp.CreatedBy, rp.CreatedTime, rp.UpdatedBy, rp.UpdatedTime)
		if err != nil {
			log.Printf("[maria_notification.repository] Exception in AdduserRole: insert into role_permission table %s \n", err)
			return nil, models.ErrInternalServerError
		}
	}
	return &common.HTTPResponse{Message: common.GetMessage(common.CreateRoleSuccess)}, nil
}

func (m mariaUserRepository) UpdateUserRole(_ context.Context, rp *models.RolePermissionsRequest) (*common.HTTPResponse, error) {
	var roleName string
	var roleID int64

	// check new role name already taken
	err := m.Conn.QueryRow(selectRoleByName, rp.NewName).Scan(&roleID, &roleName)
	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria_notification.repository] Exception in UpdateUserRole: get role by name %s \n", err)
		return nil, models.ErrInternalServerError
	}
	//Checking role name already used
	if roleName != "" {
		return nil, common.AppErrorCode(common.RoleNameTaken)
	}

	// check role name availabe to update
	err = m.Conn.QueryRow(selectRoleByName, rp.Name).Scan(&roleID, &roleName)
	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria_notification.repository] Exception in UpdateUserRole: get role by name %s \n", err)
		return nil, models.ErrInternalServerError
	}
	//Checking role name available to update
	if roleName == "" {
		return nil, common.AppErrorCode(common.RoleNameNotAvailable)
	}

	// transaction begin here
	tx, err := m.Conn.Begin()
	if err != nil {
		return nil, models.ErrInternalServerError
	}
	//Update role
	result, err := m.Conn.Exec(updateRole, rp.NewName, rp.Description, rp.Status, rp.UpdatedBy, rp.UpdatedTime, rp.Name)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in UpdateUserRole: update into role table %s \n", err)
		tx.Rollback()
		return nil, models.ErrInternalServerError
	}

	row, err := result.RowsAffected()
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in UpdateUserRole: RowsAffected: update into role table %s \n", err)
		return nil, models.ErrInternalServerError
	}

	if row == 0 {
		return nil, common.AppErrorCode(common.UpdateRoleUnsuccessful)
	}
	// delete role permissions mapping
	result, err = m.Conn.Exec(deleteRolePermisssions, roleID)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in UpdateUserRole: delete from role_permission %s \n", err)
		tx.Rollback()
		return nil, models.ErrInternalServerError
	}

	// save new role permissions mapping
	for _, permID := range rp.Permissions {
		_, err := m.Conn.Exec(insertRolePermisssions, roleID, permID, rp.Status, rp.CreatedBy, rp.CreatedTime, rp.UpdatedBy, rp.UpdatedTime)
		if err != nil {
			log.Printf("[maria_notification.repository] Exception in UpdateUserRole: update into role_permission table %s \n", err)
			tx.Rollback()
			return nil, models.ErrInternalServerError
		}
	}
	err = tx.Commit()
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in UpdateUserRole: transaction commit %s \n", err)
		return nil, models.ErrInternalServerError
	}
	return &common.HTTPResponse{Message: common.GetMessage(common.UpdateRoleSuccessful)}, nil
}

func (m mariaUserRepository) DeleteUserRole(_ context.Context, roleID string) (string, error) {
	var rowCount uint64
	var deletedRoleStatus uint8 = 4
	e := m.Conn.QueryRow(selectRolesCount, roleID).Scan(&rowCount)
	if e != nil {
		log.Printf("[repository:maria_user] roles count db query err: %s \n", e)
		return "", models.ErrInternalServerError
	}

	if rowCount > 0 {
		return "", models.ErrRegisteredUserRole
	}

	// delete role
	_, err := m.Conn.Exec(updateeRoleStatus, deletedRoleStatus, roleID)
	if err != nil {
		log.Printf("[maria_notification.repository] Exception in DeleteUserRole: delete from role %s \n", err)
		return "", models.ErrInternalServerError
	}
	return "success", nil
}

func (m mariaUserRepository) GetUserRolesList(ctx context.Context, p *models.RolesRequest) (*common.HTTPResponse, error) {
	var rowCount uint64
	e := m.Conn.QueryRow(selectUserRolesCount, p.StatusRole).Scan(&rowCount)
	if e != nil {
		if e == sql.ErrNoRows {
			log.Print("[repository:maria_user] ListPermissions : No row found ", e)
			return &common.HTTPResponse{Data: make([]*models.UserGroupPermissions, 0), Message: "Permissions not available", HTTPstatus: http.StatusNotFound}, nil
		} else {
			log.Printf("[repository:maria_user] ListPermissions count db query err: %s \n", e)
			return nil, models.ErrInternalServerError
		}

	}
	var index, count uint64
	if p.PageNumber != 0 && p.Count != 0 {
		index = (p.PageNumber * p.Count) - p.Count
		count = p.Count
	} else {
		index = 0
		count = rowCount
	}
	//Get Permissions
	qry, err := m.Conn.Query(selectUserPermissionList, p.StatusPermisson)
	if err != nil {
		log.Print("UserRoleByPermissions db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	permissions := make(map[int]interface{})
	rl := models.RolesPermission{}
	var pid int
	for qry.Next() {
		err = qry.Scan(
			&pid,
			&rl.Name,
			&rl.Description,
		)
		if err != nil {
			log.Print("[repository:maria_user] UserRoleByPermissions row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		permissions[pid] = rl
	}

	//Get RolePermissions IDs
	qry, err = m.Conn.Query(selectUserRolePermissionList, p.StatusRolePermisson)
	if err != nil {
		log.Print("[repository:maria_user] UserRoleByPermissionList db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	RolePermissions := make(map[int][]interface{})
	var RoleID, PerID int
	for qry.Next() {
		err = qry.Scan(&RoleID, &PerID)
		if err != nil {
			log.Print("[repository:maria_user] selectUserRolesList row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		RolePermissions[RoleID] = append(RolePermissions[RoleID], permissions[PerID])
	}

	//Get RolesList
	qry, err = m.Conn.Query(selectUserRolesList, p.StatusRolePermisson, index, count)
	if err != nil {
		log.Print("[repository:maria_user] selectUserRolesList db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(qry)
	roles := []models.RolesListResponce{}
	rud := models.RolesListResponce{}
	for qry.Next() {
		err = qry.Scan(
			&rud.ID,
			&rud.Name,
			&rud.Description,
		)
		if err != nil {
			log.Print("[repository:maria_user] selectUserRolesList row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		rud.Permission = RolePermissions[rud.ID]
		roles = append(roles, rud)
	}
	return &common.HTTPResponse{Data: roles, Length: rowCount, HTTPstatus: http.StatusOK}, nil
}

func (m mariaUserRepository) UpdateDeviceID(_ context.Context, deviceID, mobileNumber string) (int64, error) {
	result, err := m.Conn.Exec(updateDeviceID, deviceID, mobileNumber)

	if err != nil && err != sql.ErrNoRows {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}
	r, err := result.RowsAffected()
	if err != nil {
		log.Print(err)
		return 0, models.ErrInternalServerError
	}

	return r, nil
}

func (m mariaUserRepository) AddNewDimilandUser(ctx context.Context, r *models.AddNewUserRequest) (*common.HTTPResponse, error) {
	if r.Email == "" || r.RoleID == "" {
		return &common.HTTPResponse{Message: "Email & Role are required", HTTPstatus: http.StatusPreconditionFailed}, nil
	}
	r.Email = strings.TrimSpace(r.Email)
	var emailRegex = regexp.MustCompile("^[a-zA-Z0-9.!#$%&'*+\\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$")
	if !emailRegex.MatchString(r.Email) {
		return nil, models.ErrInvalidMail
	}

	r.RoleID = strings.TrimSpace(r.RoleID)
	RoleID, _ := strconv.Atoi(r.RoleID)
	RequestorID, _ := strconv.Atoi(r.RequestorID)
	var status int
	err := m.Conn.QueryRow(selectStatusByMail, r.Email).Scan(&status)
	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria_notification.repository] Exception in AddNewuser: check user mail %s \n", err)
		return nil, models.ErrInternalServerError
	}
	if status != 0 {
		return nil, models.ErrMailAlreadyRegistred
	}

	r.UpdatedBy = RequestorID
	r.CreatedBy = RequestorID
	//Storing User email in user table
	_, err = m.Conn.Exec(insertNewUser, r.ID, r.Email, r.Status, r.Domain, r.CreatedBy, r.CreatedTime, r.UpdatedBy, r.UpdatedTime)
	if err != nil {
		log.Print(err)
		return nil, models.ErrInternalServerError
	}
	RoleStatus := 1
	////Storing User role email in user_role table
	_, err = m.Conn.Exec(insertNewUserRole, RoleID, r.ID, RoleStatus, r.CreatedBy, r.CreatedTime, r.UpdatedBy, r.UpdatedTime)
	if err != nil {
		log.Print(err)
		return nil, models.ErrInternalServerError
	}

	return &common.HTTPResponse{Message: "Registration successful & A verification mail sent", HTTPstatus: http.StatusOK}, nil
}

func (m *mariaUserRepository) CheckUserHasAccess(ctx context.Context, username string) (bool, error) {
	log.Println("In CheckUserHasAccess : ", username, fmt.Sprintf(selectUserByUserName, username))
	var roleName string

	err := m.Conn.QueryRow(fmt.Sprintf(selectUserByUserName, username)).Scan(&roleName)
	if err != nil {
		return false, err
	}

	return strings.EqualFold(strings.ToLower(roleName), dimmiLandAccess), nil
}

func (m mariaUserRepository) GetUserRolePermissionByUserName(ctx context.Context, userName string) ([]*models.RolePermissions, error) {
	query := fmt.Sprintf(queryUserRoleByUserName, userName)
	log.Println("Inside GetUserRolePermissionByUserName query :\n", query)
	rows, err := m.Conn.Query(query)
	if err != nil {
		log.Print("GetUserRolePermissionByUserName db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(rows)

	result := make([]*models.RolePermissions, 0)
	temp := map[string]models.RolePermissions{}
	for rows.Next() {
		var roleName string
		perm := new(models.Permission)
		//role_name | permission_name
		err = rows.Scan(&roleName, &perm.ID, &perm.Name)
		per := models.Permission{
			ID:   perm.ID,
			Name: perm.Name,
		}
		ura := models.RolePermissions{
			Name:        roleName,
			Permissions: []models.Permission{per},
		}
		data, ok := temp[roleName]
		if !ok {
			temp[roleName] = ura
		} else {
			data.Permissions = append(data.Permissions, per)
			temp[roleName] = data
		}
	}

	// Inline REST API RESP
	for _, val := range temp {
		result = append(result, &val)
	}
	return result, nil

}

func (m mariaUserRepository) EditDimiilandUser(ctx context.Context, rq *models.UserEditRequest) (*common.HTTPResponse, error) {
	//Get RolesByUserID
	qry, err := m.Conn.Query(selectRolesByUserID, rq.UserID)
	if err != nil {
		log.Print("[repository:maria_user] RolesByUserID db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(qry)
	var Existing []int
	var id int
	for qry.Next() {
		err = qry.Scan(&id)
		if err != nil {
			log.Print("[repository:maria_user] RolesByUserID row parse err: ", err)
			return nil, models.ErrInternalServerError
		}
		Existing = append(Existing, id)
	}

	// transaction begin here
	tx, err := m.Conn.Begin()
	if err != nil {
		return nil, models.ErrInternalServerError
	}
	New := rq.RolesID
	var Add []int
	var Remove []int
	if len(Existing) > 0 {
		//find roles for delete
		for _, s1 := range Existing {
			found := false
			for _, s2 := range New {
				if s1 == s2 {
					found = true
					break
				}
			}
			if !found {
				Remove = append(Remove, s1)
			}
		}
		//find new roles
		for _, n1 := range New {
			found := false
			for _, n2 := range Existing {
				if n1 == n2 {
					found = true
					break
				}
			}
			// if not found. We add it to return slice
			if !found {
				Add = append(Add, n1)
			}
		}
		//Remove roles
		for _, roleID := range Remove {
			_, err := m.Conn.Exec(deleteUserRole, rq.StatusUserRoleDelete, roleID, rq.UserID)
			if err != nil {
				log.Printf("[maria_notification.repository] Exception in EditDimiilandUser: delete user role %s \n", err)
				tx.Rollback()
				return nil, models.ErrInternalServerError
			}
		}
	} else {
		Add = rq.RolesID
	}

	//Add new roles
	for _, roleID := range Add {
		timestamp := time.Now()
		time.Sleep(1000 * time.Millisecond) // get unique time in loop
		_, err := m.Conn.Exec(addUserRole, roleID, rq.UserID, rq.StatusUserRoleActive, rq.RequestorID, timestamp, rq.RequestorID, timestamp)
		if err != nil {
			log.Printf("[maria_notification.repository] Exception in EditDimiilandUser: add user role %s \n", err)
			tx.Rollback()
			return nil, models.ErrInternalServerError
		}
	}
	return &common.HTTPResponse{Message: "Edit User Successful", HTTPstatus: http.StatusOK}, nil
}

func (m mariaUserRepository) GetPermissionByUserId(ctx context.Context, param map[string]interface{}) (*models.PermissionsUser, error) {
	userId := param["user_id"]
	activePermission := param["permission_active"]
	activeRole := param["role_active"]
	query := fmt.Sprintf(selectPermissionByUserID, userId, activePermission, activeRole)
	log.Println("Inside GetPermissionByUserId query :\n", query)
	rows, err := m.Conn.Query(query)
	if err != nil {
		log.Print("GetPermissionByUserId db query err: ", err)
		return nil, models.ErrInternalServerError
	}
	defer closeRows(rows)

	permissions := make([]string, 0)
	var uid uint64
	var uname string

	for rows.Next() {
		perm := new(models.Permission)
		err = rows.Scan(&uid, &uname, &perm.ID, &perm.Name, &perm.Status, &perm.Description)

		permissions = append(permissions, perm.Name)
	}
	result := &models.PermissionsUser{
		UserId:      uid,
		UserName:    uname,
		Permissions: permissions,
	}
	return result, nil
}

func (m *mariaUserRepository) BlockUserByID(ctx context.Context, userReq *models.UserBlockStatus) (string, error) {

	result, err := m.Conn.Exec(blockUserByUserID, userReq.Status, userReq.Reason, userReq.UserID)

	if err != nil {
		log.Printf("[maria_notification.repository] BlockUserByID. Exception in updating user status. %s \n", err)
		return "", err
	}
	row, err := result.RowsAffected()

	if err != nil {
		log.Printf("[maria_notification.repository] BlockUserByID. RowsAffected. %s \n", err)
		return "", err
	}

	if row == 0 {
		return common.GetMessage(common.BlockUserUnSuccess), nil
	}
	return common.GetMessage(common.BlockUserSuccess), nil
}

func (m *mariaUserRepository) UnblockUserByID(ctx context.Context, userReq *models.UserBlockStatus) (string, error) {

	// unblock
	result, err := m.Conn.Exec(unblockUserByUserID, userReq.Status, userReq.UserID)

	if err != nil {
		log.Printf("[maria_notification.repository] UnblockUserByID. Exception in updating user status. %s \n", err)
		return "", err
	}
	row, err := result.RowsAffected()

	if err != nil {
		log.Printf("[maria_notification.repository] UnblockUserByID. RowsAffected. %s \n", err)
		return "", err
	}

	if row == 0 {
		return common.GetMessage(common.UnBlockUserUnSuccess), nil
	}
	return common.GetMessage(common.UnBlockUserSuccess), nil
}

func (m *mariaUserRepository) GetUserByUserID(_ context.Context, userID uint64) (*models.User, error) {
	list, err := m.fetch(selectUserbyUserID, userID)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, common.AppErrorCode(common.UserNotFound)
		}
		return nil, err
	}

	if len(list) <= 0 {
		return nil, common.AppErrorCode(common.UserNotFound)
	}

	return list[0], nil
}
