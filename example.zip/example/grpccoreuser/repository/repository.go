package repository

import (
	"context"

	"git.capitalx.id/core/user/common"
	models "git.capitalx.id/core/user/model"
)

// CacheUserRepository represent the cache user's repository contract
type CacheUserRepository interface {
	StoreOTP(ctx context.Context, key string, req *models.GenerateOTP, counter int, expiredPeriod int32) error
	GetValueOTP(ctx context.Context, key string) (map[string]string, error)
	DeleteOTP(ctx context.Context, key string) bool
	GetRemainingTimeOTP(ctx context.Context, key string) int32
	StoreResendOTP(ctx context.Context, key, status string, counter int, expiredPeriod int32) error
	StoreEmailToken(key string, token string) error
}

// SqlUserRepository represent the user's repository contract
type SqlUserRepository interface {
	MariaStoreUser(ID uint64, passCode string, u *models.User) (uint64, error)
	CheckStatusByPhoneNumber(mobileNumber string) (int, error)
	GetPassCodeByPhoneNumber(mobileNumber string) (string, error)
	GetPassCodeByUserName(userName string) (string, error)
	GetUserByPhoneNumber(ctx context.Context, mobileNumber string) (*models.User, error)
	BlockUser(ctx context.Context, mobileNumber string, status int) (string, error)
	DeleteUser(ctx context.Context, mobileNumber string) (string, error)
	UpdatePasscode(ctx context.Context, mobileNumber, passcode string) (int64, error)
	GetDimiilandUsersList(ctx context.Context, params map[string]string) (*[]models.DimilandUsers, uint64, error)
	ListPermissions(ctx context.Context, p *models.PageRequest) (*common.HTTPResponse, error)
	AddUserRole(ctx context.Context, p *models.RolePermissionsRequest) (*common.HTTPResponse, error)
	UpdateUserRole(ctx context.Context, p *models.RolePermissionsRequest) (*common.HTTPResponse, error)
	DeleteUserRole(ctx context.Context, roleID string) (string, error)
	AddNewDimilandUser(ctx context.Context, rq *models.AddNewUserRequest) (*common.HTTPResponse, error)
	UpdateDeviceID(ctx context.Context, deviceID, mobileNumber string) (int64, error)
	GetUserRolesList(ctx context.Context, r *models.RolesRequest) (*common.HTTPResponse, error)
	GetUserRolePermissionByUserName(ctx context.Context, userName string) ([]*models.RolePermissions, error)
	CheckUserHasAccess(ctx context.Context, username string) (bool, error)
	EditDimiilandUser(ctx context.Context, rq *models.UserEditRequest) (*common.HTTPResponse, error)
	GetPermissionByUserId(ctx context.Context, param map[string]interface{}) (*models.PermissionsUser, error)
	BlockUserByID(ctx context.Context, user *models.UserBlockStatus) (string, error)
	UnblockUserByID(ctx context.Context, user *models.UserBlockStatus) (string, error)
	GetUserByUserID(_ context.Context, userID uint64) (*models.User, error)

	// user_device table
	CheckStatusByDeviceID(mobileNumber, deviceID string) (models.UserDevice, error)
	GetUserDeviceByMobileNumber(mobileNumber string) (models.UserDevice, error)
	StoreUserDevice(req *models.UserDevice) (string, error)
	UpdateUserDevice(req *models.UserDevice) (string, error)
	UpdateUserDeviceToken(mobileNumber, deviceID, deviceToken string) (int64, error)
	UserRoleByRoles(ctx context.Context, role string) ([]*models.RolePermissions, error)
	UserRoleByPermissions(ctx context.Context, permission string) ([]*models.RolePermissions, error)
	GetUserDeviceByUserID(ctx context.Context, p *models.UserDeviceListRequest) (*common.HTTPResponse, error)
}

// UserRepository represent the user's repository contract
type UserRepository interface {
	// Redis
	CacheUserRepository
	// Maria
	SqlUserRepository
}
