package repository

import (
	"context"
	"time"

	"github.com/go-redis/redis/v7"

	models "git.capitalx.id/core/user/model"
)

type redisSingleRepository struct {
	Conn *redis.Client
}

// NewRedisUserRepository will create an object that represent the user.Repository interface
func NewRedisSingleRepository(Conn *redis.Client) CacheUserRepository {
	return &redisSingleRepository{Conn}
}

func (r *redisSingleRepository) StoreOTP(ctx context.Context, key string, req *models.GenerateOTP, counter int, expiredPeriod int32) error {
	expiredTime := time.Duration(expiredPeriod) * time.Second
	value := map[string]interface{}{
		"otp_code": req.OtpCode,
		"secret":   req.Secret,
		"counter":  counter,
		"status":   req.Status,
	}

	err := r.Conn.HMSet(key, value).Err()
	if err != nil {
		return err
	}

	_ = r.Conn.Expire(key, expiredTime)

	return nil
}

func (r *redisSingleRepository) GetValueOTP(ctx context.Context, key string) (map[string]string, error) {
	val, err := r.Conn.HGetAll(key).Result()
	if err != nil {
		return nil, err
	}

	return val, nil
}

func (r *redisSingleRepository) DeleteOTP(ctx context.Context, key string) bool {
	err := r.Conn.Del(key).Err()
	if err != nil {
		return false
	}

	return true
}

func (r *redisSingleRepository) GetRemainingTimeOTP(ctx context.Context, key string) int32 {
	ttl, _ := r.Conn.TTL(key).Result()

	remaining := int32(ttl / time.Second)

	return remaining
}

func (r *redisSingleRepository) StoreResendOTP(ctx context.Context, key, status string, counter int, expiredPeriod int32) error {
	expiredTime := time.Duration(expiredPeriod) * time.Second
	var value map[string]interface{}
	value = map[string]interface{}{
		"counter": counter,
		"status":  status,
	}

	err := r.Conn.HMSet(key, value).Err()
	if err != nil {
		return err
	}

	_ = r.Conn.Expire(key, expiredTime)

	return nil
}

func (r *redisSingleRepository) StoreEmailToken(key string, token string) error {
	err := r.Conn.HMSet(key, token).Err()
	if err != nil {
		return err
	}

	_ = r.Conn.Expire(key, 24*time.Hour)

	return nil
}
