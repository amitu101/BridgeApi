package utils

const (
	StatusUserActive           = 1
	StatusUserInactive         = 2
	StatusUserBlocked          = 3
	StatusUserDeleted          = 4
	StatusUserPermanentBlocked = 5
)
