package delivery

import (
	"context"
	"fmt"
	"log"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	models "git.capitalx.id/core/user/model"
	userSrv "git.capitalx.id/core/user/service"
)

//NewUserServerGrpc ...
func NewUserServerGrpc(gserver *grpc.Server, userSrv userSrv.UserService) {
	// RegisterUserHandlerServer using Server struct
	userServer := &server{
		service: userSrv,
	}
	RegisterUserHandlerServer(gserver, userServer)

	reflection.Register(gserver)
}

type server struct {
	service userSrv.UserService
}

func (s *server) ResendOTPLinkage(ctx context.Context, request *ResendOTPLinkageRequest) (*ResendOTPLinkageResponse, error) {
	log.Println("resend OTP, Mobile Number : ", request.MobileNumber)
	OTPData, err := s.service.ResendOTPLinkage(ctx, request.MobileNumber, request.Id)
	if err != nil {
		return nil, err
	}
	fmt.Println("Resend from delivery")
	fmt.Println("OTPDATA resend form delivery: ", OTPData)

	return &ResendOTPLinkageResponse{
		CountDownResendOtp: OTPData.CountdownResendOTP,
		OtpDuration:        OTPData.OtpDuration,
		NumberOfResend:     OTPData.NumberOfResend,
		Message:            OTPData.Message,
	}, err
}

func (s *server) CheckMobileNumberLinkage(ctx context.Context, request *CheckMobileNumberLinkageRequest) (*CheckMobileNumberLinkageResponse, error) {
	log.Println("check mobile number linkage :", request.MobileNumber)
	OTPData, err := s.service.CheckMobileNumberLinkage(ctx, request.DeviceId, request.MobileNumber,request.ClientId)

	if err != nil {
		log.Println(err)
		return nil, err
	}

	return &CheckMobileNumberLinkageResponse{
		CountDownResendOtp: OTPData.CountdownResendOTP,
		OtpDuration:        OTPData.OtpDuration,
		Message:            OTPData.Message,
	}, err
}

func (s *server) ValidateInputOTPLinkage(ctx context.Context, request *OTPValidationLinkageRequest) (*OTPValidationLinkageResponse, error) {
	OTPResponse, err := s.service.ValidateInputOTPLinkage(ctx, request.MobileNumber, request.OtpCode, request.Id,request.ClientId)
	if err != nil {
		return nil, err
	}

	return &OTPValidationLinkageResponse{
		Message: OTPResponse.Message,
	}, err
}

func (s *server) LoginLinkage(ctx context.Context, request *LoginLinkageRequest) (*LoginLinkageResponse, error) {
	resp, err := s.service.LoginLinkage(ctx, request.Passcode, request.DeviceId, request.MobileNumber)
	if err != nil {
		return nil, err
	}

	return &LoginLinkageResponse{
		IdToken:      resp.IdToken,
		UserName:     resp.UserName,
		MobileNumber: resp.MobileNumber,
	}, nil
}

func (s *server) GetUserDevice(ctx context.Context, request *GetMobileNumberRequest) (*UserDevice, error) {
	userDevice, err := s.service.GetUserDeviceByMobileNumber(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}
	return &UserDevice{
		Mobile:         userDevice.Mobile,
		DeviceId:       userDevice.DeviceID,
		Status:         userDevice.Status,
		DeviceRegToken: userDevice.DeviceRegToken,
	}, nil
}

func (s *server) GenerateOTP(ctx context.Context, request *GenerateOTPRequest) (*GetOTPResponse, error) {
	OTPData, err := s.service.GenerateOTP(ctx, request.Mobilenumber, request.Id)
	if err != nil {
		return nil, err
	}

	return &GetOTPResponse{
		Otpcode:      OTPData.OtpCode,
		Mobilenumber: OTPData.MobileNumber,
		Otpduration:  OTPData.OtpDuration,
		Message:      OTPData.Message,
	}, err
}

func (s *server) ValidateInputOTP(ctx context.Context, request *GetOTPValidateRequest) (*OTPValidateResponse, error) {
	OTPResponse, err := s.service.ValidateInputOTP(ctx, request.MobileNumber, request.OtpCode, request.Id)
	if err != nil {
		return nil, err
	}

	return &OTPValidateResponse{
		Message: OTPResponse.Message,
	}, err
}

func (s *server) ResendOTP(ctx context.Context, request *ResendOTPRequest) (*ResendOTPResponse, error) {
	log.Println("Mobile Number : ", request.MobileNumber)
	OTPData, err := s.service.ResendOTP(ctx, request.MobileNumber, request.Id)
	if err != nil {
		return nil, err
	}
	fmt.Println("Resend from delivery")
	fmt.Println("OTPDATA resend form delivery: ", OTPData)

	return &ResendOTPResponse{
		CountDownResendOtp: OTPData.CountdownResendOTP,
		OtpDuration:        OTPData.OtpDuration,
		NumberOfResend:     OTPData.NumberOfResend,
		Message:            OTPData.Message,
	}, err
}

func (s *server) StoreUser(ctx context.Context, request *StoreUserData) (*StoreUserDataResponse, error) {
	fmt.Println("as")
	u := &models.User{
		CreatedBy: request.Createdby,
		Passcode:  request.Passcode,
		Mobile:    request.Mobilenumber,
		DeviceID:  request.Deviceid,
		Username:  request.Username,
		Email:     request.Email,
		Name:      request.Name,
	}

	resp, err := s.service.StoreUser(ctx, u)
	if err != nil {
		return nil, err
	}

	return &StoreUserDataResponse{
		Id: resp,
	}, nil
}

func (s *server) CheckLoginPhoneNumberStatus(ctx context.Context, request *CheckStatusRequest) (*GetCheckLoginPhoneNumberStatusResponse, error) {

	log.Println("mobile number :", request.MobileNumber)
	OTPData, err := s.service.CheckLoginPhoneNumberStatus(ctx, request.DeviceId, request.MobileNumber)

	if err != nil {
		log.Println(err)
		return nil, err
	}

	return &GetCheckLoginPhoneNumberStatusResponse{
		CountDownResendOtp: OTPData.CountdownResendOTP,
		OtpDuration:        OTPData.OtpDuration,
		Message:            OTPData.Message,
	}, err
}

func (s *server) Login(ctx context.Context, request *LoginRequest) (*LoginResponse, error) {
	resp, err := s.service.Login(ctx, request.Passcode, request.DeviceId, request.MobileNumber)
	if err != nil {
		return nil, err
	}

	return &LoginResponse{
		IdToken:      resp.IDToken,
		UserName:     resp.Username,
		MobileNumber: resp.MobileNumber,
	}, nil
}

func (s *server) GetUserByPhoneNumber(ctx context.Context, request *GetUserByPhoneNumberRequest) (*GetUserByPhoneNumberResponse, error) {
	resp, err := s.service.GetUserByMobileNumber(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &GetUserByPhoneNumberResponse{
		Id:       resp.ID,
		Username: resp.Username,
		Name:     resp.Name,
		Mobile:   resp.Mobile,
		Email:    resp.Email,
		Status:   resp.Status,
		Deviceid: resp.DeviceID,
	}, nil
}

func (s *server) BlockUser(ctx context.Context, request *GetMobileNumberRequest) (*BlockUserResponse, error) {
	resp, err := s.service.BlockUser(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &BlockUserResponse{
		Message: resp,
	}, nil
}

func (s *server) DeleteUser(ctx context.Context, request *GetMobileNumberRequest) (*DeleteUserResponse, error) {
	resp, err := s.service.DeleteUser(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &DeleteUserResponse{
		Message: resp,
	}, nil
}

func (s *server) UpdateDeviceRegisterToken(ctx context.Context, request *UpdateDeviceTokenRequest) (*UpdateDeviceTokenResponse, error) {
	status, err := s.service.UpdateDeviceToken(ctx, request.Mobilenumber, request.Deviceid, request.Token)
	if err != nil {
		return nil, err
	}

	return &UpdateDeviceTokenResponse{Status: status}, nil
}

func (s *server) GetUserResendOTPBlockedTime(ctx context.Context, request *GetMobileNumberRequest) (*GetUserResendOTPBlockedTimeResponse, error) {
	remainingTime, err := s.service.GetUserResendOTPBlockedTime(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &GetUserResendOTPBlockedTimeResponse{
		Remainingtime: remainingTime,
	}, nil
}

func (s *server) GetUserInputOTPBlockedTime(ctx context.Context, request *GetMobileNumberRequest) (*GetUserInputOTPBlockedTimeResponse, error) {
	remainingTime, err := s.service.GetUserInputOTPBlockedTime(ctx, request.Mobilenumber)
	if err != nil {
		return nil, err
	}

	return &GetUserInputOTPBlockedTimeResponse{
		Remainingtime: remainingTime,
	}, nil
}

func (s *server) ResetPasscodeOTP(ctx context.Context, request *PasscodeResetOTPRequest) (*PasscodeResetOTPResponse, error) {
	OTPData, err := s.service.ResetPasscodeOTP(ctx, request.DeviceId, request.MobileNumber)

	if err != nil {
		return nil, err
	}

	return &PasscodeResetOTPResponse{
		CountdownResendOtp: OTPData.CountdownResendOTP,
		OtpDuration:        OTPData.OtpDuration,
		Message:            OTPData.Message,
		MobileNumber:       OTPData.MobileNumber}, err
}

func (s *server) UpdatePasscode(ctx context.Context, request *UpdatePasscodeRequest) (*UpdatePasscodeResponse, error) {
	status, err := s.service.UpdatePasscode(ctx, request.Mobilenumber, request.Passcode)
	if err != nil {
		return nil, err
	}
	return &UpdatePasscodeResponse{Status: status}, nil
}
func (s server) ValidatePasscode(ctx context.Context,request *ValidatePasscodeRequest) (*ValidatePasscodeResponse, error) {
	var validatePassCodeResponse = ValidatePasscodeResponse{
		Valid: false,
	}
	resp,err := s.service.ValidatePhoneAndPasscode(request.PaymentCode)
	if err !=nil {
		log.Println("error in validating passcode", err)
		return &validatePassCodeResponse,nil
	}
	validatePassCodeResponse.Valid=resp
	return &validatePassCodeResponse,nil
}

