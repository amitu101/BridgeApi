package model

import "time"

//User is user data type
type User struct {
	ID          uint64
	Username    string
	Name        string
	Mobile      string
	Email       string
	Passcode    string
	Status      int32
	DeviceID    string
	LastBlocked time.Time
	CreatedBy   uint64
	CreatedTime time.Time
	UpdatedBy   uint64
	UpdatedTime time.Time
}

//LoginData is login data type
type LoginData struct {
	Mobile               string
	Passcode             string
	Status               int32
	DeviceID             string
	ExpiredDeviceBlocked int64
}

//OTPResponse is otp response data type
type OTPResponse struct {
	CountdownResendOTP int32
	OtpCode            string
	MobileNumber       string
	OtpDuration        int32
	Message            string
}

//GenerateOTP is generate otp data type
type GenerateOTP struct {
	OtpCode string
	Secret  string
	Status  string
}

//OTPValidateResponse is otp validate response data type
type OTPValidateResponse struct {
	//NumberOfFailed int32
	Message string
}

//ResendOTPResponse is resend otp response data type
type ResendOTPResponse struct {
	CountdownResendOTP int32
	OtpDuration        int32
	NumberOfResend     int32
	Message            string
}

//GeneratePwdParams is generate password params data type
type GeneratePwdParams struct {
	Memory      uint32
	Iterations  uint32
	Parallelism uint8
	SaltLength  uint32
	KeyLength   uint32
}

//SendMessage is send message data type
type SendMessage struct {
	MobileNumber string
	OtpCode      string
}

// PassCodeSecret is passcode and secret data type
type PasscodeSecret struct {
	PassCode string
}

type LoginResponse struct {
	IDToken      string
	Username     string
	MobileNumber string             `json:",omitempty"`
	UserRole     []*RolePermissions `json:"UserRole,omitempty"`
}

type OtpPhoneNumberTesting struct {
	PhoneNumber string
	Otp         string
}

//User is user data type
type DimilandUsers struct {
	ID        uint64
	Email     string
	Role      string
	LastLogin time.Time
	Status    int32
	Otp       string
}

type Permission struct {
	ID          uint64 `json:"id,omitempty"`
	Name        string `json:"name,omitempty"`
	Status      int64  `json:"status,omitempty"`
	Description string `json:"description,omitempty"`
}

type UserGroupPermissions struct {
	GroupID     string        `json:"group_id"`
	GroupName   string        `json:"group_name"`
	Permissions []*Permission `json:"permissions"`
}
type PageRequest struct {
	PageNumber uint64
	Count      uint64
}

//ResendOTPResponse is resend otp response data type
type ResendOTPLinkageResponse struct {
	CountdownResendOTP int32
	OtpDuration        int32
	NumberOfResend     int32
	Message            string
}

type LoginLinkageResponse struct {
	IdToken      string
	UserName     string
	MobileNumber string
}

type RolePermissions struct {
	Name        string       `json:"name,omitempty"`
	Description string       `json:"description,omitempty"`
	Status      uint8        `json:"status,omitempty"`
	Permissions []Permission `json:"permissions,omitempty"`
}

type RolePermissionsRequest struct {
	Name        string    `json:"name,omitempty"`
	NewName     string    `json:"new_name,omitempty"`
	Description string    `json:"description,omitempty"`
	Status      uint8     `json:"status,omitempty"`
	Permissions []uint64  `json:"permission_ids,omitempty"`
	CreatedBy   uint64    `json:"created_by,omitempty"`
	CreatedTime time.Time `json:"created_time,omitempty"`
	UpdatedBy   uint64    `json:"updated_by,omitempty"`
	UpdatedTime time.Time `json:"updated_time,omitempty"`
}

type RolesList struct {
	ID          int    `json:"id,omitempty"`
	Name        string `json:"name,omitempty"`
	Description string `json:"description,omitempty"`
}
type RolesRequest struct {
	PageNumber          uint64
	Count               uint64
	StatusRole          uint8
	StatusPermisson     uint8
	StatusRolePermisson uint8
}

type RolesPermission struct {
	ID          int    `json:"id,omitempty"`
	Name        string `json:"name,omitempty"`
	Description string `json:"description,omitempty"`
}
type RolesListResponce struct {
	ID          int         `json:"id,omitempty"`
	Name        string      `json:"name,omitempty"`
	Description string      `json:"description,omitempty"`
	Permission  interface{} `json:"permissions,omitempty"`
}

type AddNewUserRequest struct {
	Email       string `json:"email,omitempty"`
	RoleID      string `json:"role_id,omitempty"`
	RequestorID string `json:"requestor_id,omitempty"`
	Status      uint8
	ID          uint64
	Domain      string
	Token       string
	CreatedBy   int
	UpdatedBy   int
	CreatedTime time.Time
	UpdatedTime time.Time
}

type DummyLoginRequest struct {
	UserName string `json:"user_name,omitempty"`
	Password string `json:"password,omitempty"`
}

type DummyLoginResponse struct {
	IdToken string `json:"id_token"`
}

type OTPData struct {
	OtpCode      string `json:"otp_code"`
	MobileNumber string `json:"mobile_number"`
	OtpDuration  int32  `json:"otp_duration"`
}

type OTPDataRequest struct {
	OtpType      int32  `json:"otp_type"`
	MobileNumber string `json:"mobile_number"`
}

//UserEditRequest for Dimiiland user edit request
type UserEditRequest struct {
	UserID               uint64 `json:"user_id"`
	RolesID              []int  `json:"roles_id"`
	RequestorID          uint64 `json:"requestor_id"`
	StatusUserRoleActive uint64
	StatusUserRoleDelete uint64
}

type PermissionsUser struct {
	UserId      uint64   `json:"user_id"`
	UserName    string   `json:"user_name"`
	Permissions []string `json:"permission_list"`
}

type DimiilandUserReinviteRequest struct {
	Email string `json:"email"`
}
type UserBlockStatus struct {
	UserID uint64 `json:"user_id"`
	Status int32  `json:"status"`
	Reason string `json:"reason,omitempty"`
}
