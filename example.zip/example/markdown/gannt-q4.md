## Timeline
```mermaid
gantt
    title Q4 Resource Gantt Diagram
    todayMarker stroke-width:5px,stroke:#0f0,opacity:0.5
    dateFormat DD-MM-YYYY
    excludes weekends 29-10-2020 30-10-2020 24-12-2020 25-12-2020
    axisFormat %d-%m
    section Instant Payment (0)
        Account linkage (ACQ): active, 01-10-2020, 30d
          BE-Vijay (acq): active, vijay, 01-10-2020, 30d
          Web-Ahmad: active, anasikin1, 01-10-2020, 30d
          Android-Adri: active, asavana1, 01-10-2020, 30d
          QA (acq): active, 01-10-2020, 30d
        Payment at partner (ACQ): active, 01-10-2020, 30d
          BE-Dimas (acq): active, dimas, 01-10-2020, 30d
          Web-Febri Ramadhan: active, framadhan1, 01-10-2020, 30d
          Android-Lukas: active, ldadisurya1, 01-10-2020, 30d
          QA (acq): active, 01-10-2020, 30d
        Manual Transaction Posting Topup + Refund (ISS): after jithin, 10d
          BE-Jithin (iss): jithin2, after jithin, 10d
          QA (iss): after jithin, 10d
    section Manual Transaction Posting Payroll (0)     
        Manual Transaction Posting Payroll (ISS): after jithin2, 5d
          BE-Jithin (iss): jithin3, after jithin2, 5d
          QA (iss): after jithin2, 5d      
    section Topup Report (0)     
        Topup Report(ISS):after jithin3, 20d
          BE-Jithin (iss): jithin4, after jithin3, 20d
          QA (iss): after jithin3, 20d                
    section Role management(0)
      Role management: active, 01-10-2020, 10d
        BE-Jithin (iss): active, jithin, 01-10-2020, 10d
        Web-Akhil: active, akhil1, 01-10-2020, 10d
        QA (iss): active, 01-10-2020, 10d
    section User management(0)
      User management: active, 01-10-2020, 50d
        BE-Tharun (acq): active, tharun, 01-10-2020, 40d
        Web-Akhil: akhil2, after akhil1, 40d
        QA (acc): active, 01-10-2020, 50d
    section KYC (1&2)
        Acc Verification Req (ISS): active, 01-10-2020, 58d
          BE-Dwi (iss): active, dwi, 01-10-2020, 58d
          Android-Jeffry (-20d): crit, jirmawan1, 27-10-2020, 40d
          QA (iss): active, 01-10-2020, 58d
        Acc Verification Approval (ISS): 27-10-2020, 40d
          BE-Viknesh (iss): viknesh, 27-10-2020, 40d
          Web-Albert: albert1, 27-10-2020, 40d
          QA (iss): 27-10-2020, 40d
    section DimiiLand - Login (3)
      DimiiLand - Login: active, 01-10-2020, 47d
        BE-Nantha (acq): active, nantha, 01-10-2020, 40d
        Web-Akbar: akbar1, 12-10-2020, 40d
        QA (acq): active, 01-10-2020, 47d
    section P2P (4)  
      P2P (ISS): active, 01-10-2020, 58d
      BE-Zulkan (iss): active, zulkan, 01-10-2020, 40d
      Android-Ganen: ganen1, 27-10-2020, 40d
      QA (iss): active, 01-10-2020, 58d
    section Change phone (5)
      Change Phone: 02-11-2020, 29d
      BE-Faris (acq): faris, 02-11-2020, 20d
      Android-Adri: asavana2, after asavana1, 19d
      QA (acq): 02-11-2020, 29d
    section IBFT (6)
        IBFT (ISS): active, 01-10-2020, 58d
        BE-Nisar (iss): active, nisar, 01-10-2020, 58d  
        Android-Hafidh (-20d): crit, hafidh1, 27-10-2020, 40d
        Android-Lukas (help): crit, ldadisurya2, after ldadisurya1, 28d
        QA (iss): active, 01-10-2020, 58d
    section Change passcode (7)
          Change passcode: after faris, 18d
          BE-Faris (acq): faris2, after faris, 10d
          Android-Adri: crit, asavana3, after asavana2, 9d
          QA (acq): after faris, 18d
    section Manual Block & Unblock (8)
        Manual Block & Unblock: after dimas, 20d
        BE-Dimas (acq): dimas2, after dimas, 20d
        Web-Yoga: yoga1, 09-11-2020, 25d
        QA (acq): after dimas, 20d
    section Topup via Bank (9)
        Topup via Bank (ISS): 12-10-2020, 51d
        BE-Robai (iss): 12-10-2020, 51d
        QA (iss): 12-10-2020, 51d
```

## color explanation:
- gray - the project that has started
- blue - projects that haven't started yet
- orange - optimized timeline (means the resource will try to complete the project faster than the estimated timeline)

## Potential Release Date:
- Dimiiland : 15-10-2020
  - Role Management
- Instant Payment SDK : 14-11-2020
  - Account linkage
  - Payment at partner
  - Manual Transaction Posting
- DimiiLand : 12-12-2020
  - User Management
  - login
  - Manual Block & Unblock
  - Top up Report
- Dimii App: 12-12-2020
  - Change Phone Number
- Dimiiland: 23-12-2020
  - Account Verification Approval
- Dimii App: 23-12-2020
  - Account Verification Request
  - P2P
  - IBFT
  - Top Up via Bank
  - Change Passcode

## New Resource Join Date
- Robai (Be):
  - join: 5-10-2020
  - effective: 12-10-2020
- Akbar (Web):
  - join: 5-10-2020
  - effective: 12-10-2020
- Viknesh (Be):
  - join: 21-10-2020
  - effective: ~~28-10-2020~~ 27-10-2020
- Faris (Be):
  - join: 26-10-2020
  - effective: 02-11-2020
- Jeffry (Android):
  - join: 26-10-2020
  - effective: ~~02-11-2020~~ 27-10-2020
- Ganen (Android):
  - join: 26-10-2020
  - effective: ~~02-11-2020~~ 27-10-2020
- Hafidh (Android):
  - join: 26-10-2020
  - effective: ~~02-11-2020~~ 27-10-2020
- Albert (Web):
  - join: 26-10-2020
  - effective: ~~02-11-2020~~ 27-10-2020
- Yoga (Web):
  - join: 02-11-2020
  - effective: ~~09-11-2020~~ 16-11-2020
### acquire
- dimas (Be)
- vijay (Be)
- nantha (Be)
- tharun (Be)
- faris  (Be)
- Lukas (android)
- Adri (android)
- Ahmad (Web)
- Febri (Web)
- Akhil (web)
### issuer
- jithin (Be)
- dwi (Be)
- zulkan (Be)
- nisar (Be)
- ~~amit (Be)~~ viknesh (Be)
- robai (Be)
- Jeffry (Android)
- Hafidh (Android)
- Ganen (Android)
- Yoga (Web)
- Albert (Web)
- Akbar (Web)
### Dimiiland-Platform
- Akhil (Web)
- Akbar (Web)
- Yoga (Web)
### QA will be parallel
- Tengku
- Gavril
- Gunar
- Ratih Andini
- Melinda
- Iwan
- Dina

### Need confirmation Join
- Devina (QA):

---

|Feature|Epic|
|---|---|
|account linkage|account linkage ([DIMII-248](https://capitalx.atlassian.net/browse/DIMII-248))|
|payment at partner|payment at partner ([DIMII-148](https://capitalx.atlassian.net/browse/DIMII-148))|
|manual transaction posting Topup & Refund|manual transaction posting - purchase complaint ([DIMII-1229](https://capitalx.atlassian.net/browse/DIMII-1229))|
| |manual transaction posting - top up ([DIMII-1230](https://capitalx.atlassian.net/browse/DIMII-1230))|
|manual transaction posting Payroll|manual transaction posting - payroll ([DIMII-1231](https://capitalx.atlassian.net/browse/DIMII-1231))|
|topup report|Dimii Reports ([DIMII-622](https://capitalx.atlassian.net/browse/DIMII-622))|
|role mgmt|DimiiLand - Manage Role ([DIMII-705](https://capitalx.atlassian.net/browse/DIMII-705))|
|user mgmt|DimiiLand - Manage Users ([DIMII-711](https://capitalx.atlassian.net/browse/DIMII-711))|
|kyc|Account Verification (KYC) ([DIMII-820](https://capitalx.atlassian.net/browse/DIMII-820))|
| |Account Verification Approval ([DIMII-1217](https://capitalx.atlassian.net/browse/DIMII-1217))|
|dimiiland login|DimiiLand - Login ([DIMII-723](https://capitalx.atlassian.net/browse/DIMII-723))|
|p2p|P2P Transfer ([DIMII-683](https://capitalx.atlassian.net/browse/DIMII-683))|
|change phone|-|
|ibft|Interbank Transfer ([DIMII-1182](https://capitalx.atlassian.net/browse/DIMII-1182))|
|change passcode|-|
|manual block&unblock|-|
|topup via bank|Top Up - CIMB ([DIMII-1415](https://capitalx.atlassian.net/browse/DIMII-1415))|
