package grpc

import (
	"context"
	"github.com/dgrijalva/jwt-go"
	"google.golang.org/grpc/metadata"
	"log"
	"strings"
)

const (
	bearer string = "bearer"
)

func extractTokenFromAuthHeader(val string) (token string, ok bool) {
	authHeaderParts := strings.Split(val, " ")
	if len(authHeaderParts) != 2 || !strings.EqualFold(authHeaderParts[0], bearer) {
		return "", false
	}

	return authHeaderParts[1], true
}

func extractUserInfo(ctx context.Context) context.Context {
	md, ok := metadata.FromIncomingContext(ctx)
	if !ok {
		return ctx
	}

	authHeader, ok := md["authorization"]
	if !ok {
		return ctx
	}

	token, ok := extractTokenFromAuthHeader(authHeader[0])
	if ok {
		parser := jwt.Parser{}
		claims := jwt.MapClaims{}
		_, _, err := parser.ParseUnverified(token, claims)
		if err != nil {
			log.Println(err)
			return ctx
		}
		mobile, ok := claims["mobile"]
		if ok {
			ctx = context.WithValue(ctx, "mobile", mobile)
		}
		userID, ok := claims["user_id"]
		if ok {
			ctx = context.WithValue(ctx, "user_id", userID)
		}
	}

	return ctx
}