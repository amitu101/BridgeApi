package grpc

import (
	"context"
	svcerr "git.capitalx.id/example/common/error"
	"git.capitalx.id/example/common/tls"
	middleware "github.com/grpc-ecosystem/go-grpc-middleware"
	recovery "github.com/grpc-ecosystem/go-grpc-middleware/recovery"
	validator "github.com/grpc-ecosystem/go-grpc-middleware/validator"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/credentials"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"
)

// UnaryErrorInterceptor returns a new unary server interceptor that added error detail for service error.
func UnaryErrorInterceptor() grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
		resp, err := handler(ctx, req)
		if err != nil {
			switch err.(type) {
			case svcerr.ServiceError:
				serviceError := err.(svcerr.ServiceError)
				grpcError := status.New(serviceError.Status, serviceError.Message)
				data := make(map[string]string)
				data["error_code"] = serviceError.Code
				data["error_message"] = serviceError.Message
				if len(serviceError.Attributes) > 0 {
					for k, v := range serviceError.Attributes {
						data[k] = v
					}
				}
				md := metadata.New(data)
				grpc.SetTrailer(ctx, md)

				return nil, grpcError.Err()
			default:
				return nil, err
			}
		}

		return resp, nil
	}
}

// StreamErrorInterceptor returns a new streaming server interceptor that added error detail for service error.
func StreamErrorInterceptor() grpc.StreamServerInterceptor {
	return func(srv interface{}, stream grpc.ServerStream, info *grpc.StreamServerInfo, handler grpc.StreamHandler) error {
		err := handler(srv, stream)
		if err != nil {
			switch err.(type) {
			case svcerr.ServiceError:
				serviceError := err.(svcerr.ServiceError)
				pbError := Error{
					Code:       serviceError.Code,
					Message:    serviceError.Message,
					Attributes: serviceError.Attributes,
				}
				grpcError := status.New(serviceError.Status, serviceError.Message)
				grpcError.WithDetails(&pbError)
				return grpcError.Err()
			default:
				return err
			}
		}

		return nil
	}
}

// UnaryAuthInterceptor returns a new unary server interceptor that extract user info from token.
func UnaryAuthInterceptor() grpc.UnaryServerInterceptor {
	return func(ctx context.Context, req interface{}, info *grpc.UnaryServerInfo, handler grpc.UnaryHandler) (interface{}, error) {
		ctx = extractUserInfo(ctx)
		return handler(ctx, req)
	}
}

func recoveryInterceptor() (grpc.UnaryServerInterceptor, grpc.StreamServerInterceptor) {
	handler := func(p interface{}) (err error) {
		log.Print("panic", p)
		return status.Error(codes.Internal, "server panic")
	}

	opts := []recovery.Option{
		recovery.WithRecoveryHandler(handler),
	}

	return recovery.UnaryServerInterceptor(opts...), recovery.StreamServerInterceptor(opts...)
}

//WithRecovery return gRPC server options with recovery handler
func WithRecovery() []grpc.ServerOption {
	unary, stream := recoveryInterceptor()
	serverOptions := []grpc.ServerOption{
		middleware.WithUnaryServerChain(
			unary,
		),
		middleware.WithStreamServerChain(
			stream,
		)}
	return serverOptions
}

//WithValidation returns gRPC server options with request validator
func WithValidation() []grpc.ServerOption {
	serverOptions := []grpc.ServerOption{
		middleware.WithUnaryServerChain(
			validator.UnaryServerInterceptor(),
		),
		middleware.WithStreamServerChain(
			validator.StreamServerInterceptor(),
		)}
	return serverOptions
}

//WithErrorDetails returns gRPC server options with request validator
func WithErrorDetails() []grpc.ServerOption {
	serverOptions := []grpc.ServerOption{
		middleware.WithUnaryServerChain(
			UnaryErrorInterceptor(),
		),
		middleware.WithStreamServerChain(
			StreamErrorInterceptor(),
		)}
	return serverOptions
}

//WithSecure returns gRPC server option with SSL credentials
func WithSecure(ca, cert, key []byte, mutual bool) grpc.ServerOption {
	tlsCfg := tls.WithCertificate(ca, cert, key, mutual)
	return grpc.Creds(credentials.NewTLS(tlsCfg))
}

//DefaultServerOptions returns default gRPC server option with validation and recovery
func WithDefault() []grpc.ServerOption {
	unaryRecovery, streamRecovery := recoveryInterceptor()
	serverOptions := []grpc.ServerOption{
		middleware.WithUnaryServerChain(
			validator.UnaryServerInterceptor(),
			UnaryAuthInterceptor(),
			unaryRecovery,
			UnaryErrorInterceptor(),
		),
		middleware.WithStreamServerChain(
			validator.StreamServerInterceptor(),
			streamRecovery,
			StreamErrorInterceptor(),
		)}
	return serverOptions
}

//Serve listen for client request
func Serve(address string, server *grpc.Server) {

	lis, err := net.Listen("tcp", address)
	if err != nil {
		log.Print(err)
		return
	}

	c := make(chan os.Signal, 1)
	signal.Notify(c, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGHUP)
	go func() {
		<-c
		log.Println("Shutting down server gracefully...")
		server.GracefulStop()
	}()

	err = server.Serve(lis)
	if err != nil {
		log.Print(err)
		return
	}
}
