package common

const (
	//success
	CustomerAccSuccess = 100

	//Failure
	CustomerNotFound        = 200
	CustomerSavingsNotFound = 201

	//server error
	InternalError = 500
)

func GetMessage(id uint32) string {
	keyValueMap := map[uint32]string{
		CustomerAccSuccess:      "Successfully get customer money information",
		CustomerNotFound:        "Customer not found",
		CustomerSavingsNotFound: "No savings accounts found",
		InternalError:           "Internal server error"}
	return keyValueMap[id]
}
