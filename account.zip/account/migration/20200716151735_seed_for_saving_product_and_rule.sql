-- +goose Up
-- SQL in this section is executed when the migration is applied.
INSERT INTO saving_product (id,description,is_allow_overdraft,is_calculate_total_monthly_cash_in,is_calculate_pending_cash_in,is_calculate_pending_cash_out,created_timestamp,updated_timestamp) VALUES 
(1,'E-Money Account',0,1,1,1,'2020-06-21 12:15:22.000',NULL),
(2,'Partner Non Deposit Topup Account',1,0,0,1,'2020-06-21 12:17:27.000',NULL);

INSERT INTO saving_product_rule (saving_product_id,code,value,created_by,created_timestamp,updated_by,updated_timestamp) VALUES 
(1,'kyc[1].max_balance',2000000,0,'2020-06-21 12:24:55.000',NULL,NULL),
(1,'kyc[2].max_balance',10000000,0,'2020-06-21 12:25:24.000',NULL,NULL),
(1,'max_monthly_funds_in',20000000,0,'2020-06-21 12:25:57.000',NULL,NULL),
(1,'min_topup_amount',10000,0,'2020-06-21 12:18:52.000',NULL,NULL);

UPDATE saving_account SET fund_in_end_period = LAST_DAY(CURRENT_TIMESTAMP) WHERE fund_in_end_period IS NULL;
-- if the table already created without default value (this doesnt have a problem if executed multiple times)
ALTER TABLE saving_account ALTER fund_in_end_period SET DEFAULT LAST_DAY(CURRENT_TIMESTAMP);

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DELETE FROM saving_product WHERE id = 1;
DELETE FROM saving_product WHERE id = 2;
DELETE FROM saving_product_rule WHERE saving_product_id = 1;