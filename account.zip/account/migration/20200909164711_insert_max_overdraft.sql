-- +goose Up
-- SQL in this section is executed when the migration is applied.
INSERT INTO saving_product_rule
(saving_product_id, code, value, created_by, created_timestamp, updated_by, updated_timestamp)
VALUES(2, 'max_overdraft', -1000000000, 0, CURRENT_TIMESTAMP(), 0, CURRENT_TIMESTAMP());
-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DELETE FROM saving_product_rule WHERE `saving_product_id` = 2 AND `code` = 'max_overdraft';
