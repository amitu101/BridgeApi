<h1>Account Service</h1>

Project structure

```
git.capitalx.id/dimii/account
├── client
│   └── main.go
├── config
│   └── env
│       └── config.go
├── delivery
│   ├── saving_account.pb.go
│   └── handler.go
├── migration
│   └── saving_account.sql
├── model
│   ├── saving_account.go
│   └── errors.go
├── repository
│   ├── maria_saving_account.go
│   └── repository.go
├── service
│   └── service.go
├── config.json
├── Dockerfile
├── sonar-project.properties
├── go.mod
├── go.sum
├── main.go
├── Makefile
└── README.md
```