package model

import "time"

const (
	StatusInProgress        = 1
	StatusCompleted         = 2
	StatusFailed            = 3
	InsufficientBalance     = "0001"
	NominalNotValid         = "0006"
	ExceedsMaximumBalance   = "0015"
	MonthlyMaxExceedsAmount = "2025"
	InternalSystemError     = "0500"
	SuccessCode             = "0200"
)

//SavingAccountAmountAuthorization corresponds to the saving_account_amount_authorization table
//holds the transaction info of Dimii and alfamart accounts
type SavingAccountAmountAuthorization struct {
	TransactionID   uint64
	FundInAmount    float64
	FundOutAmount   float64
	Status          uint8
	SavingAccountID uint64
	CreatedInfo     CreatedInfo
}

//CreatedInfo holds the basic created infologs
type CreatedInfo struct {
	CreatedBy        uint64
	CreatedTimestamp time.Time
	UpdatedBy        uint64
	UpdatedTimestamp time.Time
}

//SavingProductRule holds the set of rules
//where the key is code and value is the amount allowed
type SavingProductRule map[string]float64

type Customer struct {
	Id       uint64
	FullName string
	MobileNo string
	Type     uint8
	KycLevel uint8
}

type ValidateTransferRequest struct {
	FromAccProduct uint32
	FromCustomerId uint64
	FromCusCardNo  string
	ToAccProduct   uint32
	ToCustomerId   uint64
	ToCusCardNo    string
	Amount         float64
}

type AuthTransactionRequest struct {
	ValidateTransferRequest
	TransactionId uint64
}

type Response struct {
	Code        string
	Description string
}

type ValidationResponse Response
type AuthResponse authFundTransferAmountResponse

type authFundTransferAmountResponse struct {
	Code              string
	Description       string
	FromSavingAccount SavingAccountResponse
	ToSavingAccount   SavingAccountResponse
}

type TransactionResponse struct {
	Code              string
	Description       string
	FromSavingAccount SavingAccountResponse
	ToSavingAccount   SavingAccountResponse
}
