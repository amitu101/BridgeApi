package model

import (
	"time"

	"github.com/dgrijalva/jwt-go"
)

// SavingAccount is account data type
type SavingAccount struct {
	ID                 uint64
	CardNo             string
	CustomerID         uint64
	SavingProductID    uint32
	Balance            float64
	TotalMonthlyFundIn float64
	FundInEndPeriod    *time.Time
	PendingFundIn      float64
	PendingFundOut     float64
	Status             int64
	CreatedBy          uint64
	CreatedTimestamp   time.Time
	UpdatedBy          uint64
	UpdatedTimestamp   time.Time
	IsDefaultAccount   int64
}

type SavingAccountResponse struct {
	ID               uint64
	CardNo           string
	CustomerID       uint64
	SavingProductID  uint32
	Balance          float64
	Status           int64
	AvailableBalance float64
	MaxBalance       float64
	MaxMonthlyTopup  float64
	MaxTopup         float64
}

type SavingAccountRequest struct {
	CustomerID      uint64
	CardNo          string
	ID              uint64
	SavingProductID uint32
}

type SavingProduct struct {
	ID                            uint32
	Description                   string
	IsAllowOverdraft              uint32
	IsCalCulateTotalMonthlyCashIn uint32
	IsCalculatePendingCashIn      uint32
	IsCalculatePendingCashOut     uint32
}

type SavingAccountProduct struct {
	SavingAccount
	IsAllowOverdraft uint32
}

type SavingAccountWithType struct {
	SavingAccount
	Type string
}

type SavingAccountCustomerRequest struct {
	CustomerID uint64
	CardNo     string
}

type ListSavingAccountsReponse struct {
	List []*SavingAccount
}

type TokenClaims struct {
	Name        string `json:"name"`
	PhoneNumber string `json:"phone_number"`
	Username    string `json:"username"`
	jwt.StandardClaims
}

type BankMasterData struct {
	BankName string `json:"bank_name"`
	BankCode string `json:"bank_code"`
	Initial  string `json:"initial"`
}

type BankMasterDataResponse struct {
	Data   []*BankMasterData `json:"data"`
	Length uint32            `json:"length"`
}
