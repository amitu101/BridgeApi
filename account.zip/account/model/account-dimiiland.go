package model

// CustomerAccountResponse customer account response
type CustomerAccountResponse struct {
	ID                  string  `json:"id"`
	CardNo              string  `json:"card_no"`
	CustomerID          string  `json:"customer_id"`
	SavingProductID     uint32  `json:"saving_product_id"`
	Balance             float64 `json:"balance"`
	TotalMonthlyFundIn  float64 `json:"total_monthly_fund_in"`
	PendingFundIn       float64 `json:"pending_fund_in"`
	PendingFundOut      float64 `json:"pending_fund_up"`
	Status              int64   `json:"status"`
	MaximumMonthlyTopUp float64 `json:"maximum_monthly_topup"`
}
