package model

import "errors"

var (
	// ErrInternalServerError will throw if any the Internal Server Error happen
	ErrInternalServerError = errors.New("internal Server Error")
	// ErrNotFound will throw if the requested item is not exists
	ErrNotFound = errors.New("your requested Item is not found")
	// ErrConflict will throw if the current action already exists
	ErrConflict = errors.New("your Item already exist")
	// ErrBadParamInput will throw if the given request-body or params is not valid
	ErrBadParamInput = errors.New("given Param is not valid")
	// ErrCanNotUpdate will throw if the given request-body or params is can not be updated
	ErrCanNotUpdate = errors.New("your request can not be updated")
	// ErrNotAuthorized will throw if the user not authorized
	ErrNotAuthorized = errors.New("you are not authorized")
	// ErrMobileNumberBlocked will throw if the user blocked
	ErrMobileNumberBlocked = errors.New("this mobile number already blocked")

	//ErrInsufficientBalance will thorw if from acc balance is less than the requested amount
	ErrInsufficientBalance = errors.New("insufficient balance")
)
