package main

import (
	"context"
	"net/http"

	"git.capitalx.id/dimii/account/utils"

	"github.com/grpc-ecosystem/grpc-gateway/runtime"

	commonHttp "git.capitalx.id/core/common/http"
	core_config "git.capitalx.id/core/config"
	vault_cfg "git.capitalx.id/core/config/vault"
	viper_cfg "git.capitalx.id/core/config/viper"
	"git.capitalx.id/core/id/client"
	customerClient "git.capitalx.id/dimii/customer/client"

	"encoding/json"

	common "git.capitalx.id/core/common/grpc"
	restHandler "git.capitalx.id/dimii/account/common"
	deliveryGrpc "git.capitalx.id/dimii/account/delivery"
	HandlerHTTP "git.capitalx.id/dimii/account/delivery/http"
	deliverProto "git.capitalx.id/dimii/account/proto"
	accountRepo "git.capitalx.id/dimii/account/repository"
	accountSrv "git.capitalx.id/dimii/account/service"

	"log"
	"os"
	"os/signal"
	"syscall"

	_ "git.capitalx.id/dimii/account/client"

	"git.capitalx.id/core/common/mysql"
	bookkeeperClient "git.capitalx.id/dimii/bookkeeper/client"
	"google.golang.org/grpc"
	grpcStatus "google.golang.org/grpc/status"
)

func init() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	os.Setenv("GRPC_GO_RETRY", "on")
}

type Error struct {
	Errors map[string]interface{} `json:"errors"`
}

func getConfig() (core_config.Config, error) {
	address := os.Getenv("VAULT_ADDR")
	token := os.Getenv("VAULT_TOKEN")

	if address != "" && token != "" {
		config, err := vault_cfg.GetConfig("account")

		if err == nil {
			return config, nil
		} else {
			return nil, err
		}
	}
	return viper_cfg.NewConfig("account", "config.json")
}

func serveHTTP(addr string, ac accountSrv.AccountInternalService) {
	mux := http.DefaultServeMux
	HandlerHTTP.NewAccountInternalHandler(mux, ac)
	log.Println("http server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(http.HandlerFunc(restHandler.Serve))); err != nil {
		log.Println(err)
	}
}

func main() {
	config, err := getConfig()
	if err != nil {
		log.Println(err)
		return
	}

	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	dbConn, err := mysql.DB(dbConfig)
	if err != nil {
		log.Println(err)
		return
	}
	defer func() {
		if err := dbConn.Close(); err != nil {
			log.Print(err)
		}
	}()

	//Connection to customer service
	customerServiceAddr := config.GetString("server.customer_service_address")
	cusClient, errC := customerClient.NewCustomerClient(customerServiceAddr)
	if errC != nil {
		log.Printf("error: connection to customer service - %s", errC.Error())
	}

	//Connection to bookkeeper service
	bookkeeperServiceAddr := config.GetString("server.bookkeeper_service_address")
	bookClient, errB := bookkeeperClient.NewCustomerAccountClient(bookkeeperServiceAddr)

	if errB != nil {
		log.Printf("error: connection to bookkeeper service - %s", errB.Error())
	}

	idGeneratorAddr := config.GetString(`server.id_generator`)
	idClient, err := client.NewSequenceClient(idGeneratorAddr)
	utils.PrintErrorNotNil(err)

	ar := accountRepo.NewMariaAccountRepository(dbConn)
	au := accountSrv.NewAccountService(ar, bookClient, idClient, cusClient)

	//account-transaction service initialization
	as := accountSrv.NewAccountTransactionService(ar, cusClient)

	//account-internal service initialization
	ias := accountSrv.NewAccountInternalService(ar, cusClient)

	// start grpc
	pbServer := grpc.NewServer(common.WithDefault()...)
	deliveryGrpc.NewAccountServerGrpc(pbServer, au, as, bookClient)

	addrGrpc := config.GetString("server.address")
	addrGw := config.GetString("server.address.gw")
	addrHTTP := config.GetString("server.address.http")

	// grpc
	errHdlr := common.WithDefault()
	server := grpc.NewServer(errHdlr...)
	deliveryGrpc.NewAccountServerGrpc(server, au, as, bookClient)

	go func() {
		common.Serve(addrGrpc, server)
	}()

	// Graceful shut down of server
	graceful := make(chan os.Signal)
	signal.Notify(graceful, syscall.SIGINT)
	signal.Notify(graceful, syscall.SIGTERM)
	go func() {
		<-graceful
		log.Println("Shutting down server gracefully...")
		pbServer.GracefulStop()
	}()

	go serveHTTP(addrHTTP, ias)
	go serveHTTPGRPC(addrGw, addrGrpc)
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGINT, syscall.SIGTERM)

	<-done
	//l.Close()
	log.Println("All server stopped!")
	//}()

}
func serveHTTPGRPC(addr, addrGrpc string) {
	log.Println("ini addrGrpc: ", addrGrpc)
	ctx := context.Background()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()

	// Set runtime.GlobalHTTPErrorHandler = CustomHTTPError
	runtime.GlobalHTTPErrorHandler = CustomHTTPError

	mux := runtime.NewServeMux()
	opts := []grpc.DialOption{grpc.WithInsecure()}
	err := deliverProto.RegisterAccountManagementHandlerHandlerFromEndpoint(ctx, mux, addrGrpc, opts)
	if err != nil {
		log.Println("err in serveHTTPGrpc: ", err)
	}

	log.Println("gw server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(mux)); err != nil {
		log.Println(err)
	}
}
func CustomHTTPError(ctx context.Context, _ *runtime.ServeMux, marshaler runtime.Marshaler, w http.ResponseWriter, _ *http.Request, err error) {
	const fallback = `{"error": "failed to marshal error message"}`

	sm, _ := runtime.ServerMetadataFromContext(ctx)
	e := Error{}
	attr := make(map[string]interface{})
	e.Errors = make(map[string]interface{})

	// extract trailer metadata
	for k, vs := range sm.TrailerMD {
		for _, v := range vs {
			switch k {
			case "error_code":
				e.Errors["error_code"] = v
			case "error_message":
				e.Errors["error_message"] = v
			case "content-type":

			default:
				attr[k] = v
			}
		}
	}

	e.Errors["attributes"] = attr

	w.Header().Set("Content-type", marshaler.ContentType())
	w.WriteHeader(runtime.HTTPStatusFromCode(grpcStatus.Code(err)))

	jErr := json.NewEncoder(w).Encode(e.Errors)

	if jErr != nil {
		_, err := w.Write([]byte(fallback))
		utils.PrintErrorNotNil(err)
	}
}
