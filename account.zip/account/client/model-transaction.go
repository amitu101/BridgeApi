package client

type ValidationFundReq struct {
	FromAccountProduct uint32
	FromCustomerId     uint64
	FromCardNo         string
	ToAccountProduct   uint32
	ToCustomerId       uint64
	ToCardNo           string
	Amount             float64
}

type AccTransResponse struct {
	Code        string
	Description string
}

type BasicResponse struct {
	Code        string
	Description string
}

type AuthorizeFundTransferAmountReq struct {
	FromAccountProduct uint32
	FromCustomerId     uint64
	FromCardNo         string
	ToAccountProduct   uint32
	ToCustomerId       uint64
	ToCardNo           string
	Amount             float64
	TransactionId      uint64
}

//deprecated to use new naming
type AuthFundTransferResponse struct {
	Code              string
	Description       string
	FromSavingAccount *GetSavingAccountResponse
	ToSavingAccount   *GetSavingAccountResponse
}

type TransactionResponse struct {
	Code              string
	Description       string
	FromSavingAccount *GetSavingAccountResponse
	ToSavingAccount   *GetSavingAccountResponse
}
