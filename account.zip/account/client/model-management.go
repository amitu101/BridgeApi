package client

import "time"

type SavingAccount struct {
	ID                 uint64
	CardNo             string
	CustomerID         uint64
	SavingProductID    uint32
	Balance            float64
	TotalMonthlyFundIn float64
	FundInEndPeriod    *time.Time
	PendingFundIn      float64
	PendingFundOut     float64
	Status             int64
}

type GetSavingAccountRequest struct {
	Id              uint64
	CardNo          string
	CustomerId      uint64
	SavingProductId uint32
}

type GetSavingAccountResponse struct {
	Id               uint64
	CardNo           string
	CustomerId       uint64
	SavingProductId  uint32
	Balance          float64
	Status           int64
	AvailableBalance float64
	MaxBalance       float64
	MaxMonthlyTopup  float64
	MaxTopup         float64
}

type GetSavingProductResponse struct {
	Id                            uint32
	Description                   string
	IsAllowOverdraft              uint32
	IsCalCulateTotalMonthlyCashIn uint32
	IsCalculatePendingCashIn      uint32
	IsCalculatePendingCashOut     uint32
}

type GetSavingAccountCustomerRequest struct {
	CustomerID uint64
	CardNo     string
}
type GetListSavingAccountsReponse struct {
	List []*SavingAccount
}
