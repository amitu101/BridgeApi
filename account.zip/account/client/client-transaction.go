package client

import (
	"context"

	"git.capitalx.id/dimii/account/proto"
)

type AccountTransactionClient interface {
	ValidateFundTransferAmount(ctx context.Context, request *ValidationFundReq) (*AccTransResponse, error)
	AuthorizeFundTransferAmount(ctx context.Context, request *AuthorizeFundTransferAmountReq) (*AuthFundTransferResponse, error)
	CommitFundTransferAmount(ctx context.Context, transactionID string) (*AuthFundTransferResponse, error)
	InsertFundTransfer(ctx context.Context, request *AuthorizeFundTransferAmountReq) (*AuthFundTransferResponse, error)
	RollbackTransaction(ctx context.Context, transactionId uint64, rollbackType uint8) (*TransactionResponse, error)
}

func (a accountTransactionCli) ValidateFundTransferAmount(ctx context.Context, request *ValidationFundReq) (*AccTransResponse, error) {
	accTransRes, err := a.client.ValidateFundTransferAmount(ctx, &proto.ValidationFundReq{
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCardNo:         request.FromCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCardNo:           request.ToCardNo,
		Amount:             request.Amount,
	})
	if err != nil {
		return nil, err
	}

	return &AccTransResponse{
		Code:        accTransRes.Code,
		Description: accTransRes.Description,
	}, nil

}

func (a accountTransactionCli) convertTransactionResponse(response *proto.TransactionResponse) *TransactionResponse {
	return &TransactionResponse{
		Code:        response.Code,
		Description: response.Description,
		FromSavingAccount: &GetSavingAccountResponse{
			Id:              response.FromSavingAccount.Id,
			CardNo:          response.FromSavingAccount.CardNo,
			CustomerId:      response.FromSavingAccount.CustomerId,
			SavingProductId: response.FromSavingAccount.SavingProductId,
			Balance:         response.FromSavingAccount.Balance,
			Status:          response.FromSavingAccount.Status,
		},
		ToSavingAccount: &GetSavingAccountResponse{
			Id:              response.ToSavingAccount.Id,
			CardNo:          response.ToSavingAccount.CardNo,
			CustomerId:      response.ToSavingAccount.CustomerId,
			SavingProductId: response.ToSavingAccount.SavingProductId,
			Balance:         response.ToSavingAccount.Balance,
			Status:          response.ToSavingAccount.Status,
		},
	}
}

func (a accountTransactionCli) convertAuthFundTransferResponse(response *proto.AuthFundTransferResponse) *AuthFundTransferResponse {
	return &AuthFundTransferResponse{
		Code:        response.Code,
		Description: response.Description,
		FromSavingAccount: &GetSavingAccountResponse{
			Id:              response.FromSavingAccount.Id,
			CardNo:          response.FromSavingAccount.CardNo,
			CustomerId:      response.FromSavingAccount.CustomerId,
			SavingProductId: response.FromSavingAccount.SavingProductId,
			Balance:         response.FromSavingAccount.Balance,
			Status:          response.FromSavingAccount.Status,
		},
		ToSavingAccount: &GetSavingAccountResponse{
			Id:              response.ToSavingAccount.Id,
			CardNo:          response.ToSavingAccount.CardNo,
			CustomerId:      response.ToSavingAccount.CustomerId,
			SavingProductId: response.ToSavingAccount.SavingProductId,
			Balance:         response.ToSavingAccount.Balance,
			Status:          response.ToSavingAccount.Status,
		},
	}
}

func (a accountTransactionCli) AuthorizeFundTransferAmount(ctx context.Context, request *AuthorizeFundTransferAmountReq) (*AuthFundTransferResponse, error) {

	response, err := a.client.AuthorizeFundTransferAmount(ctx, &proto.AuthorizeFundTransferAmountReq{
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCardNo:         request.FromCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCardNo:           request.ToCardNo,
		Amount:             request.Amount,
		TransactionId:      request.TransactionId,
	})
	if err != nil {
		return nil, err
	}

	return a.convertAuthFundTransferResponse(response), nil
}

func (a accountTransactionCli) CommitFundTransferAmount(ctx context.Context, transactionID string) (*AuthFundTransferResponse, error) {

	response, err := a.client.CommitFundTransferAmount(ctx, &proto.CommitFundTransferAmountReq{
		TransactionId: transactionID,
	})
	if err != nil {
		return nil, err
	}

	return a.convertAuthFundTransferResponse(response), nil
}

func (a accountTransactionCli) InsertFundTransfer(ctx context.Context, request *AuthorizeFundTransferAmountReq) (*AuthFundTransferResponse, error) {
	response, err := a.client.InsertFundTransfer(ctx, &proto.AuthorizeFundTransferAmountReq{
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCardNo:         request.FromCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCardNo:           request.ToCardNo,
		Amount:             request.Amount,
		TransactionId:      request.TransactionId,
	})
	if err != nil {
		return nil, err
	}

	return a.convertAuthFundTransferResponse(response), nil
}

func (a accountTransactionCli) RollbackTransaction(ctx context.Context, transactionId uint64, rollbackType uint8) (*TransactionResponse, error) {
	response, err := a.client.RollbackTransaction(ctx, &proto.RollbackTransactionRequest{
		TransactionId: transactionId,
		RollbackType:  uint32(rollbackType),
	})
	if err != nil {
		return nil, err
	}

	return a.convertTransactionResponse(response), nil
}
