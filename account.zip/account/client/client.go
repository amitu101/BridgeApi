package client

import (
	"google.golang.org/grpc"

	"git.capitalx.id/dimii/account/proto"
)

type accountClient struct {
	conn   *grpc.ClientConn
	client clientAll
}

type clientAll struct {
	clientMgmt  proto.AccountManagementHandlerClient
	clientTrans proto.AccountTransactionHandlerClient
}

func NewAccountClient(address string) (AccountClient, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	client := clientAll{
		clientMgmt:  proto.NewAccountManagementHandlerClient(conn),
		clientTrans: proto.NewAccountTransactionHandlerClient(conn),
	}

	return &accountClient{conn: conn, client: client}, nil
}

type accountTransactionCli struct {
	conn   *grpc.ClientConn
	client proto.AccountTransactionHandlerClient
}

func NewAccountTransactionClient(address string) (AccountTransactionClient, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	client := proto.NewAccountTransactionHandlerClient(conn)

	return &accountTransactionCli{conn: conn, client: client}, nil
}
