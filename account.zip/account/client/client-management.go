package client

import (
	"context"
	"log"

	"git.capitalx.id/dimii/account/proto"
)

type AccountClient interface {
	StoreSavingAccount(ctx context.Context, customerID, createdBy uint64, savingProductID uint32, mobileNumber, fullName string) (uint64, error)
	GetSavingAccount(ctx context.Context, req *GetSavingAccountRequest) (*GetSavingAccountResponse, error)
	GetSavingProduct(ctx context.Context, req uint32) (*GetSavingProductResponse, error)
	GetCustomerSavingAccount(ctx context.Context, a *GetSavingAccountCustomerRequest) (*GetListSavingAccountsReponse, error)
}

func (c *accountClient) StoreSavingAccount(ctx context.Context, customerID, createdBy uint64, savingProductID uint32, mobileNumber, fullName string) (uint64, error) {
	resp, err := c.client.clientMgmt.StoreSavingAccount(ctx, &proto.StoreSavingAccountDataRequest{
		Customerid:      customerID,
		Createdby:       createdBy,
		Savingproductid: savingProductID,
		Mobilenumber:    mobileNumber,
		Fullname:        fullName,
	})

	if err != nil {
		return 0, err
	}

	return resp.Id, nil
}

func (c *accountClient) GetSavingAccount(ctx context.Context, req *GetSavingAccountRequest) (*GetSavingAccountResponse, error) {
	resp, err := c.client.clientMgmt.GetSavingAccount(ctx, &proto.GetSavingAccountRequest{
		Id:              req.Id,
		CardNo:          req.CardNo,
		CustomerId:      req.CustomerId,
		SavingProductId: req.SavingProductId,
	})

	if err != nil {
		return nil, err
	}

	savingAccountResp := &GetSavingAccountResponse{
		Id:               resp.Id,
		CardNo:           resp.CardNo,
		CustomerId:       resp.CustomerId,
		SavingProductId:  resp.SavingProductId,
		Balance:          resp.Balance,
		Status:           resp.Status,
		AvailableBalance: resp.AvailableBalance,
		MaxBalance:       resp.MaxBalance,
		MaxMonthlyTopup:  resp.MaxMonthlyTopup,
		MaxTopup:         resp.MaxTopup,
	}

	return savingAccountResp, nil
}

func (c *accountClient) GetSavingProduct(ctx context.Context, req uint32) (*GetSavingProductResponse, error) {
	resp, err := c.client.clientMgmt.GetSavingProduct(ctx, &proto.GetSavingProductRequest{
		SavingProductId: req,
	})

	if err != nil {
		return nil, err
	}

	savingProductResponse := &GetSavingProductResponse{
		Id:                            resp.Id,
		Description:                   resp.Description,
		IsAllowOverdraft:              resp.IsAllowOverdraft,
		IsCalCulateTotalMonthlyCashIn: resp.IsCalCulateTotalMonthlyCashIn,
		IsCalculatePendingCashIn:      resp.IsCalculatePendingCashIn,
		IsCalculatePendingCashOut:     resp.IsCalculatePendingCashOut,
	}

	return savingProductResponse, nil
}

func (c *accountClient) GetCustomerSavingAccount(ctx context.Context, req *GetSavingAccountCustomerRequest) (*GetListSavingAccountsReponse, error) {

	resp, err := c.client.clientMgmt.GetSavingAccountsCustomer(ctx, &proto.GetSavingAccountCustomerRequest{
		CardNo:     req.CardNo,
		CustomerId: req.CustomerID})

	if err != nil {
		log.Printf("[client: handler-management] Error when GetCustomerSavingAccount %s\n", err.Error())
		return nil, err
	}

	list := make([]*SavingAccount, 0)

	for _, sAccount := range resp.SavingAccountList {
		sa := new(SavingAccount)
		sa.ID = sAccount.Id
		sa.CardNo = sAccount.CardNo
		sa.CustomerID = sAccount.CustomerId
		sa.SavingProductID = sAccount.SavingProductId
		sa.Balance = sAccount.Balance
		sa.Status = sAccount.Status
		list = append(list, sa)
	}

	return &GetListSavingAccountsReponse{List: list}, nil
}
