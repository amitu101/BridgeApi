package delivery

import (
	"context"
	"errors"
	"fmt"
	"strconv"

	"git.capitalx.id/dimii/account/constant"
	"git.capitalx.id/dimii/account/model"
	"git.capitalx.id/dimii/account/proto"
)

func (ats *accTranscServer) convertResponse(response *model.AuthResponse) *proto.AuthFundTransferResponse {
	return &proto.AuthFundTransferResponse{
		Code:        response.Code,
		Description: response.Description,
		FromSavingAccount: &proto.GetSavingAccountResponse{
			Id:              response.FromSavingAccount.ID,
			CardNo:          response.FromSavingAccount.CardNo,
			CustomerId:      response.FromSavingAccount.CustomerID,
			SavingProductId: response.FromSavingAccount.SavingProductID,
			Balance:         response.FromSavingAccount.Balance,
			Status:          response.FromSavingAccount.Status,
		},
		ToSavingAccount: &proto.GetSavingAccountResponse{
			Id:              response.ToSavingAccount.ID,
			CustomerId:      response.ToSavingAccount.CustomerID,
			Balance:         response.ToSavingAccount.Balance,
			SavingProductId: response.ToSavingAccount.SavingProductID,
			CardNo:          response.ToSavingAccount.CardNo,
			Status:          response.ToSavingAccount.Status,
		},
	}
}

func (ats *accTranscServer) convertTransactionResponse(response *model.TransactionResponse) *proto.TransactionResponse {
	return &proto.TransactionResponse{
		Code:        response.Code,
		Description: response.Description,
		FromSavingAccount: &proto.GetSavingAccountResponse{
			Id:              response.FromSavingAccount.ID,
			CardNo:          response.FromSavingAccount.CardNo,
			CustomerId:      response.FromSavingAccount.CustomerID,
			SavingProductId: response.FromSavingAccount.SavingProductID,
			Balance:         response.FromSavingAccount.Balance,
			Status:          response.FromSavingAccount.Status,
		},
		ToSavingAccount: &proto.GetSavingAccountResponse{
			Id:              response.ToSavingAccount.ID,
			CustomerId:      response.ToSavingAccount.CustomerID,
			Balance:         response.ToSavingAccount.Balance,
			SavingProductId: response.ToSavingAccount.SavingProductID,
			CardNo:          response.ToSavingAccount.CardNo,
			Status:          response.ToSavingAccount.Status,
		},
	}
}

func (ats *accTranscServer) ValidateFundTransferAmount(ctx context.Context, vReq *proto.ValidationFundReq) (*proto.AccTransResponse, error) {
	validateTransferIns := &model.ValidateTransferRequest{
		FromAccProduct: vReq.FromAccountProduct,
		FromCustomerId: vReq.FromCustomerId,
		FromCusCardNo:  vReq.FromCardNo,
		ToAccProduct:   vReq.ToAccountProduct,
		ToCustomerId:   vReq.ToCustomerId,
		ToCusCardNo:    vReq.ToCardNo,
		Amount:         vReq.Amount,
	}

	resp, err := ats.tServ.ValidateFundTransferAmount(ctx, validateTransferIns)
	if err != nil {
		fmt.Printf("Error when validate transfer amount: %s\n", err.Error())
		return nil, err
	}

	return &proto.AccTransResponse{
		Code:        resp.Code,
		Description: resp.Description,
	}, nil
}
func (ats *accTranscServer) AuthorizeFundTransferAmount(ctx context.Context, aReq *proto.AuthorizeFundTransferAmountReq) (*proto.AuthFundTransferResponse, error) {

	authTransIns := &model.AuthTransactionRequest{
		ValidateTransferRequest: model.ValidateTransferRequest{
			FromAccProduct: aReq.FromAccountProduct,
			FromCustomerId: aReq.FromCustomerId,
			FromCusCardNo:  aReq.FromCardNo,
			ToAccProduct:   aReq.ToAccountProduct,
			ToCustomerId:   aReq.ToCustomerId,
			ToCusCardNo:    aReq.ToCardNo,
			Amount:         aReq.Amount,
		},
		TransactionId: aReq.TransactionId,
	}

	response, err := ats.tServ.AuthorizeFundTransferAmount(ctx, authTransIns)
	if err != nil {
		return nil, err
	}

	return ats.convertResponse(response), nil

}
func (ats *accTranscServer) CommitFundTransferAmount(ctx context.Context, cFtReq *proto.CommitFundTransferAmountReq) (*proto.AuthFundTransferResponse, error) {

	transactionId, _ := strconv.ParseUint(cFtReq.TransactionId, 10, 64)

	response, err := ats.tServ.CommitFundTransferAmount(ctx, transactionId)
	if err != nil {
		return nil, err
	}

	return ats.convertResponse(response), nil
}

func (ats *accTranscServer) InsertFundTransfer(ctx context.Context, aReq *proto.AuthorizeFundTransferAmountReq) (*proto.AuthFundTransferResponse, error) {
	authTransIns := &model.AuthTransactionRequest{
		ValidateTransferRequest: model.ValidateTransferRequest{
			FromAccProduct: aReq.FromAccountProduct,
			FromCustomerId: aReq.FromCustomerId,
			FromCusCardNo:  aReq.FromCardNo,
			ToAccProduct:   aReq.ToAccountProduct,
			ToCustomerId:   aReq.ToCustomerId,
			ToCusCardNo:    aReq.ToCardNo,
			Amount:         aReq.Amount,
		},
		TransactionId: aReq.TransactionId,
	}

	response, err := ats.tServ.InsertFundTransfer(ctx, authTransIns)
	if err != nil {
		return nil, err
	}

	return ats.convertResponse(response), nil
}

func (ats *accTranscServer) RollbackTransaction(ctx context.Context, req *proto.RollbackTransactionRequest) (*proto.TransactionResponse, error) {
	if req.RollbackType != constant.AuthRollbackType && req.RollbackType != constant.CommitRollbackType {
		return nil, errors.New("Wrong rollback type " + string(req.RollbackType))
	}
	response, err := ats.tServ.RollbackTransaction(ctx, req.TransactionId, uint8(req.RollbackType))

	var respFinal *proto.TransactionResponse

	if response != nil {
		respFinal = ats.convertTransactionResponse(response)
	}

	if err != nil {
		return respFinal, err
	}

	return respFinal, nil
}
