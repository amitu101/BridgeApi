package http

import (
	"encoding/json"
	"log"
	"net/http"
	"strconv"

	"git.capitalx.id/dimii/account/utils"

	"git.capitalx.id/dimii/account/common"
	AccountServ "git.capitalx.id/dimii/account/service"
)

// AccountInternalHandler  represent the http handler for account
type AccountInternalHandler struct {
	AccUsecase AccountServ.AccountInternalService
}

// NewAccountInternalHandler will initialize the account resources endpoint
func NewAccountInternalHandler(m *http.ServeMux, ac AccountServ.AccountInternalService) {
	handler := &AccountInternalHandler{
		AccUsecase: ac}
	common.Route(http.MethodGet, "/r/account/customer/([0-9]+)", handler.getCustomerMoneyInfo)

}

func httpResponseWrite(rw http.ResponseWriter, response interface{}, statusCode int) {
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	err := json.NewEncoder(rw).Encode(response)
	utils.PrintErrorNotNil(err)
}

func (handler *AccountInternalHandler) getCustomerMoneyInfo(rw http.ResponseWriter, req *http.Request) {
	customerID, err := strconv.ParseUint(common.Param(req, 0), 10, 64)
	if err != nil {
		log.Printf("[handler.http] Exception in converting customerID to integer  %s\n", err)
		response := &common.DataResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, http.StatusInternalServerError)
		return
	}
	result, err := handler.AccUsecase.GetCustomerMoneyInfo(customerID)

	switch e := err.(type) {
	case nil:
		httpResponseWrite(rw, result, http.StatusOK)
	case *common.AppError:
		if e.Code == common.CustomerNotFound || e.Code == common.CustomerSavingsNotFound {
			response := &common.DataResponse{Message: e.Message, Data: []int{}}
			httpResponseWrite(rw, response, http.StatusOK)
		} else {
			response := &common.DataResponse{Message: "Internal server error"}
			httpResponseWrite(rw, response, http.StatusInternalServerError)
		}
	default:
		response := &common.DataResponse{Message: "Internal server error"}
		httpResponseWrite(rw, response, http.StatusInternalServerError)
	}

}
