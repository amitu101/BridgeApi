package delivery

import (
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"

	"git.capitalx.id/dimii/account/proto"
	_srv "git.capitalx.id/dimii/account/service"
	_bookSrv "git.capitalx.id/dimii/bookkeeper/service"
)

func NewAccountServerGrpc(gserver *grpc.Server, accountSrv _srv.AccountService,
	accTranscSrv _srv.AccountTransactionService, bookkeeperSrv _bookSrv.Service) {
	accountServer := &server{
		service:           accountSrv,
		bookkeeperService: bookkeeperSrv,
	}

	accTransSer := &accTranscServer{
		tServ: accTranscSrv,
	}

	proto.RegisterAccountManagementHandlerServer(gserver, accountServer)
	proto.RegisterAccountTransactionHandlerServer(gserver, accTransSer)
	reflection.Register(gserver)
}

type server struct {
	service           _srv.AccountService
	bookkeeperService _bookSrv.Service
}

type accTranscServer struct {
	tServ _srv.AccountTransactionService
}
