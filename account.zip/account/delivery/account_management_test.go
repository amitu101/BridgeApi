package delivery

import (
	context "context"
	"encoding/json"
	"log"
	"net"
	"testing"

	idGenerator_mocks "git.capitalx.id/core/id/mocks/service"
	mocks "git.capitalx.id/dimii/account/mocks/service"
	models "git.capitalx.id/dimii/account/model"
	"git.capitalx.id/dimii/account/proto"
	bookkeeper_mocks "git.capitalx.id/dimii/bookkeeper/mocks/service"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	grpc "google.golang.org/grpc"
	"google.golang.org/grpc/test/bufconn"
)

const bufSize = 1024 * 1024

var lis *bufconn.Listener

var mockAccountService = &mocks.AccountService{}
var mockBookkeeperService = &bookkeeper_mocks.Service{}
var mockIdGeneratorService = &idGenerator_mocks.SequenceService{}

func init() {
	lis = bufconn.Listen(bufSize)
	s := grpc.NewServer()
	proto.RegisterAccountManagementHandlerServer(s, &server{mockAccountService, mockBookkeeperService})
	go func() {
		if err := s.Serve(lis); err != nil {
			log.Fatalf("Server exited with error: %v", err)
		}
	}()
}

func bufDialer(context.Context, string) (net.Conn, error) {
	return lis.Dial()
}

func TestGetSavingAccountHandler(t *testing.T) {

	grpcResponse := &proto.GetSavingAccountResponse{
		CustomerId:      1,
		Id:              1,
		CardNo:          "Hello",
		SavingProductId: 1,
		Balance:         0,
		Status:          1,
	}

	serviceResponse := &models.SavingAccountResponse{
		CustomerID:      1,
		ID:              1,
		CardNo:          "Hello",
		SavingProductID: 1,
		Balance:         0,
		Status:          1,
	}

	serviceRequest := &models.SavingAccountRequest{
		CustomerID:      1,
		CardNo:          "Hello",
		ID:              1,
		SavingProductID: 1,
	}

	ctx := context.Background()

	conn, err := grpc.DialContext(ctx, "bufnet", grpc.WithContextDialer(bufDialer), grpc.WithInsecure())
	if err != nil {
		t.Fatalf("Failed to dial bufnet: %v", err)
	}
	defer conn.Close()
	client := proto.NewAccountManagementHandlerClient(conn)

	mockAccountService.On("GetSavingAccount", mock.Anything, serviceRequest).Return(serviceResponse, nil)

	resp, err := client.GetSavingAccount(ctx, &proto.GetSavingAccountRequest{
		Id:              uint64(1),
		CustomerId:      uint64(1),
		CardNo:          "Hello",
		SavingProductId: uint32(1),
	})

	if err != nil {
		t.Fatalf("GetSavingAccount failed: %v", err)
	}

	respJson, _ := json.Marshal(resp)
	respJsonString := string(respJson)

	grpcResponseJson, _ := json.Marshal(grpcResponse)
	grpcResponseJsonString := string(grpcResponseJson)

	assert.Equal(t, respJsonString, grpcResponseJsonString)
}
