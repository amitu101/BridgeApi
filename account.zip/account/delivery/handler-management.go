package delivery

import (
	"context"
	"log"
	"strings"

	"github.com/dgrijalva/jwt-go"
	"google.golang.org/grpc/metadata"

	"git.capitalx.id/dimii/account/model"
	models "git.capitalx.id/dimii/account/model"
	"git.capitalx.id/dimii/account/proto"
)

func (s *server) StoreSavingAccount(ctx context.Context, request *proto.StoreSavingAccountDataRequest) (*proto.StoreSavingAccountResponse, error) {
	//acc := &models.SavingAccount{
	//	CustomerID: request.Customerid,
	//	CreatedBy: request.Createdby,
	//}

	resp, err := s.service.StoreSavingAccount(ctx, request.Customerid, request.Createdby, request.Savingproductid, request.Mobilenumber, request.Fullname)
	if err != nil {
		log.Printf("[handler-management] Error when StoreSavingAccount %s\n", err.Error())
		return nil, err
	}

	return &proto.StoreSavingAccountResponse{
		Id: resp,
	}, nil
}

func mapSavingAccountResponse(resp *model.SavingAccountResponse) *proto.GetSavingAccountResponse {
	return &proto.GetSavingAccountResponse{
		Id:               resp.ID,
		CardNo:           resp.CardNo,
		CustomerId:       resp.CustomerID,
		SavingProductId:  resp.SavingProductID,
		Balance:          resp.Balance,
		Status:           resp.Status,
		AvailableBalance: resp.AvailableBalance,
		MaxBalance:       resp.MaxBalance,
		MaxMonthlyTopup:  resp.MaxMonthlyTopup,
		MaxTopup:         resp.MaxTopup,
	}
}

func (s *server) GetSavingAccount(ctx context.Context, request *proto.GetSavingAccountRequest) (*proto.GetSavingAccountResponse, error) {
	acc := &models.SavingAccountRequest{
		CustomerID:      request.CustomerId,
		CardNo:          request.CardNo,
		ID:              request.Id,
		SavingProductID: request.SavingProductId,
	}

	resp, err := s.service.GetSavingAccount(ctx, acc)

	if err != nil {
		log.Printf("[handler-management] Error when GetSavingAccount %s\n", err.Error())
		return nil, err
	}

	return mapSavingAccountResponse(resp), nil
}

func (s *server) GetSavingProduct(ctx context.Context, request *proto.GetSavingProductRequest) (*proto.GetSavingProductResponse, error) {
	savingProductId := request.SavingProductId

	resp, err := s.service.GetSavingProduct(ctx, savingProductId)

	if err != nil {
		log.Printf("[handler-management] Error when GetSavingProduct %s\n", err.Error())
		return nil, err
	}

	savingProductResponse := &proto.GetSavingProductResponse{
		Id:                            resp.ID,
		Description:                   resp.Description,
		IsAllowOverdraft:              resp.IsAllowOverdraft,
		IsCalCulateTotalMonthlyCashIn: resp.IsCalCulateTotalMonthlyCashIn,
		IsCalculatePendingCashIn:      resp.IsCalculatePendingCashIn,
		IsCalculatePendingCashOut:     resp.IsCalculatePendingCashOut,
	}

	return savingProductResponse, nil
}

func (s *server) GetSavingAccountsCustomer(ctx context.Context, req *proto.GetSavingAccountCustomerRequest) (*proto.GetSavingAccountCustomerResponse, error) {
	acc := &models.SavingAccountCustomerRequest{
		CustomerID: req.CustomerId,
		CardNo:     req.CardNo}

	resp, err := s.service.GetCustomerSavingAccount(ctx, acc)

	if err != nil {
		log.Printf("[handler-management] Error when GetSavingAccount %s\n", err.Error())
		return nil, err
	}

	list := make([]*proto.GetCustomerSavingAccountResponse, 0)

	for _, sAccount := range resp.List {
		sa := new(proto.GetCustomerSavingAccountResponse)
		sa.Id = sAccount.ID
		sa.CardNo = sAccount.CardNo
		sa.CustomerId = sAccount.CustomerID
		sa.SavingProductId = sAccount.SavingProductID
		sa.Balance = sAccount.Balance
		sa.Status = sAccount.Status
		list = append(list, sa)
	}

	return &proto.GetSavingAccountCustomerResponse{SavingAccountList: list}, nil
}

func (s *server) GetAccount(ctx context.Context, request *proto.GetAccountRequest) (*proto.GetSavingAccountResponse, error) {
	md, _ := metadata.FromIncomingContext(ctx)
	header := md.Get("Authorization")

	idTokenBearer := header[0]

	idTokenList := strings.Split(idTokenBearer, " ")

	idToken := idTokenList[1]

	var mobileNumber string
	var savingProductId uint32

	if request.SavingProductId == 0 {
		savingProductId = 1
	} else {
		savingProductId = request.SavingProductId
	}

	if token, _ := jwt.ParseWithClaims(idToken, &model.TokenClaims{}, nil); token != nil {
		claim := token.Claims.(*model.TokenClaims)
		mobileNumber = claim.Subject
	}

	acc := &models.SavingAccountRequest{
		CardNo:          mobileNumber,
		SavingProductID: savingProductId,
	}

	resp, err := s.service.GetSavingAccount(ctx, acc)

	if err != nil {
		log.Printf("[handler-management] Error when GetSavingAccount %s\n", err.Error())
		return nil, err
	}

	return mapSavingAccountResponse(resp), nil
}

func (s *server) GetBankMasterData(ctx context.Context, req *proto.GetBankMasterDataRequest) (*proto.GetBankMasterDataResponse, error) {

	bankMaster, err := s.service.GetBankMasterData(ctx)

	if err != nil {
		log.Printf("[handler-management] Error when GetBankMasterData %s\n", err.Error())
		return nil, err
	}

	bankMasterData := make([]*proto.BankMasterData, 0)

	for _, data := range bankMaster.Data {
		bm := new(proto.BankMasterData)
		bm.BankName = data.BankName
		bm.BankCode = data.BankCode
		bm.Initial = data.Initial
		bankMasterData = append(bankMasterData, bm)
	}

	return &proto.GetBankMasterDataResponse{Data: bankMasterData, Length: bankMaster.Length}, nil
}
