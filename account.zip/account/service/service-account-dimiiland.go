package service

import (
	"git.capitalx.id/dimii/account/common"
	"git.capitalx.id/dimii/account/repository"
	customerClient "git.capitalx.id/dimii/customer/client"
)

//AccountInternalService is interface
type AccountInternalService interface {
	GetCustomerMoneyInfo(customerID uint64) (*common.DataResponse, error)
}

// NewAccountInternalService will create new an accountService object representation of AccountService interface
func NewAccountInternalService(r repository.AccountRepository, customerClient customerClient.CustomerClient) AccountInternalService {
	return &accountInternalService{r, customerClient}
}

type accountInternalService struct {
	accountRepos   repository.AccountRepository
	customerClient customerClient.CustomerClient
}
