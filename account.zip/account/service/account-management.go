package service

import (
	"context"
	"errors"
	"fmt"
	"log"
	"math"
	"time"

	models "git.capitalx.id/dimii/account/model"
	bkMdl "git.capitalx.id/dimii/bookkeeper/models"
	customerClient "git.capitalx.id/dimii/customer/client"
)

const (
	StatusAccountActive   = 1
	StatusAccountInactive = 2
	StatusAccountBlocked  = 3
	StatusAccountDeleted  = 4
	IsDefaultAccount      = 1
	IsNotDefaultAccount   = 0
	//SavingProductIDEMoney = 1
)

func (a *accountService) storeAccountToBookKeeper(ctx context.Context, bkMdl bkMdl.CustomerAccountGrpcRequest) map[string]interface{} {
	resp, err := a.bookkeeperSrv.CreateAccountCustomerToBookKeeper(ctx, bkMdl)

	if err != nil {
		log.Printf("[account-management.service] Error when store storing account to bookkeeper %s\n", err.Message)
	}

	return resp
}

func (a *accountService) StoreSavingAccount(ctx context.Context, customerID, createdBy uint64, savingProductID uint32, mobileNumber, fullName string) (uint64, error) {
	id, err := a.idGeneratorSrv.GetIdNextVal(ctx)
	if err != nil {
		log.Println("Unable to get ID from ID Generator Service when storing account, customerId :" + string(customerID))
		return 0, err
	}

	createdTime := time.Now()

	acc := &models.SavingAccount{
		ID:               id.Value,
		CardNo:           mobileNumber,
		CustomerID:       customerID,
		SavingProductID:  savingProductID,
		Status:           StatusAccountActive,
		CreatedBy:        createdBy,
		CreatedTimestamp: createdTime,
		UpdatedBy:        createdBy,
		UpdatedTimestamp: createdTime,
		IsDefaultAccount: IsDefaultAccount,
	}

	resp, err := a.accountRepos.StoreSavingAccount(ctx, acc)
	if err != nil {
		log.Printf("[account-management.service] Error when store saving account %s\n", err.Error())
		return 0, err
	}

	createAccountCustomerRequest := bkMdl.CustomerAccountGrpcRequest{
		FullName:        fullName,
		CardNumber:      mobileNumber,
		CustomerID:      customerID,
		AccountID:       id.Value,
		SavingProductID: savingProductID,
		CustomerType:    1,
	}

	t := a.storeAccountToBookKeeper(ctx, createAccountCustomerRequest)

	log.Printf("[PassAccountToBookkeeper] response from bookkeeper is: %s\n", t)

	return resp, nil
}

func (a *accountService) GetSavingAccount(ctx context.Context, request *models.SavingAccountRequest) (*models.SavingAccountResponse, error) {
	acc := &models.SavingAccount{
		ID:              request.ID,
		CustomerID:      request.CustomerID,
		CardNo:          request.CardNo,
		SavingProductID: request.SavingProductID,
	}

	sa, err := a.accountRepos.GetSavingAccount(ctx, acc)
	if err != nil {
		log.Printf("[account-management.service] Error when getting saving account %s\n", err.Error())
		return nil, err
	}

	customer, err := a.customerClient.GetCustomerData(context.Background(), &customerClient.CustomerMobileNumberRequest{
		CustomerID: sa.CustomerID,
	})
	if err != nil {
		log.Printf("[account-management.service] Error when getting customer data %s\n", err.Error())
		return nil, err
	}
	customerKycLevel := customer.Kyclevel

	rules, err := a.accountRepos.GetProductRule(sa.SavingProductID)

	if err != nil {
		log.Printf("[account-management.service] Error when getting rules %s\n", err.Error())
		return nil, err
	}

	maxBalanceStringRule := fmt.Sprintf("kyc[%d].max_balance", customerKycLevel)

	maxBalance, maxBalanceRuleExist := rules[maxBalanceStringRule]
	maxMonthlyTopup, maxTopupRuleExist := rules["max_monthly_funds_in"]

	maxTopup := float64(0)
	if maxBalanceRuleExist && maxTopupRuleExist {
		if maxBalance < 1 || maxMonthlyTopup < 1 {
			log.Printf("[account-management.service] max balance or max monthly topup is not set for %d\n", sa.SavingProductID)

			return nil, errors.New("maximum balance or maximum top up is invalid")
		}

		maxTopup = math.Min(maxBalance-sa.Balance-sa.PendingFundIn, maxMonthlyTopup-sa.TotalMonthlyFundIn)
	}

	return &models.SavingAccountResponse{
		ID:               sa.ID,
		CardNo:           sa.CardNo,
		CustomerID:       sa.CustomerID,
		SavingProductID:  sa.SavingProductID,
		Balance:          sa.Balance,
		Status:           sa.Status,
		AvailableBalance: sa.Balance - sa.PendingFundOut,
		MaxBalance:       maxBalance,
		MaxMonthlyTopup:  maxMonthlyTopup,
		MaxTopup:         maxTopup,
	}, nil
}

func (a *accountService) GetSavingProduct(ctx context.Context, savingProductId uint32) (*models.SavingProduct, error) {
	savingProduct, err := a.accountRepos.GetSavingProduct(savingProductId)

	if err != nil {
		log.Printf("[account-management.service] Error when getting saving product %s\n", err)
		return &models.SavingProduct{}, err
	}
	return savingProduct, nil
}

func (a *accountService) GetCustomerSavingAccount(ctx context.Context, req *models.SavingAccountCustomerRequest) (*models.ListSavingAccountsReponse, error) {
	savingAccounts, err := a.accountRepos.GetCustomerSavingAccount(ctx, req)

	if err != nil {
		log.Printf("[account-management.service] Error when getting saving product %s\n", err)
		return nil, err
	}
	return savingAccounts, nil
}

func (a *accountService) GetBankMasterData(ctx context.Context) (*models.BankMasterDataResponse, error) {
	data, err := a.accountRepos.GetBankMasterData(ctx)

	if err != nil {
		log.Printf("[account-management.service] Error when getting Get Bank Master Data %s\n", err)
		return nil, err
	}
	return data, nil
}
