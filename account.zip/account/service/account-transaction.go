package service

import (
	"log"

	"git.capitalx.id/dimii/account/model"
	models "git.capitalx.id/dimii/account/model"
	customerClient "git.capitalx.id/dimii/customer/client"

	"context"
	"fmt"
)

func convertCustomerModel(source *customerClient.CustomerDataResponse) *model.Customer {
	return &model.Customer{
		Id:       source.Customerid,
		FullName: source.Fullname,
		MobileNo: source.Mobilenumber,
		Type:     uint8(source.Type),
		KycLevel: uint8(source.Kyclevel),
	}
}

func convertSavingAccount(source *model.SavingAccount) *model.SavingAccountResponse {
	return &model.SavingAccountResponse{
		ID:              source.ID,
		CardNo:          source.CardNo,
		CustomerID:      source.CustomerID,
		SavingProductID: source.SavingProductID,
		Balance:         source.Balance,
		Status:          source.Status,
	}
}

func (ats *accountTransactionService) getCustomersData(fromCustomerId uint64, fromCustomerPhoneNumber string, toCustomerId uint64,
	toCustomerPhoneNumber string) (*model.Customer, *model.Customer, error) {

	fromCustomer, err1 := ats.customerClient.GetCustomerData(context.Background(), &customerClient.CustomerMobileNumberRequest{
		Mobilenumber: fromCustomerPhoneNumber,
		CustomerID:   fromCustomerId,
	})

	toCustomer, err2 := ats.customerClient.GetCustomerData(context.Background(), &customerClient.CustomerMobileNumberRequest{
		Mobilenumber: toCustomerPhoneNumber,
		CustomerID:   toCustomerId,
	})
	if err1 != nil || err2 != nil {
		if err1 != nil {
			log.Printf("Error when getting customer data (from) card no: %s, %s\n", fromCustomerPhoneNumber, err1.Error())
		}
		if err2 != nil {
			log.Printf("Error when getting customer data (to) card no: %s, %s\n", toCustomerPhoneNumber, err2.Error())
			return nil, nil, err2
		}
		return nil, nil, err1
	}
	return convertCustomerModel(fromCustomer), convertCustomerModel(toCustomer), nil
}

// This is a place for put your service function associated with transaction in account service.
// For example you can see account-management.go in the service directory
func (ats *accountTransactionService) ValidateFundTransferAmount(ctx context.Context, request *model.ValidateTransferRequest) (*model.ValidationResponse, error) {
	fromCustomer, toCustomer, err := ats.getCustomersData(request.FromCustomerId, request.FromCusCardNo, request.ToCustomerId, request.ToCusCardNo)

	//no need to log the error because already logged in method above
	if err != nil {
		return &model.ValidationResponse{
			Code:        models.InternalSystemError,
			Description: "Internal system error getting customer",
		}, err
	}
	return ats.ValidateCustomerFundTransfer(fromCustomer, toCustomer, request)
}

//split so doesnt call customer service anymore to get customer data
func (ats *accountTransactionService) ValidateCustomerFundTransfer(fromCustomer, toCustomer *model.Customer, request *model.ValidateTransferRequest) (*model.ValidationResponse, error) {
	toCustomerKycLevel := toCustomer.KycLevel

	validationMap, err := ats.arepo.ValidateFundTransfer(request.Amount, fromCustomer.Id, request.FromAccProduct, toCustomer.Id,
		request.ToAccProduct, toCustomerKycLevel)
	if err != nil {
		log.Printf("Error when getting validation query: %s\n", err.Error())
		return &model.ValidationResponse{
			Code:        models.InternalSystemError,
			Description: "Internal system error getting validation",
		}, err
	}

	if !validationMap["valid_minimum_amount"] {
		return &model.ValidationResponse{
			Code:        models.NominalNotValid,
			Description: "Topup amount not valid",
		}, nil
	}
	if !validationMap["sufficient_source_balance"] {
		return &model.ValidationResponse{
			Code:        models.InsufficientBalance,
			Description: "Insufficient source balance",
		}, nil
	}
	if !validationMap["valid_receiver_max_balance"] {
		return &model.ValidationResponse{
			Code:        models.ExceedsMaximumBalance,
			Description: "Account receiver exceeds maximum balance",
		}, nil
	}
	if !validationMap["valid_receiver_max_monthly_fund_in"] {
		return &model.ValidationResponse{
			Code:        models.MonthlyMaxExceedsAmount,
			Description: "Account receiver exceeds maximum monthly topup",
		}, nil
	}

	return &model.ValidationResponse{
		Code:        models.SuccessCode,
		Description: "Validation success",
	}, nil
}

func (ats *accountTransactionService) AuthorizeFundTransferAmount(ctx context.Context, request *model.AuthTransactionRequest) (*model.AuthResponse, error) {
	return ats.handleFundTransfer(ctx, request, false)
}

//handle authorize balance or authorize and commit
func (ats *accountTransactionService) handleFundTransfer(ctx context.Context, request *model.AuthTransactionRequest, isCommit bool) (*model.AuthResponse, error) {

	fromCustomer, toCustomer, err := ats.getCustomersData(request.FromCustomerId, request.FromCusCardNo, request.ToCustomerId, request.ToCusCardNo)

	//no need to log the error because already logged in method above
	if err != nil {
		fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(request.TransactionId)
		return generateAuthResponse(&fromAcc, &toAcc, model.InternalSystemError, "Failed to get customer data"), err
	}

	toCustomerKycLevel := toCustomer.KycLevel

	tx, err := ats.arepo.InitiateTransaction(ctx)

	if err != nil {
		fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(request.TransactionId)
		return generateAuthResponse(&fromAcc, &toAcc, model.InternalSystemError, "Failed to start db transaction"), err
	}

	var status uint8 = models.StatusInProgress
	if isCommit {
		status = models.StatusCompleted
	}

	err = ats.arepo.InsertAccAuth(ctx, tx, request, status, fromCustomer.Id, toCustomer.Id, 100)

	if err != nil {
		fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(request.TransactionId)
		return generateAuthResponse(&fromAcc, &toAcc, models.InternalSystemError, "failed insert acc auth"), err
	}

	if isCommit {
		err = ats.arepo.UpdateCustomerSavingAccount(ctx, tx, request.TransactionId, toCustomerKycLevel)
	} else {
		err = ats.arepo.UpdatePendingFundCustomerSavingAccount(ctx, tx, request.TransactionId, toCustomerKycLevel)
	}

	if err != nil {
		fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(request.TransactionId)
		failedReason, err := ats.ValidateCustomerFundTransfer(fromCustomer, toCustomer, &request.ValidateTransferRequest)
		return generateAuthResponse(&fromAcc, &toAcc, failedReason.Code, failedReason.Description), err
	}

	err = ats.arepo.CommitTransaction(tx)

	if err != nil {
		fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(request.TransactionId)
		return generateAuthResponse(&fromAcc, &toAcc, models.InternalSystemError, "failed to commit db transaction"), err
	}

	fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(request.TransactionId)

	return generateAuthResponse(&fromAcc, &toAcc, models.SuccessCode, ""), nil
}

func (ats *accountTransactionService) CommitFundTransferAmount(ctx context.Context, transactionId uint64) (*model.AuthResponse, error) {

	err := ats.arepo.CommitAndTransfer(ctx, transactionId)

	if err != nil {
		fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(transactionId)
		return generateAuthResponse(&fromAcc, &toAcc, model.InternalSystemError, "failed commit and transfer"), err
	}

	fromAcc, toAcc, _ := ats.getSavingAccountByTransactionId(transactionId)

	return generateAuthResponse(&fromAcc, &toAcc, model.SuccessCode, ""), nil
}

func (a *accountTransactionService) RollbackTransaction(ctx context.Context, transactionId uint64, rollbackType uint8) (*model.TransactionResponse, error) {
	err := a.arepo.RollbackTransaction(ctx, transactionId, rollbackType)

	fromSavingAccount, toSavingAccount, err2 := a.getSavingAccountByTransactionId(transactionId)

	fromSavingAccountResponse, toSavingAccountResponse := model.SavingAccountResponse{}, model.SavingAccountResponse{}

	if err2 == nil {
		fromSavingAccountResponse = *convertSavingAccount(&fromSavingAccount)
		toSavingAccountResponse = *convertSavingAccount(&toSavingAccount)
	}

	if err != nil {
		return &model.TransactionResponse{
			Code:              model.InternalSystemError,
			Description:       fmt.Sprintf("Failed rollback :%d", rollbackType),
			FromSavingAccount: fromSavingAccountResponse,
			ToSavingAccount:   toSavingAccountResponse,
		}, err
	}

	return &model.TransactionResponse{
		Code:              model.SuccessCode,
		Description:       fmt.Sprintf("Success rollback :%d", rollbackType),
		FromSavingAccount: fromSavingAccountResponse,
		ToSavingAccount:   toSavingAccountResponse,
	}, nil
}

func (a *accountTransactionService) getSavingAccountByTransactionId(transactionId uint64) (model.SavingAccount, model.SavingAccount, error) {
	savingAccountsWithType, err := a.arepo.GetSavingAccountByTransactionId(transactionId)

	if err != nil {
		log.Println(err)
		return model.SavingAccount{}, model.SavingAccount{}, err
	}
	var fromAcc, toAcc model.SavingAccount
	for _, s := range savingAccountsWithType {
		if s.Type == "source" {
			fromAcc = s.SavingAccount
		} else {
			toAcc = s.SavingAccount
		}
	}

	return fromAcc, toAcc, nil
}

func (ats *accountTransactionService) InsertFundTransfer(ctx context.Context, request *model.AuthTransactionRequest) (*model.AuthResponse, error) {
	return ats.handleFundTransfer(ctx, request, true)
}

func generateAuthResponse(fromAccPayload, toAccPayload *models.SavingAccount, code, description string) *model.AuthResponse {
	return &model.AuthResponse{
		Code:        code,
		Description: description,
		FromSavingAccount: model.SavingAccountResponse{
			ID:              fromAccPayload.ID,
			CardNo:          fromAccPayload.CardNo,
			CustomerID:      fromAccPayload.CustomerID,
			SavingProductID: fromAccPayload.SavingProductID,
			Balance:         fromAccPayload.Balance,
			Status:          fromAccPayload.Status,
		},
		ToSavingAccount: model.SavingAccountResponse{
			ID:              toAccPayload.ID,
			CardNo:          toAccPayload.CardNo,
			CustomerID:      toAccPayload.CustomerID,
			SavingProductID: toAccPayload.SavingProductID,
			Balance:         toAccPayload.Balance,
			Status:          toAccPayload.Status,
		},
	}
}
