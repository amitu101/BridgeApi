package service

import (
	"context"
	"fmt"
	"log"

	"git.capitalx.id/dimii/account/common"
	models "git.capitalx.id/dimii/account/model"
	customerClient "git.capitalx.id/dimii/customer/client"
)

func (a *accountInternalService) GetCustomerMoneyInfo(customerID uint64) (*common.DataResponse, error) {
	var listAccResponse []*models.CustomerAccountResponse
	cust, err := a.customerClient.GetCustomerDataByIdOrMobileNumber(context.Background(), &customerClient.GetCustomerRequest{CustomerId: customerID})

	if err != nil {
		log.Printf("[account-dimiiland.service] Error when getting customer data %s\n", err)
		return nil, common.AppErrorCode(common.CustomerNotFound)
	}

	savingAccs, err := a.accountRepos.GetCustomerSavingAccount(context.Background(), &models.SavingAccountCustomerRequest{CustomerID: customerID})

	if err != nil {
		log.Printf("[account-dimiiland.service] Error when getting saving account %s\n", err)
		return nil, common.AppErrorCode(common.InternalError)
	}

	if len(savingAccs.List) == 0 {
		return nil, common.AppErrorCode(common.CustomerSavingsNotFound)
	}

	for _, savingAcc := range savingAccs.List {

		rule, err := a.accountRepos.GetProductRule(savingAcc.SavingProductID)
		if err != nil {
			log.Printf("[account-dimiiland.service] Error when getting saving product rule  %s\n", err)
			return nil, common.AppErrorCode(common.InternalError)
		}

		customerKycLevel := cust.Kyclevel

		// calculate Maximum Monthly TopUp
		var maximumMonthlyTopUp, maxBalDiffer, maxMonthlyDiffer float64
		code := fmt.Sprintf("kyc[%d].max_balance", customerKycLevel)
		maxBal := rule[code]
		maxMonthlyFund := rule["max_monthly_funds_in"]

		if maxBalDiffer = maxBal - savingAcc.Balance; maxBalDiffer < 0 {
			maxBalDiffer = 0
		}

		if maxMonthlyDiffer = maxMonthlyFund - savingAcc.TotalMonthlyFundIn; maxMonthlyDiffer < 0 {
			maxMonthlyDiffer = 0
		}

		if maxBalDiffer < maxMonthlyDiffer {
			maximumMonthlyTopUp = maxBalDiffer
		} else {
			maximumMonthlyTopUp = maxMonthlyDiffer
		}

		listAccResponse = append(listAccResponse, &models.CustomerAccountResponse{ID: fmt.Sprint(savingAcc.ID),
			CardNo: savingAcc.CardNo, CustomerID: fmt.Sprint(savingAcc.CustomerID), SavingProductID: savingAcc.SavingProductID, Balance: savingAcc.Balance,
			PendingFundIn: savingAcc.PendingFundIn, PendingFundOut: savingAcc.PendingFundOut, Status: savingAcc.Status, TotalMonthlyFundIn: savingAcc.TotalMonthlyFundIn,
			MaximumMonthlyTopUp: maximumMonthlyTopUp})

	}

	return &common.DataResponse{Data: listAccResponse, Message: common.GetMessage(common.CustomerAccSuccess)}, nil
}
