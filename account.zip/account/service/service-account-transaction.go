package service

import (
	"git.capitalx.id/dimii/account/model"
	"git.capitalx.id/dimii/account/repository"
	customerClient "git.capitalx.id/dimii/customer/client"

	"context"
)

type AccountTransactionService interface {
	ValidateFundTransferAmount(ctx context.Context, request *model.ValidateTransferRequest) (*model.ValidationResponse, error)
	AuthorizeFundTransferAmount(ctx context.Context, request *model.AuthTransactionRequest) (*model.AuthResponse, error)
	CommitFundTransferAmount(context.Context, uint64) (*model.AuthResponse, error)
	RollbackTransaction(ctx context.Context, transactionId uint64, rollbackType uint8) (*model.TransactionResponse, error)

	//InsertFundTransfer authorises and commit the transaction
	InsertFundTransfer(ctx context.Context, request *model.AuthTransactionRequest) (*model.AuthResponse, error)
}

func NewAccountTransactionService(r repository.AccountRepository, customerClient customerClient.CustomerClient) AccountTransactionService {
	return &accountTransactionService{r, customerClient}
}

type accountTransactionService struct {
	arepo          repository.AccountRepository
	customerClient customerClient.CustomerClient
}
