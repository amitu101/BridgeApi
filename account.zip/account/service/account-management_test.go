package service

import (
	"context"
	"encoding/json"

	customerClient "git.capitalx.id/dimii/customer/client"
	customerClientMock "git.capitalx.id/dimii/customer/mocks/client"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/suite"

	idGenerator_mocks "git.capitalx.id/core/id/mocks/service"
	mocks "git.capitalx.id/dimii/account/mocks/repository"
	models "git.capitalx.id/dimii/account/model"
	bookkeeper_mocks "git.capitalx.id/dimii/bookkeeper/mocks/service"
	"github.com/stretchr/testify/assert"
)

var mockAccountRepository = &mocks.AccountRepository{}
var mockBookkeeperService = &bookkeeper_mocks.Service{}
var mockIdGeneratorService = &idGenerator_mocks.SequenceService{}
var mockCustomerClient = &customerClientMock.CustomerClient{}

var u uint64 = 0
var uOne uint64 = 1
var i uint32 = 1
var iZero int64 = 0
var f float64 = 0

type AccountManagementSuite struct {
	suite.Suite
}

func (suite *AccountManagementSuite) SetupTest() {
	ctx := context.Background()
	acc := &models.SavingAccount{
		CardNo:          "Hello",
		SavingProductID: 1,
	}
	repositoryResponse := &models.SavingAccount{
		CustomerID:      0,
		ID:              0,
		CardNo:          "Hello",
		SavingProductID: 1,
		Balance:         0,
		Status:          0,
	}

	repositoryProductRule := models.SavingProductRule{}
	repositoryProductRule["kyc[1].max_balance"] = 2000000
	repositoryProductRule["kyc[2].max_balance"] = 10000000
	repositoryProductRule["max_monthly_funds_in"] = 20000000

	mockAccountRepository.On("GetSavingAccount", ctx, acc).Return(repositoryResponse, nil)
	mockAccountRepository.On("GetProductRule", uint32(1)).Return(repositoryProductRule, nil)

	customerResponseMock := &customerClient.CustomerDataResponse{
		Customerid:   0,
		Fullname:     "test name",
		Mobilenumber: "0812345678",
		Email:        "a@a.com",
		Type:         1,
		Kyclevel:     1,
		Status:       1,
		Photourl:     "",
	}
	mockCustomerClient.On("GetCustomerData", mock.IsType(context.Background()),
		mock.IsType(&customerClient.CustomerMobileNumberRequest{})).Return(customerResponseMock, nil)
}

func (suite *AccountManagementSuite) TestGetSavingAccountByCardNoAndSavingProductId() {
	t := suite.T()

	accRequest := &models.SavingAccountRequest{
		CardNo:          "Hello",
		SavingProductID: 1,
	}

	newAccountService := NewAccountService(mockAccountRepository, mockBookkeeperService, mockIdGeneratorService, mockCustomerClient)

	resp, err := newAccountService.GetSavingAccount(context.Background(), accRequest)

	if err != nil {
		t.Errorf("error while getting saving acc response :%s", err.Error())
	}

	respJson, err := json.Marshal(resp)
	if err != nil {
		t.Errorf("error while parse json response :%s", err.Error())
	}
	respJsonString := string(respJson)

	expectedResponse := &models.SavingAccountResponse{
		CustomerID:      0,
		ID:              0,
		CardNo:          "Hello",
		SavingProductID: 1,
		Balance:         0,
		Status:          0,
		MaxBalance:      2_000_000,
		MaxMonthlyTopup: 20_000_000,
		MaxTopup:        2_000_000,
	}
	expectedResponseJson, _ := json.Marshal(expectedResponse)
	expectedResponseJsonString := string(expectedResponseJson)

	assert.Equal(t, expectedResponseJsonString, respJsonString)
}

func (suite *AccountManagementSuite) TestGetSavingAccountByIdAndSavingProductId() {
	t := suite.T()
	ctx := context.Background()

	accRequest := &models.SavingAccountRequest{
		ID:              uOne,
		SavingProductID: i,
	}

	expectedResponse := &models.SavingAccountResponse{
		CustomerID:      0,
		ID:              uOne,
		CardNo:          "Hello",
		SavingProductID: i,
		Balance:         0,
		Status:          iZero,
		MaxBalance:      2_000_000,
		MaxMonthlyTopup: 20_000_000,
		MaxTopup:        2_000_000,
	}

	newAccountService := NewAccountService(mockAccountRepository, mockBookkeeperService, mockIdGeneratorService, mockCustomerClient)

	resp, _ := newAccountService.GetSavingAccount(ctx, accRequest)

	respJson, _ := json.Marshal(resp)
	respJsonString := string(respJson)

	expectedResponseJson, _ := json.Marshal(expectedResponse)
	expectedResponseJsonString := string(expectedResponseJson)

	assert.Equal(t, respJsonString, expectedResponseJsonString)
}

func (suite *AccountManagementSuite) TestGetSavingAccountByCustomerIdAndSavingProductId() {
	t := suite.T()
	ctx := context.Background()

	accRequest := &models.SavingAccountRequest{
		CustomerID:      uOne,
		SavingProductID: i,
	}

	expectedServiceResponse := &models.SavingAccountResponse{
		CustomerID:      uOne,
		ID:              uOne,
		CardNo:          "Hello",
		SavingProductID: i,
		Balance:         0,
		Status:          iZero,
		MaxBalance:      2_000_000,
		MaxMonthlyTopup: 20_000_000,
		MaxTopup:        2_000_000,
	}

	newAccountService := NewAccountService(mockAccountRepository, mockBookkeeperService, mockIdGeneratorService, mockCustomerClient)

	resp, _ := newAccountService.GetSavingAccount(ctx, accRequest)

	respJson, _ := json.Marshal(resp)
	respJsonString := string(respJson)

	expectedServiceResponseJson, _ := json.Marshal(expectedServiceResponse)
	expectedServiceResponseJsonString := string(expectedServiceResponseJson)

	assert.Equal(t, respJsonString, expectedServiceResponseJsonString)

}
