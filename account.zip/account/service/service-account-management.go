package service

import (
	"context"

	idGeneratorService "git.capitalx.id/core/id/service"
	models "git.capitalx.id/dimii/account/model"
	"git.capitalx.id/dimii/account/repository"
	bookkeeperService "git.capitalx.id/dimii/bookkeeper/service"
	customerClient "git.capitalx.id/dimii/customer/client"
)

// AccountService represent the account's service
type AccountService interface {
	StoreSavingAccount(ctx context.Context, customerID, createdBy uint64, savingProductID uint32, mobileNumber, fullName string) (uint64, error)
	GetSavingAccount(ctx context.Context, request *models.SavingAccountRequest) (*models.SavingAccountResponse, error)
	GetSavingProduct(ctx context.Context, id uint32) (*models.SavingProduct, error)
	GetCustomerSavingAccount(ctx context.Context, a *models.SavingAccountCustomerRequest) (*models.ListSavingAccountsReponse, error)
	GetBankMasterData(ctx context.Context) (*models.BankMasterDataResponse, error)
}

// NewAccountService will create new an accountService object representation of AccountService interface
func NewAccountService(r repository.AccountRepository, b bookkeeperService.Service,
	i idGeneratorService.SequenceService, customerClient customerClient.CustomerClient) AccountService {
	return &accountService{r, b, i, customerClient}
}

type accountService struct {
	accountRepos   repository.AccountRepository
	bookkeeperSrv  bookkeeperService.Service
	idGeneratorSrv idGeneratorService.SequenceService
	customerClient customerClient.CustomerClient
}
