package repository

import (
	"database/sql"
)

type mariaAccountRepository struct {
	Conn *sql.DB
}

// NewMariaAccountRepository will create an object that represent the account.Repository interface
func NewMariaAccountRepository(Conn *sql.DB) AccountRepository {
	return &mariaAccountRepository{Conn}
}
