package repository

import (
	"context"
	"database/sql"

	model "git.capitalx.id/dimii/account/model"
)

// AccountRepository represent the account's repository contract
type AccountRepository interface {
	StoreSavingAccount(ctx context.Context, a *model.SavingAccount) (uint64, error)

	GetSavingAccount(ctx context.Context, a *model.SavingAccount) (*model.SavingAccount, error)
	//GetProductRule fetches the set of rules that are defined in saving_product_rule
	GetProductRule(productID uint32) (model.SavingProductRule, error)

	CommitTransaction(tx *sql.Tx) error

	UpdateTotalMonthlyFundIn(ctx context.Context, cardno, fundInEndPeriod string, amount float64) error

	CommitAndTransfer(ctx context.Context, transactionId uint64) error

	GetSavingProduct(id uint32) (*model.SavingProduct, error)

	FetchSavingAccount(acc *model.SavingAccount) (*model.SavingAccount, error)

	InitiateTransaction(ctx context.Context) (*sql.Tx, error)

	UpdatePendingFundCustomerSavingAccount(ctx context.Context, tx *sql.Tx, transactionId uint64, toAccKycLevel uint8) error

	ValidateFundTransfer(amount float64, fromCustomerId uint64, fromSavingProductId uint32, toCustomerId uint64, toSavingProductId uint32,
		toKycLv uint8) (map[string]bool, error)

	InsertAccAuth(ctx context.Context, tx *sql.Tx, request *model.AuthTransactionRequest, status uint8, fromCustomerId, toCustomerId, actor uint64) error

	GetSavingAccountByTransactionId(transactionId uint64) ([]*model.SavingAccountWithType, error)

	UpdateCustomerSavingAccount(ctx context.Context, tx *sql.Tx, transactionId uint64, toAccKycLevel uint8) error

	RollbackTransaction(ctx context.Context, transactionId uint64, rollbackType uint8) error

	GetCustomerSavingAccount(ctx context.Context, a *model.SavingAccountCustomerRequest) (*model.ListSavingAccountsReponse, error)

	GetBankMasterData(ctx context.Context) (*model.BankMasterDataResponse, error)
}
