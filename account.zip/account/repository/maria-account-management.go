package repository

import (
	"context"
	"database/sql"
	"log"

	"git.capitalx.id/dimii/account/constant"
	"git.capitalx.id/dimii/account/model"
	models "git.capitalx.id/dimii/account/model"
)

const (
	insertSavingAccount = "insert into saving_account(id, card_no, customer_id, saving_product_id," +
		"status, created_by, created_timestamp, updated_by, updated_timestamp, is_default_account) values " +
		"(?,?,?,?,?,?,?,?,?,?)"
	getSavingAccountById = "select id, card_no, customer_id, saving_product_id, balance, status, " +
		"total_monthly_fund_in, fund_in_end_period, pending_fund_in, pending_fund_out from saving_account where id = ?"
	getSavingAccountByCustomerIdAndSavingProductId = "select id, card_no, customer_id, saving_product_id, balance, status, " +
		"total_monthly_fund_in, fund_in_end_period, pending_fund_in, pending_fund_out from saving_account where customer_id = ? AND saving_product_id = ? "
	getSavingAccountByCardNoAndSavingProductId = "select id, card_no, customer_id, saving_product_id, balance, status, " +
		"total_monthly_fund_in, fund_in_end_period, pending_fund_in, pending_fund_out from saving_account where card_no = ? AND saving_product_id = ? "
	getSavingProductBySavingProductId = `select id, description, is_allow_overdraft, is_calculate_total_monthly_cash_in, 
	   is_calculate_pending_cash_in, is_calculate_pending_cash_out from saving_product where id = ?`
	getSavingAccountByCustomerId = "select id, card_no, customer_id, saving_product_id, balance, status, " +
		"total_monthly_fund_in, fund_in_end_period, pending_fund_in, pending_fund_out from saving_account where customer_id = ?"
	getSavingAccountByCard = "select id, card_no, customer_id, saving_product_id, balance, status, " +
		"total_monthly_fund_in, fund_in_end_period, pending_fund_in, pending_fund_out from saving_account where card_no = ?"

	getBankMaster = "select bank_name, bank_code , initial from dimii.bank_master where status = ? order by priority,bank_name "
)

func (m *mariaAccountRepository) fetch(query string, args ...interface{}) ([]*models.SavingAccount, error) {
	rows, err := m.Conn.Query(query, args...)

	if err != nil {
		log.Printf("[maria-account-management] Error when fetch %s\n", err.Error())
		return nil, models.ErrInternalServerError
	}
	defer rows.Close()
	result := make([]*models.SavingAccount, 0)
	for rows.Next() {
		t := new(models.SavingAccount)

		err = rows.Scan(
			&t.ID,
			&t.CardNo,
			&t.CustomerID,
			&t.SavingProductID,
			&t.Balance,
			&t.Status,
			&t.TotalMonthlyFundIn,
			&t.FundInEndPeriod,
			&t.PendingFundIn,
			&t.PendingFundOut,
		)

		if err != nil {
			log.Printf("[maria-account-management] Error when scan %s\n", err.Error())
			return nil, models.ErrInternalServerError
		}
		result = append(result, t)
	}

	return result, nil
}

func (m *mariaAccountRepository) fetchBankMaster(query string, args ...interface{}) ([]*models.BankMasterData, error) {
	rows, err := m.Conn.Query(query, args...)

	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria-account-management]  fetch Bank Master Error when fetch %s\n", err.Error())
		return nil, models.ErrInternalServerError
	}
	defer rows.Close()
	result := make([]*models.BankMasterData, 0)
	for rows.Next() {
		t := new(models.BankMasterData)

		err = rows.Scan(
			&t.BankName,
			&t.BankCode,
			&t.Initial)

		if err != nil {
			log.Printf("[maria-account-management]  fetch Bank Master Error when scan %s\n", err.Error())
			return nil, models.ErrInternalServerError
		}
		result = append(result, t)
	}

	return result, nil
}

func (m *mariaAccountRepository) GetSavingProduct(id uint32) (*models.SavingProduct, error) {
	rows, err := m.Conn.Query(getSavingProductBySavingProductId, id)

	if err != nil {
		log.Printf("[maria-account-management] Error when GetSavingProduct %s\n", err.Error())
		return nil, models.ErrInternalServerError
	}
	defer rows.Close()
	t := new(models.SavingProduct)
	for rows.Next() {
		err = rows.Scan(
			&t.ID,
			&t.Description,
			&t.IsAllowOverdraft,
			&t.IsCalCulateTotalMonthlyCashIn,
			&t.IsCalculatePendingCashIn,
			&t.IsCalculatePendingCashOut,
		)

		if err != nil {
			log.Printf("[maria-account-management] Error when scan saving product %s\n", err.Error())
			return nil, models.ErrInternalServerError
		}
	}

	return t, nil
}

func (m *mariaAccountRepository) StoreSavingAccount(ctx context.Context, a *models.SavingAccount) (uint64, error) {
	_, err := m.Conn.Exec(insertSavingAccount, a.ID, a.CardNo, a.CustomerID, a.SavingProductID, a.Status,
		a.CreatedBy, a.CreatedTimestamp, a.CreatedBy, a.UpdatedTimestamp, a.IsDefaultAccount)
	if err != nil {
		log.Printf("[maria-account-management] Error when StoreSavingAccount %s\n", err.Error())
		return 0, err
	}

	return a.ID, nil
}

func (m *mariaAccountRepository) GetSavingAccount(ctx context.Context, a *models.SavingAccount) (*models.SavingAccount, error) {
	var list []*models.SavingAccount
	var err error

	if a.ID != 0 {
		list, err = m.fetch(getSavingAccountById, a.ID)
	} else if a.CustomerID != 0 {
		list, err = m.fetch(getSavingAccountByCustomerIdAndSavingProductId, a.CustomerID, a.SavingProductID)
	} else {
		list, err = m.fetch(getSavingAccountByCardNoAndSavingProductId, a.CardNo, a.SavingProductID)
	}
	if err != nil {
		log.Printf("[maria-account-management] Error when GetSavingAccount %s\n", err.Error())
		return nil, err
	}

	if len(list) > 0 {
		return list[0], nil
	} else {
		return nil, models.ErrNotFound
	}
}

func (m *mariaAccountRepository) GetCustomerSavingAccount(ctx context.Context, a *models.SavingAccountCustomerRequest) (*models.ListSavingAccountsReponse, error) {
	var list []*models.SavingAccount
	var response = new(models.ListSavingAccountsReponse)
	var err error

	if a.CustomerID != 0 {
		list, err = m.fetch(getSavingAccountByCustomerId, a.CustomerID)
	} else if a.CardNo != "" {
		list, err = m.fetch(getSavingAccountByCard, a.CardNo)
	}
	if err != nil {
		log.Printf("[maria-account-management] Error when GetSavingAccount %s\n", err.Error())
		return nil, err
	}
	response.List = list
	return response, nil
}

func (m *mariaAccountRepository) GetBankMasterData(ctx context.Context) (*model.BankMasterDataResponse, error) {
	var response = new(models.BankMasterDataResponse)

	list, err := m.fetchBankMaster(getBankMaster, constant.StatusActive)

	if err != nil && err != sql.ErrNoRows {
		log.Printf("[maria-account-management:GetBankMasterData] Error when Get Bank Master Data %s\n", err.Error())
		return nil, err
	}
	response.Data = list
	response.Length = uint32(len(list))
	return response, nil
}
