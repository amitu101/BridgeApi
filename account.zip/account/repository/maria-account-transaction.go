package repository

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"log"

	"git.capitalx.id/dimii/account/utils"

	"git.capitalx.id/dimii/account/constant"
	"git.capitalx.id/dimii/account/model"
)

const (
	SelectRule = `select code,value from saving_product_rule where saving_product_id = ?`

	UpdatePendingFundCustomerSavingAccount = BatchUpdateTables + `
	SET saFrom.pending_fund_out = saFrom.pending_fund_out + authFrom.fund_out_amount,
			saTo.pending_fund_in =  saTo.pending_fund_in + authTo.fund_in_amount,
			saFrom.updated_timestamp = CURRENT_TIMESTAMP(),
			saTo.updated_timestamp = CURRENT_TIMESTAMP()
	` + BatchUpdateConditions +
		`AND authTo.fund_in_amount >= (
		SELECT IFNULL ((SELECT spr.value
				FROM saving_product_rule spr
				  WHERE saving_product_id = saTo.saving_product_id
				AND spr.code = 'min_topup_amount'), 0)
			  )
	AND    (((SELECT is_allow_overdraft FROM saving_product WHERE id = saFrom.saving_product_id) = 1 AND (saFrom.balance - saFrom.pending_fund_out - authTo.fund_in_amount >= (
			SELECT spr.value
			FROM saving_product_rule spr
			WHERE saving_product_id = saFrom.saving_product_id
				AND spr.code = 'max_overdraft'                
		))) OR ((SELECT is_allow_overdraft FROM saving_product WHERE id = saFrom.saving_product_id) = 0 AND (saFrom.balance - saFrom.pending_fund_out - authTo.fund_in_amount >= 0))
		)
	AND    IFNULL(saTo.balance + saTo.pending_fund_in + authTo.fund_in_amount <= (
		SELECT spr.value
		FROM saving_product_rule spr
		WHERE saving_product_id = saTo.saving_product_id
			AND spr.code = ?
		), TRUE)
	AND (IFNULL((CURRENT_TIMESTAMP < saTo.fund_in_end_period AND saTo.total_monthly_fund_in + authTo.fund_in_amount <= (
		SELECT spr.value
		FROM saving_product_rule spr
		WHERE saving_product_id = saTo.saving_product_id
			AND spr.code = 'max_monthly_funds_in'
		)),TRUE) OR CURRENT_TIMESTAMP > saTo.fund_in_end_period
	)
`
	SavingAccountColumns = `id, card_no, customer_id, saving_product_id, balance, total_monthly_fund_in, fund_in_end_period,
		pending_fund_in, pending_fund_out, sa.status, sa.created_by, sa.created_timestamp, sa.updated_by, sa.updated_timestamp, is_default_account
	`
	GetSavingAccountByTransactionId = `
		SELECT ` + SavingAccountColumns + `, CASE WHEN auth.fund_in_amount = 0 THEN 'source' ELSE 'destination' END AS type
	
		FROM saving_account sa
		JOIN saving_account_amount_authorization auth ON auth.saving_account_id = sa.id
		WHERE auth.transaction_id = ?
    `
	BatchUpdateTables = `UPDATE saving_account saFrom, saving_account saTo, saving_account_amount_authorization authFrom, saving_account_amount_authorization authTo`

	BatchUpdateConditions = `
		WHERE TRUE
        	AND authFrom.transaction_id = ?
			AND authFrom.transaction_id = authTo.transaction_id
			AND authFrom.saving_account_id != authTo.saving_account_id
			AND authFrom.status = authTo.status
			AND authTo.status = ?
			AND saFrom.id = authFrom.saving_account_id
			AND saTo.id = authTo.saving_account_id
			AND saFrom.id != saTo.id
			AND authFrom.fund_in_amount = 0
			AND authTo.fund_out_amount = 0
	`
	RollbackAuthTransaction = BatchUpdateTables +
		` SET saFrom.pending_fund_out = saFrom.pending_fund_out - authFrom.fund_out_amount,
            saTo.pending_fund_in = saTo.pending_fund_in - authTo.fund_in_amount,
			authFrom.status = ?,
			authTo.status = ?
		` + BatchUpdateConditions

	RollbackCommitTransaction = BatchUpdateTables +
		` SET saFrom.balance = saFrom.balance + authFrom.fund_out_amount,
            saTo.balance = saTo.balance - authTo.fund_in_amount,
			authFrom.status = ?,
			authTo.status = ?,
			saTo.total_monthly_fund_in = saTo.total_monthly_fund_in - authTo.fund_in_amount 
		` + BatchUpdateConditions

	UpdateTotalMonthlyFundIn = `update saving_account set fund_in_end_period = ?, total_monthly_fund_in = ? where card_no = ?`

	InsertAccAuth = `
		INSERT INTO saving_account_amount_authorization (transaction_id, fund_in_amount, status, 
	    fund_out_amount, saving_account_id, created_by, created_timestamp, updated_by, updated_datetime) (
		SELECT params.transaction_id, CASE WHEN type = 'source' THEN 0 ELSE params.amount END AS fund_in_amount, params.status, CASE WHEN type = 'source' THEN params.amount ELSE 0 END AS fund_out_amount, 
			CASE WHEN type = 'source' THEN from_sa.id ELSE to_sa.id END AS saving_account_id,params.actor_id AS created_by,CURRENT_TIMESTAMP() AS created_timestamp, params.actor_id AS updated_by, CURRENT_TIMESTAMP() AS updated_datetime 

		FROM (SELECT ? AS transaction_id, ? AS from_product_id, ? AS to_product_id, ? AS from_customer_id, ? AS to_customer_id, ? AS amount, ? AS status, ? AS actor_id)
		AS params
		JOIN saving_account from_sa ON from_sa.customer_id = params.from_customer_id 
			AND from_sa.saving_product_id = params.from_product_id
		JOIN saving_account to_sa ON to_sa.customer_id = params.to_customer_id 
			AND to_sa.saving_product_id = params.to_product_id
		JOIN ( SELECT 'source' AS type
			UNION
			SELECT 'destination' AS type
		) AS type_transaction ON TRUE
		) `

	ValidateTransaction = `
		SELECT params.amount >= (
			SELECT IFNULL ((SELECT spr.value
        	        FROM saving_product_rule spr
  	                WHERE saving_product_id = saTo.saving_product_id
                    AND spr.code = 'min_topup_amount'), 0)
                  )
			AS valid_minimum_amount,
			(((SELECT is_allow_overdraft FROM saving_product WHERE id = saFrom.saving_product_id) = 1 AND (saFrom.balance - saFrom.pending_fund_out - params.amount >= (
                SELECT spr.value
                FROM saving_product_rule spr
                WHERE saving_product_id = saFrom.saving_product_id
                    AND spr.code = 'max_overdraft'                
            ))) OR ((SELECT is_allow_overdraft FROM saving_product WHERE id = saFrom.saving_product_id) = 0 AND (saFrom.balance - saFrom.pending_fund_out - params.amount >= 0))
            )
			AS sufficient_source_balance,
			IFNULL(saTo.balance + saTo.pending_fund_in + params.amount <= (
            SELECT spr.value
            FROM saving_product_rule spr
            WHERE saving_product_id = saTo.saving_product_id
                AND spr.code = CONCAT('kyc[', params.to_kyc_lv , '].max_balance')
            ), TRUE)
            AS valid_receiver_max_balance,
            (IFNULL((CURRENT_TIMESTAMP < saTo.fund_in_end_period AND saTo.total_monthly_fund_in + params.amount <= (
            SELECT spr.value
            FROM saving_product_rule spr
            WHERE saving_product_id = saTo.saving_product_id
                AND spr.code = 'max_monthly_funds_in'
            )),TRUE) OR CURRENT_TIMESTAMP > saTo.fund_in_end_period
        	) 
			AS valid_receiver_max_monthly_fund_in
			FROM (SELECT ? AS amount, ? AS from_customer_id, ? AS from_saving_product_id, ? AS to_customer_id, ? AS to_saving_product_id, ? AS to_kyc_lv) AS params
			JOIN saving_account saFrom ON saFrom.customer_id = params.from_customer_id
				AND saFrom.saving_product_id = params.from_saving_product_id
			JOIN saving_account saTo ON saTo.customer_id = params.to_customer_id
				AND saTo.saving_product_id = params.to_saving_product_id
	`

	UpdateAccountAutoCommit = BatchUpdateTables + `
		SET saFrom.balance = saFrom.balance - authFrom.fund_out_amount,
    		saTo.balance =  saTo.balance + authTo.fund_in_amount,
		saTo.total_monthly_fund_in = CASE WHEN saTo.fund_in_end_period > CURRENT_TIMESTAMP THEN authTo.fund_in_amount ELSE saTo.total_monthly_fund_in + authTo.fund_in_amount END,
		saTo.fund_in_end_period = CASE WHEN saTo.fund_in_end_period > CURRENT_TIMESTAMP THEN LAST_DAY(CURRENT_TIMESTAMP) ELSE saTo.fund_in_end_period END,
		saFrom.updated_timestamp = CURRENT_TIMESTAMP(),
		saTo.updated_timestamp = CURRENT_TIMESTAMP()
		` + BatchUpdateConditions +
		`AND authTo.fund_in_amount >= (
			SELECT IFNULL ((SELECT spr.value
        	        FROM saving_product_rule spr
  	                WHERE saving_product_id = saTo.saving_product_id
                    AND spr.code = 'min_topup_amount'), 0)
                  )
        AND    (((SELECT is_allow_overdraft FROM saving_product WHERE id = saFrom.saving_product_id) = 1 AND (saFrom.balance - saFrom.pending_fund_out - authTo.fund_in_amount >= (
                SELECT spr.value
                FROM saving_product_rule spr
                WHERE saving_product_id = saFrom.saving_product_id
                    AND spr.code = 'max_overdraft'                
            ))) OR ((SELECT is_allow_overdraft FROM saving_product WHERE id = saFrom.saving_product_id) = 0 AND (saFrom.balance - saFrom.pending_fund_out - authTo.fund_in_amount >= 0))
            )
        AND    IFNULL(saTo.balance + saTo.pending_fund_in + authTo.fund_in_amount <= (
            SELECT spr.value
            FROM saving_product_rule spr
            WHERE saving_product_id = saTo.saving_product_id
                AND spr.code = ?
            ), TRUE)
        AND (IFNULL((CURRENT_TIMESTAMP < saTo.fund_in_end_period AND saTo.total_monthly_fund_in + authTo.fund_in_amount <= (
            SELECT spr.value
            FROM saving_product_rule spr
            WHERE saving_product_id = saTo.saving_product_id
                AND spr.code = 'max_monthly_funds_in'
            )),TRUE) OR CURRENT_TIMESTAMP > saTo.fund_in_end_period
        )
	`

	CommitTransaction = `
		UPDATE saving_account saFrom, saving_account saTo, saving_account_amount_authorization authFrom, saving_account_amount_authorization authTo
		JOIN (SELECT ? AS transaction_id, ? as status_filter, ? AS status) AS params ON TRUE
		SET saFrom.balance = saFrom.balance - authFrom.fund_out_amount,
						saFrom.pending_fund_out = saFrom.pending_fund_out - authFrom.fund_out_amount,
			saTo.balance =  saTo.balance + authTo.fund_in_amount,
						saTo.pending_fund_in = saTo.pending_fund_in - authTo.fund_in_amount,
						authFrom.status = params.status,
						authTo.status = params.status,
						saTo.total_monthly_fund_in = CASE WHEN saTo.fund_in_end_period < CURRENT_TIMESTAMP THEN authTo.fund_in_amount ELSE saTo.total_monthly_fund_in + authTo.fund_in_amount END,
						saTo.fund_in_end_period = CASE WHEN saTo.fund_in_end_period < CURRENT_TIMESTAMP THEN LAST_DAY(CURRENT_TIMESTAMP) ELSE saTo.fund_in_end_period END
		WHERE TRUE
		AND authFrom.transaction_id = params.transaction_id
				AND authFrom.transaction_id = authTo.transaction_id
				AND authFrom.saving_account_id != authTo.saving_account_id
				AND authFrom.status = params.status_filter
				AND authTo.status = params.status_filter
				AND saFrom.id = authFrom.saving_account_id
				AND saTo.id = authTo.saving_account_id
				AND saFrom.id != saTo.id
				AND authFrom.fund_in_amount = 0
				AND authTo.fund_out_amount = 0
		`
)

func (m *mariaAccountRepository) GetProductRule(productID uint32) (model.SavingProductRule, error) {

	rows, err := m.Conn.Query(SelectRule, productID)

	if err != nil {
		return nil, err
	}
	if rows.Err() != nil {
		return nil, rows.Err()
	}
	defer rows.Close()

	mp := make(model.SavingProductRule)

	for rows.Next() {
		key, val := "", 0.0
		if err := rows.Scan(&key, &val); err != nil {
			return nil, err
		}
		mp[key] = val
	}

	return mp, err
}

func (m *mariaAccountRepository) InitiateTransaction(ctx context.Context) (*sql.Tx, error) {
	tx, err := m.Conn.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}

	return tx, nil
}

func rollback(tx *sql.Tx) {
	rbErr := tx.Rollback()
	utils.PrintErrorNotNil(rbErr)
}

func (m *mariaAccountRepository) CommitTransaction(tx *sql.Tx) error {

	if err := tx.Commit(); err != nil {
		rollback(tx)
		return err
	}

	return nil
}

func (m *mariaAccountRepository) UpdatePendingFundCustomerSavingAccount(ctx context.Context, tx *sql.Tx, transactionId uint64, toAccKycLevel uint8) error {
	resultUpdatePendingFundCustomerSavingAccount, err := tx.ExecContext(ctx, UpdatePendingFundCustomerSavingAccount, transactionId, model.StatusInProgress, fmt.Sprintf("kyc[%d].max_balance", toAccKycLevel))

	if err != nil {
		rollback(tx)
		return err
	}

	rowsAffected, err := resultUpdatePendingFundCustomerSavingAccount.RowsAffected()

	if err != nil {
		rollback(tx)
		return err
	}

	if rowsAffected != 2 {
		rollback(tx)
		return errors.New("No rows updated for pending fund")
	}

	return nil
}

func (m *mariaAccountRepository) UpdateCustomerSavingAccount(ctx context.Context, tx *sql.Tx, transactionId uint64, toAccKycLevel uint8) error {
	resultUpdateToCustomerSavingAccount, err := tx.ExecContext(ctx, UpdateAccountAutoCommit, transactionId, model.StatusCompleted, fmt.Sprintf("kyc[%d].max_balance", toAccKycLevel))

	if err != nil {
		log.Println(err)
		rollback(tx)
		return err
	}
	rowsAffected, _ := resultUpdateToCustomerSavingAccount.RowsAffected()

	if err != nil {
		rollback(tx)
		return err
	}

	if rowsAffected != 2 {
		rollback(tx)
		return errors.New("No rows updated for customer account")
	}

	return nil
}

func (m *mariaAccountRepository) InsertAccAuth(ctx context.Context, tx *sql.Tx, request *model.AuthTransactionRequest, status uint8, fromCustomerId, toCustomerId, actor uint64) error {
	if _, err := tx.ExecContext(ctx, InsertAccAuth, request.TransactionId, request.FromAccProduct, request.ToAccProduct,
		fromCustomerId, toCustomerId, request.Amount, status, actor); err != nil {
		rollback(tx)
		return err
	}

	return nil
}

func (m *mariaAccountRepository) UpdateTotalMonthlyFundIn(ctx context.Context, cardNo, fundInEndPeriod string, amount float64) error {

	tx, err := m.Conn.BeginTx(ctx, nil)
	if err != nil {
		return err
	}

	_, err = tx.ExecContext(ctx, UpdateTotalMonthlyFundIn, fundInEndPeriod, amount, cardNo)
	if err != nil {
		rollback(tx)
		return err
	}

	if err = tx.Commit(); err != nil {
		rollback(tx)
		return err
	}

	return nil
}

func (m *mariaAccountRepository) CommitAndTransfer(ctx context.Context, transactionId uint64) error {
	if _, err := m.Conn.ExecContext(ctx, CommitTransaction, transactionId, model.StatusInProgress, model.StatusCompleted); err != nil {
		log.Printf("Error when update saving ammount auth: %s\n", err.Error())
		return err
	}

	return nil
}

func (m *mariaAccountRepository) RollbackTransaction(ctx context.Context, transactionId uint64, rollbackType uint8) error {
	tx, err := m.Conn.Begin()
	if err != nil {
		return err
	}
	query := ""
	currentStatus := 0
	if rollbackType == constant.AuthRollbackType {
		query = RollbackAuthTransaction
		currentStatus = model.StatusInProgress
	} else if rollbackType == constant.CommitRollbackType {
		query = RollbackCommitTransaction
		currentStatus = model.StatusCompleted
	} else {
		panic("wrong rollback type " + string(rollbackType))
	}
	res, err := tx.ExecContext(ctx, query, model.StatusFailed, model.StatusFailed, transactionId, currentStatus)

	if err != nil {
		rollback(tx)
		log.Println(err)
		return err
	}
	rowAffected, _ := res.RowsAffected()

	if rowAffected != 4 {
		rollback(tx)
		log.Println("error, updated rows is not 4, :", rowAffected, model.StatusFailed, transactionId, currentStatus)
		return errors.New("error, updated rows is not 4")
	}

	return tx.Commit()
}

//FetchSavingAccount gets the saving account data with respect to the transaction scope
func FetchSavingAccount(tx *sql.Tx, acc *model.SavingAccount) (*model.SavingAccount, error) {

	var row *sql.Row
	if acc.ID != 0 {
		row = tx.QueryRow(getSavingAccountById, acc.ID)
	} else if acc.CustomerID != 0 {
		row = tx.QueryRow(getSavingAccountByCustomerIdAndSavingProductId, acc.CustomerID, acc.SavingProductID)
	} else {
		row = tx.QueryRow(getSavingAccountByCardNoAndSavingProductId, acc.CardNo, acc.SavingProductID)
	}

	accIns := new(model.SavingAccount)

	if err := row.Scan(
		&accIns.ID,
		&accIns.CardNo,
		&accIns.CustomerID,
		&accIns.SavingProductID,
		&accIns.Balance,
		&accIns.Status,
		&accIns.TotalMonthlyFundIn,
		&accIns.FundInEndPeriod,
		&accIns.PendingFundIn,
		&accIns.PendingFundOut,
	); err != nil {
		return acc, err
	}

	return accIns, nil
}

func (m *mariaAccountRepository) FetchSavingAccount(acc *model.SavingAccount) (*model.SavingAccount, error) {

	var row *sql.Rows
	var err error
	accIns := new(model.SavingAccount)

	if acc.ID != 0 {
		row, err = m.Conn.Query(getSavingAccountById, acc.ID)
		if err != nil {
			return accIns, err
		}

		if row.Err() != nil {
			return accIns, row.Err()
		}
		defer row.Close()

	} else if acc.CustomerID != 0 {
		row, err = m.Conn.Query(getSavingAccountByCustomerIdAndSavingProductId, acc.CustomerID, acc.SavingProductID)
		if err != nil {
			return accIns, err
		}

		if row.Err() != nil {
			return accIns, row.Err()
		}
		defer row.Close()

	} else {
		row, err = m.Conn.Query(getSavingAccountByCardNoAndSavingProductId, acc.CardNo, acc.SavingProductID)
		if err != nil {
			return accIns, err
		}

		if row.Err() != nil {
			return accIns, row.Err()
		}
		defer row.Close()

	}

	for row.Next() {
		if err = row.Scan(
			&accIns.ID,
			&accIns.CardNo,
			&accIns.CustomerID,
			&accIns.SavingProductID,
			&accIns.Balance,
			&accIns.Status,
			&accIns.TotalMonthlyFundIn,
			&accIns.FundInEndPeriod,
			&accIns.PendingFundIn,
			&accIns.PendingFundOut,
		); err != nil {
			return acc, err
		}
	}
	return accIns, nil
}

func (m *mariaAccountRepository) ValidateFundTransfer(
	amount float64,
	fromCustomerId uint64,
	fromSavingProductId uint32,
	toCustomerId uint64,
	toSavingProductId uint32,
	toKycLv uint8,
) (map[string]bool, error) {

	validMinimumAmount, sufficientSourceBalance, validReceiverMaxBalance, validReceiverMaxMonthlyFundIn := false, false, false, false

	row := m.Conn.QueryRow(ValidateTransaction, amount, fromCustomerId, fromSavingProductId, toCustomerId, toSavingProductId, toKycLv)
	if err := row.Scan(
		&validMinimumAmount, &sufficientSourceBalance, &validReceiverMaxBalance, &validReceiverMaxMonthlyFundIn,
	); err != nil {
		return nil, err
	}

	return map[string]bool{
		"valid_minimum_amount":               validMinimumAmount,
		"sufficient_source_balance":          sufficientSourceBalance,
		"valid_receiver_max_balance":         validReceiverMaxBalance,
		"valid_receiver_max_monthly_fund_in": validReceiverMaxMonthlyFundIn,
	}, nil
}

func (m *mariaAccountRepository) GetSavingAccountByTransactionId(transactionId uint64) ([]*model.SavingAccountWithType, error) {
	rows, err := m.Conn.Query(GetSavingAccountByTransactionId, transactionId)

	if err != nil {
		return nil, err
	}

	if rows.Err() != nil {
		return nil, rows.Err()
	}

	defer rows.Close()
	var savingAccountsWithType []*model.SavingAccountWithType

	for rows.Next() {
		var savingAccountWithType model.SavingAccountWithType

		if err := rows.Scan(&savingAccountWithType.ID,
			&savingAccountWithType.CardNo, &savingAccountWithType.CustomerID, &savingAccountWithType.SavingProductID,
			&savingAccountWithType.Balance, &savingAccountWithType.TotalMonthlyFundIn, &savingAccountWithType.FundInEndPeriod, &savingAccountWithType.PendingFundIn,
			&savingAccountWithType.PendingFundOut, &savingAccountWithType.Status, &savingAccountWithType.CreatedBy, &savingAccountWithType.CreatedTimestamp,
			&savingAccountWithType.UpdatedBy, &savingAccountWithType.UpdatedTimestamp, &savingAccountWithType.IsDefaultAccount, &savingAccountWithType.Type); err != nil {

			return nil, err
		}

		savingAccountsWithType = append(savingAccountsWithType, &savingAccountWithType)
	}

	return savingAccountsWithType, nil
}
