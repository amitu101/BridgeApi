package constant

const (
	AuthRollbackType   = 1
	CommitRollbackType = 2

	KycLevelUnverified = int32(1)
	KycLevelVerified   = int32(2)
)

const (
	StatusActive   = 1
	StatusInactive = 0
)
