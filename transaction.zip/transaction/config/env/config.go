package env

import (
	"fmt"
	"os"
	"strings"

	"github.com/spf13/viper"
)

type Config interface {
	GetString(key string) string
	GetInt(key string) int
	GetBool(key string) bool
	GetStringSlice(key string) []string
	Init()
}

type viperConfig struct {
}

func (v *viperConfig) Init() {
	viper.SetEnvPrefix(`transaction`)
	viper.AutomaticEnv()

	env := os.Getenv("ENV")

	replacer := strings.NewReplacer(`.`, `_`)
	viper.SetEnvKeyReplacer(replacer)
	viper.SetConfigType(`json`)
	if env != "" {
		viper.SetConfigFile(fmt.Sprintf(`config.%s.json`, env))
	} else {
		viper.SetConfigFile(`config.json`)
	}

	err := viper.ReadInConfig()

	if err != nil {
		panic(err)
	}

}

func (v *viperConfig) GetString(key string) string {
	return viper.GetString(key)
}

func (v *viperConfig) GetStringSlice(key string) []string {
	return viper.GetStringSlice(key)
}

func (v *viperConfig) GetInt(key string) int {
	return viper.GetInt(key)
}

func (v *viperConfig) GetBool(key string) bool {
	return viper.GetBool(key)
}

func NewViperConfig() Config {
	v := &viperConfig{}
	v.Init()
	return v
}
