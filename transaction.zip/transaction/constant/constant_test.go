package constant

import (
	"testing"
)

//make sure constant and grpc sync
func TestGetEventTypeKey(t *testing.T) {
	if GetEventTypeKey(1) != "TOPUP" {
		t.Errorf("TOPUP constant not match")
	}
	if GetEventTypeKey(2) != "WITHDRAW" {
		t.Errorf("WITHDRAW constant not match")
	}
	if GetEventTypeKey(3) != "PAYMENT" {
		t.Errorf("PAYMENT constant not match")
	}
	if GetEventTypeKey(4) != "TRANSFER" {
		t.Errorf("TRANSFER constant not match")
	}
}
