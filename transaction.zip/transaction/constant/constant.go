package constant

import (
	"errors"
	"time"
)

//status code
const (
	NominalNotValid             = "0006"
	ExceedsMaximumBalance       = "0015"
	MonthlyMaxExceedsAmount     = "2025"
	InternalSystemError         = "0005"
	SuccessCode                 = "0200"
	ReferenceIdAlreadyUsed      = "0009"
	InvalidStatus               = "0010"
	InvalidTransactionEventType = "0011"
	TransactionAlreadyRefunded  = "0012"
	SuccessCallingAccountAuth   = 11

	SuccessCallingAccountCommit    = 21
	SuccessCallingBookkeeperCommit = 22
	GeneralSuccessCode             = 200
	GeneralSuccessString           = "success"

	InvalidPasscode = "invalid passcode"
)

var InvalidPasscodeError = errors.New(InvalidPasscode)

//Time format layout
const (
	TimeLayout = time.RFC3339
)

//Transaction Type
const (
	CASH_IN  = "1"
	CASH_OUT = "2"
)

var TransferStatus = map[string]uint64{
	"0200": 200,
	"0015": 500,
	"0006": 500,
	"0001": 400,
	"0005": 500,
	"0009": 500,
	"0010": 500,
	"0011": 500,
}

var TransferErrorStatus = map[string]string{
	"0001": "INSUFFICIENT_BALANCE",
	"0005": "INTERNAL_SYSTEM_ERROR",
	"0006": "NOMINAL_NOT_VALID",
	"0009": "CLIENT_REFERENCE_ID_USED",
	"0015": "EXCEEDS_MAXIMUM_BALANCE",
	"0500": "INTERNAL_SYSTEM_ERROR",
	"0200": "SUCCESS",
	"0300": "INVALID_REFERENCE_CODE",
	"0011": "INVALID_TRANSACTION_EVENT",
	"0010": "INVALID_STATUS",
	"0012": "TRANSACTION_ALREADY_REFUNDED",
}

var TransferErrorDesc = map[string]string{
	"0001": "Insufficient Balance",
	"0006": "Nominal not valid",
	"0015": "Exceeds maximum balance",
	"0500": "Internal server error",
	"0200": "Success",
	"0300": "Invalid reference code",
	"0009": "Client reference id is already used",
	"0011": "Invalid transaction event",
	"0010": "Invalid status",
}

//saving account transaction and account transfer transaction status constant

var statusMap = map[string]uint8{
	"CREATED":     0, //neutral state, in case failure, we make the status to 0 instead deleting it
	"IN_PROGRESS": 1,
	"SUCCESS":     2,
	"FAILED":      3,
}

func GetStatusValue(key string) uint8 {
	if _, ok := statusMap[key]; !ok {
		return 0
	}
	return statusMap[key]
}

func GetStatusKey(value uint8) string {
	for key, element := range statusMap {
		if value == element {
			return key
		}
	}
	return ""
}

//saving account transaction transaction type constant
var transactionTypeMap = map[string]uint8{
	"CASH_IN":  1,
	"CASH_OUT": 2,
}

func GetTransactionTypeValue(key string) uint8 {
	if _, ok := transactionTypeMap[key]; !ok {
		return 0
	}
	return transactionTypeMap[key]
}

func GetTransactionTypeKey(value uint8) string {
	for key, element := range transactionTypeMap {
		if value == element {
			return key
		}
	}
	return ""
}

//event type id constant
var eventTypeMap = map[string]uint16{
	"TOPUP":              1,
	"WITHDRAW":           2,
	"PAYMENT":            3,
	"PAYMENT_AT_PARTNER": 301,
	"TRANSFER":           4,
	"REFUND":             5,
}

func GetEventTypeValue(key string) uint16 {
	if _, ok := eventTypeMap[key]; !ok {
		return 0
	}
	return eventTypeMap[key]
}

func GetEventTypeKey(value uint16) string {
	for key, element := range eventTypeMap {
		if value == element {
			return key
		}
	}
	return ""
}

//journal type constant
var journalTypeMap = map[string]uint32{
	"TOPUP":   1,
	"PAYMENT": 2,
	"REFUND":  3,
}

func GetJournalTypeValue(key string) uint32 {
	if _, ok := journalTypeMap[key]; !ok {
		return 0
	}
	return journalTypeMap[key]
}

func GetJournalTypeKey(value uint32) string {
	for key, element := range journalTypeMap {
		if value == element {
			return key
		}
	}
	return ""
}

var TransactionType = map[uint8]string{
	1: "CREDIT",
	2: "DEBIT",
}
var TransactionStatus = map[uint8]string{
	1: "PENDING",
	2: "SUCCESS",
	3: "FAILED",
}

var Token = map[string]string{
	"ALG": "ES256",
}
