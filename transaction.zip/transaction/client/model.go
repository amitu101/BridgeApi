package client

type TransactionDataByID struct {
	PartnerReferenceID string
	FromAccountID      uint64
	ToAccountID        uint64
	Amount             float64
	TransactionType    uint32
	LocationInfo       string
	Status             uint32
	Description        string
	EventTypeID        uint32
	CreatedTimestamp   string
	FromProductID      uint32
	ToProductID        uint32
}
type RefundPaymentRequest struct {
	TransactionID      uint64
	PartnerReferenceID string
	Description        string
	LocationInfo       string
}
