package client

import (
	"context"
	"log"

	"git.capitalx.id/dimii/transaction/proto"
	"github.com/shopspring/decimal"
	"google.golang.org/grpc"
)

type GetTransactionIdRequest struct {
	ClientReferenceId string
}

type InsertFundTransferRequest struct {
	LocationInfo       string
	PartnerReferenceId string
	FromAccountProduct uint32
	FromCustomerId     uint64
	FromCustomerCardNo string
	ToAccountProduct   uint32
	ToCustomerId       uint64
	ToCustomerCardNo   string
	Amount             decimal.Decimal
	Description        string
	IsCommit           uint32
	EventType          uint16
}

type FundTransferResponse struct {
	StatusCode        string
	Description       string
	TransactionId     uint64
	TransactionStatus string
}

type transactionClient struct {
	conn   *grpc.ClientConn
	client proto.TransactionHandlerClient
}

type TransactionClientService interface {
	ValidateFundTransfer(ctx context.Context, request InsertFundTransferRequest) (FundTransferResponse, error)
	InsertFundTransfer(ctx context.Context, request InsertFundTransferRequest) (FundTransferResponse, error)
	CommitFundTransfer(ctx context.Context, transactionId uint64) (FundTransferResponse, error)
	GetTransactionDataById(ctx context.Context, transactionID uint64) (TransactionDataByID, error)
	PaymentRefund(ctx context.Context, request RefundPaymentRequest) (FundTransferResponse, error)
	Close() error
}

func (c transactionClient) Close() error {
	return c.conn.Close()
}

func (c transactionClient) ValidateFundTransfer(ctx context.Context, request InsertFundTransferRequest) (FundTransferResponse, error) {
	param := proto.InsertFundTransferRequest{
		PartnerReferenceId: request.PartnerReferenceId,
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCustomerCardNo: request.FromCustomerCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCustomerCardNo:   request.ToCustomerCardNo,
		Amount:             request.Amount.String(),
		Description:        request.Description,
	}
	response, err := c.client.ValidateFundTransfer(ctx, &param)

	if err != nil {
		return FundTransferResponse{}, nil
	}
	responseModel := FundTransferResponse{
		StatusCode:        response.StatusCode,
		Description:       response.Description,
		TransactionId:     response.TransactionId,
		TransactionStatus: response.TransactionStatus,
	}
	return responseModel, nil
}

func (c transactionClient) InsertFundTransfer(ctx context.Context, request InsertFundTransferRequest) (FundTransferResponse, error) {
	param := proto.InsertFundTransferRequest{
		PartnerReferenceId: request.PartnerReferenceId,
		LocationInfo:       request.LocationInfo,
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCustomerCardNo: request.FromCustomerCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCustomerCardNo:   request.ToCustomerCardNo,
		Amount:             request.Amount.String(),
		Description:        request.Description,
		IsCommit:           request.IsCommit,
		EventType:          proto.InsertFundTransferRequest_EventType(request.EventType),
	}
	response, err := c.client.InsertFundTransfer(ctx, &param)

	if err != nil {
		return FundTransferResponse{}, nil
	}
	responseModel := FundTransferResponse{
		StatusCode:        response.StatusCode,
		Description:       response.Description,
		TransactionId:     response.TransactionId,
		TransactionStatus: response.TransactionStatus,
	}
	return responseModel, nil
}
func (c transactionClient) CommitFundTransfer(ctx context.Context, transactionId uint64) (FundTransferResponse, error) {
	param := proto.CommitTransferRequest{
		TransactionId: transactionId,
	}

	response, err := c.client.CommitFundTransfer(ctx, &param)

	if err != nil {
		return FundTransferResponse{}, nil
	}
	responseModel := FundTransferResponse{
		StatusCode:        response.StatusCode,
		Description:       response.Description,
		TransactionId:     response.TransactionId,
		TransactionStatus: response.TransactionStatus,
	}
	return responseModel, nil
}

func (c transactionClient) GetTransactionDataById(ctx context.Context, transactionId uint64) (TransactionDataByID, error) {
	param := proto.GetTransactionDataByIdRequest{
		TransactionId: transactionId,
	}
	transactionData, err := c.client.GetTransactionDataById(ctx, &param)
	if err != nil {
		log.Printf("Failed to getTransactionDetail, %s", err)
		return TransactionDataByID{}, err
	}
	return TransactionDataByID{
		PartnerReferenceID: transactionData.PartnerReferenceId,
		FromAccountID:      transactionData.FromAccountId,
		ToAccountID:        transactionData.ToAccountId,
		Amount:             transactionData.Amount,
		TransactionType:    transactionData.TransactionType,
		LocationInfo:       transactionData.LocationInfo,
		Status:             transactionData.Status,
		Description:        transactionData.Description,
		EventTypeID:        transactionData.EventTypeId,
		CreatedTimestamp:   transactionData.CreatedTimestamp,
		FromProductID:      transactionData.FromProductId,
		ToProductID:        transactionData.ToProductId,
	}, err

}

func (c transactionClient) PaymentRefund(ctx context.Context, request RefundPaymentRequest) (FundTransferResponse, error) {
	param := proto.RefundPaymentRequest{
		TransactionId:      request.TransactionID,
		PartnerReferenceId: request.PartnerReferenceID,
		Description:        request.Description,
		LocationInfo:       request.LocationInfo,
	}
	refundResponse, err := c.client.RefundPayment(ctx, &param)
	if err != nil {
		log.Printf("Failed to refund, %s", err)
		return FundTransferResponse{}, err
	}
	return FundTransferResponse{
		StatusCode:        refundResponse.StatusCode,
		Description:       refundResponse.Description,
		TransactionId:     refundResponse.TransactionId,
		TransactionStatus: refundResponse.TransactionStatus,
	}, nil
}

func NewTransactionClient(address string) (TransactionClientService, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}

	client := proto.NewTransactionHandlerClient(conn)

	return &transactionClient{conn: conn, client: client}, nil
}
