package utils

import (
	"encoding/json"
	"log"
)

func PrintErrorNotNil(err error) {
	if err != nil {
		log.Println(err)
	}
}

func StructToString(data interface{}) string {
	msg, _ := json.Marshal(data)
	return string(msg)
}
