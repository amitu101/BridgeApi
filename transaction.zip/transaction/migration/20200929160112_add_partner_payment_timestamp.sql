-- +goose Up
-- SQL in this section is executed when the migration is applied.
ALTER TABLE transaction_event ADD partner_payment_timestamp BIGINT UNSIGNED NOT NULL default 0 AFTER partner_reference_id;

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
ALTER TABLE transaction_event DROP COLUMN partner_payment_timestamp