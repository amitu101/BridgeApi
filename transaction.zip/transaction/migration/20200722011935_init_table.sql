-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE IF NOT EXISTS saving_account_transaction (
  id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
  saving_account_id BIGINT UNSIGNED NOT NULL,
  transaction_type INT UNSIGNED NOT NULL,
  transaction_datetime DATETIME,
  amount DECIMAL(20,4) NOT NULL,
  status TINYINT NOT NULL,
  description VARCHAR(100) NULL DEFAULT NULL,
  created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  committed_by BIGINT UNSIGNED NULL DEFAULT NULL,
  committed_timestamp TIMESTAMP NULL DEFAULT NULL,
  transaction_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE (transaction_id, transaction_type)
);

CREATE TABLE IF NOT EXISTS transaction_event (
  id BIGINT UNSIGNED NOT NULL,
  transaction_datetime TIMESTAMP NOT NULL,
  event_type_id SMALLINT UNSIGNED NOT NULL,
  amount DECIMAL(20,4) NOT NULL,
  location_info VARCHAR(200) NULL,
  partner_id BIGINT(20) NOT NULL,
  partner_reference_id VARCHAR(200) NOT NULL,
  description VARCHAR(200) NULL DEFAULT NULL,
  status TINYINT NOT NULL,
  sub_status TINYINT NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
  committed_by BIGINT UNSIGNED NULL DEFAULT NULL,
  committed_timestamp TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id)
);

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP TABLE IF EXISTS client_reference_id_mapping;
DROP TABLE IF EXISTS saving_account_transaction;
DROP TABLE IF EXISTS account_transfer_transaction;
