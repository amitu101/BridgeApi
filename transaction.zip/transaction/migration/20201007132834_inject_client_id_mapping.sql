-- +goose Up
-- SQL in this section is executed when the migration is applied.
INSERT INTO client_id_mapping
(client_id, partner_id, created_by, created_timestamp)
VALUES('public.alfagift.test', 13004, 0, CURRENT_TIMESTAMP());

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DELETE FROM client_id_mapping WHERE `client_id` = 'public.alfagift.test' AND `partner_id` = 13004;
