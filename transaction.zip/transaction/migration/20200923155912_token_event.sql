-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE IF NOT EXISTS token_event (
    id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
    token TEXT NOT NULL,
    status VARCHAR(20) NOT NULL,
    count int NOT NULL,
    created_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP(),
    updated_timestamp TIMESTAMP NULL,
    blocked_until_timestamp TIMESTAMP NULL,
    PRIMARY KEY (id)
);

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP TABLE IF EXISTS token_event;