-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE IF NOT EXISTS client_id_mapping (
  client_id TEXT NOT NULL,
  partner_id BIGINT(20) NOT NULL,
  created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
);
-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP TABLE IF EXISTS client_id_mapping;
