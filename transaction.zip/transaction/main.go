package main

import (
	"crypto/tls"
	"database/sql"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	common "git.capitalx.id/core/common/grpc"
	commonHttp "git.capitalx.id/core/common/http"
	tls2 "git.capitalx.id/core/common/tls"
	coreConfig "git.capitalx.id/core/config"
	vaultCfg "git.capitalx.id/core/config/vault"
	viperCfg "git.capitalx.id/core/config/viper"
	rds "git.capitalx.id/core/messaging/redis"
	userClient "git.capitalx.id/core/user/client"
	accountClient "git.capitalx.id/dimii/account/client"
	bookkeeperClient "git.capitalx.id/dimii/bookkeeper/client"
	bookkeeperService "git.capitalx.id/dimii/bookkeeper/service"
	customerClient "git.capitalx.id/dimii/customer/client"
	_ "git.capitalx.id/dimii/transaction/client"
	restHandler "git.capitalx.id/dimii/transaction/common"
	deliveryGrpc "git.capitalx.id/dimii/transaction/delivery/grpc"
	HandlerHTTP "git.capitalx.id/dimii/transaction/delivery/http"

	"git.capitalx.id/core/common/mysql"
	"git.capitalx.id/core/messaging"
	"git.capitalx.id/core/messaging/kafka"
	"git.capitalx.id/dimii/transaction/repository"
	"git.capitalx.id/dimii/transaction/service"
	"git.capitalx.id/dimii/transaction/utils"
	"github.com/Shopify/sarama"
	"github.com/go-redis/redis/v7"
	"google.golang.org/grpc"
)

var config coreConfig.Config

func init() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	os.Setenv("GRPC_GO_RETRY", "on")
}

func getConfig() (coreConfig.Config, error) {
	address := os.Getenv("VAULT_ADDR")
	token := os.Getenv("VAULT_TOKEN")

	if address != "" && token != "" {
		config, err := vaultCfg.GetConfig("transaction")

		if err == nil {
			return config, nil
		} else {
			return nil, err
		}
	}
	return viperCfg.NewConfig("transaction", "config.json")
}

func getDatabase() (*sql.DB, error) {
	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	return mysql.DB(dbConfig)
}
func getCustomerClient() (customerClient.CustomerClient, error) {
	customerClientAddr := config.GetString(`server.customer_service_address`)
	return customerClient.NewCustomerClient(customerClientAddr)
}

func getAccountTransactionClient() (accountClient.AccountTransactionClient, error) {
	transactionAddress := config.GetString(`server.account_service_address`)

	transactionServiceClient, err := accountClient.NewAccountTransactionClient(transactionAddress)

	return transactionServiceClient, err
}

func getBookkeeperServiceClient() (bookkeeperService.Service, error) {
	bookkeeperAddress := config.GetString(`server.bookkeeper_service_address`)

	return bookkeeperClient.NewCustomerAccountClient(bookkeeperAddress)
}

func getAccountManagementClient() (accountClient.AccountClient, error) {
	accountClientAddr := config.GetString(`server.account_service_address`)
	return accountClient.NewAccountClient(accountClientAddr)
}

func getUserClient() (userClient.UserClient, error) {
	userClientAddr := config.GetString(`server.user_service_address`)
	return userClient.NewUserClient(userClientAddr)
}

func getKafkaConfig(username, password string, tlsConfig *tls.Config) *sarama.Config {
	kafkaConfig := sarama.NewConfig()
	kafkaConfig.Producer.Return.Successes = true
	kafkaConfig.Net.DialTimeout = 5 * time.Second
	kafkaConfig.Net.WriteTimeout = 5 * time.Second

	if tlsConfig != nil {
		kafkaConfig.Net.TLS.Enable = true
		kafkaConfig.Net.TLS.Config = tlsConfig
	}

	if username != "" {
		kafkaConfig.Net.SASL.Enable = true
		kafkaConfig.Net.SASL.User = username
		kafkaConfig.Net.SASL.Password = password
	}
	return kafkaConfig
}

func getKafkaClient(kafkaAddresses []string) (messaging.Client, error) {
	kafkaCa := config.GetBinary("kafka.ca")
	kafkaCert := config.GetBinary("kafka.cert")
	kafkaKey := config.GetBinary("kafka.key")

	tlsConfig := tls2.WithCertificate(kafkaCa, kafkaCert, kafkaKey, false)
	config := getKafkaConfig("", "", tlsConfig)
	return kafka.NewClient(kafkaAddresses, config)
}

func getRedisClient(address []string, tlsconfig *tls.Config) (messaging.Client, error) {
	options := redis.ClusterOptions{TLSConfig: tlsconfig}
	return rds.NewClusterClient(address, &options)
}

func serveHTTP(addr string, srv service.TransactionService) {
	HandlerHTTP.NewTransactionHandler(srv)
	log.Println("http server started. Listening on port: ", addr)
	if err := http.ListenAndServe(addr, commonHttp.DefaultHandler(http.HandlerFunc(restHandler.Serve))); err != nil {
		utils.PrintErrorNotNil(err)
	}
}

func main() {
	var err error
	config, err = getConfig()

	if err != nil {
		log.Println("Error get config")
		panic(err)
	}

	mdb, err := getDatabase()
	if err != nil {
		log.Println(err)
		return
	}
	defer func() {
		if err := mdb.Close(); err != nil {
			log.Println(err)
		}
	}()

	err = mdb.Ping()
	if err != nil {
		log.Println("error ping database", err)
		return
	}

	customerService, err := getCustomerClient()
	if err != nil {
		log.Println("error connect to customer", err)
		return
	}
	bookkeeperService, err := getBookkeeperServiceClient()

	if err != nil {
		log.Println("error connect bookkeeper", err)
		return
	}

	accountManagementService, err := getAccountManagementClient()
	if err != nil {
		log.Println("error connect account management", err)
		return
	}
	accountTransactionService, err := getAccountTransactionClient()
	if err != nil {
		log.Println("error connect account transaction", err)
		return
	}

	userClient, err := getUserClient()
	if err != nil {
		log.Println("error connect to user", err)
		return
	}

	repo := repository.NewMariaTransactionRepository(mdb)

	var msgClient messaging.Client
	var msgErr error

	redisCluster := config.GetArray("redis.cluster")
	if len(redisCluster) > 0 {
		redisCa := config.GetBinary("redis.ca")
		tlsConfig := tls2.WithCA(redisCa)
		tlsConfig.InsecureSkipVerify = true
		msgClient, msgErr = getRedisClient(redisCluster, tlsConfig)
		log.Println("publisher set to redis cluster", redisCluster)
	} else {
		kafkaAddr := config.GetArray("messaging.host")
		msgClient, msgErr = getKafkaClient(kafkaAddr)
		log.Println("publisher set to kafka cluster", kafkaAddr)
	}

	if msgErr != nil {
		msgClient = nil
		log.Println("Failed to connect to Kafka, will not send notification", msgErr)
	}

	server := service.NewTransactionService(repo, accountTransactionService, accountManagementService, customerService,
		bookkeeperService, msgClient, userClient, config)

	pbServer := grpc.NewServer(common.WithDefault()...)

	deliveryGrpc.NewTransactionServerGrpc(pbServer, server)

	serverAddress := config.GetString(`server.address`)
	serverHttpAddress := config.GetString("server.address.http")
	log.Println("success set delivery server and transaction service and listen")

	go func() {
		common.Serve(serverAddress, pbServer)
	}()

	go serveHTTP(serverHttpAddress, server)
	log.Println("grpc server started. Listening on port: ", serverAddress)
	done := make(chan os.Signal, 1)
	signal.Notify(done, os.Interrupt, syscall.SIGINT, syscall.SIGTERM)

	<-done
	log.Println("All server stopped!")
}
