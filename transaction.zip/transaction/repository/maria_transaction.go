package repository

import (
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"github.com/shopspring/decimal"

	"database/sql"

	"git.capitalx.id/dimii/transaction/constant"
	"git.capitalx.id/dimii/transaction/model"
	"git.capitalx.id/dimii/transaction/utils"
)

type mariaTransactionRepository struct {
	conn *sql.DB
}

func NewMariaTransactionRepository(conn *sql.DB) TransactionRepository {
	return &mariaTransactionRepository{conn}
}

const (
	SavingAccountTransactionColumns = ` id, saving_account_id, transaction_type, 
		transaction_datetime, amount, status, description, transaction_id, created_by, created_timestamp, committed_by, 
		committed_timestamp `
	InsertSavingAccountTransaction                = `INSERT INTO saving_account_transaction(` + SavingAccountTransactionColumns + `) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
	SelectSavingAccountTransaction                = `SELECT ` + SavingAccountTransactionColumns + ` FROM saving_account_transaction`
	SelectSavingAccountTransactionById            = SelectSavingAccountTransaction + ` WHERE id = ?`
	SelectSavingAccountTransactionByTransactionId = SelectSavingAccountTransaction + ` WHERE transaction_id = ?`

	UpdateSavingAccountTransactionStatus = `UPDATE saving_account_transaction SET status=?, committed_timestamp=?, 
 		committed_by=? WHERE id=?`

	TransactionEventColumns = `id, transaction_datetime, event_type_id,
	amount, location_info, partner_id, partner_reference_id, description, status, sub_status, created_by, created_timestamp, committed_by,
	committed_timestamp, is_refunded, partner_payment_timestamp`
	InsertTransactionEvent                            = `INSERT INTO transaction_event(` + TransactionEventColumns + `) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
	SelectTransactionEvent                            = `SELECT ` + TransactionEventColumns + ` FROM transaction_event`
	SelectTransactionEventById                        = SelectTransactionEvent + ` WHERE id = ?`
	SelectTransactionEventByPartnerReferenceId        = SelectTransactionEvent + ` WHERE partner_reference_id = ?`
	SelectTransactionEventByPartnerReferenceIdandDate = SelectTransactionEvent + ` WHERE partner_reference_id = ? and partner_payment_timestamp = ?`
	UpdateTransactionEvent                            = `UPDATE transaction_event SET status=?, sub_status=?, partner_id =?, committed_timestamp=?, 
 		committed_by=? WHERE id=?`
	UpdateTransactionEventRefunded = `UPDATE transaction_event SET is_refunded=? WHERE id=? AND is_refunded=?`

	UpdateTransactionEventAndSavingAccountTransactionsStatus = `
		UPDATE saving_account_transaction sat
		JOIN transaction_event te ON te.id = sat.transaction_id
		JOIN (SELECT ? AS transaction_id, ? AS status, ? AS sub_status) as param 
			ON param.transaction_id = te.id
		SET sat.status = param.status,
			te.status = param.status,
			te.sub_status = param.sub_status
		`

	SelectTransactionEventJoinSavingAccountTransactionByTransactionType = `
	SELECT te.id, te.created_timestamp, te.status, te.amount, te.event_type_id, te.partner_id, sat.saving_account_id, sat.transaction_type
	FROM transaction_event te 
	JOIN saving_account_transaction sat 
		ON te.id = sat.transaction_id 
	WHERE sat.saving_account_id = ? 
		AND te.created_timestamp < ?
		AND (sat.transaction_type = ? or 0 = ?)
		AND (te.status = ? or 0 = ?)
	ORDER BY te.created_timestamp DESC
	LIMIT ?;`
	SelectTransactionDetail = `SELECT te.id, te.created_timestamp, te.status, te.amount, te.event_type_id, te.partner_id, sat.saving_account_id, sat.transaction_type, te.partner_reference_id
		FROM transaction_event te 
		JOIN saving_account_transaction sat 
		ON te.id = sat.transaction_id 
		WHERE te.id = ?
		AND sat.saving_account_id= ?;`
	UpdateSuccessCommitTables = `
		UPDATE saving_account_transaction sat, transaction_event te
		SET sat.status = ?,
			sat.committed_by = ?,
			sat.committed_timestamp = ?,
			te.status = ?,
			te.sub_status = ?,
			te.committed_by = ?,
			te.committed_timestamp = ?
		WHERE
			sat.transaction_id = te.id
			and te.id = ? `
	selectCountByAccount = `select count(*) from saving_account_transaction sat  
	where sat.saving_account_id  in `
	SelectAccountOrderBy = ` and  DATE(sat.transaction_datetime) >= ? and DATE(sat.transaction_datetime) <= ? 
	ORDER by sat.transaction_datetime DESC limit ?,? `
	SelectAccountOrderByCount = ` and  DATE(sat.transaction_datetime) >= ? and DATE(sat.transaction_datetime) <= ? 
	ORDER by sat.transaction_datetime `
	SelectTransactionsListByAcct = `select sat.transaction_id,sat.transaction_datetime ,sat.status,sat.amount, 
	te.event_type_id,sat.transaction_type,te.partner_reference_id ,sat.saving_account_id,dt.saving_account_id as to_saving_account_id,sat.description  
	from saving_account_transaction sat join transaction_event te on 
	sat.transaction_id = te.id 
	join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id and sat.saving_account_id != dt.saving_account_id 
	where sat.saving_account_id in `
	SelectTransactionsListByIdForRef = `select sat.transaction_id,sat.transaction_datetime ,sat.status,sat.amount ,
	te.event_type_id,sat.transaction_type,te.partner_reference_id ,sat.saving_account_id,dt.saving_account_id as to_saving_account_id,sat.description  
	from saving_account_transaction sat join transaction_event te on 
	sat.transaction_id = te.id 
	join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id 
	where te.partner_reference_id = ? 
	and sat.transaction_type = 2 and dt.transaction_type =1 ` + SelectAccountOrderBy
	SelectTransactionsHistListById = `select sat.transaction_id,sat.transaction_datetime ,sat.status,sat.amount ,
	te.event_type_id,sat.transaction_type,te.partner_reference_id ,sat.saving_account_id,dt.saving_account_id as to_saving_account_id,sat.description   
	from saving_account_transaction sat join transaction_event te on 
	sat.transaction_id = te.id 
	join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id 
	where sat.transaction_id = ? 
	and sat.transaction_type = 2 and dt.transaction_type =1 ` + SelectAccountOrderBy
	SelectAllTransactionsHistList = `select sat.transaction_id,sat.transaction_datetime ,sat.status,sat.amount ,
	te.event_type_id,sat.transaction_type,te.partner_reference_id ,sat.saving_account_id,dt.saving_account_id as to_saving_account_id,sat.description   
	from saving_account_transaction sat join transaction_event te on 
	sat.transaction_id = te.id 
	join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id where 
	sat.transaction_type = 2 and dt.transaction_type =1 ` + SelectAccountOrderBy
	SelectAllTransactionsHistListCount = `select count(*)    
	from saving_account_transaction sat join transaction_event te on 
	sat.transaction_id = te.id 
	join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id where 
	sat.transaction_type = 2 and dt.transaction_type =1 ` + SelectAccountOrderBy

	SelectSavingAccountTransactionBySavingAccountID = `
		SELECT te.event_type_id, sat.transaction_datetime, sat.amount, sat.status, sat.transaction_id 
		FROM saving_account_transaction sat 
		JOIN transaction_event te on sat.transaction_id = te.id  
		WHERE saving_account_id=? ORDER BY transaction_datetime DESC LIMIT ?;`

	SelectTransactionsHistListByOnlyByID = `select sat.transaction_id,sat.transaction_datetime ,sat.status,sat.amount ,
		te.event_type_id, sat.transaction_type, te.partner_reference_id ,sat.saving_account_id,dt.saving_account_id as to_saving_account_id,sat.description   
		from saving_account_transaction sat join transaction_event te on 
		sat.transaction_id = te.id 
		join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id 
		where sat.transaction_id = ? 
		and sat.transaction_type = ? and dt.transaction_type = ? `

	SelectTokenEventCount = `SELECT count(*) FROM token_event WHERE token = ?`                                   // #nosec
	SelectTokenEvent      = `SELECT status,count,blocked_until_timestamp,token FROM token_event WHERE token = ?` // #nosec
	UpdateTokenEvent      = `UPDATE token_event 
	SET 
		status = ?, 
		count = ?, 
		blocked_until_timestamp = ?,
		updated_timestamp = ?
	WHERE 
		token = ?`
	DeleteTokenEvent       = `DELETE FROM token_event WHERE token = ?`
	SavingTokenEvenColumns = `token, status, count, created_timestamp, updated_timestamp` // #nosec
	InsertTokenEvent       = `INSERT INTO  token_event(` + SavingTokenEvenColumns + `) VALUES (?, ?, ?, ?, ?)`
	SelectTransactionByID  = `select te.partner_reference_id ,sat.saving_account_id,dt.saving_account_id as to_saving_account_id,
    sat.amount ,sat.transaction_type,te.location_info ,sat.status,sat.description ,te.event_type_id , sat.created_timestamp   
	from saving_account_transaction sat join transaction_event te on 
	sat.transaction_id = te.id 
	join  saving_account_transaction dt on dt.transaction_id = sat.transaction_id 
	where sat.transaction_id = ? 
	and sat.transaction_type = ` + constant.CASH_OUT + ` and dt.transaction_type = ` + constant.CASH_IN
	GetPartnerId = `SELECT partner_id FROM client_id_mapping WHERE client_id = ?`
)

func (mdb *mariaTransactionRepository) InsertSavingAccountTransaction(satList ...model.SavingAccountTransaction) (uint64, error) {
	params := make([]interface{}, 0)
	for i := 0; i < len(satList); i++ {
		params = append(params, satList[i].Id)
		params = append(params, satList[i].SavingAccountId)
		params = append(params, satList[i].TransactionType)
		params = append(params, satList[i].TransactionDatetime)
		params = append(params, satList[i].Amount)
		params = append(params, satList[i].Status)
		params = append(params, satList[i].Description)
		params = append(params, satList[i].TransactionId)
		params = append(params, satList[i].CreatedBy)
		params = append(params, satList[i].CreatedTimestamp)
		params = append(params, satList[i].CommittedBy)
		params = append(params, satList[i].CommittedTimestamp)
	}
	query := InsertSavingAccountTransaction + strings.Repeat(`,(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, len(satList)-1)
	row, err := mdb.conn.Exec(query, params...)

	if err != nil {
		return 0, err
	}

	lastInsertId, err := row.LastInsertId()
	return uint64(lastInsertId), err
}

func (mdb *mariaTransactionRepository) GetSavingAccountTransactionList(query string, params ...interface{}) ([]model.SavingAccountTransaction, error) {
	rows, err := mdb.conn.Query(query, params...)
	var satList []model.SavingAccountTransaction

	if err != nil {
		return satList, err
	}
	if rows.Err() != nil {
		return satList, rows.Err()
	}
	for rows.Next() {
		var sat model.SavingAccountTransaction
		err = rows.Scan(&sat.Id, &sat.SavingAccountId, &sat.TransactionType, &sat.TransactionDatetime, &sat.Amount, &sat.Status,
			&sat.Description, &sat.TransactionId, &sat.CreatedBy, &sat.CreatedTimestamp, &sat.CommittedBy, &sat.CommittedTimestamp)
		if err != nil {
			return nil, err
		}
		satList = append(satList, sat)
	}
	defer rows.Close()
	return satList, nil
}
func (mdb *mariaTransactionRepository) GetAllSavingAccountTransaction() ([]model.SavingAccountTransaction, error) {
	return mdb.GetSavingAccountTransactionList(SelectSavingAccountTransaction, nil)
}

func (mdb *mariaTransactionRepository) GetSavingAccountTransactionById(id uint64) (model.SavingAccountTransaction, error) {
	resultList, err := mdb.GetSavingAccountTransactionList(SelectSavingAccountTransactionById, id)
	if err != nil {
		return model.SavingAccountTransaction{}, err
	}
	if len(resultList) == 0 {
		return model.SavingAccountTransaction{}, fmt.Errorf("Saving Account Transaction with id %d not found", id)
	}
	return resultList[0], err
}

//should return with size 2
func (mdb *mariaTransactionRepository) GetSavingAccountTransactionByTransactionId(transactionId uint64) ([]model.SavingAccountTransaction, error) {
	resultList, err := mdb.GetSavingAccountTransactionList(SelectSavingAccountTransactionByTransactionId, transactionId)
	if err != nil {
		return []model.SavingAccountTransaction{}, err
	}
	if len(resultList) != 2 {
		return []model.SavingAccountTransaction{},
			fmt.Errorf("Saving Account Transaction with transaction id %d found %d\n", transactionId, len(resultList))
	}
	return resultList, err
}

func (mdb *mariaTransactionRepository) ExecQuery(query string, args ...interface{}) error {
	_, err := mdb.conn.Exec(query, args...)
	return err
}

func (mdb *mariaTransactionRepository) UpdateSavingAccountTransactionStatus(sat model.SavingAccountTransaction) error {
	_, err := mdb.conn.Exec(UpdateSavingAccountTransactionStatus, sat.Status, sat.CommittedTimestamp,
		sat.CommittedBy, sat.Id)
	return err
}

func (mdb *mariaTransactionRepository) GetTransactionEventList(query string, params ...interface{}) ([]model.TransactionEvent, error) {
	rows, err := mdb.conn.Query(query, params...)
	var attList []model.TransactionEvent

	if err != nil {
		return attList, err
	}

	if rows.Err() != nil {
		return attList, rows.Err()
	}
	for rows.Next() {
		var att model.TransactionEvent
		err = rows.Scan(&att.Id, &att.TransactionDatetime, &att.EventTypeId, &att.Amount, &att.LocationInfo,
			&att.PartnerId, &att.PartnerReferenceId, &att.Description, &att.Status, &att.SubStatus, &att.CreatedBy, &att.CreatedTimestamp,
			&att.CommittedBy, &att.CommittedTimestamp, &att.IsRefunded, &att.PartnerPaymentTimestamp)
		if err != nil {
			return nil, err
		}
		attList = append(attList, att)
	}
	defer rows.Close()
	return attList, nil
}

func (mdb *mariaTransactionRepository) GetTransactionHistoryList(query string, params ...interface{}) ([]model.TransactionHistoryListItem, error) {
	rows, err := mdb.conn.Query(query, params...)
	var attList []model.TransactionHistoryListItem

	if err != nil {
		return attList, err
	}
	if rows.Err() != nil {
		return attList, rows.Err()
	}
	for rows.Next() {
		var att model.TransactionHistoryListItemDB
		err = rows.Scan(&att.TransactionId, &att.TransactionDateTime, &att.TransactionStatus, &att.TransactionAmount,
			&att.TransactionType, &att.TransactionPartnerId, &att.SavingAccountId, &att.TransactionBalanceType)
		if err != nil {
			log.Printf("[maria_transaction] Error when scan transaction history list %s\n", err.Error())
			return nil, err
		}

		transactionDateTimeConverted := att.TransactionDateTime.Format(constant.TimeLayout)

		attConv := model.TransactionHistoryListItem{
			TransactionId:          strconv.FormatUint(att.TransactionId, 10),
			TransactionDatetime:    transactionDateTimeConverted,
			TransactionStatus:      att.TransactionStatus,
			TransactionAmount:      att.TransactionAmount,
			TransactionType:        att.TransactionType,
			TransactionPartnerId:   att.TransactionPartnerId,
			TransactionBalanceType: att.TransactionBalanceType,
		}

		attList = append(attList, attConv)
	}

	defer rows.Close()
	return attList, nil
}

func (mdb *mariaTransactionRepository) GetTransactionHistory(count, savingAccountId uint64, lastCreatedTimeStamp string, transactionBalanceType, status uint8) ([]model.TransactionHistoryListItem, error) {
	var t time.Time
	var err error
	if lastCreatedTimeStamp == "" {
		t = time.Now()
	} else {
		t, err = time.Parse(constant.TimeLayout, lastCreatedTimeStamp)

		if err != nil {
			log.Printf("[maria_transaction] Error when parse time format %s\n", err.Error())
		}
	}

	resultList, err := mdb.GetTransactionHistoryList(SelectTransactionEventJoinSavingAccountTransactionByTransactionType, savingAccountId, t, transactionBalanceType, transactionBalanceType, status, status, count)
	if err != nil {
		log.Printf("[maria_transaction] Error when GetTransactionHistoryList %s\n", err.Error())
		return []model.TransactionHistoryListItem{}, err
	}

	return resultList, err
}

func (mdb *mariaTransactionRepository) GetTransactionDetail(transactionId uint64, savingAccountId uint64) (*model.TransactionDetail, error) {
	rows, err := mdb.conn.Query(SelectTransactionDetail, transactionId, savingAccountId)

	if err != nil {
		log.Printf("Error when GetTransactionDetail %s\n", err.Error())
		return nil, err
	}

	if rows.Err() != nil {
		log.Printf("Error when GetTransactionDetail %s\n", err.Error())
		return nil, err
	}

	var att model.TransactionDetailDB

	attConv := new(model.TransactionDetail)

	for rows.Next() {
		err = rows.Scan(&att.TransactionId, &att.TransactionDateTime, &att.TransactionStatus, &att.TransactionAmount,
			&att.TransactionType, &att.TransactionPartnerId, &att.SavingAccountId, &att.TransactionBalanceType, &att.TransactionReferenceId)
		if err != nil {
			fmt.Println(err)
			return nil, err
		}

		transactionDateTimeConverted := att.TransactionDateTime.Format(constant.TimeLayout)

		attConv = &model.TransactionDetail{
			TransactionId:          strconv.FormatUint(att.TransactionId, 10),
			TransactionDatetime:    transactionDateTimeConverted,
			TransactionStatus:      att.TransactionStatus,
			TransactionAmount:      att.TransactionAmount,
			TransactionType:        att.TransactionType,
			TransactionPartnerId:   att.TransactionPartnerId,
			TransactionBalanceType: att.TransactionBalanceType,
			TransactionReferenceId: att.TransactionReferenceId,
			SavingAccountId:        att.SavingAccountId,
		}

	}

	defer rows.Close()
	return attConv, nil
}

func (mdb *mariaTransactionRepository) GetAllTransactionEvent() ([]model.TransactionEvent, error) {
	return mdb.GetTransactionEventList(SelectTransactionEvent, nil)
}

func (mdb *mariaTransactionRepository) GetTransactionEventById(transactionId uint64) (model.TransactionEvent, error) {
	resultList, err := mdb.GetTransactionEventList(SelectTransactionEventById, transactionId)
	if err != nil {
		return model.TransactionEvent{}, err
	}
	if len(resultList) == 0 {
		return model.TransactionEvent{}, fmt.Errorf("transaction id %d not found", transactionId)
	}

	return resultList[0], nil
}

func (mdb *mariaTransactionRepository) GetTransactionEventByPartnerReferenceId(partnerReferenceId string) (*model.TransactionEvent, error) {
	resultList, err := mdb.GetTransactionEventList(SelectTransactionEventByPartnerReferenceId, partnerReferenceId)
	if err != nil {
		return nil, err
	}
	if len(resultList) == 0 {
		return nil, nil
	}

	return &resultList[0], nil
}

func (mdb *mariaTransactionRepository) InsertTransactionEvent(transaction model.TransactionEvent) error {
	_, err := mdb.conn.Exec(InsertTransactionEvent, transaction.Id, transaction.TransactionDatetime, transaction.EventTypeId,
		transaction.Amount, transaction.LocationInfo, transaction.PartnerId, transaction.PartnerReferenceId,
		transaction.Description, transaction.Status, transaction.SubStatus, transaction.CreatedBy,
		transaction.CreatedTimestamp, transaction.CommittedBy, transaction.CommittedTimestamp, transaction.IsRefunded, transaction.PartnerPaymentTimestamp)
	return err
}

func (mdb *mariaTransactionRepository) UpdateTransactionEventRefunded(transactionID uint64) (int64, error) {
	result, err := mdb.conn.Exec(UpdateTransactionEventRefunded, true, transactionID, false)

	if err != nil {
		return 0, err
	}

	rowsAffected, err := result.RowsAffected()

	if err != nil {
		return 0, err
	}

	return rowsAffected, nil
}

func (mdb *mariaTransactionRepository) UpdateTransactionEvent(te model.TransactionEvent) error {
	_, err := mdb.conn.Exec(UpdateTransactionEvent, te.Status, te.SubStatus, te.PartnerId, te.CommittedTimestamp,
		te.CommittedBy, te.Id)
	return err
}

func (mdb *mariaTransactionRepository) TransactionEventExistsByPartnerReferenceId(partnerReferenceId string) (bool, error) {
	query := fmt.Sprintf("SELECT exists (%s)", SelectTransactionEventByPartnerReferenceId)

	rows, err := mdb.conn.Query(query, partnerReferenceId)
	if err != nil && err != sql.ErrNoRows {
		return false, err
	}
	if rows.Err() != nil {
		log.Println(rows.Err())
		return false, rows.Err()
	}
	defer rows.Close()
	if rows.Next() {
		var exists bool
		err = rows.Scan(&exists)
		if err != nil {
			fmt.Println(err)
			return false, err
		}
		return exists, nil
	}
	return false, nil
}

func (mdb *mariaTransactionRepository) UpdateSuccessCommitTables(transactionId uint64, status, subStatus uint8, committedBy uint64, committedTimestamp time.Time) error {
	tx, err := mdb.conn.Begin()
	if err != nil {
		return err
	}
	res, err := mdb.conn.Exec(UpdateSuccessCommitTables, status, committedBy, committedTimestamp, status, subStatus,
		committedBy, committedTimestamp, transactionId)
	if err != nil {
		return err
	}
	affectedRows, err := res.RowsAffected()
	if affectedRows != 3 || err != nil {
		errRb := tx.Rollback()
		utils.PrintErrorNotNil(errRb)
		return errors.New("rows affected is not equal 3, fail the commit")
	}
	return tx.Commit()
}

func (mdb *mariaTransactionRepository) GetTransactionHistoryByPartnerID(refID string, data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error) {
	var err error
	var transactionHistoryResponse model.TransactionHistoryResponse
	resultList, err := mdb.FetchTransactionHistory(SelectTransactionsListByIdForRef, refID, data.StartDate, data.EndDate, param.Start, param.Count)
	if err != nil {
		log.Printf("[maria_transaction] Error when GetTransactionHistoryByReferenceId %s\n", err.Error())
		return transactionHistoryResponse, err
	}
	transactionHistoryResponse.Data = resultList
	transactionHistoryResponse.Length = len(resultList)
	return transactionHistoryResponse, err
}

func (mdb *mariaTransactionRepository) GetTransactionHistoryByTransactionID(transactionID uint64, data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error) {
	var transactionHistoryResponse model.TransactionHistoryResponse

	resultList, err := mdb.FetchTransactionHistory(SelectTransactionsHistListById, transactionID, data.StartDate, data.EndDate, param.Start, param.Count)
	if err != nil {
		log.Printf("[maria_transaction] Error when GetTransactionHistoryByTransactionID %s\n", err.Error())
		return transactionHistoryResponse, err
	}
	transactionHistoryResponse.Data = resultList
	transactionHistoryResponse.Length = len(resultList)
	return transactionHistoryResponse, err
}

func (mdb *mariaTransactionRepository) GetTransactionsHistoryByOnlyTransactionID(transactionID uint64) (model.TransactionHistoryResponse, error) {
	var transactionHistoryResponse model.TransactionHistoryResponse

	resultList, err := mdb.FetchTransactionHistory(SelectTransactionsHistListByOnlyByID, transactionID, constant.GetTransactionTypeValue("CASH_OUT"), constant.GetTransactionTypeValue("CASH_IN"))
	if err != nil {
		log.Printf("[maria_transaction] Error when GetTransactionsHistoryByOnlyTransactionID %s\n", err.Error())
		return transactionHistoryResponse, err
	}
	transactionHistoryResponse.Data = resultList
	transactionHistoryResponse.Length = len(resultList)
	return transactionHistoryResponse, err
}

func (mdb *mariaTransactionRepository) GetTransactionHistoryByAccountIds(accountIds []uint64, data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error) {
	var transactionHistoryResponse model.TransactionHistoryResponse
	acctParams := make([]interface{}, len(accountIds))
	queryAcc := `(?` + strings.Repeat(",?", len(accountIds)-1) + `)`
	for i, s := range accountIds {
		acctParams[i] = s
	}
	acctParams = append(acctParams, data.StartDate, data.EndDate, param.Start, param.Count)
	query := SelectTransactionsListByAcct + queryAcc + SelectAccountOrderBy
	countQuery := selectCountByAccount + queryAcc + SelectAccountOrderByCount
	resultList, err := mdb.FetchTransactionHistory(query, acctParams...)
	if err != nil {
		log.Printf("[maria_transaction] Error fetcing transaction  Data %s\n", err.Error())
		return transactionHistoryResponse, err
	}
	count, err := mdb.FetchCountForTransaction(countQuery, acctParams[:len(acctParams)-2]...)
	if err != nil {
		log.Printf("[maria_transaction] Error fetching count %s\n", err.Error())
		return transactionHistoryResponse, err
	}
	transactionHistoryResponse.Data = resultList
	transactionHistoryResponse.Length = count

	return transactionHistoryResponse, nil
}

func (mdb *mariaTransactionRepository) GetAllTransactionHistory(data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error) {
	var transactionHistoryResponse model.TransactionHistoryResponse
	query := SelectAllTransactionsHistList
	countQuery := SelectAllTransactionsHistListCount
	resultList, err := mdb.FetchTransactionHistory(query, data.StartDate, data.EndDate, param.Start, param.Count)
	if err != nil {
		log.Println(err)
		return transactionHistoryResponse, err
	}
	count, err := mdb.FetchCountForTransaction(countQuery, data.StartDate, data.EndDate, 0, 1)
	if err != nil {
		log.Println(err)
		return transactionHistoryResponse, err
	}
	transactionHistoryResponse.Data = resultList
	transactionHistoryResponse.Length = count

	return transactionHistoryResponse, nil
}
func (mdb *mariaTransactionRepository) FetchCountForTransaction(query string, params ...interface{}) (int, error) {
	var count int
	rows, err := mdb.conn.Query(query, params...)

	if err != nil {
		return 0, err
	}
	if rows.Err() != nil {
		return 0, rows.Err()
	}
	for rows.Next() {
		err := rows.Scan(&count)
		if err != nil {
			return 0, err
		}
	}
	defer rows.Close()
	return count, nil

}

func (mdb *mariaTransactionRepository) FetchTransactionHistory(query string, params ...interface{}) ([]model.TransactionHistoryDetail, error) {
	var err error
	var rows *sql.Rows
	rows, err = mdb.conn.Query(query, params...)

	if err != nil {
		return nil, err
	}
	if rows.Err() != nil {
		return nil, rows.Err()
	}
	var transactionList []model.TransactionHistoryDetail
	for rows.Next() {
		var data model.TransactionHistoryDataModel
		err := rows.Scan(&data.TransactionId, &data.TransactionDateTime, &data.TransactionStatus, &data.TransactionAmount, &data.TransactionEventType,
			&data.TransactionType, &data.TransactionReferenceId, &data.SavingAccountId, &data.ToSavingAccountId, &data.TransactionDescription)
		if err != nil {
			log.Printf("[maria_transaction] Error when scan transaction  Data %s\n", err.Error())
			return nil, err
		}
		transactionDateTimeConverted := data.TransactionDateTime.Format(constant.TimeLayout)
		transactionHistoryDetail := model.TransactionHistoryDetail{
			TransactionID:          data.TransactionId,
			TransactionDatetime:    transactionDateTimeConverted,
			TransactionStatus:      constant.TransactionStatus[data.TransactionStatus],
			TransactionAmount:      data.TransactionAmount,
			TransactionType:        constant.GetEventTypeKey(data.TransactionEventType),
			TransactionReferenceID: data.TransactionReferenceId,
			SavingAccountID:        data.SavingAccountId,
			TransactionBalanceType: constant.TransactionType[data.TransactionType],
			ToSavingAccountID:      data.ToSavingAccountId,
			TransactionName:        data.TransactionDescription,
		}
		transactionList = append(transactionList, transactionHistoryDetail)
	}
	defer rows.Close()
	return transactionList, nil

}

func (mdb *mariaTransactionRepository) GetTransactionDetailsBySavingAccountID(savingAccountIDs []uint64, limitCount string) (*[]model.LastTransactionDetail, error) {
	var TransactionDetails []model.LastTransactionDetail

	for _, savingAccountID := range savingAccountIDs {

		rows, err := mdb.conn.Query(SelectSavingAccountTransactionBySavingAccountID, savingAccountID, limitCount)

		if err != nil {
			log.Println(savingAccountID, " GetTransactionDetailsBySavingAccountID SQL QUERY : ", err)
			return &TransactionDetails, err
		}
		if rows.Err() != nil {
			return &TransactionDetails, rows.Err()
		}
		defer rows.Close()

		var transactionDetail model.LastTransactionDetail
		transactionDetail.SavingAccountID = fmt.Sprintf("%d", savingAccountID)
		transactionDetail.Transactions = make([]model.TransactionResponse, 0)

		for rows.Next() {
			var status int
			detail := model.Transaction{}
			//transaction_type | transaction_datetime |  amount  | status | transaction_id
			err = rows.Scan(&detail.TransactionType, &detail.TransactionDateTime, &detail.TransactionAmount, &status, &detail.TransactionID)
			if err != nil {
				fmt.Println(savingAccountID, " GetTransactionDetailsBySavingAccountID rows.Scan err: ", err)
				return &TransactionDetails, err
			}
			detail.TransactionStatus = constant.TransactionStatus[uint8(status)]
			resp := model.TransactionResponse{
				TransactionID:       detail.TransactionID,
				TransactionDateTime: detail.TransactionDateTime,
				TransactionStatus:   detail.TransactionStatus,
				TransactionAmount:   detail.TransactionAmount,
				TransactionType:     constant.GetEventTypeKey(detail.TransactionType),
			}
			transactionDetail.Transactions = append(transactionDetail.Transactions, resp)
		}
		// Appending
		TransactionDetails = append(TransactionDetails, transactionDetail)
	}
	return &TransactionDetails, nil
}

func (mdb *mariaTransactionRepository) TokenPresentInTokenEvent(token string) (bool, error) {

	log.Println("Inside TokenPresentInTokenEvent")
	rows, err := mdb.conn.Query(SelectTokenEventCount, token)

	if err != nil {
		log.Println("TokenPresentInTokenEvent SQL Error : ", err)
		return false, err
	}
	if rows.Err() != nil {
		return false, rows.Err()
	}
	var count int
	for rows.Next() {
		err := rows.Scan(&count)
		if err != nil {
			return false, err
		}
	}
	defer rows.Close()
	if count > 0 {
		return true, nil
	}
	return false, nil
}

func (mdb *mariaTransactionRepository) GetDetailsOfTokenEvent(token string) (model.TokenEvent, error) {

	log.Println("Inside GetDetailsOfTokenEvent")
	rows, err := mdb.conn.Query(SelectTokenEvent, token)

	if err != nil {
		log.Println("GetDetailsOfTokenEvent SQL Error : ", err)
		return model.TokenEvent{}, err
	}
	if rows.Err() != nil {
		return model.TokenEvent{}, rows.Err()
	}
	tokenEvent := model.TokenEvent{}
	for rows.Next() {
		err = rows.Scan(&tokenEvent.Status, &tokenEvent.Count, &tokenEvent.BlockedTime, &tokenEvent.Token)
		if err != nil {
			log.Println("GetDetailsOfTokenEvent Error in scanning", err)
			return model.TokenEvent{}, err
		}
	}

	defer rows.Close()

	return tokenEvent, nil
}

func (mdb *mariaTransactionRepository) UpdateDetailsOfTokenEvent(token string, tokenEvent model.TokenEvent) error {

	log.Println("Inside UpdateDetailsOfTokenEvent")
	_, err := mdb.conn.Exec(UpdateTokenEvent, tokenEvent.Status, tokenEvent.Count, tokenEvent.BlockedTime, tokenEvent.UpdatedOn, token)
	if err != nil {
		log.Println("UpdateDetailsOfTokenEvent SQL Error : ", err)
		return err
	}
	return nil
}

func (mdb *mariaTransactionRepository) DeleteTokeninTokenEvent(token string) error {

	log.Println("Inside DeleteTokeninTokenEvent")
	_, err := mdb.conn.Exec(DeleteTokenEvent, token)
	if err != nil {
		log.Println("DeleteTokeninTokenEvent SQL Error : ", err)
		return err
	}
	return nil
}

func (mdb *mariaTransactionRepository) InsertTokenInTokenEvent(tokenEvent model.TokenEvent) error {

	log.Println("Inside InsertTokenInTokenEvent")
	_, err := mdb.conn.Exec(InsertTokenEvent, tokenEvent.Token, tokenEvent.Status, tokenEvent.Count, tokenEvent.CreatedOn, tokenEvent.UpdatedOn)
	if err != nil {
		log.Println("InsertTokenInTokenEvent SQL Error : ", err)
		return err
	}
	return nil
}

func (mdb *mariaTransactionRepository) GetTransactionByTransactionID(transactionID uint64) (*model.TransactionDataByID, error) {
	var err error
	var rows *sql.Rows
	var data model.TransactionDataByID
	rows, err = mdb.conn.Query(SelectTransactionByID, transactionID)

	if err != nil {
		log.Println("Error in fetching Data ", err)
		return nil, err
	}
	if rows.Err() != nil {
		return nil, rows.Err()
	}
	defer rows.Close()
	for rows.Next() {

		err := rows.Scan(&data.PartnerReferenceID, &data.FromAccountID, &data.ToAccountID, &data.Amount, &data.TransactionType,
			&data.LocationInfo, &data.Status, &data.Description, &data.EventTypeID, &data.CreatedTimestamp)
		if err != nil {
			log.Printf("[maria_transaction] Error when scan transaction  Data %s\n", err.Error())
			return &data, err
		}
	}
	return &data, nil
}
func (mdb *mariaTransactionRepository) GetPartnerId(clientId string) (uint64, error) {
	rows, err := mdb.conn.Query(GetPartnerId, clientId)
	if err != nil {
		log.Println("GetPartnerId SQL Error : ", err)
		return 0, err
	}

	if rows.Err() != nil {
		return 0, rows.Err()
	}

	var partnerId uint64

	for rows.Next() {
		err = rows.Scan(&partnerId)
		if err != nil {
			fmt.Println("GetPartnerId Error in scanning", err)
			return 0, err
		}
	}

	defer rows.Close()

	return partnerId, nil
}

func (mdb *mariaTransactionRepository) GetTransactionPaymentInfo(paymentTimestamp, partnerRefID string) (*model.PartnerPaymentInformation, int, error) {
	rows, err := mdb.conn.Query(SelectTransactionEventByPartnerReferenceIdandDate, partnerRefID, paymentTimestamp)
	var partnerPaymentInfo model.PartnerPaymentInformation
	var count int = 0
	if err != nil {
		return &partnerPaymentInfo, count, err
	}

	if rows.Err() != nil {
		return &partnerPaymentInfo, count, rows.Err()
	}

	for rows.Next() {
		var att model.TransactionEvent
		err = rows.Scan(&att.Id, &att.TransactionDatetime, &att.EventTypeId, &att.Amount, &att.LocationInfo,
			&att.PartnerId, &att.PartnerReferenceId, &att.Description, &att.Status, &att.SubStatus, &att.CreatedBy, &att.CreatedTimestamp,
			&att.CommittedBy, &att.CommittedTimestamp, &att.IsRefunded, &att.PartnerPaymentTimestamp)
		if err != nil {
			return nil, count, err
		}

		transactionDateTimeConverted := att.TransactionDatetime.Format(constant.TimeLayout)

		partnerPaymentInfo = model.PartnerPaymentInformation{
			TransactionID:        att.Id,
			PaymentTimestamp:     transactionDateTimeConverted,
			TransactionStatus:    constant.TransactionStatus[att.Status],
			Amount:               att.Amount,
			PartnerReferenceCode: att.PartnerReferenceId,
			TotalAmount:          att.Amount,
			Fee:                  decimal.NewFromInt(0),
			Tax:                  decimal.NewFromInt(0),
		}

		count++
	}

	defer rows.Close()
	return &partnerPaymentInfo, count, nil
}
