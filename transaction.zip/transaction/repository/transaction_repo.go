package repository

import (
	"time"

	"git.capitalx.id/dimii/transaction/model"
)

type TransactionRepository interface {
	ExecQuery(query string, args ...interface{}) error

	InsertTransactionEvent(model.TransactionEvent) error
	GetAllTransactionEvent() ([]model.TransactionEvent, error)
	UpdateTransactionEvent(model.TransactionEvent) error
	UpdateTransactionEventRefunded(transactionId uint64) (int64, error)
	GetTransactionEventById(uint64) (model.TransactionEvent, error)
	GetTransactionEventByPartnerReferenceId(partnerReferenceId string) (*model.TransactionEvent, error)
	TransactionEventExistsByPartnerReferenceId(partnerReferenceId string) (bool, error)

	InsertSavingAccountTransaction(...model.SavingAccountTransaction) (uint64, error)
	GetAllSavingAccountTransaction() ([]model.SavingAccountTransaction, error)
	GetSavingAccountTransactionById(uint64) (model.SavingAccountTransaction, error)
	GetSavingAccountTransactionByTransactionId(uint64) ([]model.SavingAccountTransaction, error)
	UpdateSavingAccountTransactionStatus(model.SavingAccountTransaction) error

	GetTransactionHistory(count, savingAccountId uint64, lastCreatedTimeStamp string, transactionBalanceType, status uint8) ([]model.TransactionHistoryListItem, error)
	GetTransactionDetail(transactionId uint64, savingAccountId uint64) (*model.TransactionDetail, error)
	GetTransactionPaymentInfo(paymentTimestamp, partnerRefID string) (*model.PartnerPaymentInformation, int, error)

	UpdateSuccessCommitTables(transactionId uint64, status, subStatus uint8, committedBy uint64, committedTimestamp time.Time) error
	GetTransactionHistoryByPartnerID(refID string, data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error)
	GetTransactionHistoryByTransactionID(transactionID uint64, data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error)
	GetTransactionsHistoryByOnlyTransactionID(transactionID uint64) (model.TransactionHistoryResponse, error)
	GetTransactionHistoryByAccountIds(accountIds []uint64, data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error)
	GetAllTransactionHistory(data model.TransactionHistoryData, param model.TransactionHistoryParam) (model.TransactionHistoryResponse, error)
	GetTransactionDetailsBySavingAccountID(savingAccountID []uint64, limitCount string) (*[]model.LastTransactionDetail, error)

	TokenPresentInTokenEvent(token string) (bool, error)
	GetDetailsOfTokenEvent(token string) (model.TokenEvent, error)
	UpdateDetailsOfTokenEvent(token string, tokenEvent model.TokenEvent) error
	DeleteTokeninTokenEvent(token string) error
	InsertTokenInTokenEvent(tokenEvent model.TokenEvent) error
	GetTransactionByTransactionID(transactionID uint64) (*model.TransactionDataByID, error)
	GetPartnerId(clientId string) (uint64, error)
}
