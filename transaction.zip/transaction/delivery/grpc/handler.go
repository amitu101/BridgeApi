package grpc

import (
	"context"
	"log"
	"strconv"

	"git.capitalx.id/dimii/transaction/model"
	"git.capitalx.id/dimii/transaction/proto"
	_srv "git.capitalx.id/dimii/transaction/service"
	"github.com/shopspring/decimal"
	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

type server struct {
	service _srv.TransactionService
}

//only consumed by front end yet, so I don't think necessary to create in client
func (s server) P2PTransferInquiry(ctx context.Context, request *proto.P2PTransferRequest) (*proto.P2PTransferResponse, error) {
	resp, err := s.service.P2PTransferInquiry(ctx, &model.P2PTransferRequest{
		Recipient: request.Recipient,
		Amount:    request.Amount,
		Notes:     request.Notes,
	})

	if err != nil {
		return nil, err
	}
	return &proto.P2PTransferResponse{
		RecipientName: resp.RecipientName,
		Amount:        resp.Amount,
		Fee:           0,
		Notes:         resp.Notes,
		SourceOfFund:  resp.SourceOfFund,
		ReferenceNo:   resp.ReferenceNo,
	}, nil
}

func (s server) ValidateFundTransfer(ctx context.Context, request *proto.InsertFundTransferRequest) (*proto.FundTransferResponse, error) {
	log.Printf("Validate %s\n", request.PartnerReferenceId)
	requestModel := model.InsertFundTransferRequest{
		PartnerReferenceId: request.PartnerReferenceId,
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCustomerCardNo: request.FromCustomerCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCustomerCardNo:   request.ToCustomerCardNo,
		Amount:             decimal.RequireFromString(request.Amount),
		Description:        request.Description,
	}
	responseModel := s.service.ValidateFundTransfer(ctx, requestModel)

	response := proto.FundTransferResponse{
		StatusCode:        responseModel.StatusCode,
		Description:       responseModel.Description,
		TransactionId:     responseModel.TransactionId,
		TransactionStatus: responseModel.TransactionStatus,
	}

	return &response, nil
}

func (s server) InsertFundTransfer(ctx context.Context, request *proto.InsertFundTransferRequest) (*proto.FundTransferResponse, error) {
	log.Printf("Insert fund transfer %s\n", request.PartnerReferenceId)

	requestModel := model.InsertFundTransferRequest{
		LocationInfo:            request.LocationInfo,
		PartnerReferenceId:      request.PartnerReferenceId,
		FromAccountProduct:      request.FromAccountProduct,
		FromCustomerId:          request.FromCustomerId,
		FromCustomerCardNo:      request.FromCustomerCardNo,
		ToAccountProduct:        request.ToAccountProduct,
		ToCustomerId:            request.ToCustomerId,
		ToCustomerCardNo:        request.ToCustomerCardNo,
		Amount:                  decimal.RequireFromString(request.Amount),
		Description:             request.Description,
		IsCommit:                request.IsCommit,
		TransactionType:         uint16(request.EventType),
		PartnerPaymentTimestamp: request.PartnerPaymentTimestamp,
	}
	responseModel := s.service.InsertFundTransfer(ctx, requestModel)

	response := proto.FundTransferResponse{
		StatusCode:        responseModel.StatusCode,
		Description:       responseModel.Description,
		TransactionId:     responseModel.TransactionId,
		TransactionStatus: responseModel.TransactionStatus,
	}

	return &response, nil
}

func (s server) CommitFundTransfer(ctx context.Context, request *proto.CommitTransferRequest) (*proto.FundTransferResponse, error) {
	log.Printf("Commit %d\n", request.TransactionId)
	responseModel := s.service.CommitFundTransfer(ctx, request.TransactionId)

	response := proto.FundTransferResponse{
		StatusCode:        responseModel.StatusCode,
		Description:       responseModel.Description,
		TransactionId:     responseModel.TransactionId,
		TransactionStatus: responseModel.TransactionStatus,
	}

	return &response, nil
}

func (s server) GetTransactionHistoryList(ctx context.Context, request *proto.GetTransactionHistoryListRequest) (*proto.GetTransactionHistoryListResponse, error) {
	r := s.service.GetTransactionHistoryItem(ctx, request.CustomerId, request.Count, request.LastCreatedTimestamp, request.SavingProductId, request.CardNo, uint8(request.TransactionBalanceType.Number()), uint8(request.Status.Number()))
	var transactionHistoryList []*proto.TransactionHistoryListItem

	for _, elem := range r {
		var stat proto.TransactionHistoryListItem_TransactionStatus
		var balanceType proto.TransactionHistoryListItem_TransactionBalanceType
		if elem.TransactionStatus == 1 {
			stat = proto.TransactionHistoryListItem_PENDING
		} else if elem.TransactionStatus == 2 {
			stat = proto.TransactionHistoryListItem_SUCCESS
		} else {
			stat = proto.TransactionHistoryListItem_FAILED
		}

		if elem.TransactionBalanceType == 1 {
			balanceType = proto.TransactionHistoryListItem_DEBIT
		} else {
			balanceType = proto.TransactionHistoryListItem_CREDIT
		}

		transactionHistoryList = append(transactionHistoryList, &proto.TransactionHistoryListItem{
			TransactionId:          elem.TransactionId,
			TransactionDateTime:    elem.TransactionDatetime,
			TransactionStatus:      stat,
			TransactionAmount:      elem.TransactionAmount,
			TransactionType:        uint64(elem.TransactionType),
			IconUrl:                elem.IconUrl,
			TransactionName:        elem.TransactionName,
			TransactionBalanceType: balanceType,
			SavingAccountId:        elem.SavingAccountId,
		})
	}
	return &proto.GetTransactionHistoryListResponse{
		TransactionHistoryList: transactionHistoryList,
	}, nil
}

func (s server) GetTransactionDetail(ctx context.Context, request *proto.GetTransactionDetailRequest) (*proto.GetTransactionDetailResponse, error) {
	trxId, err := strconv.ParseUint(request.TransactionId, 10, 64)

	if err != nil {
		log.Println("Failed to parse transactionId")
		return nil, nil
	}

	savingAccountId, _ := strconv.ParseUint(request.SavingAccountId, 10, 64)

	r, err := s.service.GetTransactionDetail(ctx, trxId, request.CardNo, savingAccountId)

	if err != nil {
		log.Printf("Failed to getTransactionDetail, %s", err)
		return nil, err
	}

	var stat proto.GetTransactionDetailResponse_TransactionStatus
	var balanceType proto.GetTransactionDetailResponse_TransactionBalanceType
	if r.TransactionStatus == 1 {
		stat = proto.GetTransactionDetailResponse_PENDING
	} else if r.TransactionStatus == 2 {
		stat = proto.GetTransactionDetailResponse_SUCCESS
	} else {
		stat = proto.GetTransactionDetailResponse_FAILED
	}

	if r.TransactionBalanceType == 1 {
		balanceType = proto.GetTransactionDetailResponse_DEBIT
	} else {
		balanceType = proto.GetTransactionDetailResponse_CREDIT
	}

	trxDetail := &proto.GetTransactionDetailResponse{
		TransactionId:          r.TransactionId,
		TransactionDateTime:    r.TransactionDatetime,
		TransactionStatus:      stat,
		TransactionAmount:      r.TransactionAmount,
		TransactionType:        uint64(r.TransactionType),
		IconUrl:                r.IconUrl,
		TransactionName:        r.TransactionName,
		TransactionBalanceType: balanceType,
		SourceOfFund:           r.SourceOfFund,
		TransactionReferenceId: r.TransactionReferenceId,
		TransactionInfo:        r.TransactionInfo,
		SavingAccountId:        request.SavingAccountId,
	}
	return trxDetail, nil
}

func (s server) GetTransactionDataById(ctx context.Context, req *proto.GetTransactionDataByIdRequest) (*proto.TransactionDataResponse, error) {
	transactionData, err := s.service.GetTransactionByTransactionID(ctx, req.TransactionId)
	if err != nil {
		log.Printf("Failed to getTransactionDetail, %s", err)
		return nil, err
	}

	return &proto.TransactionDataResponse{
		PartnerReferenceId: transactionData.PartnerReferenceID,
		FromAccountId:      transactionData.FromAccountID,
		ToAccountId:        transactionData.ToAccountID,
		Amount:             transactionData.Amount,
		TransactionType:    transactionData.TransactionType,
		LocationInfo:       transactionData.LocationInfo,
		Status:             transactionData.Status,
		Description:        transactionData.Description,
		EventTypeId:        uint32(transactionData.EventTypeID),
		CreatedTimestamp:   transactionData.CreatedTimestamp,
		FromProductId:      transactionData.ToProductID,
		ToProductId:        transactionData.FromProductID,
	}, err
}

func (s server) RefundPayment(ctx context.Context, request *proto.RefundPaymentRequest) (*proto.RefundPaymentResponse, error) {
	refundResponse := s.service.RefundFundTransfer(model.RefundPaymentRequest{
		TransactionID:      request.TransactionId,
		RefundRefernceCode: request.PartnerReferenceId,
		Description:        request.Description,
		LocationInfo:       request.LocationInfo,
	})
	return &proto.RefundPaymentResponse{
		StatusCode:        refundResponse.StatusCode,
		Description:       refundResponse.Description,
		TransactionId:     refundResponse.TransactionId,
		TransactionStatus: refundResponse.TransactionStatus,
	}, nil
}

func NewTransactionServerGrpc(gserver *grpc.Server, transactionService _srv.TransactionService) {
	transactionServer := &server{
		service: transactionService,
	}

	proto.RegisterTransactionHandlerServer(gserver, transactionServer)
	reflection.Register(gserver)
}
