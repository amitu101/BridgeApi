package http

import (
	"context"
	"encoding/json"
	"io/ioutil"
	"log"
	"sort"
	"strconv"
	"strings"
	"time"

	"net/http"
	nethttp "net/http"

	rh "git.capitalx.id/dimii/transaction/common"
	"git.capitalx.id/dimii/transaction/constant"
	"git.capitalx.id/dimii/transaction/model"
	srv "git.capitalx.id/dimii/transaction/service"
	"git.capitalx.id/dimii/transaction/utils"
	"github.com/shopspring/decimal"
)

func httpResponseWrite(rw nethttp.ResponseWriter, message string, data interface{}, statusCode int) {
	response := &httpResponse{Message: message, Data: data}
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	err := json.NewEncoder(rw).Encode(response)
	utils.PrintErrorNotNil(err)
}

func httpResponseWriteTr(rw nethttp.ResponseWriter, message string, data interface{}, statusCode int, length int) {
	response := &TransactionHistoryHttpResponse{Message: message, Length: length, Data: data}
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	err := json.NewEncoder(rw).Encode(response)
	utils.PrintErrorNotNil(err)
}

func httpErrorResponseWriter(rw nethttp.ResponseWriter, errorCode string, statusCode int) {
	response := &errorHttpResponse{ErrorCode: errorCode}
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	err := json.NewEncoder(rw).Encode(response)
	utils.PrintErrorNotNil(err)
}

func httpRefudResponseWriter(rw nethttp.ResponseWriter, data interface{}, statusCode int) {
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	err := json.NewEncoder(rw).Encode(data)
	utils.PrintErrorNotNil(err)
}

func httpPaymentNonceResponseWriter(rw http.ResponseWriter, paymentNonce string, statusCode int) {
	response := &paymentNonceHttpResponse{PaymentNonce: paymentNonce}
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	json.NewEncoder(rw).Encode(response)
}

func httpPaymentInfoResponseWriter(rw http.ResponseWriter, paymentInfo *model.PartnerPaymentInformation, statusCode int) {
	response := paymentInfo
	rw.Header().Set("Content-type", "application/json")
	rw.WriteHeader(statusCode)
	json.NewEncoder(rw).Encode(response)
}

func httpPaymentRedirectResponseWriter(rw http.ResponseWriter, challengeUrl string) {
	rw.Header().Set("Content-type", "application/json")
	rw.Header().Set("Location", challengeUrl)
	rw.WriteHeader(nethttp.StatusFound)
	json.NewEncoder(rw).Encode(nil)
}

type TransactionHandler struct {
	TUsecase srv.TransactionService
}

type httpResponse struct {
	Message string      `json:"message"`
	Data    interface{} `json:"data"`
}

type errorHttpResponse struct {
	ErrorCode string `json:"error_code"`
}

type paymentNonceHttpResponse struct {
	PaymentNonce string `json:"payment_nonce"`
}

type TransactionHistoryHttpResponse struct {
	Message string      `json:"message"`
	Length  int         `json:"length"`
	Data    interface{} `json:"data"`
}

func NewTransactionHandler(transactionSrv srv.TransactionService) {
	handler := &TransactionHandler{
		TUsecase: transactionSrv,
	}
	log.Println("[Transaction] : In rest Transaction Handler ")
	rh.Route(nethttp.MethodGet, "/r/transaction/welcome", handler.welcome)
	rh.Route(nethttp.MethodGet, "/r/transaction", handler.GetTransactionHistoryDetails)
	rh.Route(nethttp.MethodPost, "/r/transaction/payment", handler.Payment)
	rh.Route(nethttp.MethodGet, "/r/transaction/customer", handler.GetCustomerLastTransactionDetails)
	rh.Route(nethttp.MethodPost, "/r/transaction/payment-verify", handler.ValidateAndCommitTransaction)
	rh.Route(nethttp.MethodPost, "/r/transaction/refund-payment", handler.RefundPayment)
	rh.Route(nethttp.MethodGet, "/r/transaction/payment", handler.GetTransactionPaymentInfo)
}

func (handler *TransactionHandler) welcome(rw nethttp.ResponseWriter, req *nethttp.Request) {
	log.Println("welcome transaction")
	httpResponseWrite(rw, "welcome transaction", nil, nethttp.StatusOK)
}

func (handler *TransactionHandler) GetTransactionHistoryDetails(rw nethttp.ResponseWriter, req *nethttp.Request) {
	mobileNumber := req.URL.Query().Get("mobile_number")
	pageNumberStr := req.URL.Query().Get("page_number")
	savingAccountIDStr := req.URL.Query().Get("saving_account_id")
	countStr := req.URL.Query().Get("count")
	partnerRefID := req.URL.Query().Get("partner_ref_id")
	startDate := req.URL.Query().Get("start_date")
	endDate := req.URL.Query().Get("end_date")
	transactionIDStr := req.URL.Query().Get("transaction_id")

	log.Println("[Handler] : In GetTransactionHistoryDetails ")

	var count uint64 = 10
	var pageNumber uint64 = 1
	var savingAccountID uint64
	var transactionID uint64
	var err error
	var emptyResp = []int{}
	var startTime time.Time
	var endTime time.Time
	timeFormat := "2006-01-02"

	if countStr != "" {
		count, err = strconv.ParseUint(countStr, 0, 64)
		if err != nil {
			httpResponseWriteTr(rw, "Invalid Count", emptyResp, nethttp.StatusBadRequest, 0)
			log.Printf("[handler] Invalid Count %s\n", err.Error())
			return
		} else if count > 1000 {
			count = 1000
		}
	}

	if startDate == "" && endDate == "" {
		startTime = time.Now().AddDate(0, 0, -89)
		startDate = time.Now().AddDate(0, 0, -89).Format(timeFormat)
		endTime = time.Now()
		endDate = time.Now().Format(timeFormat)
	} else if startDate != "" && endDate != "" {
		startTime, err = time.Parse(timeFormat, startDate)
		if err != nil {
			httpResponseWriteTr(rw, "Invalid Date", emptyResp, nethttp.StatusBadRequest, 0)
			log.Printf("[handler] Invalid Date  %s\n", err.Error())
			return
		}
		endTime, err = time.Parse(timeFormat, endDate)
		if err != nil {
			httpResponseWriteTr(rw, "Invalid Date", emptyResp, nethttp.StatusBadRequest, 0)
			log.Printf("[handler] Invalid Date  %s\n", err.Error())
			return
		}
	} else {
		httpResponseWriteTr(rw, "Invalid Date Send", emptyResp, nethttp.StatusBadRequest, 0)
		log.Printf("[handler] Invalid Date Send ")
		return
	}
	if (endTime.Sub(startTime).Hours() / 24) > 90 {
		httpResponseWriteTr(rw, "Date more than 90 Days", emptyResp, nethttp.StatusBadRequest, 0)
		log.Printf("[handler] Date more than 90 Days %s\n", err.Error())
		return
	}

	if pageNumberStr != "" {
		pageNumber, err = strconv.ParseUint(pageNumberStr, 0, 64)
		if err != nil {
			httpResponseWriteTr(rw, "Invalid pageNumber", emptyResp, nethttp.StatusBadRequest, 0)
			log.Printf("[handler] Invalid Page Number %s\n", err.Error())
			return
		}
	}
	if savingAccountIDStr != "" {
		savingAccountID, err = strconv.ParseUint(savingAccountIDStr, 0, 64)
		if err != nil {
			httpResponseWriteTr(rw, "Invalid Account", emptyResp, nethttp.StatusBadRequest, 0)
			log.Printf("[handler] Invalid Saving Account Id %s\n", err.Error())
			return
		}
	} else if transactionIDStr != "" {
		transactionID, err = strconv.ParseUint(transactionIDStr, 0, 64)
		if err != nil {
			httpResponseWriteTr(rw, "Invalid Transaction Id", emptyResp, nethttp.StatusBadRequest, 0)
			return
		}
	}

	data := model.TransactionHistoryData{
		CardNo:            mobileNumber,
		SavingAccountID:   savingAccountID,
		TransactionID:     transactionID,
		PartnerRefernceID: partnerRefID,
		StartDate:         startDate,
		EndDate:           endDate,
	}

	params := model.TransactionHistoryParam{
		PageNumber: pageNumber,
		Count:      count,
	}

	transactionHistoryDetail, err := handler.TUsecase.GetTransactionHistoryDetails(req.Context(), data, params)
	if err != nil {
		httpResponseWriteTr(rw, "Error fetching transaction History", emptyResp, nethttp.StatusInternalServerError, 0)
		log.Printf("[Handler] Error when GetTransactionHistory Details %s\n", err.Error())
		return
	}
	if transactionHistoryDetail.Data == nil {
		httpResponseWriteTr(rw, "No entries found", emptyResp, nethttp.StatusOK, transactionHistoryDetail.Length)
		return
	}
	log.Println("[Handler] : Fetch Transaction Successful ")
	httpResponseWriteTr(rw, "Transaction History Fetch Successful", transactionHistoryDetail.Data, nethttp.StatusOK, transactionHistoryDetail.Length)
}

func (handler *TransactionHandler) Payment(rw nethttp.ResponseWriter, req *nethttp.Request) {
	ctx := req.Context()

	body, err := ioutil.ReadAll(req.Body)

	header := req.Header.Get("Authorization")

	headerList := strings.Split(header, " ")

	header = headerList[1]

	if err != nil {
		log.Println(err)
		httpErrorResponseWriter(rw, "INTERNAL_SERVER_ERROR", nethttp.StatusInternalServerError)
		return
	}

	defer req.Body.Close()

	var paymentRequest model.PaymentRequest

	err = json.Unmarshal(body, &paymentRequest)

	if err != nil {
		log.Println(err)
		httpErrorResponseWriter(rw, "INTERNAL_SERVER_ERROR", nethttp.StatusInternalServerError)
		return
	}

	var resp *model.PaymentResponse

	if paymentRequest.Passcode != "" && paymentRequest.PaymentInfo != "" {
		paymentRequest.PaymentInfo = strings.ReplaceAll(paymentRequest.PaymentInfo, " ", "+")

		resp, err = handler.TUsecase.GenerateNonce(ctx, paymentRequest.PaymentInfo, header, paymentRequest.Passcode)
		if err != nil {
			log.Println(err)
			if err == constant.InvalidPasscodeError {
				httpErrorResponseWriter(rw, "INVALID_PASSCODE", nethttp.StatusForbidden)
				return
			}
			httpErrorResponseWriter(rw, "INTERNAL_SERVER_ERROR", nethttp.StatusInternalServerError)
			return
		}
		httpPaymentNonceResponseWriter(rw, resp.PaymentNonce, nethttp.StatusOK)
		return
	} else {

		if paymentRequest.PartnerReferenceCode == "" || paymentRequest.PartnerPaymentTimestamp == 0 {
			log.Println(err)
			httpErrorResponseWriter(rw, "INTERNAL_SERVER_ERROR", nethttp.StatusInternalServerError)
			return
		}

		resp, err = handler.TUsecase.Payment(ctx, paymentRequest)
		if err != nil {
			log.Println(err)
			httpErrorResponseWriter(rw, "INTERNAL_SERVER_ERROR", nethttp.StatusInternalServerError)
			return
		}

		httpPaymentRedirectResponseWriter(rw, resp.ChallengeUrl)
	}

}

func (handler *TransactionHandler) GetCustomerLastTransactionDetails(rw nethttp.ResponseWriter, req *nethttp.Request) {
	// Checking for //-----ENDPOINT---  {Base_URL}/r/transaction/customer?customer_id={customer_id}&limit=5
	customerID, _ := strconv.Atoi(strings.TrimSpace(req.URL.Query().Get("customer_id")))
	limitCount := strings.TrimSpace(req.URL.Query().Get("limit"))
	emptyResp := []int{}

	log.Println("[Handler] : In GetCustomerLastTransactionDetails : ", customerID, limitCount)
	if customerID == 0 {
		httpResponseWrite(rw, "Customer ID is Required", emptyResp, nethttp.StatusBadRequest)
		return
	}

	if limitCount == "" {
		// Default Count Value
		limitCount = "5"
	}

	//var savingAccountIDs = []uint64{100390261216, 2612100390, 2612100399}
	savingAccountIDs, err := handler.TUsecase.GetCustomerSavingAccount(req.Context(), uint64(customerID))
	if err != nil || len(savingAccountIDs) == 0 {
		log.Printf("[Handler] AccountMgtSrv:GetCustomerSavingAccount %v  : err: %v", customerID, err)
		httpResponseWrite(rw, "Unable to Fetch Saving Account IDs from Account Service", emptyResp, nethttp.StatusInternalServerError)
		return
	}

	outputs, err := handler.TUsecase.GetTransactionDetailsBySavingAccountID(savingAccountIDs, limitCount)
	if err != nil {
		log.Println("[Handler] :GetTransactionDetailsBySavingAccountID err:", err)
		httpResponseWrite(rw, nethttp.StatusText(nethttp.StatusInternalServerError), emptyResp, nethttp.StatusInternalServerError)
		return
	}

	if len(*outputs) == 0 {
		httpResponseWrite(rw, "No entries found", emptyResp, nethttp.StatusNotFound)
		return
	}

	for _, output := range *outputs {
		// Sorting in Desc Order based on TransactionDateTime
		sort.Slice(output.Transactions, func(i, j int) bool {
			return output.Transactions[i].TransactionDateTime.After(*output.Transactions[j].TransactionDateTime)
		})
	}

	httpResponseWrite(rw, "success", outputs, nethttp.StatusOK)

}

func (handler *TransactionHandler) ValidateAndCommitTransaction(rw nethttp.ResponseWriter, req *nethttp.Request) {

	var err error
	defer req.Body.Close()
	var FundTransferRequest model.FundTransferRequest
	var fundTransferErrorResponse model.FundTransferErrorResponse

	body, err := ioutil.ReadAll(req.Body)
	if err != nil {
		httpResponseWrite(rw, "Request Body error", nil, nethttp.StatusInternalServerError)
		return
	}
	err = json.Unmarshal(body, &FundTransferRequest)
	if err != nil {
		httpResponseWrite(rw, "Request Body unmarshall error", nil, nethttp.StatusInternalServerError)
		return
	}

	claims, err := handler.TUsecase.ValidateToken(FundTransferRequest.PaymentNonce, &model.Claims{})
	if err != nil || !claims.IsValid {
		httpResponseWrite(rw, "Token Validation Failed", nil, nethttp.StatusBadRequest)
		log.Printf("[Handler] Parsing claims failed %s\n", err.Error())
		return
	}
	if claims.PartnerReferenceCode != FundTransferRequest.PartnerReferenceCode {
		fundTransferErrorResponse.ErrorCode = constant.TransferErrorStatus["0300"]
		fundTransferErrorResponse.ErrorDescription = constant.TransferErrorDesc["0300"]
		httpResponseWrite(rw, "PartnerReference ID does not match", fundTransferErrorResponse, nethttp.StatusBadRequest)
		log.Printf("[Handler] Parsing claims failed :: %s\n", FundTransferRequest.PartnerReferenceCode)
		return
	}

	insertFundTransferModel := model.InsertFundTransferRequest{
		PartnerReferenceId:      claims.PartnerReferenceCode,
		FromAccountProduct:      claims.CustomerProductId,
		FromCustomerId:          claims.CustomerId,
		ToAccountProduct:        claims.PartnerProductId,
		ToCustomerId:            claims.PartnerId,
		Amount:                  claims.Amount,
		Description:             claims.Description,
		TransactionType:         claims.TransactionType,
		IsCommit:                1,
		PartnerPaymentTimestamp: claims.PartnerPaymentTimestamp,
	}

	responseModel := handler.TUsecase.InsertFundTransfer(context.Background(), insertFundTransferModel)
	t := time.Now()
	timestamp := t.Format(constant.TimeLayout)
	if responseModel.StatusCode == "0200" {
		response := model.FundValidateAndTransferResponse{
			ReponseText:      responseModel.TransactionStatus,
			ResponseCode:     constant.TransferStatus[responseModel.StatusCode],
			Description:      responseModel.Description,
			TransactionId:    responseModel.TransactionId,
			RefCode:          claims.PartnerReferenceCode,
			PaymentStatus:    string(responseModel.TransactionStatus[0]),
			Amount:           claims.Amount,
			Fee:              claims.Fee,
			Tax:              claims.Tax,
			TotalAmount:      decimal.Sum(claims.Amount, claims.Fee, claims.Tax),
			PaymentTimestamp: timestamp,
		}

		httpResponseWrite(rw, responseModel.TransactionStatus, response, nethttp.StatusOK)
		return
	} else {
		fundTransferErrorResponse.ErrorCode = constant.TransferErrorStatus[responseModel.StatusCode]
		fundTransferErrorResponse.ErrorDescription = constant.TransferErrorDesc[responseModel.StatusCode]
		httpResponseWrite(rw, responseModel.TransactionStatus, fundTransferErrorResponse, nethttp.StatusOK)
		return
	}
}

func (handler *TransactionHandler) RefundPayment(rw nethttp.ResponseWriter, req *nethttp.Request) {
	defer req.Body.Close()
	var RefundPaymentRequest model.RefundPaymentRequest
	var fundTransferErrorResponse model.FundTransferErrorResponse

	body, err := ioutil.ReadAll(req.Body)
	if err != nil {
		fundTransferErrorResponse.ErrorCode = "REQUEST_BODY_ERROR"
		fundTransferErrorResponse.ErrorDescription = "Request Body unmarshall error"
		httpRefudResponseWriter(rw, fundTransferErrorResponse, nethttp.StatusInternalServerError)
		return
	}
	err = json.Unmarshal(body, &RefundPaymentRequest)
	if err != nil {
		fundTransferErrorResponse.ErrorCode = "INTERNAL_SERVER_ERROR"
		fundTransferErrorResponse.ErrorDescription = "Request Body unmarshall error"
		httpRefudResponseWriter(rw, fundTransferErrorResponse, nethttp.StatusInternalServerError)
		return
	}

	responseModel := handler.TUsecase.RefundFundTransfer(RefundPaymentRequest)
	if responseModel.StatusCode == "0200" {
		response := model.RefundPaymentResponse{
			TransactionID:      responseModel.TransactionId,
			RefundRefernceCode: RefundPaymentRequest.RefundRefernceCode,
			RefundStatus:       "SUCCESS",
		}

		httpRefudResponseWriter(rw, response, nethttp.StatusOK)
		return
	}

	fundTransferErrorResponse.ErrorCode = constant.TransferErrorStatus[responseModel.StatusCode]
	fundTransferErrorResponse.ErrorDescription = responseModel.Description
	httpRefudResponseWriter(rw, fundTransferErrorResponse, nethttp.StatusOK)
}

func (handler *TransactionHandler) GetTransactionPaymentInfo(rw nethttp.ResponseWriter, req *nethttp.Request) {
	partnerRefID := req.URL.Query().Get("partner_reference_code")
	paymentTimestamp := req.URL.Query().Get("payment_timestamp")
	var err error

	if len(partnerRefID) <= 0 {
		httpErrorResponseWriter(rw, "Invalid partner reference code", nethttp.StatusBadRequest)
		log.Printf("[handler] Invalid Partner Reference Code Send ")
		return
	}

	paymentTime, err := strconv.ParseUint(paymentTimestamp, 10, 64)
	if err != nil {
		httpErrorResponseWriter(rw, "Invalid payment timestamp", nethttp.StatusBadRequest)
		return
	}
	if paymentTime <= 0 {
		httpErrorResponseWriter(rw, "Invalid payment timestamp", nethttp.StatusBadRequest)
		return
	}

	paymentInfoData, count, err := handler.TUsecase.GetTransactionPaymentInfo(req.Context(), paymentTimestamp, partnerRefID)
	if err != nil {
		httpErrorResponseWriter(rw, "service not available", nethttp.StatusInternalServerError)
		log.Printf("[Handler] Error when GetTransactionPaymentInfo Details %s\n", err.Error())
		return
	}
	if count <= 0 {
		httpErrorResponseWriter(rw, "No entries found", nethttp.StatusNotFound)
		return
	}
	log.Println("[Handler] : Fetch Payment Info Successful")
	httpPaymentInfoResponseWriter(rw, paymentInfoData, nethttp.StatusOK)
}
