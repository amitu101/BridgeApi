package model

import (
	"time"
)

type TransactionDetail struct {
	TransactionId          string
	TransactionDatetime    string
	IconUrl                string
	TransactionName        string
	TransactionStatus      int
	TransactionAmount      float64
	TransactionBalanceType uint8
	TransactionType        uint16
	TransactionPartnerId   uint64
	TransactionReferenceId string
	TransactionInfo        map[string]string
	SourceOfFund           string
	SavingAccountId        uint64
}

type TransactionDetailDB struct {
	TransactionId          uint64
	TransactionDateTime    *time.Time
	TransactionStatus      int
	TransactionAmount      float64
	TransactionType        uint16
	TransactionPartnerId   uint64
	SavingAccountId        uint64
	TransactionBalanceType uint8
	TransactionReferenceId string
}

type LastTransactionDetail struct {
	SavingAccountID string                `json:"saving_account_id"`
	Transactions    []TransactionResponse `json:"transaction_history"`
}

type Transaction struct {
	TransactionID       uint64
	TransactionDateTime *time.Time
	TransactionStatus   string
	TransactionAmount   float64
	TransactionType     uint16
}

type TransactionResponse struct {
	TransactionID       uint64     `json:"transaction_id"`
	TransactionDateTime *time.Time `json:"transaction_date_time"`
	TransactionStatus   string     `json:"transaction_status"`
	TransactionAmount   float64    `json:"transaction_amount"`
	TransactionType     string     `json:"transaction_type"`
}

type ValidateTokenForPaymentResponse struct {
	Duration *time.Time
	Status   string
	Message  string
}

type TransactionDataByID struct {
	PartnerReferenceID string
	FromAccountID      uint64
	ToAccountID        uint64
	Amount             float64
	TransactionType    uint32
	LocationInfo       string
	Status             uint32
	Description        string
	EventTypeID        uint16
	CreatedTimestamp   string
	FromProductID      uint32
	ToProductID        uint32
}
