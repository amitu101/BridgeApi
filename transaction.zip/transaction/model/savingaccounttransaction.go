package model

import (
	"time"

	"github.com/shopspring/decimal"
)

type SavingAccountTransaction struct {
	Id                  uint64
	SavingAccountId     uint64
	TransactionType     uint8
	TransactionDatetime *time.Time
	Amount              decimal.Decimal
	Status              uint8
	Description         string
	TransactionId       uint64
	CreatedBy           uint64
	CreatedTimestamp    *time.Time
	CommittedBy         *uint64
	CommittedTimestamp  *time.Time
}
