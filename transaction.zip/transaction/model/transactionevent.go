package model

import (
	"time"

	"github.com/shopspring/decimal"
)

type TransactionEvent struct {
	Id                      uint64
	TransactionDatetime     *time.Time
	EventTypeId             uint16
	Amount                  decimal.Decimal
	LocationInfo            string
	PartnerId               uint64
	PartnerReferenceId      string
	Description             string
	Status                  uint8
	SubStatus               uint8
	CreatedBy               uint64
	CreatedTimestamp        *time.Time
	CommittedBy             *uint64
	CommittedTimestamp      *time.Time
	IsRefunded              bool
	PartnerPaymentTimestamp int64
}

type PaymentInfoTransactionEvent struct {
	TransactionID          uint64          `json:"transaction_id"`
	TransactionDatetime    string          `json:"transaction_date_time"`
	TransactionStatus      string          `json:"transaction_status"`
	TransactionAmount      decimal.Decimal `json:"amount"`
	TransactionFee         decimal.Decimal `json:"fee"`
	TransactionTax         decimal.Decimal `json:"tax"`
	TransactionTotalAmount decimal.Decimal `json:"total_amount"`
	TransactionPartnerId   string          `json:"partner_reference_code"`
}
