package model

type FundTransferResponse struct {
	StatusCode        string
	Description       string
	TransactionId     uint64
	TransactionStatus string
}
