package model

import (
	"time"
)

type TokenEvent struct {
	ID          uint64
	Token       string
	Status      string
	Count       int
	BlockedTime *time.Time
	CreatedOn   *time.Time
	UpdatedOn   *time.Time
}
