package model

import "time"

type TransactionHistoryListItem struct {
	TransactionId          string
	TransactionDatetime    string
	IconUrl                string
	TransactionName        string
	TransactionStatus      int
	TransactionAmount      float64
	TransactionBalanceType uint8
	TransactionType        uint16
	TransactionPartnerId   uint64
	SavingAccountId        string
}

type TransactionHistoryListItemDB struct {
	TransactionId          uint64
	TransactionDateTime    *time.Time
	TransactionStatus      int
	TransactionAmount      float64
	TransactionType        uint16
	TransactionPartnerId   uint64
	SavingAccountId        uint64
	TransactionBalanceType uint8
}

type TransactionHistoryDetail struct {
	TransactionInfo        map[string]string `json:"transaction_info"`
	TransactionID          uint64            `json:"transaction_id"`
	TransactionDatetime    string            `json:"transaction_date_time"`
	IconURL                string            `json:"icon_url"`
	TransactionName        string            `json:"transaction_name"`
	TransactionStatus      string            `json:"transaction_status"`
	TransactionAmount      float64           `json:"transaction_amount"`
	TransactionBalanceType string            `json:"transaction_balance_type"`
	TransactionType        string            `json:"transaction_type"`
	SourceOfFund           string            `json:"source_of_fund"`
	TransactionReferenceID string            `json:"transaction_reference_id"`
	SavingAccountID        uint64            `json:"saving_account_id"`
	ToSavingAccountID      uint64            `json:"to_saving_account_id"`
	SavingProductID        uint32            `json:"-"`
	ToSavingProductID      uint32            `json:"-"`
	CardNo                 string            `json:"-"`
	ToCardNo               string            `json:"-"`
	From                   CustomerData      `json:"from"`
	To                     CustomerData      `json:"to"`
}

type TransactionHistoryResponse struct {
	Data   []TransactionHistoryDetail
	Length int
}

type TransactionHistoryParam struct {
	PageNumber uint64
	Count      uint64
	Start      uint64
	Ascending  bool
	OrderBy    string
}

type TransactionHistoryDataModel struct {
	TransactionId          uint64
	TransactionDateTime    *time.Time
	TransactionStatus      uint8
	TransactionAmount      float64
	TransactionEventType   uint16
	TransactionType        uint8
	TransactionReferenceId string
	SavingAccountId        uint64
	TransactionBalanceType string
	ToSavingAccountId      uint64
	TransactionDescription string
}

type CustomerData struct {
	CustomerID   uint64 `json:"customer_id"`
	CustomerName string `json:"customer_name"`
}

type TransactionHistoryData struct {
	SavingAccountID   uint64
	CardNo            string
	TransactionID     uint64
	PartnerRefernceID string
	StartDate         string
	EndDate           string
}
