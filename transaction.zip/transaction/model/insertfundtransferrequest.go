package model

import (
	"github.com/shopspring/decimal"
)

type InsertFundTransferRequest struct {
	PartnerReferenceId      string
	LocationInfo            string
	FromAccountProduct      uint32
	FromCustomerId          uint64
	FromCustomerCardNo      string
	ToAccountProduct        uint32
	ToCustomerId            uint64
	ToCustomerCardNo        string
	Amount                  decimal.Decimal
	Description             string
	IsCommit                uint32
	TransactionType         uint16
	PartnerPaymentTimestamp int64
}
