package model

type P2PTransferRequest struct {
	Recipient string
	Amount    float64
	Notes     string
}

type P2PTransferResponse struct {
	RecipientName string
	Amount        float64
	Fee           float64
	Notes         string
	SourceOfFund  string
	ReferenceNo   string
}
