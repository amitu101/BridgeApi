package model

import (
	"github.com/dgrijalva/jwt-go"
	"github.com/shopspring/decimal"
)

type PaymentRequest struct {
	Amount                  float64 `json:"amount"`
	Fee                     float64 `json:"fee"`
	Tax                     float64 `json:"tax"`
	TransactionType         uint16  `json:"transaction_type"`
	Description             string  `json:"description"`
	PartnerReferenceCode    string  `json:"partner_reference_code"`
	PartnerPaymentTimestamp int64   `json:"partner_payment_timestamp"`
	Passcode                string  `json:"passcode"`
	PaymentInfo             string  `json:"payment_info"`
}
type PaymentResponse struct {
	PaymentNonce     string `json:"payment_nonce,omitempty"`
	ChallengeUrl     string `json:"challenge_url,omitempty"`
	ErrorDescription string `json:"error_description,omitempty"`
	ErrorCode        string `json:"error_code,omitempty"`
}

type Claims struct {
	Amount                  decimal.Decimal `json:"amount"`
	Fee                     decimal.Decimal `json:"fee"`
	Tax                     decimal.Decimal `json:"tax"`
	TransactionType         uint16          `json:"transaction_type"`
	Description             string          `json:"description"`
	PartnerReferenceCode    string          `json:"partner_reference_code"`
	CustomerId              uint64          `json:"customer_id"`
	PartnerId               uint64          `json:"partner_id"`
	CustomerProductId       uint32          `json:"customer_product_id"`
	PartnerProductId        uint32          `json:"partner_product_id"`
	PartnerPaymentTimestamp int64           `json:"partner_payment_timestamp"`
	IsValid                 bool
	jwt.StandardClaims
}

type TokenClaims struct {
	Audience []string `json:"aud"`
	jwt.StandardClaims
}

type FundTransferRequest struct {
	PaymentNonce         string `json:"payment_nonce"`
	PartnerReferenceCode string `json:"partner_reference_code"`
}

type FundValidateAndTransferResponse struct {
	ResponseCode     uint64          `json:"response_code"`
	ReponseText      string          `json:"response_text"`
	Description      string          `json:"description"`
	TransactionId    uint64          `json:"transaction_id"`
	RefCode          string          `json:"ref_code"`
	PaymentStatus    string          `json:"payment_status"`
	PaymentTimestamp string          `json:"payment_timestamp"`
	Amount           decimal.Decimal `json:"amount"`
	Fee              decimal.Decimal `json:"fee"`
	Tax              decimal.Decimal `json:"tax"`
	TotalAmount      decimal.Decimal `json:"total_amount"`
}

type FundTransferErrorResponse struct {
	ErrorCode        string `json:"error_code"`
	ErrorDescription string `json:"error_description"`
}

type RefundPaymentRequest struct {
	TransactionID      uint64 `json:"transaction_id"`
	RefundRefernceCode string `json:"refund_ref_code"`
	Description        string `json:"description,omitempty"`
	LocationInfo       string `json:"location_info,omitempty"`
}

type RefundPaymentResponse struct {
	TransactionID      uint64 `json:"refund_transaction_id"`
	RefundRefernceCode string `json:"refund_ref_code"`
	RefundStatus       string `json:"refund_status"`
}

type PartnerPaymentInformation struct {
	ResponseCode         uint64          `json:"response_code"`
	ResponseText         string          `json:"response_text"`
	TransactionID        uint64          `json:"transaction_id"`
	PartnerReferenceCode string          `json:"partner_reference_code"`
	TransactionStatus    string          `json:"transaction_status"`
	PaymentTimestamp     string          `json:"payment_timestamp"`
	Amount               decimal.Decimal `json:"amount"`
	Fee                  decimal.Decimal `json:"fee"`
	Tax                  decimal.Decimal `json:"tax"`
	TotalAmount          decimal.Decimal `json:"total_amount"`
}
