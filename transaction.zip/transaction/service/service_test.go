package service

import (
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/suite"
	"testing"
)

type ServiceSuite struct {
	suite.Suite
}

func (suite *ServiceSuite) TestMaskName() {
	name1 := "zulkan tes    baru"
	out1 := maskName(name1)

	assert.Equal(suite.T(), "z****n ***    b**u", out1)

	name2 := "zulkan baru"
	out2 := maskName(name2)

	assert.Equal(suite.T(), "z***** b**u", out2)

	name3 := "zulkan"
	out3 := maskName(name3)

	assert.Equal(suite.T(), "z****n", out3)

}

func TestServiceSuite(t *testing.T) {
	suite.Run(t, new(ServiceSuite))
}

