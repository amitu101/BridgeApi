package service

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdsa"
	cRand "crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"strconv"
	"strings"
	"time"

	"git.capitalx.id/dimii/transaction/utils"
	"github.com/dgrijalva/jwt-go"
	"github.com/shopspring/decimal"

	"git.capitalx.id/core/messaging"

	"git.capitalx.id/dimii/bookkeeper/models"

	accountClient "git.capitalx.id/dimii/account/client"
	customerClient "git.capitalx.id/dimii/customer/client"

	bookkeeper_service "git.capitalx.id/dimii/bookkeeper/service"
	bookkeeper_errors "git.capitalx.id/dimii/bookkeeper/utils/errors"

	core_config "git.capitalx.id/core/config"
	user_client "git.capitalx.id/core/user/client"

	"git.capitalx.id/dimii/transaction/constant"
	"git.capitalx.id/dimii/transaction/model"
	"git.capitalx.id/dimii/transaction/repository"
	"google.golang.org/grpc/metadata"
)

type transactionService struct {
	repo                     repository.TransactionRepository
	accountTransactionClient accountClient.AccountTransactionClient
	accountClient            accountClient.AccountClient
	customerClient           customerClient.CustomerClient
	bookkeeperService        bookkeeper_service.Service
	kafkaClient              messaging.Client
	userClient               user_client.UserClient
	config                   core_config.Config
}

type TransactionService interface {
	GetTransactionId(ctx context.Context, clientReferenceId string) (uint64, error)
	ValidateFundTransfer(ctx context.Context, request model.InsertFundTransferRequest) model.FundTransferResponse
	InsertFundTransfer(ctx context.Context, request model.InsertFundTransferRequest) model.FundTransferResponse
	CommitFundTransfer(ctx context.Context, transactionId uint64) model.FundTransferResponse
	GetAccount(ctx context.Context, savingAccountId, customerId uint64, cardNo string, savingProductId uint32) *accountClient.GetSavingAccountResponse
	GetCustomerDataByCustomerId(ctx context.Context, customerId uint64, mobileNumber string) (*customerClient.CustomerDataResponse, error)
	GetTransactionHistoryItem(ctx context.Context, customerId, count uint64, lastCreatedTimeStamp string, savingProductId uint32, cardNo string, transactionBalanceType, status uint8) []model.TransactionHistoryListItem
	GetTransactionDetail(ctx context.Context, transactionId uint64, cardNo string, savingAccountId uint64) (*model.TransactionDetail, error)
	GetTransactionHistoryDetails(ctx context.Context, requestData model.TransactionHistoryData, requestParam model.TransactionHistoryParam) (model.TransactionHistoryResponse, error)
	Payment(ctx context.Context, paymentRequest model.PaymentRequest) (*model.PaymentResponse, error)
	GetTransactionDetailsBySavingAccountID(savingAccountID []uint64, limitCount string) (*[]model.LastTransactionDetail, error)
	ValidateToken(paymentNonce string, claims *model.Claims) (*model.Claims, error)
	GetCustomerSavingAccount(ctx context.Context, customerID uint64) ([]uint64, error)
	ValidateTokenForPayment(mobileNumber, passCode, token string) (*model.ValidateTokenForPaymentResponse, error)
	GetTransactionByTransactionID(ctx context.Context, transactionID uint64) (*model.TransactionDataByID, error)
	GetTransactionPaymentInfo(ctx context.Context, paymentTimestamp, partnerRefID string) (*model.PartnerPaymentInformation, int, error)

	RefundFundTransfer(refundPaymentRequest model.RefundPaymentRequest) model.FundTransferResponse
	GenerateNonce(ctx context.Context, paymentInfo, header, passcode string) (*model.PaymentResponse, error)

	P2PTransferInquiry(context.Context, *model.P2PTransferRequest) (*model.P2PTransferResponse, error)
}

func (t transactionService) GetTransactionId(ctx context.Context, clientReferenceId string) (uint64, error) {
	currentString := strings.Replace(time.Now().Format("060102150405.000"), ".", "", 1)

	return strconv.ParseUint(currentString, 10, 64)
}

func (t transactionService) ValidateFundTransfer(ctx context.Context, request model.InsertFundTransferRequest) model.FundTransferResponse {
	transactionId, err := t.GetTransactionId(ctx, request.PartnerReferenceId)

	if err != nil {
		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       "Failed to get transaction id",
			TransactionId:     0,
			TransactionStatus: "3 - FAILED",
		}
	}

	validationResponse, err := t.validateFundTransferToAccountService(request)

	if err != nil {
		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       fmt.Sprintf("Error when calling account service: %s", err.Error()),
			TransactionId:     0,
			TransactionStatus: "3 - FAILED",
		}
	}

	if validationResponse != nil && validationResponse.Code != constant.SuccessCode {
		return model.FundTransferResponse{
			StatusCode:        validationResponse.Code,
			Description:       validationResponse.Description,
			TransactionId:     0,
			TransactionStatus: "3 - FAILED",
		}
	}

	return model.FundTransferResponse{
		StatusCode:        constant.SuccessCode,
		Description:       "valid transaction",
		TransactionId:     transactionId,
		TransactionStatus: "success",
	}
}

func (t transactionService) P2PTransferInquiry(ctx context.Context, request *model.P2PTransferRequest) (*model.P2PTransferResponse, error) {
	custResp, err := t.customerClient.GetCustomerDataByIdOrMobileNumber(context.Background(),
		&customerClient.GetCustomerRequest{MobileNumber: request.Recipient})

	if err != nil {
		return nil, err
	}

	return &model.P2PTransferResponse{
		RecipientName: maskName(custResp.Fullname),
		Amount:        request.Amount,
		Fee:           0,
		Notes:         request.Notes,
		SourceOfFund:  "Saldo dimii",
		ReferenceNo:   "",
	}, nil
}

/*
	mask name with rule:
	First Name: first & last letter seen, the rest hide
	Last Name: First & last letter seen, the rest hide
	Other than that, all alphabet should be mask
*/
func maskName(name string) string {
	name = strings.Trim(name, " ")

	result := make([]byte, len(name))

	writeFront, writeBack := true, true

	for i := 0; i < len(name); i++ {
		j := len(name) - 1 - i

		if i > 0 && (i == j || i > j) {
			if i == j {
				result[i] = byte('*')
			}
			break
		}

		if name[i] == ' ' {
			writeFront = false
			result[i] = byte(' ')
		} else if writeFront {
			if (i+1 < len(name) && name[i+1] == ' ') || i == 0 {
				result[i] = name[i]
			} else {
				result[i] = '*'
			}
		} else {
			result[i] = '*'
		}
		if name[j] == ' ' {
			writeBack = false
			result[j] = byte(' ')
		} else if writeBack {
			if (j-1 > 0 && name[j-1] == ' ') || i == 0 {
				result[j] = name[j]
			} else {
				result[j] = '*'
			}
		} else {
			result[j] = '*'
		}

	}

	return string(result)
}

func (t transactionService) InsertFundTransfer(ctx context.Context, request model.InsertFundTransferRequest) model.FundTransferResponse {
	var err error

	te, err := t.repo.GetTransactionEventByPartnerReferenceId(request.PartnerReferenceId)

	if err != nil {
		return generateFundTransferResponse(constant.InternalSystemError, fmt.Sprintf("%v", err), 0, constant.GetStatusValue("FAILED"))
	}

	if te != nil && te.Status != constant.GetStatusValue("CREATED") {
		return generateFundTransferResponse(constant.ReferenceIdAlreadyUsed, "Client reference id already used", 0, constant.GetStatusValue("FAILED"))
	}
	//currently only support topup or payment
	if request.TransactionType != constant.GetEventTypeValue("TOPUP") &&
		request.TransactionType != constant.GetEventTypeValue("PAYMENT") &&
		request.TransactionType != constant.GetEventTypeValue("PAYMENT_AT_PARTNER") &&
		request.TransactionType != constant.GetEventTypeValue("PAYMENT") &&
		request.TransactionType != constant.GetEventTypeValue("REFUND") {
		return generateFundTransferResponse(constant.InvalidTransactionEventType, "Transaction event type is invalid", 0, constant.GetStatusValue("FAILED"))
	}

	currentTime := time.Now()
	md, ok := metadata.FromIncomingContext(ctx)
	var serviceIdList []string
	if !ok {
		log.Printf("[Service] metadata Not  Found ")
	} else {
		serviceIdList = md.Get("service_id")
	}
	var serviceIdInt uint64
	if len(serviceIdList) > 0 {
		serviceIdInt, _ = strconv.ParseUint(md.Get("service_id")[0], 10, 64)
	} else {
		serviceIdInt = 4
	}

	transactionId, err := t.GetTransactionId(ctx, request.PartnerReferenceId)
	if err != nil {
		return generateFundTransferResponse(constant.InternalSystemError, "Failed to get transaction id", 0, constant.GetStatusValue("FAILED"))
	}
	var status, subStatus, rollbackType uint8
	newTe := generateTransactionEvent(transactionId, serviceIdInt, currentTime, request, constant.GetStatusValue("IN_PROGRESS"), subStatus)
	err = t.repo.InsertTransactionEvent(newTe)
	if err != nil {
		return handleCustomError(0, constant.InternalSystemError,
			fmt.Sprintf("Failed to save transaction event %v", err))
	}
	te = &newTe

	// --------- Part after calling account service

	var authResponse *accountClient.AuthFundTransferResponse
	if request.IsCommit == 0 {
		authResponse, err = t.authorizeFundTransferToAccountService(request, transactionId)
		rollbackType = 1
	} else {
		authResponse, err = t.autoCommitToAccountService(request, transactionId)
		rollbackType = 2
	}

	if err != nil || authResponse.Code != constant.SuccessCode {

		//mark as failed
		te.Status = constant.GetStatusValue("FAILED")
		err2 := t.repo.UpdateTransactionEvent(*te)

		utils.PrintErrorNotNil(err2)

		var errDescription, statusCode string
		if err != nil {
			errDescription = err.Error()
			statusCode = constant.InternalSystemError
		} else {
			errDescription = authResponse.Description
			statusCode = authResponse.Code
		}
		log.Print("ERROR WHEN CALLING ACCOUNT SERVICE: ", errDescription)
		return generateFundTransferResponse(statusCode, fmt.Sprintf("Failed to do auth to account service: %s", errDescription), 0, constant.GetStatusValue("FAILED"))
	}

	currentTime = time.Now()

	var fromSavingAccountId = authResponse.FromSavingAccount.Id
	var toSavingAccountId = authResponse.ToSavingAccount.Id
	request.FromCustomerId = authResponse.FromSavingAccount.CustomerId
	request.ToCustomerId = authResponse.ToSavingAccount.CustomerId

	status = constant.GetStatusValue("IN_PROGRESS")
	if request.IsCommit == 0 {
		subStatus = constant.SuccessCallingAccountAuth
	} else {
		subStatus = constant.SuccessCallingAccountCommit
	}

	te2 := generateTransactionEvent(transactionId, serviceIdInt, currentTime, request, status, subStatus)
	te = &te2
	err = t.repo.UpdateTransactionEvent(*te)

	if err != nil {
		log.Println(err)
		_, err = t.accountTransactionClient.RollbackTransaction(context.Background(), te.Id, rollbackType)
		utils.PrintErrorNotNil(err)
		return generateFundTransferResponse(constant.InternalSystemError, "Failed update transaction event", transactionId, te.Status)
	}

	satClient := generateSavingAccountTransactionData(serviceIdInt, transactionId, fromSavingAccountId,
		currentTime, constant.GetTransactionTypeValue("CASH_OUT"), request, status)
	satCustomer := generateSavingAccountTransactionData(serviceIdInt, transactionId, toSavingAccountId,
		currentTime, constant.GetTransactionTypeValue("CASH_IN"), request, status)

	_, err = t.repo.InsertSavingAccountTransaction(satClient, satCustomer)

	if err != nil {
		log.Println(err)
		_, err = t.accountTransactionClient.RollbackTransaction(context.Background(), te.Id, rollbackType)
		utils.PrintErrorNotNil(err)
		return generateFundTransferResponse(constant.InternalSystemError, "Failed insert saving account transaction", transactionId, te.Status)
	}

	if request.IsCommit == 1 {
		err = t.handleBookkeeperAndNotifCall(te, &satClient, authResponse, currentTime, subStatus, rollbackType)
		if err != nil {
			return generateFundTransferResponse(constant.InternalSystemError, "Failed when recording to bookkeeper", transactionId, satClient.Status)
		}
		return generateFundTransferResponse(constant.SuccessCode, "Success insert fund transfer", transactionId, constant.GetStatusValue("SUCCESS"))
	}

	return generateFundTransferResponse(constant.SuccessCode, "Success insert fund transfer", transactionId, satClient.Status)
}

func generateFundTransferResponse(statusCode, description string, transactionID uint64, transactionStatus uint8) model.FundTransferResponse {
	return model.FundTransferResponse{
		StatusCode:        statusCode,
		Description:       description,
		TransactionId:     transactionID,
		TransactionStatus: fmt.Sprintf("%d - %s", transactionStatus, constant.GetStatusKey(transactionStatus)),
	}
}

func (t transactionService) handleBookkeeperAndNotifCall(te *model.TransactionEvent, sat *model.SavingAccountTransaction,
	authResponse *accountClient.AuthFundTransferResponse, currentTime time.Time, subStatus, rollbackType uint8) error {
	r, errBk := t.recordToBookkeeperService(te, authResponse.FromSavingAccount, authResponse.ToSavingAccount)

	log.Printf("[recordTrxToBookkeeperService] Response from bookkeeper is %s\n", r)

	if errBk != nil {
		log.Println(errBk)
		err := t.repo.ExecQuery(repository.UpdateTransactionEventAndSavingAccountTransactionsStatus, te.Id,
			constant.GetStatusValue("FAILED"), subStatus)
		utils.PrintErrorNotNil(err)
		_, err = t.accountTransactionClient.RollbackTransaction(context.Background(), te.Id, rollbackType)
		utils.PrintErrorNotNil(err)

		return errors.New(errBk.Message)
	}

	t.sendNotification(*te, *sat, authResponse, currentTime)

	subStatus = constant.SuccessCallingBookkeeperCommit

	err := t.repo.ExecQuery(repository.UpdateTransactionEventAndSavingAccountTransactionsStatus, te.Id,
		constant.GetStatusValue("SUCCESS"), subStatus)
	utils.PrintErrorNotNil(err)
	return nil
}

func (t transactionService) sendNotification(te model.TransactionEvent, sat model.SavingAccountTransaction,
	accountResponse *accountClient.AuthFundTransferResponse, currentTime time.Time) {
	if t.kafkaClient != nil && (te.EventTypeId == constant.GetEventTypeValue("TOPUP") || te.EventTypeId == constant.GetEventTypeValue("PAYMENT") || te.EventTypeId == constant.GetEventTypeValue("REFUND")) {
		err := t.TopupNotification(te.EventTypeId, sat, accountResponse, currentTime)

		if err != nil {
			log.Println("Error send notification", err)
		}
	}
	log.Println("kafka not reachable or the event is not topup")
}

func (t transactionService) validateFundTransferToAccountService(request model.InsertFundTransferRequest) (*accountClient.AccTransResponse, error) {
	amountFloat, _ := request.Amount.Float64()
	authRequest := accountClient.ValidationFundReq{
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCardNo:         request.FromCustomerCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCardNo:           request.ToCustomerCardNo,
		Amount:             amountFloat,
	}

	return t.accountTransactionClient.ValidateFundTransferAmount(context.Background(), &authRequest)
}

func (t transactionService) authorizeFundTransferToAccountService(request model.InsertFundTransferRequest,
	transactionId uint64) (*accountClient.AuthFundTransferResponse, error) {
	amountFloat, _ := request.Amount.Float64()
	authRequest := accountClient.AuthorizeFundTransferAmountReq{
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCardNo:         request.FromCustomerCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCardNo:           request.ToCustomerCardNo,
		Amount:             amountFloat,
		TransactionId:      transactionId,
	}
	return t.accountTransactionClient.AuthorizeFundTransferAmount(context.Background(), &authRequest)
}

func (t transactionService) commitFundTransferToAccountService(transactionId uint64) (*accountClient.AuthFundTransferResponse, error) {
	return t.accountTransactionClient.CommitFundTransferAmount(context.Background(), strconv.FormatUint(transactionId, 10))
}

func (t transactionService) recordToBookkeeperService(te *model.TransactionEvent, fromSavingAccount,
	toSavingAccount *accountClient.GetSavingAccountResponse) (map[string]interface{}, *bookkeeper_errors.RestErr) {

	ts := te.CreatedTimestamp.Format("2006-01-02")

	amountFloat, _ := te.Amount.Float64()

	var journalType uint32

	if te.EventTypeId == constant.GetEventTypeValue("TOPUP") {
		journalType = constant.GetJournalTypeValue("TOPUP")
	} else if te.EventTypeId == constant.GetEventTypeValue("PAYMENT") {
		journalType = constant.GetJournalTypeValue("PAYMENT")
	} else {
		journalType = constant.GetJournalTypeValue("REFUND")
	}

	fundTransfer := models.FundTransferTransactionGrpcRequest{
		FromCustomerID:          fromSavingAccount.CustomerId,
		FromAccountProductGroup: fromSavingAccount.SavingProductId,
		FromAccountID:           fromSavingAccount.Id,
		ToCustomerID:            toSavingAccount.CustomerId,
		ToAccountProductGroup:   toSavingAccount.SavingProductId,
		ToAccountID:             toSavingAccount.Id,
		TransferDate:            ts,
		Amount:                  amountFloat,
		Description:             fmt.Sprint(te.Id),
		JournalType:             journalType,
	}
	return t.bookkeeperService.FundTransferRequestToBookkeeper(context.Background(), fundTransfer)
}

func getSavingAccountTransactionByTransactionType(satList []model.SavingAccountTransaction, transactionType uint8) model.SavingAccountTransaction {
	var sat model.SavingAccountTransaction
	for i := 0; i < len(satList); i++ {
		if satList[i].TransactionType == transactionType {
			return satList[i]
		}
	}
	return sat
}

func (t transactionService) autoCommitToAccountService(request model.InsertFundTransferRequest,
	transactionId uint64) (*accountClient.AuthFundTransferResponse, error) {
	amountFloat, _ := request.Amount.Float64()
	authRequest := accountClient.AuthorizeFundTransferAmountReq{
		FromAccountProduct: request.FromAccountProduct,
		FromCustomerId:     request.FromCustomerId,
		FromCardNo:         request.FromCustomerCardNo,
		ToAccountProduct:   request.ToAccountProduct,
		ToCustomerId:       request.ToCustomerId,
		ToCardNo:           request.ToCustomerCardNo,
		Amount:             amountFloat,
		TransactionId:      transactionId,
	}
	return t.accountTransactionClient.InsertFundTransfer(context.Background(), &authRequest)
}

func (t transactionService) CommitFundTransfer(ctx context.Context, transactionId uint64) model.FundTransferResponse {
	currentTime := time.Now()

	md, ok := metadata.FromIncomingContext(ctx)

	if !ok {
		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       "Service id caller not set",
			TransactionId:     0,
			TransactionStatus: "3 - FAILED",
		}
	}

	serviceIdInt, _ := strconv.ParseUint(md.Get("service_id")[0], 10, 64)

	te, err := t.repo.GetTransactionEventById(transactionId)

	if err != nil {
		log.Println(err)
		return handleInternalError(transactionId, err)
	}

	satList, err := t.repo.GetSavingAccountTransactionByTransactionId(transactionId)

	if err != nil {
		log.Println(err)
		return handleInternalError(transactionId, err)
	}

	sourceSat := getSavingAccountTransactionByTransactionType(satList, constant.GetTransactionTypeValue("CASH_OUT"))
	destinationSat := getSavingAccountTransactionByTransactionType(satList, constant.GetTransactionTypeValue("CASH_IN"))

	if te.Status != constant.GetStatusValue("IN_PROGRESS") ||
		sourceSat.Status != constant.GetStatusValue("IN_PROGRESS") ||
		destinationSat.Status != constant.GetStatusValue("IN_PROGRESS") {

		return handleCustomError(transactionId, constant.InvalidStatus, "transaction status not in progress")
	}

	commitResponse, err := t.commitFundTransferToAccountService(sourceSat.TransactionId)

	if err != nil || commitResponse.Code != constant.SuccessCode {

		var statusCode, errMsg string
		if err != nil {
			statusCode = constant.InternalSystemError
			errMsg = err.Error()
		} else {
			statusCode = commitResponse.Code
			errMsg = commitResponse.Description
		}
		return model.FundTransferResponse{
			StatusCode:        statusCode,
			Description:       fmt.Sprintf("Error commit to account service: %s\n", errMsg),
			TransactionId:     0,
			TransactionStatus: "3 - FAILED",
		}
	}

	err = t.repo.UpdateSuccessCommitTables(transactionId, constant.GetStatusValue("SUCCESS"),
		constant.SuccessCallingBookkeeperCommit, serviceIdInt, currentTime)

	if err != nil {
		return handleInternalError(transactionId, err)
	}

	err = t.handleBookkeeperAndNotifCall(&te, &sourceSat, commitResponse, currentTime,
		constant.SuccessCallingBookkeeperCommit, 2)

	if err != nil {
		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       "Failed when recording to bookkeeper",
			TransactionId:     transactionId,
			TransactionStatus: fmt.Sprintf("%d - %s", te.Status, constant.GetStatusKey(te.Status)),
		}
	}

	return model.FundTransferResponse{
		StatusCode:        constant.SuccessCode,
		Description:       "Success commit fund transfer",
		TransactionId:     transactionId,
		TransactionStatus: fmt.Sprintf("%d - %s", te.Status, "SUCCESS"),
	}
}

func handleInternalError(transactionId uint64, err error) model.FundTransferResponse {
	return model.FundTransferResponse{
		StatusCode:        constant.InternalSystemError,
		Description:       err.Error(),
		TransactionId:     transactionId,
		TransactionStatus: "0 - UNKNOWN",
	}
}
func handleCustomError(transactionId uint64, statusCode string, description string) model.FundTransferResponse {
	return model.FundTransferResponse{
		StatusCode:        statusCode,
		Description:       description,
		TransactionId:     transactionId,
		TransactionStatus: "0 - UNKNOWN",
	}
}

func generateTransactionEvent(transactionId uint64, serviceId uint64, currentTime time.Time,
	request model.InsertFundTransferRequest, status uint8, subStatus uint8) model.TransactionEvent {
	currentDateTime := time.Date(currentTime.Year(), currentTime.Month(), currentTime.Day(), currentTime.Hour(),
		currentTime.Minute(), currentTime.Second(), 0, currentTime.Location())

	var committedBy *uint64 = nil
	var committedTimestamp *time.Time = nil

	if request.IsCommit == 1 {
		committedBy = &serviceId
		committedTimestamp = &currentTime
	}

	var partnerId uint64
	if request.TransactionType == constant.GetEventTypeValue("TOPUP") || request.TransactionType == constant.GetEventTypeValue("REFUND") {
		partnerId = request.FromCustomerId
	} else {
		partnerId = request.ToCustomerId
	}

	if request.TransactionType != constant.GetEventTypeValue("PAYMENT_AT_PARTNER") {
		request.PartnerPaymentTimestamp = 0
	}

	return model.TransactionEvent{
		Id:                      transactionId,
		TransactionDatetime:     &currentDateTime,
		EventTypeId:             request.TransactionType,
		Amount:                  request.Amount,
		LocationInfo:            request.LocationInfo,
		PartnerId:               partnerId,
		PartnerReferenceId:      request.PartnerReferenceId,
		Description:             request.Description,
		Status:                  status,
		SubStatus:               subStatus,
		CreatedBy:               serviceId,
		CreatedTimestamp:        &currentTime,
		CommittedBy:             committedBy,
		CommittedTimestamp:      committedTimestamp,
		IsRefunded:              false,
		PartnerPaymentTimestamp: request.PartnerPaymentTimestamp,
	}
}

func generateSavingAccountTransactionData(serviceId uint64, transactionId uint64, savingAccountId uint64, currentTime time.Time,
	transactionType uint8, request model.InsertFundTransferRequest, status uint8) model.SavingAccountTransaction {

	currentDateTime := time.Date(currentTime.Year(), currentTime.Month(), currentTime.Day(), currentTime.Hour(),
		currentTime.Minute(), currentTime.Second(), 0, currentTime.Location())

	var committedBy *uint64 = nil
	var committedTimestamp *time.Time = nil

	if request.IsCommit == 1 {
		committedBy = &serviceId
		committedTimestamp = &currentTime
	}

	return model.SavingAccountTransaction{
		SavingAccountId:     savingAccountId,
		TransactionType:     transactionType, // cash in or cash out
		TransactionDatetime: &currentDateTime,
		Amount:              request.Amount,
		Status:              status, // in progress
		Description:         request.Description,
		TransactionId:       transactionId,
		CreatedBy:           serviceId,
		CreatedTimestamp:    &currentTime,
		CommittedBy:         committedBy,
		CommittedTimestamp:  committedTimestamp,
	}
}

func (t transactionService) GetCustomerDataByCustomerId(ctx context.Context, customerId uint64, mobileNumber string) (*customerClient.CustomerDataResponse, error) {
	customerClientResp, err := t.customerClient.GetCustomerDataByIdOrMobileNumber(ctx, &customerClient.GetCustomerRequest{
		CustomerId:   customerId,
		MobileNumber: mobileNumber,
	})
	if err != nil {
		log.Printf("[service] Error when GetCustomerDataByCustomerId %s\n", err.Error())
		return nil, err
	}
	return customerClientResp, nil
}

func (t transactionService) GetAccount(ctx context.Context, savingAccountId, customerId uint64, cardNo string, savingProductId uint32) *accountClient.GetSavingAccountResponse {
	accountClientResp, err := t.accountClient.GetSavingAccount(ctx, &accountClient.GetSavingAccountRequest{
		Id:              savingAccountId,
		CardNo:          cardNo,
		SavingProductId: savingProductId,
		CustomerId:      customerId,
	})
	if err != nil {
		log.Printf("[service] Error when GetSavingProduct %s\n", err.Error())
		return &accountClient.GetSavingAccountResponse{}
	}
	return accountClientResp
}

func (t transactionService) GetSavingProduct(ctx context.Context, savingProductId uint32) (*accountClient.GetSavingProductResponse, error) {
	savingProductResp, err := t.accountClient.GetSavingProduct(ctx, savingProductId)
	if err != nil {
		log.Printf("[service] Error when GetSavingProduct %s\n", err.Error())
		return nil, err
	}
	return savingProductResp, nil
}

func (t transactionService) GetTransactionHistoryItem(ctx context.Context, customerId, count uint64, lastCreatedTimeStamp string, savingProductId uint32, cardNo string, transactionBalanceType, status uint8) []model.TransactionHistoryListItem {
	account := t.GetAccount(ctx, 0, customerId, cardNo, savingProductId)

	resp, err := t.repo.GetTransactionHistory(count, account.Id, lastCreatedTimeStamp, transactionBalanceType, status)

	if err != nil {
		log.Printf("[service] Error when GetTransactionHistoryItem %s\n", err.Error())
		return nil
	}

	for i, elem := range resp {
		customer, _ := t.GetCustomerDataByCustomerId(ctx, elem.TransactionPartnerId, "")
		resp[i].SavingAccountId = strconv.FormatUint(uint64(account.Id), 10)
		resp[i].IconUrl = customer.Photourl
		resp[i].TransactionName = customer.Fullname
	}

	return resp
}

func (t transactionService) GetTransactionDetail(ctx context.Context, transactionId uint64, cardNo string, savingAccountId uint64) (*model.TransactionDetail, error) {

	savingAccount := t.GetAccount(ctx, savingAccountId, 0, cardNo, 0)
	resp, err := t.repo.GetTransactionDetail(transactionId, savingAccount.Id)

	if err != nil {
		log.Printf("[service] Error when GetTransactionDetail %s\n", err.Error())
		return nil, err
	}

	savingProduct, err := t.GetSavingProduct(ctx, savingAccount.SavingProductId)

	if err != nil {
		log.Printf("[service] Error when GetTransactionDetail %s\n", err.Error())
		return nil, err
	}

	resp.SourceOfFund = savingProduct.Description

	customer, err := t.GetCustomerDataByCustomerId(ctx, resp.TransactionPartnerId, "")

	if err != nil {
		log.Printf("[service] Error when GetTransactionDetail %s\n", err.Error())
		return nil, err
	}

	resp.IconUrl = customer.Photourl
	resp.TransactionName = customer.Fullname

	trxInfo := map[string]string{"transaction_reference_id": resp.TransactionReferenceId}

	resp.TransactionInfo = trxInfo

	return resp, nil
}

func (t transactionService) GetCustomerDataByAccountId(ctx context.Context, accountId uint64) (*accountClient.GetSavingAccountResponse, error) {
	accountResp, err := t.accountClient.GetSavingAccount(ctx, &accountClient.GetSavingAccountRequest{
		Id: accountId,
	})
	if err != nil {
		log.Printf("[service] Error when GetCustomerDataByAccountId %s\n", err.Error())
		return nil, err
	}
	return accountResp, nil
}

func (t transactionService) GetTransactionHistoryDetails(ctx context.Context, requestData model.TransactionHistoryData, requestParam model.TransactionHistoryParam) (model.TransactionHistoryResponse, error) {
	var transactionHistory model.TransactionHistoryResponse
	var err error
	start := (requestParam.PageNumber * requestParam.Count) - requestParam.Count
	requestParam.Start = start

	if requestData.CardNo != "" {
		accountIds, err := t.GetAcctsByCard(ctx, requestData.CardNo)
		if err != nil || len(accountIds) == 0 {
			log.Printf("[service]  Error in getting Account ID Error: %s \n", err)
			return transactionHistory, err
		}
		transactionHistory, err = t.GetTransactionHistoryByAcctID(accountIds, requestData, requestParam)
		if err != nil {
			log.Printf("[service]  Error fetching Transaction History : %s \n", err)
			return transactionHistory, err
		}

	} else if requestData.SavingAccountID != 0 {
		transactionHistory, err = t.GetTransactionHistoryByAcctID([]uint64{requestData.SavingAccountID}, requestData, requestParam)
		if err != nil {
			log.Printf("[service]  Error fetching Transaction History : %s \n", err)
			return transactionHistory, err
		}
	} else if requestData.TransactionID != 0 {
		transactionHistory, err = t.repo.GetTransactionHistoryByTransactionID(requestData.TransactionID, requestData, requestParam)
		if err != nil {
			log.Printf("[service] Error when Fetch By Transaction ID %s\n", err.Error())
			return transactionHistory, err
		}

	} else if requestData.PartnerRefernceID != "" {
		transactionHistory, err = t.repo.GetTransactionHistoryByPartnerID(requestData.PartnerRefernceID, requestData, requestParam)
		if err != nil {
			log.Printf("[service] Error when GetTransactionHistory By Reference ID %s\n", err.Error())
			return transactionHistory, err
		}
	} else {
		transactionHistory, err = t.repo.GetAllTransactionHistory(requestData, requestParam)
		if err != nil {
			log.Printf("[service] Error when fetching All transactions  %s\n", err.Error())
			return transactionHistory, err
		}
	}

	transactionHistory, err = t.GetTransactionHistoryData(ctx, transactionHistory)
	if err != nil {
		log.Printf("[service] Error when GetTransactionHistory Data %s\n", err.Error())
		return transactionHistory, err
	}

	return transactionHistory, nil
}

func (t transactionService) GetTransactionHistoryByAcctID(accountIds []uint64, requestData model.TransactionHistoryData, requestParam model.TransactionHistoryParam) (model.TransactionHistoryResponse, error) {
	var transactionHistory model.TransactionHistoryResponse
	var err error
	transactionHistory, err = t.repo.GetTransactionHistoryByAccountIds(accountIds, requestData, requestParam)
	if err != nil {
		log.Printf("[service] Error when FetchTransactionHistoryByAccountIds %s\n", err.Error())
		return transactionHistory, err
	}
	return transactionHistory, nil
}

func (t transactionService) GetAcctsByCard(ctx context.Context, cardNo string) ([]uint64, error) {
	accountList, err := t.accountClient.GetCustomerSavingAccount(ctx, &accountClient.GetSavingAccountCustomerRequest{
		CardNo: cardNo})
	if err != nil {
		log.Printf("[service] Error when Fetch account by Card %s\n", err.Error())
		return nil, err
	}
	var accountIds = make([]uint64, len(accountList.List))
	for i, elem := range accountList.List {
		accountIds[i] = elem.ID
	}
	return accountIds, nil

}

func (t transactionService) GetTransactionHistoryData(ctx context.Context, transactionHistory model.TransactionHistoryResponse) (model.TransactionHistoryResponse, error) {
	for i := range transactionHistory.Data {
		data := &transactionHistory.Data[i]
		accountID := data.SavingAccountID
		toAccountID := data.ToSavingAccountID
		account, err := t.GetCustomerDataByAccountId(ctx, accountID)
		if err != nil {
			log.Printf("[service] Error when fetching account %s\n", err.Error())
			return transactionHistory, err
		}
		toAccount, err := t.GetCustomerDataByAccountId(ctx, toAccountID)
		if err != nil {
			log.Printf("[service] Error when account fetch %s\n", err.Error())
			return transactionHistory, err
		}
		customer, err := t.GetCustomerDataByCustomerId(ctx, account.CustomerId, "")
		if err != nil {
			log.Printf("[service] Error on customer Fetch %s\n", err.Error())
			return transactionHistory, err
		}
		toCustomer, err := t.GetCustomerDataByCustomerId(ctx, toAccount.CustomerId, "")
		if err != nil {
			log.Printf("[service] Error on customer data fetch %s\n", err.Error())
			return transactionHistory, err
		}
		savingProduct, err := t.accountClient.GetSavingProduct(ctx, account.SavingProductId)
		if err != nil {
			log.Printf("[service] Error when GetSavingProduct %s\n", err.Error())
			return transactionHistory, err
		}
		from := model.CustomerData{
			CustomerID:   customer.Customerid,
			CustomerName: customer.Fullname,
		}
		to := model.CustomerData{
			CustomerID:   toCustomer.Customerid,
			CustomerName: toCustomer.Fullname,
		}
		data.SourceOfFund = savingProduct.Description
		data.From = from
		data.To = to
		data.IconURL = customer.Photourl
		data.TransactionInfo = map[string]string{"transaction_reference_id": data.TransactionReferenceID}
		data.SavingProductID = account.SavingProductId
		data.ToSavingProductID = toAccount.SavingProductId
		data.CardNo = account.CardNo
		data.ToCardNo = toAccount.CardNo
	}
	return transactionHistory, nil
}

func (t transactionService) Payment(ctx context.Context, paymentRequest model.PaymentRequest) (*model.PaymentResponse, error) {
	js, err := json.Marshal(paymentRequest)

	if err != nil {
		log.Printf("Error marshailling paymentRequest, %v, %s", paymentRequest, err)
		return nil, err
	}

	keyStr := t.config.GetString(`encrypt.key`)

	key := []byte(keyStr)

	enc, err := encrypt(key, []byte(string(js)))

	if err != nil {
		log.Printf("Error encrypt paymentRequest, %v, %s", paymentRequest, err)
		return nil, err
	}

	s := base64.StdEncoding.EncodeToString(enc)

	baseUrl := t.config.GetString(`challenge.url`)

	return &model.PaymentResponse{
		ChallengeUrl:     baseUrl + "?payment_info=" + s,
		ErrorCode:        "401",
		ErrorDescription: "Request unauthorized",
	}, nil

}

func encrypt(key, text []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	b := base64.StdEncoding.EncodeToString(text)
	ciphertext := make([]byte, aes.BlockSize+len(b))
	iv := ciphertext[:aes.BlockSize]
	if _, err := io.ReadFull(cRand.Reader, iv); err != nil {
		return nil, err
	}
	cfb := cipher.NewCFBEncrypter(block, iv)
	cfb.XORKeyStream(ciphertext[aes.BlockSize:], []byte(b))
	return ciphertext, nil
}

func decrypt(key, text []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	if len(text) < aes.BlockSize {
		return nil, errors.New("ciphertext too short")
	}
	iv := text[:aes.BlockSize]
	text = text[aes.BlockSize:]
	cfb := cipher.NewCFBDecrypter(block, iv)
	cfb.XORKeyStream(text, text)
	data, err := base64.StdEncoding.DecodeString(string(text))
	if err != nil {
		return nil, err
	}
	return data, nil
}

func (t transactionService) GetTransactionDetailsBySavingAccountID(savingAccountIDs []uint64, limitCount string) (*[]model.LastTransactionDetail, error) {
	return t.repo.GetTransactionDetailsBySavingAccountID(savingAccountIDs, limitCount)
}

func (t transactionService) ValidateToken(paymentNonce string, claims *model.Claims) (*model.Claims, error) {
	var err error
	claims.IsValid = true
	token := t.config.GetString(`nonce.public.key`)

	key := []byte(token)

	var ecdsaKey *ecdsa.PublicKey
	if ecdsaKey, err = jwt.ParseECPublicKeyFromPEM(key); err != nil {
		log.Printf("Token signature not valid %s\n", err.Error())
		return claims, err
	}
	parts := strings.Split(paymentNonce, ".")
	method := jwt.GetSigningMethod(constant.Token["ALG"])
	err = method.Verify(strings.Join(parts[0:2], "."), parts[2], ecdsaKey)
	if err != nil {
		log.Printf("Token signature not valid %s\n", err.Error())
		return claims, err
	}
	tkn, err := jwt.ParseWithClaims(paymentNonce, claims, func(token *jwt.Token) (interface{}, error) {
		return ecdsaKey, nil
	})
	if err != nil {
		log.Printf(" Token not valid %s\n", err.Error())
		return claims, err
	}

	if !tkn.Valid {
		claims.IsValid = false
		log.Printf(" Token not valid ")
		return claims, err
	}

	return claims, nil
}

func (t transactionService) GetCustomerSavingAccount(ctx context.Context, customerID uint64) ([]uint64, error) {
	defer func() {
		if err := recover(); err != nil {
			log.Println("GetCustomerSavingAccount Execption : ", err)
		}
	}()
	var savingAccountIDs []uint64
	listSavingAccountsReponse, err := t.accountClient.GetCustomerSavingAccount(ctx, &accountClient.GetSavingAccountCustomerRequest{CustomerID: customerID})
	for _, list := range listSavingAccountsReponse.List {
		savingAccountIDs = append(savingAccountIDs, list.ID)
	}
	return savingAccountIDs, err
}

func (t transactionService) ValidateTokenForPayment(mobileNumber, passCode, token string) (*model.ValidateTokenForPaymentResponse, error) {
	type Code struct {
		MobileNumber string `json:"mobileNumber"`
		Passcode     string `json:"passcode"`
	}
	encryptingPassCodeRequest := Code{
		MobileNumber: mobileNumber,
		Passcode:     passCode,
	}
	js, err := json.Marshal(encryptingPassCodeRequest)

	if err != nil {
		log.Printf("Error marshailling encryptingPassCodeRequest, %v, %s", encryptingPassCodeRequest, err)
		return nil, err
	}

	keyStr := t.config.GetString(`payment.key`)

	key := []byte(keyStr)

	enc, err := encrypt(key, []byte(string(js)))

	if err != nil {
		log.Printf("Error encrypt encryptingPassCodeRequest, %v, %s", encryptingPassCodeRequest, err)
		return nil, err
	}

	s := base64.StdEncoding.EncodeToString(enc)

	validatePasscodeResponse, err := t.userClient.ValidatePasscode(context.Background(), &user_client.ValidatePasscodeRequest{PaymentCode: s})

	if err != nil {
		log.Printf("Error validatePasscodeResponse, %s", err)
		return nil, err
	}
	tokenPresent, err := t.repo.TokenPresentInTokenEvent(token)
	if err != nil {
		return nil, err
	}

	// Pass Code Valid
	if validatePasscodeResponse.Valid {
		if tokenPresent {
			tokenEventDetails, err := t.repo.GetDetailsOfTokenEvent(token)
			if err != nil {
				return nil, err
			}
			if tokenEventDetails.Status == "PASSCODE_BLOCKED" {
				if tokenEventDetails.BlockedTime.After(time.Now()) {
					return &model.ValidateTokenForPaymentResponse{
						Duration: tokenEventDetails.BlockedTime,
						Status:   tokenEventDetails.Status,
						Message:  "You are blocked please wait",
					}, nil
				}
			}
			err = t.repo.DeleteTokeninTokenEvent(token)
			if err != nil {
				return nil, err
			}
		}
		return &model.ValidateTokenForPaymentResponse{
			Status:  "PASSCODE_VALID",
			Message: "valid pass code",
		}, nil
	}

	//Pass Code invalid
	if tokenPresent {
		tokenEventDetails, err := t.repo.GetDetailsOfTokenEvent(token)
		if err != nil {
			return nil, err
		}
		tokenEventDetails.Count = tokenEventDetails.Count + 1
		tokenEventDetails.UpdatedOn = &[]time.Time{time.Now()}[0]
		var message string
		if tokenEventDetails.Count >= 5 {
			tokenEventDetails.BlockedTime = &[]time.Time{time.Now().Add(time.Hour)}[0]
			tokenEventDetails.Status = "PASSCODE_BLOCKED"
			message = "you entered wrong pass code more than 5 times you are blocked for 60 minutes"
		}
		if tokenEventDetails.Count == 4 {
			message = "if you enter one more time wrong pass code you will be blocked for 60 minutes"
		}
		err = t.repo.UpdateDetailsOfTokenEvent(token, tokenEventDetails)
		if err != nil {
			return &model.ValidateTokenForPaymentResponse{}, err
		}
		return &model.ValidateTokenForPaymentResponse{
			Duration: tokenEventDetails.BlockedTime,
			Status:   tokenEventDetails.Status,
			Message:  message,
		}, nil
	}
	var tokenEventDetails model.TokenEvent
	tokenEventDetails.Count = 1
	tokenEventDetails.Token = token
	tokenEventDetails.Status = "PASSCODE_INVALID"
	tokenEventDetails.CreatedOn = &[]time.Time{time.Now()}[0]
	tokenEventDetails.UpdatedOn = &[]time.Time{time.Now()}[0]

	err = t.repo.InsertTokenInTokenEvent(tokenEventDetails)
	if err != nil {
		return nil, err
	}
	return &model.ValidateTokenForPaymentResponse{
		Duration: tokenEventDetails.BlockedTime,
		Status:   tokenEventDetails.Status,
		Message:  "entered wrong pass code",
	}, nil
}

func (t transactionService) GetTransactionByTransactionID(ctx context.Context, transactionID uint64) (*model.TransactionDataByID, error) {
	transactionData, err := t.repo.GetTransactionByTransactionID(transactionID)
	if err != nil {
		log.Printf("Error getting transaction %s", err)
		return nil, err
	}
	fromAccount, err := t.GetCustomerDataByAccountId(ctx, transactionData.FromAccountID)
	if err != nil {
		log.Printf("Error getting Account %s", err)
		return nil, err
	}
	toAccount, err := t.GetCustomerDataByAccountId(ctx, transactionData.ToAccountID)
	if err != nil {
		log.Printf("Error getting Account %s", err)
		return nil, err
	}
	transactionData.FromProductID = fromAccount.SavingProductId
	transactionData.ToProductID = toAccount.SavingProductId
	return transactionData, nil
}

func (t transactionService) RefundFundTransfer(refundPaymentRequest model.RefundPaymentRequest) model.FundTransferResponse {
	transactionEvent, err := t.repo.GetTransactionEventById(refundPaymentRequest.TransactionID)
	if err != nil {
		log.Printf("Error [service] GetTransactionEventById %s", err)

		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       fmt.Sprintf("%v", err),
			TransactionStatus: "3 - FAILED",
		}
	}

	if (transactionEvent.EventTypeId != constant.GetEventTypeValue("PAYMENT_AT_PARTNER") || transactionEvent.EventTypeId != constant.GetEventTypeValue("PAYMENT")) &&
		transactionEvent.Status != constant.GetStatusValue("SUCCESS") {
		return model.FundTransferResponse{
			StatusCode:        constant.InvalidTransactionEventType,
			Description:       "transaction is not valid for refund",
			TransactionStatus: "3 - FAILED",
		}
	}

	if transactionEvent.IsRefunded {
		return model.FundTransferResponse{
			StatusCode:        constant.TransactionAlreadyRefunded,
			Description:       "transaction is already refunded",
			TransactionStatus: "3 - FAILED",
		}
	}

	transactionHistory, err := t.repo.GetTransactionsHistoryByOnlyTransactionID(refundPaymentRequest.TransactionID)
	if err != nil {
		return model.FundTransferResponse{
			StatusCode:        constant.TransactionAlreadyRefunded,
			Description:       fmt.Sprintf("%v", err),
			TransactionStatus: "3 - FAILED",
		}
	}

	transactionHistory, err = t.GetTransactionHistoryData(context.Background(), transactionHistory)
	if err != nil {
		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       fmt.Sprintf("%v", err),
			TransactionStatus: "3 - FAILED",
		}
	}
	var description = "REFUND"
	var locationInfo = ""

	if refundPaymentRequest.Description != "" {
		description = refundPaymentRequest.Description
	}
	if refundPaymentRequest.LocationInfo != "" {
		locationInfo = refundPaymentRequest.LocationInfo
	}

	rowsAffected, err := t.repo.UpdateTransactionEventRefunded(refundPaymentRequest.TransactionID)
	if err != nil || rowsAffected == 0 {
		log.Printf("Error [service] UpdateTransactionEventRefunded %s", err)
		return model.FundTransferResponse{
			StatusCode:        constant.InternalSystemError,
			Description:       fmt.Sprintf("%v", err),
			TransactionStatus: "3 - FAILED",
		}
	}

	insertFundTransferModel := model.InsertFundTransferRequest{
		PartnerReferenceId: refundPaymentRequest.RefundRefernceCode,
		FromAccountProduct: transactionHistory.Data[0].ToSavingProductID,
		FromCustomerId:     transactionHistory.Data[0].To.CustomerID,
		FromCustomerCardNo: transactionHistory.Data[0].ToCardNo,
		ToAccountProduct:   transactionHistory.Data[0].SavingProductID,
		ToCustomerId:       transactionHistory.Data[0].From.CustomerID,
		ToCustomerCardNo:   transactionHistory.Data[0].CardNo,
		Amount:             decimal.NewFromFloat(transactionHistory.Data[0].TransactionAmount),
		Description:        description,
		TransactionType:    constant.GetEventTypeValue("REFUND"),
		LocationInfo:       locationInfo,
		IsCommit:           1,
	}

	fundTransferResponse := t.InsertFundTransfer(context.Background(), insertFundTransferModel)

	return fundTransferResponse
}
func (t transactionService) GenerateNonce(ctx context.Context, paymentInfo, header, passcode string) (*model.PaymentResponse, error) {
	keyStr := t.config.GetString(`encrypt.key`)

	key := []byte(keyStr)
	dec, err := base64.StdEncoding.DecodeString(paymentInfo)

	if err != nil {
		log.Println(err)
		return nil, err
	}

	dec, err = decrypt(key, dec)
	if err != nil {
		log.Println(err)
		return nil, err
	}
	paymentReq := model.PaymentRequest{}

	err = json.Unmarshal(dec, &paymentReq)
	if err != nil {
		log.Println(err)
		return nil, err
	}

	var mobileNumber string
	var partnerClientId string

	defaultAlfagift := t.config.GetBool(`default.partner.alfagift`)

	if token, _ := jwt.ParseWithClaims(header, &model.TokenClaims{}, nil); token != nil {
		claim := token.Claims.(*model.TokenClaims)
		mobileNumber = claim.Subject
		if defaultAlfagift {
			partnerClientId = t.config.GetString(`partner.client.id`)
		} else {
			partnerClientId = claim.Audience[0]
		}
	}

	type Code struct {
		MobileNumber string `json:"mobileNumber"`
		Passcode     string `json:"passcode"`
	}

	encryptingPassCodeRequest := Code{
		MobileNumber: mobileNumber,
		Passcode:     passcode,
	}
	js, err := json.Marshal(encryptingPassCodeRequest)

	if err != nil {
		log.Printf("Error marshailling encryptingPassCodeRequest, %v, %s", encryptingPassCodeRequest, err)
		return nil, err
	}

	enc, err := encrypt(key, []byte(string(js)))

	if err != nil {
		log.Printf("Error encrypt encryptingPassCodeRequest, %v, %s", encryptingPassCodeRequest, err)
		return nil, err
	}

	s := base64.StdEncoding.EncodeToString(enc)

	validatePasscodeResponse, err := t.userClient.ValidatePasscode(ctx, &user_client.ValidatePasscodeRequest{PaymentCode: s})
	if err != nil {
		log.Println(err)
		return nil, err
	}
	if validatePasscodeResponse.Valid {

		cust, _ := t.GetCustomerDataByCustomerId(ctx, 0, mobileNumber)
		pci, _ := t.repo.GetPartnerId(partnerClientId)
		part, _ := t.GetCustomerDataByCustomerId(ctx, pci, "")

		nowUnix := time.Now().Unix()

		expiresAt := nowUnix + (5 * 60 * 1000)

		nonceStruct := &model.Claims{
			Amount:                  decimal.NewFromFloat(paymentReq.Amount),
			Fee:                     decimal.NewFromFloat(paymentReq.Fee),
			Tax:                     decimal.NewFromFloat(paymentReq.Tax),
			TransactionType:         paymentReq.TransactionType,
			Description:             paymentReq.Description,
			PartnerReferenceCode:    paymentReq.PartnerReferenceCode,
			CustomerId:              cust.Customerid,
			CustomerProductId:       1,
			PartnerId:               part.Customerid,
			PartnerProductId:        3,
			IsValid:                 true,
			PartnerPaymentTimestamp: paymentReq.PartnerPaymentTimestamp,
			StandardClaims: jwt.StandardClaims{
				ExpiresAt: expiresAt,
			},
		}

		privateKey := t.config.GetString(`nonce.private.key`)

		privateKeyByte := []byte(privateKey)

		var ecdsaKey *ecdsa.PrivateKey
		if ecdsaKey, err = jwt.ParseECPrivateKeyFromPEM(privateKeyByte); err != nil {
			log.Printf("Token signature not valid %s\n", err.Error())
			return nil, err
		}

		token := jwt.NewWithClaims(jwt.SigningMethodES256, nonceStruct)

		tokenString, err := token.SignedString(ecdsaKey)
		if err != nil {
			log.Println(err)
		}

		return &model.PaymentResponse{
			PaymentNonce: tokenString,
		}, nil
	} else {
		return nil, constant.InvalidPasscodeError
	}
}

func (t transactionService) GetTransactionPaymentInfo(ctx context.Context, paymentTimestamp, partnerRefID string) (*model.PartnerPaymentInformation, int, error) {
	var err error
	var count int
	partnerPaymentInfo, count, err := t.repo.GetTransactionPaymentInfo(paymentTimestamp, partnerRefID)
	if err != nil {
		log.Printf("[service] Error when GetPaymentInfo Data %s\n", err.Error())
		return partnerPaymentInfo, count, err
	}
	partnerPaymentInfo.ResponseCode = constant.GeneralSuccessCode
	partnerPaymentInfo.ResponseText = constant.GeneralSuccessString
	return partnerPaymentInfo, count, nil
}

func NewTransactionService(
	repo repository.TransactionRepository,
	accountTransactionService accountClient.AccountTransactionClient,
	accountService accountClient.AccountClient,
	customerService customerClient.CustomerClient,
	bookkeeperService bookkeeper_service.Service,
	kafkaClient messaging.Client,
	userClient user_client.UserClient,
	config core_config.Config,
) TransactionService {
	return &transactionService{
		repo:                     repo,
		accountTransactionClient: accountTransactionService,
		accountClient:            accountService,
		customerClient:           customerService,
		bookkeeperService:        bookkeeperService,
		kafkaClient:              kafkaClient,
		userClient:               userClient,
		config:                   config,
	}
}
