package service

import (
	"testing"
	"time"
)

func TestIdrFormat(t *testing.T) {
	input1 := float64(100000)
	output1 := idrFormat(input1)
	expected1 := "Rp 100.000"
	if output1 != expected1 {
		t.Errorf("%f have output %s, should be %s", input1, output1, expected1)
	}

	input2 := float64(49999)
	output2 := idrFormat(input2)
	expected2 := "Rp 49.999"
	if output2 != expected2 {
		t.Errorf("%f have output %s, should be %s", input2, output2, expected2)
	}
}

func TestCreatedTimeFormat(t *testing.T) {
	location, err := time.LoadLocation("Asia/Jakarta")
	if err != nil {
		t.Errorf("Error get location %s", err.Error())
		return
	}
	input1 := time.Date(2019, 1, 28, 13, 23, 6, 177, location)
	output1 := createdTimeFormat(input1)
	expected1 := "2019-01-28T13:23:06+0700"
	if output1 != expected1 {
		t.Errorf("%s have output %s, should be %s", input1, output1, expected1)
	}

	location2, err := time.LoadLocation("UTC")
	if err != nil {
		t.Errorf("Error get location %s", err.Error())
		return
	}
	input2 := time.Date(2019, 1, 28, 13, 23, 6, 177, location2)
	output2 := createdTimeFormat(input2)
	expected2 := "2019-01-28T13:23:06+0000"
	if output2 != expected2 {
		t.Errorf("%s have output %s, should be %s", input2, output2, expected2)
	}
}

func TestCreatedTimeParse(t *testing.T) {
	location1, _ := time.LoadLocation("UTC")
	input1 := "2019-01-28T13:23:06+0000"
	output1 := createdTimeParse(input1)
	expected1 := time.Date(2019, 1, 28, 13, 23, 6, 0, location1)
	t.Logf("output location %s", output1.Location().String())
	if !output1.Equal(expected1) {
		t.Errorf("%s have output %s, should be %s", input1, output1, expected1)
	}

	location2, _ := time.LoadLocation("Asia/Jakarta")
	input2 := "2019-01-28T13:23:06+0700"
	output2 := createdTimeParse(input2)
	expected2 := time.Date(2019, 1, 28, 13, 23, 6, 0, location2)
	t.Logf("output location %s", output2.Location().String())
	if !output2.Equal(expected2) {
		t.Errorf("%s have output %s, should be %s", input2, output2, expected2)
	}
}
