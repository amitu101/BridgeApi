package service

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"strconv"
	"strings"
	"time"

	"git.capitalx.id/dimii/transaction/constant"
	"git.capitalx.id/dimii/transaction/model"
	"github.com/dustin/go-humanize"

	notificationModel "git.capitalx.id/core/notification/model"
	accountClient "git.capitalx.id/dimii/account/client"
)

//publish to kafka / redis to be consumed by notification service
/*
	https://capitalx.atlassian.net/wiki/spaces/SIM/pages/115179537/Notification+Service+Message+contract
	id: To identify the template for the notification
	Channel : Should support multiple channels
		SMS/Text = 1
		Email = 2
		Push Notification = 4
	Recipient could be number/email/device token for push notification

	sample message
	{
	   "id":"trx.topup.in",
	   "channel":4,
	   "language":"in",
	   "sender":"Nis",
	   "recipient":"fiQgbu6gQkqyk2dtzPKD4V:APA91bGv80g4gFQQlZbXhYN3ZTG4maEkuC91Sd0yfJ4Z5UjxmUZXe23MqRY63gPPkLECnTTKQpZajhhrei6XejHW3iFyXm5StcP4qhiRS9wayN5gf14UQ7aCtVxbCD7roXoMKZPAS0d6",
	   "data":{
		  "userID":"1",
		  "notificationTypeID":"1",
		  "landingurl":"dimii://history-detail/1",
		  "topupAmount": "Rp10.000",
		  "balance": "Rp100.000",
		  "createdBy":"1",
		  "createdTime":"12331213"
	   }
	}
*/
func (t transactionService) TopupNotification(transactionEventType uint16, sat model.SavingAccountTransaction, authResponse *accountClient.AuthFundTransferResponse, createdTime time.Time) error {

	var savingAccountCustomer *accountClient.GetSavingAccountResponse
	if transactionEventType == constant.GetEventTypeValue("TOPUP") || transactionEventType == constant.GetEventTypeValue("REFUND") {
		savingAccountCustomer = authResponse.ToSavingAccount
	} else {
		//for payment
		savingAccountCustomer = authResponse.FromSavingAccount
	}

	userDevice, err := t.userClient.GetUserDeviceByMobileNumber(context.Background(), savingAccountCustomer.CardNo)

	if err != nil {
		log.Println("Error get user device data", err)
		return err
	}

	if userDevice.DeviceID == "" {
		log.Println("Error get user device data", err)
		return errors.New("user device not found")
	}

	amountFloat, _ := sat.Amount.Float64()
	balanceStr, amountStr := idrFormat(savingAccountCustomer.Balance), idrFormat(amountFloat)
	notificationMessage := notificationModel.NotificationMessage{
		NotificationID: "trx.topup.in",
		Channel:        4,
		Language:       "in",
		Sender:         "Alfamart",
		Recipient:      userDevice.DeviceRegToken,
		Data: map[string]string{
			"userID":             strconv.FormatUint(savingAccountCustomer.CustomerId, 10),
			"notificationTypeID": "2",
			"landingurl":         fmt.Sprintf("dimii://history-detail/%d?saving_account_id=%d", sat.TransactionId, savingAccountCustomer.Id),
			"topupAmount":        amountStr,
			"balance":            balanceStr,
			"createdTime":        createdTimeFormat(createdTime),
			"createdBy":          strconv.FormatUint(sat.CreatedBy, 10),
		},
	}

	var message, _ = json.Marshal(notificationMessage)
	return t.kafkaClient.Publish(notificationModel.NOTIFICATION_TOPIC, message)
}

func idrFormat(data float64) string {
	return fmt.Sprintf("Rp %s", humanize.FormatFloat("#.###,", data))
}

func createdTimeFormat(time time.Time) string {
	return strings.Replace(time.Format("2006-01-02T15:04:05Z0700"), "Z", "+0000", 1)
}

func createdTimeParse(timeStr string) time.Time {
	t, err := time.Parse("2006-01-02T15:04:05Z0700", timeStr)
	if err != nil {
		log.Println("Error convert string to time ", err)
	}
	return t
}
