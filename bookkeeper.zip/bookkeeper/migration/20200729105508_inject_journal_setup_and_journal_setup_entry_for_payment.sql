-- +goose Up
-- SQL in this section is executed when the migration is applied.
INSERT INTO journal_setup (transaction_type,acc_transaction_type,remark,created_by,created_timestamp,updated_by,updated_timestamp) VALUES 
(2,NULL,'Payment at partner',0,'2020-07-06 13:16:54.000',NULL,NULL);

INSERT INTO journal_setup_entry (transaction_type,entry_type,sequence,gl_account,mapping_field) VALUES 
(2,'D',1,'200.002','amount')
,(2,'C',1,'200.003','amount');

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DELETE FROM journal_setup WHERE transaction_type = 2;
DELETE FROM journal_setup_entry WHERE transaction_type = 2;