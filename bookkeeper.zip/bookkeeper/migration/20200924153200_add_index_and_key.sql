-- +goose Up
-- SQL in this section is executed when the migration is applied.

ALTER TABLE bk_entity_mapping ADD CONSTRAINT bk_entity_mapping_pk PRIMARY KEY (module_id, app_id);

ALTER TABLE journal_setup_entry ADD COLUMN id BIGINT AUTO_INCREMENT NOT NULL PRIMARY KEY FIRST;

INSERT INTO journal_setup (transaction_type,acc_transaction_type,remark,created_by,created_timestamp,updated_by,updated_timestamp) VALUES
(3,NULL,'Refund payment',0,'2020-09-25 13:00:54.000',NULL,NULL);

-- still use old gl account
INSERT INTO journal_setup_entry (transaction_type,entry_type,sequence,gl_account,mapping_field) VALUES
(3,'C',1,'200.002','amount')
,(3,'D',1,'200.003','amount');

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.

ALTER TABLE bk_entity_mapping DROP PRIMARY KEY;
ALTER TABLE journal_setup_entry DROP COLUMN id;

DELETE FROM journal_setup WHERE transaction_type = 3;
DELETE FROM journal_setup_entry WHERE transaction_type = 3;