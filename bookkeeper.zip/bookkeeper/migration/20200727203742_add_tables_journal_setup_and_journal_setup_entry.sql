-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE IF NOT EXISTS journal_setup_entry (
  transaction_type int(11) NOT NULL,
  entry_type char(1) NOT NULL,
  sequence int(11) NOT NULL,
  gl_account varchar(20) NOT NULL,
  mapping_field varchar(30) NOT NULL
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS journal_setup (
  transaction_type int(11) NOT NULL,
  acc_transaction_type varchar(100) DEFAULT NULL,
  remark varchar(100) DEFAULT NULL,
  created_by bigint(20) unsigned NOT NULL DEFAULT '0',
  created_timestamp timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_by bigint(20) unsigned DEFAULT NULL,
  updated_timestamp timestamp NULL DEFAULT NULL,
  PRIMARY KEY (transaction_type)
) ENGINE=InnoDB;


INSERT INTO journal_setup (transaction_type,acc_transaction_type,remark,created_by,created_timestamp,updated_by,updated_timestamp) VALUES 
(1,NULL,'E Money Topup',0,'2020-07-06 13:16:54.000',NULL,NULL);

INSERT INTO journal_setup_entry (transaction_type,entry_type,sequence,gl_account,mapping_field) VALUES 
(1,'D',1,'101.002','amount')
,(1,'C',1,'200.002','amount');

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP TABLE IF EXISTS journal_setup_entry;
DROP TABLE IF EXISTS journal_setup;
