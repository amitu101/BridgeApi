-- +goose Up
-- SQL in this section is executed when the migration is applied.
CREATE TABLE IF NOT EXISTS bk_entity_mapping (
	module_id INT ( 11 ) NOT NULL,
	app_id BIGINT ( 20 )UNSIGNED NOT NULL,
	external_id VARCHAR ( 30 ),
	STATUS TINYINT ( 3 )UNSIGNED NOT NULL,
	created_by BIGINT ( 20 )UNSIGNED NOT NULL ,
	created_timestamp TIMESTAMP NOT NULL,
	updated_by BIGINT ( 20 )UNSIGNED ,
	updated_timestamp TIMESTAMP
);

-- +goose Down
-- SQL in this section is executed when the migration is rolled back.
DROP TABLE IF EXISTS bk_entity_mapping;