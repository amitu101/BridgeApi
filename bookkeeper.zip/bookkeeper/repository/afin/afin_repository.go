package afin

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"

	cfg "git.capitalx.id/core/config"
	"git.capitalx.id/dimii/bookkeeper/models"
	"git.capitalx.id/dimii/bookkeeper/utils"
)

//AFRepository ...
type AFRepository interface {
	CreateCustomerAccountInFineract(models.CustomerAccountFineractRequest) (map[string]interface{}, error)
}

type afRepository struct {
	config cfg.Config
}

//NewRepository ...
func NewRepository(config cfg.Config) AFRepository {
	return &afRepository{config: config}
}

//CreateCustomerAccountInFineract ...
func (r *afRepository) CreateCustomerAccountInFineract(customerAccount models.CustomerAccountFineractRequest) (map[string]interface{}, error) {
	customerAccountBytes, err := json.Marshal(customerAccount)
	if err != nil {
		return nil, err
	}
	var responseBody map[string]interface{}
	httpClient := &http.Client{}
	req, err := http.NewRequest("POST", r.config.GetString("server.fineract_address")+"/clients", bytes.NewBuffer(customerAccountBytes))
	if err != nil {
		return nil, err
	}
	req.Header.Add("Authorization", r.config.GetString("server.fineract_authorization"))
	req.Header.Add("Content-Type", "application/json")
	req.Header.Add("Fineract-Platform-TenantId", r.config.GetString("server.fineract_tenant_id"))
	response, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	body, _ := ioutil.ReadAll(response.Body)
	err = json.Unmarshal(body, &responseBody)
	utils.PrintErrorNotNil(err)
	return responseBody, nil
}
