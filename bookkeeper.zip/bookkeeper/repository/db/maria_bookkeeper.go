package db

import (
	"database/sql"
	"fmt"
	"log"

	"git.capitalx.id/dimii/bookkeeper/models"
)

type BookkeeperRepository interface {
	InsertClientIDAndAccntID(client models.CustomerAccountLocalDB) error
	GetFineractAccountIDAndSavingIDForFundTransfer(fundTransfer *models.FundTransferTransactionGrpcRequest) (*models.FundTransferTransactionGrpcRequest, error)
	LoadJournalSetupFromDB(transactionType uint32) (*models.JournalSetUp, error)
}

type bookkeeperRepository struct {
	Conn *sql.DB
}

// NewMariaAccountRepository will create an object that represent the account.Repository interface
func NewBookkeeperRepository(Conn *sql.DB) BookkeeperRepository {
	return &bookkeeperRepository{Conn}
}

const (
	//INSERTQUERY ...
	INSERTQUERY = "INSERT INTO bk_entity_mapping(module_id,app_id,external_id,status,created_by,created_timestamp) VALUES(?,?,?,?,?,?);"
	//GETACCOUNTIDANDSAVINGIDQUERY ...
	GETACCOUNTIDANDSAVINGIDQUERY = "SELECT external_id from bk_entity_mapping where module_id=? AND app_id=?"
	//GETJOURNALSETUPQUERY ...
	GETJOURNALSETUPQUERY = "SELECT remark FROM journal_setup where transaction_type=?"
	//GETJOURNALSETUPENTRYQUERY ...
	GETJOURNALSETUPENTRYQUERY = "SELECT entry_type,sequence,gl_account,mapping_field FROM journal_setup_entry where transaction_type=?"
	//CHECKJOURNALSETUPAVAILABILITYQUERY ...
	CHECKJOURNALSETUPAVAILABILITYQUERY = "SELECT exists (SELECT * FROM journal_setup where transaction_type=?)"
)

//InsertClientIDAndAccntID ...
func (mdb *bookkeeperRepository) InsertClientIDAndAccntID(customerAccount models.CustomerAccountLocalDB) error {
	stmt, err := mdb.Conn.Prepare(INSERTQUERY)
	if err != nil {
		return err
	}
	defer stmt.Close()

	_, err = stmt.Exec(customerAccount.ModuleID, customerAccount.AppID, customerAccount.ExternalID, customerAccount.Satus,
		customerAccount.CreatedBy, customerAccount.CreatedTimestamp)
	if err != nil {
		return err
	}
	return nil

}

//GetFineractAccountIDAndSavingIDForFundTransfer ...
func (mdb *bookkeeperRepository) GetFineractAccountIDAndSavingIDForFundTransfer(fundTransferGrpcRequest *models.FundTransferTransactionGrpcRequest) (*models.FundTransferTransactionGrpcRequest, error) {
	stmt, err := mdb.Conn.Prepare(GETACCOUNTIDANDSAVINGIDQUERY)
	if err != nil {
		return nil, err
	}
	defer stmt.Close()
	result := *fundTransferGrpcRequest
	err = stmt.QueryRow(1, fundTransferGrpcRequest.FromCustomerID).Scan(&result.FromCustomerID)
	if err != nil && err != sql.ErrNoRows {
		log.Println(err)
		return nil, err
	}
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("customer id mapping not found for module id %d and customer %d", 1, fundTransferGrpcRequest.FromCustomerID)
	}
	err = stmt.QueryRow(1, fundTransferGrpcRequest.ToCustomerID).Scan(&result.ToCustomerID)
	if err != nil && err != sql.ErrNoRows {
		log.Println(err)
		return nil, err
	}
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("customer id mapping not found for module id %d and customer %d", 1, fundTransferGrpcRequest.ToCustomerID)
	}
	err = stmt.QueryRow(2, fundTransferGrpcRequest.FromAccountID).Scan(&result.FromAccountID)
	if err != nil && err != sql.ErrNoRows {
		log.Println(err)
		return nil, err
	}
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("customer id mapping not found for module id %d and customer %d", 2, fundTransferGrpcRequest.FromAccountID)
	}
	err = stmt.QueryRow(2, fundTransferGrpcRequest.ToAccountID).Scan(&result.ToAccountID)
	if err != nil && err != sql.ErrNoRows {
		log.Println(err)
		return nil, err
	}
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("customer id mapping not found for module id %d and customer %d", 2, fundTransferGrpcRequest.ToAccountID)
	}

	return &result, nil
}

func (mdb *bookkeeperRepository) LoadJournalSetupFromDB(transactionType uint32) (*models.JournalSetUp, error) {
	var exist bool
	existStmt, err := mdb.Conn.Prepare(CHECKJOURNALSETUPAVAILABILITYQUERY)
	if err != nil {
		return nil, err
	}

	defer existStmt.Close()

	if err = existStmt.QueryRow(transactionType).Scan(&exist); err != nil {
		return nil, err
	}
	if !exist {
		return nil, fmt.Errorf("no journal setup found for journal type : %d", transactionType)
	}

	journalSetupStmt, err := mdb.Conn.Prepare(GETJOURNALSETUPQUERY)
	if err != nil {
		return nil, err
	}
	defer journalSetupStmt.Close()
	journalSetupEntryStmt, err := mdb.Conn.Prepare(GETJOURNALSETUPENTRYQUERY)
	if err != nil {
		return nil, err
	}
	defer journalSetupEntryStmt.Close()

	journalSetup := models.JournalSetUp{TransactionType: transactionType}
	if err = journalSetupStmt.QueryRow(transactionType).Scan(&journalSetup.Remark); err != nil {
		return nil, err
	}
	rows, err := journalSetupEntryStmt.Query(transactionType)
	if err != nil {
		log.Println(err)
		return nil, err
	}
	if rows.Err() != nil {
		log.Println(rows.Err())
		return nil, rows.Err()
	}
	defer rows.Close()
	for rows.Next() {
		var entry models.JournalEntrySetup
		err = rows.Scan(&entry.Type, &entry.Sequence, &entry.Account, &entry.MappingField)
		if err != nil {
			return nil, err
		}
		journalSetup.Entries = append(journalSetup.Entries, entry)
	}
	return &journalSetup, nil
}
