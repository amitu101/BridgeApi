package delivery

// import (
// 	"context"
// 	"encoding/json"
// 	"testing"

// 	"git.capitalx.id/dimii/bookkeeper/models"
// 	"git.capitalx.id/dimii/bookkeeper/utils/errors"
// 	"github.com/stretchr/testify/assert"
// 	"github.com/stretchr/testify/mock"
// )

// type MockRepository struct {
// 	mock.Mock
// }

// func (mock *MockRepository) CreateAccountCustomerToBookKeeper(ctx context.Context, customerAccount models.CustomerAccount) (map[string]interface{}, *errors.RestErr) {
// 	args := mock.Called()
// 	result := args.Get(0)
// 	m := make(map[string]interface{})
// 	jBytes, _ := json.Marshal(result)
// 	json.Unmarshal(jBytes, &m)
// 	return map[string]interface{}{"clientId": 1.00, "officeId": customerAccount.OfficeID}, nil
// }

// func TestCreateAccountCustomerToBookKeeper(t *testing.T) {
// 	mockRepo := new(MockRepository)

// 	testgRPC := NewGRPCServer(mockRepo)

// 	reqData := CreateAccountCustomerRequest{
// 		AccountId:       1,
// 		CardNumber:      "7483641224",
// 		SavingProductId: 1,
// 		CustomerID:      1,
// 		FirstName:       "shubham",
// 		LastName:        "kumar",
// 		CreatedBy:       1,
// 	}
// 	expectedResp := make(map[string]interface{})

// 	mockRepo.On("CreateAccountCustomerToBookKeeper").Return(expectedResp, nil)
// 	var c context.Context
// 	resp, _ := testgRPC.CreateAccountCustomerToBookKeeper(c, &reqData)
// 	mockRepo.AssertExpectations(t)

// 	assert.Equal(t, "success", resp.Message)

// }
