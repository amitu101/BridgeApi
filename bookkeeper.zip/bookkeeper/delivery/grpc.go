package delivery

import (
	"context"

	"git.capitalx.id/dimii/bookkeeper/models"

	"git.capitalx.id/dimii/bookkeeper/service"
)

//CustomerAccountServer ...
type CustomerAccountServer interface {
	CreateAccountCustomerToBookKeeper(ctx context.Context, req *CreateAccountCustomerRequest) (*CreateAccountCustomerResponse, error)
	FundTransferRequestToBookkeeper(ctx context.Context, req *FundTransferTransactionRequest) (*CreateAccountCustomerResponse, error)
}

type grpcCustomerAccountService struct {
	customerSrv service.Service
}

//NewGRPCServer ...
func NewGRPCServer(svc service.Service) CustomerAccountServer {
	return &grpcCustomerAccountService{customerSrv: svc}
}

func (s *grpcCustomerAccountService) CreateAccountCustomerToBookKeeper(ctx context.Context, req *CreateAccountCustomerRequest) (*CreateAccountCustomerResponse, error) {

	customerAccount := models.CustomerAccountGrpcRequest{
		FullName:        req.GetFullName(),
		CardNumber:      req.GetCardNumber(),
		CustomerID:      req.GetCustomerID(),
		AccountID:       req.GetAccountID(),
		SavingProductID: req.GetSavingProductID(),
		CustomerType:    req.GetCustomerType(),
	}
	_, err := s.customerSrv.CreateAccountCustomerToBookKeeper(ctx, customerAccount)

	if err != nil {
		return nil, err
	}

	return &CreateAccountCustomerResponse{Message: "success"}, nil
}

func (s *grpcCustomerAccountService) FundTransferRequestToBookkeeper(ctx context.Context, req *FundTransferTransactionRequest) (*CreateAccountCustomerResponse, error) {

	fundTransfer := models.FundTransferTransactionGrpcRequest{
		FromCustomerID:          req.GetFromCustomerID(),
		FromAccountProductGroup: req.GetFromAccountProductGroup(),
		FromAccountID:           req.GetFromAccountID(),
		ToCustomerID:            req.GetToCustomerID(),
		ToAccountProductGroup:   req.GetToAccountProductGroup(),
		ToAccountID:             req.GetToAccountID(),
		TransferDate:            req.GetTransferDate(),
		Amount:                  req.GetAmount(),
		Description:             req.GetDescription(),
		JournalType:             req.GetJournalType(),
	}
	err := s.customerSrv.FundTransferRequestToBookkeeper(ctx, fundTransfer)

	if err != nil {
		return nil, err
	}

	return &CreateAccountCustomerResponse{Message: "success"}, nil
}
