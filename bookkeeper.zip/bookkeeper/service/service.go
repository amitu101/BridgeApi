package service

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"

	"git.capitalx.id/core/config"

	"git.capitalx.id/dimii/bookkeeper/models"
	"git.capitalx.id/dimii/bookkeeper/repository/afin"
	"git.capitalx.id/dimii/bookkeeper/repository/db"
	"git.capitalx.id/dimii/bookkeeper/utils"
	"git.capitalx.id/dimii/bookkeeper/utils/date_utils"

	"errors"
)

//Service ...
type Service interface {
	CreateAccountCustomerToBookKeeper(context.Context, models.CustomerAccountGrpcRequest) (map[string]interface{}, error)
	FundTransferRequestToBookkeeper(context.Context, models.FundTransferTransactionGrpcRequest) error
	//getJournalEntryForFineract(map[string]float64, models.JournalSetUp, models.FundTransferTransactionGrpcRequest) models.JournalEntryFineractRequestBody

}

type service struct {
	repository   afin.AFRepository
	dbRepository db.BookkeeperRepository
	config       config.Config
}

//NewService ...
func NewService(repo afin.AFRepository, dbRepo db.BookkeeperRepository, config config.Config) Service {
	return &service{
		repository:   repo,
		dbRepository: dbRepo,
		config:       config,
	}
}

func (s *service) addHeaders(header *http.Header) {
	header.Add("Authorization", s.config.GetString("server.fineract_authorization"))
	header.Add("Content-Type", "application/json")
	header.Add("Fineract-Platform-TenantId", s.config.GetString("server.fineract_tenant_id"))
}

func (s *service) CreateAccountCustomerToBookKeeper(_ context.Context, customerAccount models.CustomerAccountGrpcRequest) (map[string]interface{}, error) {
	response, err := s.repository.CreateCustomerAccountInFineract(getCustomerAccountRequestBodyForFineract(customerAccount))
	if err != nil {
		return nil, err
	}

	log.Printf("[CreateAccountCustomerToBookKeeper] response from fineract is: %s\n", response)

	cID, ok := response["clientId"].(float64)
	if !ok {
		return nil, errors.New("error converting the client id returned by fineract")
	}
	aID, ok := response["savingsId"].(float64)
	if !ok {
		return nil, errors.New("error converting the savings id returned by fineract")
	}
	fineractCustomerID := strconv.FormatFloat(cID, 'f', -1, 64)
	fineractAccountID := strconv.FormatFloat(aID, 'f', -1, 64)
	csdb := models.CustomerAccountLocalDB{
		ModuleID:         1,
		AppID:            customerAccount.CustomerID,
		ExternalID:       fineractCustomerID,
		Satus:            1,
		CreatedBy:        1,
		CreatedTimestamp: date_utils.GetNow(),
	}
	cadb := models.CustomerAccountLocalDB{
		ModuleID:         2,
		AppID:            customerAccount.AccountID,
		ExternalID:       fineractAccountID,
		Satus:            1,
		CreatedBy:        1,
		CreatedTimestamp: date_utils.GetNow(),
	}

	err = s.dbRepository.InsertClientIDAndAccntID(csdb)
	if err != nil {
		return nil, err
	}
	err = s.dbRepository.InsertClientIDAndAccntID(cadb)
	if err != nil {
		return nil, err
	}
	return response, nil
}

func (s *service) FundTransferRequestToBookkeeper(_ context.Context, fundTransfer models.FundTransferTransactionGrpcRequest) error {
	insertJournalReq, err := s.getInsertJournalHttpRequest(fundTransfer.JournalType, fundTransfer.Amount, fundTransfer.TransferDate)
	if err != nil {
		log.Printf("error generate request journal: %s\n", err.Error())
		return err
	}

	insertFinReq, err := s.getInsertFineractHttpRequest(fundTransfer)
	if err != nil {
		log.Printf("error generate fineract request: %s\n", err.Error())
		return err
	}

	result, err := sendRequest(insertJournalReq)

	if err != nil {
		log.Printf("error create journal to fineract: %s\n", err.Error())
		return err
	}

	errFin, errExist := result["errors"]
	if errExist {
		log.Println(errFin)
		return errors.New(utils.StructToString(errFin))
	}

	journalTrxId := result["transactionId"].(string)
	reverseJournalReq, reverseErr := s.getReverseJournalRequest(journalTrxId)

	result, err = sendRequest(insertFinReq)

	if err != nil {
		if reverseErr == nil {
			result, errRev := sendRequest(reverseJournalReq)
			log.Println("reverse response", utils.StructToString(result))
			utils.PrintErrorNotNil(errRev)
		}
		log.Printf("error transfer in fineract: %s\n", err.Error())
		return err
	}

	errFin, errExist = result["errors"]
	if errExist {
		log.Println(errFin)
		if reverseErr == nil {
			result, errRev := sendRequest(reverseJournalReq)
			log.Println("reverse response", utils.StructToString(result))
			utils.PrintErrorNotNil(errRev)
		}
		return errors.New(utils.StructToString(errFin))
	}

	return err
}

func (s *service) getInsertJournalHttpRequest(journalType uint32, amount float64, transferDate string) (*http.Request, error) {
	journalSetup, err := s.dbRepository.LoadJournalSetupFromDB(journalType)
	if err != nil {
		log.Printf("[LoadJournalSetupFromDB] error from bookkeeper while load journal setup is: %s\n", err.Error())
		return nil, err
	}

	m := make(map[string]float64)
	m["amount"] = amount
	journalReqBody, err := s.getJournalEntryForFineract(m, *journalSetup, transferDate)
	if err != nil {
		return nil, err
	}

	reqBytes, err := json.Marshal(journalReqBody)
	if err != nil {
		return nil, err
	}

	log.Println("journal entries request", string(reqBytes))

	req, err := http.NewRequest("POST", s.config.GetString("server.fineract_address")+"/journalentries", bytes.NewBuffer(reqBytes))
	if err != nil {
		return nil, err
	}
	s.addHeaders(&req.Header)

	return req, nil
}

func (s *service) getReverseJournalRequest(journalTransactionId string) (*http.Request, error) {
	url := fmt.Sprintf("%s/journalentries/%s?command=reverse",
		s.config.GetString("server.fineract_address"), journalTransactionId)

	req, err := http.NewRequest("POST", url, bytes.NewBuffer([]byte("{}")))
	s.addHeaders(&req.Header)
	if err != nil {
		return nil, err
	}
	return req, nil
}

func (s *service) getInsertFineractHttpRequest(fundTransfer models.FundTransferTransactionGrpcRequest) (*http.Request, error) {
	re, err := s.dbRepository.GetFineractAccountIDAndSavingIDForFundTransfer(&fundTransfer)

	if err != nil {
		log.Printf("[GetFineractAccountIDAndSavingIDForFundTransfer] error is: %s\n", err.Error())
		return nil, err
	}

	r, err := s.getFundTransferTransactionRequest(getTransferTransactionBodyForFineract(re))
	if err != nil {
		log.Printf("[FundTransferTransactionRequestToFineract] error from fineract is: %s\n", err.Error())
		return nil, err
	}

	return r, nil
}

func (s *service) getFundTransferTransactionRequest(fundTransfer models.FundTransferTransactionFineractRequest) (*http.Request, error) {
	reqBytes, err := json.Marshal(fundTransfer)
	if err != nil {
		return nil, err
	}
	log.Println("fund transfer fineract request", string(reqBytes))
	req, err := http.NewRequest("POST", s.config.GetString("server.fineract_address")+"/accounttransfers", bytes.NewBuffer(reqBytes))
	if err != nil {
		return nil, err
	}
	s.addHeaders(&req.Header)

	return req, nil
}

func sendRequest(request *http.Request) (map[string]interface{}, error) {
	httpClient := &http.Client{}
	response, err := httpClient.Do(request)
	//log.Println("Send", utils.ReadIoReaderToString(request.Body))
	utils.PrintErrorNotNil(err)
	if err != nil {
		return nil, err
	}
	if response.StatusCode/100 != 2 {
		return nil, errors.New(utils.ReadIoReaderToString(response.Body))
	}
	responseBody := map[string]interface{}{}
	body, err := ioutil.ReadAll(response.Body)
	utils.PrintErrorNotNil(err)
	err = json.Unmarshal(body, &responseBody)
	utils.PrintErrorNotNil(err)
	if err != nil {
		return nil, err
	}
	log.Println("Response", utils.StructToString(responseBody))
	return responseBody, nil
}

func getTransferTransactionBodyForFineract(fundTransfertransactionGrpcRequest *models.FundTransferTransactionGrpcRequest) models.FundTransferTransactionFineractRequest {

	transferTransactionFineractReqBody := models.FundTransferTransactionFineractRequest{
		FromOfficeID:        1,
		FromClientID:        fundTransfertransactionGrpcRequest.FromCustomerID,
		FromAccountType:     2,
		FromAccountID:       fundTransfertransactionGrpcRequest.FromAccountID,
		ToOfficeID:          1,
		ToClientID:          fundTransfertransactionGrpcRequest.ToCustomerID,
		ToAccountType:       2,
		ToAccountID:         fundTransfertransactionGrpcRequest.ToAccountID,
		DateFormat:          "YYYY-MM-dd",
		Locale:              "en",
		TransferDate:        fundTransfertransactionGrpcRequest.TransferDate,
		TransferAmount:      fundTransfertransactionGrpcRequest.Amount,
		TransferDescription: fundTransfertransactionGrpcRequest.Description,
	}
	return transferTransactionFineractReqBody
}

func getCustomerAccountRequestBodyForFineract(customerAccountGrpcRequest models.CustomerAccountGrpcRequest) models.CustomerAccountFineractRequest {
	mobileNo, _ := strconv.Atoi(customerAccountGrpcRequest.CardNumber)
	customerID := strconv.FormatUint(customerAccountGrpcRequest.CustomerID, 10)
	savingProductID := strconv.FormatUint(uint64(customerAccountGrpcRequest.SavingProductID), 10)

	customerAccountFineractReqBody := models.CustomerAccountFineractRequest{
		OfficeID:        1,
		FullName:        customerAccountGrpcRequest.FullName,
		MobileNO:        mobileNo,
		ExternalID:      customerID,
		ActivationDate:  date_utils.GetStringFormat(),
		SubmittedOnDate: date_utils.GetStringFormat(),
		SavingProductID: savingProductID,
		DateFormat:      "YYYY-MM-dd",
		Locale:          "en",
		Active:          true,
	}
	return customerAccountFineractReqBody
}

func (s *service) GeAllGlAccountIDAndGlCode() ([]models.GLAccountLookUpTable, error) {
	var glLookUpTable []models.GLAccountLookUpTable

	httpClient := &http.Client{}
	URL := s.config.GetString("server.fineract_address") + "/glaccounts?fields=id,glCode"
	req, err := http.NewRequest("GET", URL, nil)
	if err != nil {
		return nil, err
	}
	s.addHeaders(&req.Header)

	response, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	body, _ := ioutil.ReadAll(response.Body)
	err = json.Unmarshal(body, &glLookUpTable)
	if err != nil {
		return nil, err
	}
	return glLookUpTable, nil
}

func (s *service) getJournalEntryForFineract(mpField map[string]float64, journalSetup models.JournalSetUp, transferDate string) (models.JournalEntryFineractRequestBody, error) {
	glCodeLookUpTable, err := s.GeAllGlAccountIDAndGlCode()
	if err != nil {
		return models.JournalEntryFineractRequestBody{}, err
	}

	var credits, debits []models.TransactionForFineractJournal
	debitTotal, creditTotal := 0.0, 0.0

	for i := 0; i < len(journalSetup.Entries); i++ {
		var trx models.TransactionForFineractJournal
		trx.Amount = mpField[journalSetup.Entries[i].MappingField]
		trx.AccountID = getGlID(glCodeLookUpTable, journalSetup.Entries[i].Account)
		if trx.AccountID == 0 {
			return models.JournalEntryFineractRequestBody{}, errors.New("account ID mapping not found in fineract")
		}
		if journalSetup.Entries[i].Type == "C" {
			credits = append(credits, trx)
			creditTotal += trx.Amount
		}
		if journalSetup.Entries[i].Type == "D" {
			debits = append(debits, trx)
			debitTotal += trx.Amount
		}
	}
	if creditTotal != debitTotal {
		return models.JournalEntryFineractRequestBody{}, errors.New("total debit amount should be equal to the credit amount")
	}

	if creditTotal == 0 {
		return models.JournalEntryFineractRequestBody{}, errors.New("there should be at least one debit and one credit entry")
	}

	jrnlEntryFnrctReqBody := models.JournalEntryFineractRequestBody{
		OfficeID:        1,
		TransactionDate: transferDate,
		Comments:        journalSetup.Remark,
		Locale:          "en",
		DateFormat:      "YYYY-MM-dd",
		CurrencyCode:    "IDR",
		Credits:         credits,
		Debits:          debits,
	}
	return jrnlEntryFnrctReqBody, nil
}

func getGlID(lookuptable []models.GLAccountLookUpTable, glCode string) int {
	for i := 0; i < len(lookuptable); i++ {
		if lookuptable[i].GLCode == glCode {
			return lookuptable[i].ID
		}
	}
	return 0
}
