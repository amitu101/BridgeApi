package service

import (
	"testing"
)

// type MockRepository struct {
// 	mock.Mock
// }
// type DbMockrepository struct {
// 	mock.Mock
// }

// func (mock *MockRepository) CreateCustomerAccountInFineract(customerAccount models.CustomerAccount) (map[string]interface{}, *errors.RestErr) {
// 	args := mock.Called()
// 	result := args.Get(0)
// 	m := make(map[string]interface{})
// 	jBytes, _ := json.Marshal(result)
// 	json.Unmarshal(jBytes, &m)
// 	return map[string]interface{}{"clientId": 1.00, "savingsId": 1.00, "officeId": customerAccount.OfficeID}, nil
// }

// func (mock *DbMockrepository) InsertClientIDAndAccntID(customerAccount models.CustomerAccountLocalDB) *errors.RestErr {
// 	return nil
// }

// func TestCreateAccountCustomerToBookKeeper(t *testing.T) {
// 	mockRepo := new(MockRepository)
// 	dbMockRepo := new(DbMockrepository)

// 	testService := NewService(mockRepo, dbMockRepo)
// 	reqData := models.CustomerAccount{
// 		OfficeID:        1,
// 		FullName:        "shubham kumar",
// 		MobileNO:        7483641224,
// 		AccountNO:       "DMII01",
// 		ExternalID:      "EX01",
// 		ActivationDate:  "25 feb 2020",
// 		SubmittedOnDate: "25 feb 2020",
// 		SavingProductID: "1",
// 		DateFormat:      "dd MMMM yy",
// 		Locale:          "en",
// 		Active:          true,
// 	}
// 	expectedResp := make(map[string]interface{})

// 	mockRepo.On("CreateCustomerAccountInFineract").Return(expectedResp, nil)
// 	//mockRepo.On("CreateAccountCustomerToBookKeeper").Return(nil)
// 	var ctx context.Context
// 	resp, _ := testService.CreateAccountCustomerToBookKeeper(ctx, reqData)
// 	jBytes, _ := json.Marshal(reqData)
// 	json.Unmarshal(jBytes, &expectedResp)
// 	mockRepo.AssertExpectations(t)

// 	assert.Equal(t, reqData.OfficeID, resp["officeId"].(int))
// 	assert.NotEqual(t, 0.00, resp["clientId"].(float64))
// 	assert.NotEqual(t, 0.00, resp["savingsId"].(float64))

// }

func TestCreateJournal(t *testing.T) {

}
