package utils

import (
	"encoding/json"
	"io"
	"io/ioutil"
	"log"
)

func PrintErrorNotNil(err error) {
	if err != nil {
		log.Println(err)
	}
}

func StructToString(data interface{}) string {
	msg, err := json.Marshal(data)
	PrintErrorNotNil(err)
	return string(msg)
}

func ReadIoReaderToString(data io.Reader) string {
	body, err := ioutil.ReadAll(data)
	PrintErrorNotNil(err)
	return string(body)
}
