package client

import (
	"context"

	"git.capitalx.id/dimii/bookkeeper/delivery"
	"git.capitalx.id/dimii/bookkeeper/models"
	"google.golang.org/grpc"
)

type BookkeeperClientService interface {
	CreateAccountCustomerToBookKeeper(context.Context, models.CustomerAccountGrpcRequest) (map[string]interface{}, error)
	FundTransferRequestToBookkeeper(context.Context, models.FundTransferTransactionGrpcRequest) (string, error)
	//getJournalEntryForFineract(map[string]float64, models.JournalSetUp, models.FundTransferTransactionGrpcRequest) models.JournalEntryFineractRequestBody
}
type customerAccountClient struct {
	conn   *grpc.ClientConn
	client delivery.BookkeeperHandlerClient
}

func (u customerAccountClient) CreateAccountCustomerToBookKeeper(ctx context.Context, customerAccount models.CustomerAccountGrpcRequest) (map[string]interface{}, error) {
	resp, err := u.client.CreateAccountCustomerToBookKeeper(ctx, &delivery.CreateAccountCustomerRequest{
		AccountID:       customerAccount.AccountID,
		CardNumber:      customerAccount.CardNumber,
		SavingProductID: customerAccount.SavingProductID,
		CustomerID:      customerAccount.CustomerID,
		FullName:        customerAccount.FullName,
		CustomerType:    customerAccount.CustomerType,
	})

	if err != nil {
		return nil, err
	}

	return map[string]interface{}{"message": resp.Message}, nil
}

func (u customerAccountClient) FundTransferRequestToBookkeeper(ctx context.Context, fundTransfer models.FundTransferTransactionGrpcRequest) (string, error) {
	resp, err := u.client.FundTransferRequestToBookkeeper(ctx, &delivery.FundTransferTransactionRequest{
		FromCustomerID:          fundTransfer.FromCustomerID,
		FromAccountProductGroup: fundTransfer.FromAccountProductGroup,
		FromAccountID:           fundTransfer.FromAccountID,
		ToCustomerID:            fundTransfer.ToCustomerID,
		ToAccountProductGroup:   fundTransfer.ToAccountProductGroup,
		ToAccountID:             fundTransfer.ToAccountID,
		TransferDate:            fundTransfer.TransferDate,
		Amount:                  fundTransfer.Amount,
		Description:             fundTransfer.Description,
		JournalType:             fundTransfer.JournalType,
	})

	if err != nil {
		return resp.Message, err
	}

	return resp.Message, nil
}

//NewCustomerAccountClient ...
func NewCustomerAccountClient(address string) (BookkeeperClientService, error) {
	conn, err := grpc.Dial(address, grpc.WithInsecure())
	if err != nil {
		return nil, err
	}
	client := delivery.NewBookkeeperHandlerClient(conn)
	return &customerAccountClient{conn: conn, client: client}, nil
}
