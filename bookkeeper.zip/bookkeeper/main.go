package main

import (
	"crypto/tls"
	"database/sql"
	"log"
	"net"
	"net/http"
	"os"

	coreConfig "git.capitalx.id/core/config"
	vaultCfg "git.capitalx.id/core/config/vault"
	viperCfg "git.capitalx.id/core/config/viper"
	"git.capitalx.id/dimii/bookkeeper/delivery"
	"git.capitalx.id/dimii/bookkeeper/repository/afin"
	"git.capitalx.id/dimii/bookkeeper/repository/db"
	"git.capitalx.id/dimii/bookkeeper/service"

	_ "git.capitalx.id/dimii/bookkeeper/client"

	"git.capitalx.id/core/common/mysql"

	"google.golang.org/grpc"
	"google.golang.org/grpc/reflection"
)

var config coreConfig.Config

func init() {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	http.DefaultTransport.(*http.Transport).TLSClientConfig = &tls.Config{InsecureSkipVerify: true} // #nosec
}

func getConfig() (coreConfig.Config, error) {
	address := os.Getenv("VAULT_ADDR")
	token := os.Getenv("VAULT_TOKEN")

	if address != "" && token != "" {
		config, err := vaultCfg.GetConfig("bookkeeper")

		if err == nil {
			return config, nil
		} else {
			return nil, err
		}
	}
	return viperCfg.NewConfig("bookkeeper", "config.json")
}

func getDatabase() (*sql.DB, error) {
	dbCa := config.GetBinary(`database.ca`)
	dbHost := config.GetString(`database.host`)
	dbPort := config.GetString(`database.port`)
	dbUser := config.GetString(`database.user`)
	dbPass := config.GetString(`database.pass`)
	dbName := config.GetString(`database.name`)
	maxOpen := config.GetInt(`database.max.open`)
	maxIdle := config.GetInt(`database.max.idle`)
	maxLifetime := config.GetInt(`database.max.lifetime`)

	dbConfig := mysql.Config{
		Host:        dbHost,
		Port:        dbPort,
		User:        dbUser,
		Password:    dbPass,
		Name:        dbName,
		MaxOpen:     int(maxOpen),
		MaxIdle:     int(maxIdle),
		MaxLifetime: int(maxLifetime),
		CA:          dbCa,
		Location:    "Asia/Jakarta",
		ParseTime:   true,
	}

	return mysql.DB(dbConfig)
}

func main() {
	//app.StartApplication()
	var err error
	config, err = getConfig()
	if err != nil {
		log.Println(err)
		return
	}

	dbConn, err := getDatabase()
	if err != nil {
		log.Fatal("cannot connect to data store", err)
		return
	}
	dbstore := db.NewBookkeeperRepository(dbConn)

	afinRepository := afin.NewRepository(config)
	atService := service.NewService(afinRepository, dbstore, config)
	grpcHandler := delivery.NewGRPCServer(atService)
	listener, err := net.Listen("tcp", config.GetString(`server.address`))
	if err != nil {
		panic(err)
	}
	srv := grpc.NewServer()
	delivery.RegisterBookkeeperHandlerServer(srv, grpcHandler)
	reflection.Register(srv)
	if e := srv.Serve(listener); e != nil {
		panic(e)
	}

}
