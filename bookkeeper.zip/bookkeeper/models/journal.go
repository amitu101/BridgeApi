package models

//JournalEntry ...
type JournalEntry struct {
	//"D" or "C"
	Type     string  `json:"type,omitempty"`
	Sequence int     `json:"sequence,omitempty"`
	Account  string  `json:"account,omitempty"`
	Amount   float64 `json:"amount,omitempty"`
}

//JournalEntrySetup ...
type JournalEntrySetup struct {
	ID int `json:"id,omitempty"`
	//"D" or "C"
	Type         string `json:"type,omitempty"`
	Sequence     int    `json:"sequence,omitempty"`
	Account      string `json:"account,omitempty"`
	MappingField string `json:"mapping_field,omitempty"`
}

//JournalSetUp ...
type JournalSetUp struct {
	ID                 uint32              `json:"id,omitempty"`
	TransactionType    uint32              `json:"transaction_type,omitempty"`
	AccTransactionType string              `json:"acc_transaction_type,omitempty"`
	Remark             string              `json:"remark,omitempty"`
	Entries            []JournalEntrySetup `json:"entries,omitempty"`
}
