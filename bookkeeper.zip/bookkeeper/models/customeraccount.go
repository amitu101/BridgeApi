package models

import (
	"time"
)

//CustomerAccountLocalDB ...
type CustomerAccountLocalDB struct {
	ModuleID         int       `json:"module_id,omitempty"`
	AppID            uint64    `json:"app_id,omitempty"`
	ExternalID       string    `json:"external_id,omitempty"`
	Satus            int8      `json:"satus,omitempty"`
	CreatedBy        uint64    `json:"created_by,omitempty"`
	CreatedTimestamp time.Time `json:"created_timestamp,omitempty"`
	UpdatedBy        uint64    `json:"updated_by,omitempty"`
	UpdatedTimestamp time.Time `json:"updated_timestamp,omitempty"`
}

//CustomerAccountGrpcRequest ...
type CustomerAccountGrpcRequest struct {
	FullName        string `json:"fullname,omitempty"`
	CardNumber      string `json:"card_number,omitempty"`
	CustomerID      uint64 `json:"accountNo,omitempty"`
	AccountID       uint64 `json:"accountId,omitempty"`
	SavingProductID uint32 `json:"savingsProductId,omitempty"`
	CustomerType    uint32 `json:"customer_type,omitempty"`
}

//CustomerAccountFineractRequest ...
type CustomerAccountFineractRequest struct {
	OfficeID        int    `json:"officeId,omitempty"`
	FullName        string `json:"fullname,omitempty"`
	MobileNO        int    `json:"mobileNo,omitempty"`
	AccountNO       string `json:"accountNo,omitempty"`
	ExternalID      string `json:"externalId,omitempty"`
	ActivationDate  string `json:"activationDate,omitempty"`
	SubmittedOnDate string `json:"submittedOnDate,omitempty"`
	SavingProductID string `json:"savingsProductId,omitempty"`
	DateFormat      string `json:"dateFormat,omitempty"`
	Locale          string `json:"locale,omitempty"`
	Active          bool   `json:"active,omitempty"`
}

//FundTransferTransactionGrpcRequest ...
type FundTransferTransactionGrpcRequest struct {
	FromCustomerID          uint64  `json:"fromCustomerId,omitempty"`
	FromAccountProductGroup uint32  `json:"fromAccountProductGroup,omitempty"`
	FromAccountID           uint64  `json:"fromAccountId,omitempty"`
	ToCustomerID            uint64  `json:"toCustomerId,omitempty"`
	ToAccountProductGroup   uint32  `json:"toAccountProductGroup,omitempty"`
	ToAccountID             uint64  `json:"toAccountId,omitempty"`
	TransferDate            string  `json:"transferDate,omitempty"`
	Amount                  float64 `json:"amount,omitempty"`
	Description             string  `json:"description,omitempty"`
	JournalType             uint32  `json:"journalType,omitempty"`
}

//FundTransferTransactionFineractRequest ...
type FundTransferTransactionFineractRequest struct {
	FromOfficeID        int8    `json:"fromOfficeId,omitempty"`
	FromClientID        uint64  `json:"fromClientId,omitempty"`
	FromAccountType     int8    `json:"fromAccountType,omitempty"`
	FromAccountID       uint64  `json:"fromAccountId,omitempty"`
	ToOfficeID          int8    `json:"toOfficeId,omitempty"`
	ToClientID          uint64  `json:"toClientId,omitempty"`
	ToAccountType       int8    `json:"toAccountType,omitempty"`
	ToAccountID         uint64  `json:"toAccountId,omitempty"`
	DateFormat          string  `json:"dateFormat,omitempty"`
	Locale              string  `json:"locale,omitempty"`
	TransferDate        string  `json:"transferDate,omitempty"`
	TransferAmount      float64 `json:"transferAmount,omitempty"`
	TransferDescription string  `json:"transferDescription,omitempty"`
}

//TransactionForFineractJournal ...
type TransactionForFineractJournal struct {
	AccountID int     `json:"glAccountId,omitempty"`
	Amount    float64 `json:"amount,omitempty"`
}

//JournalEntryFineractRequestBody ...
type JournalEntryFineractRequestBody struct {
	OfficeID        int64                           `json:"officeId,omitempty"`
	TransactionDate string                          `json:"transactionDate,omitempty"`
	Comments        string                          `json:"comments,omitempty"`
	Locale          string                          `json:"locale,omitempty"`
	DateFormat      string                          `json:"dateFormat,omitempty"`
	CurrencyCode    string                          `json:"currencyCode,omitempty"`
	Credits         []TransactionForFineractJournal `json:"credits,omitempty"`
	Debits          []TransactionForFineractJournal `json:"debits,omitempty"`
}

//GLAccountLookUpTable ...
type GLAccountLookUpTable struct {
	GLCode string `json:"glCode,omitempty"`
	ID     int    `json:"id,omitempty"`
}
